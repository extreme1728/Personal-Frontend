<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class MineshUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Minesh',
            'email' => 'minesh@jdlife.co.nz',
            'password' => 'minesh'
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'signature_filename' => 'minesh-signature.png',
        ]);
    }
}
