<?php

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Ipp\Services\Seeders\Hazardous\BaseActivity;

class HazardousActivityCategoryTableSeeder extends DatabaseSeeder
{
    /**
     * Property indicating seeder path to be executed.
     *
     * @var string
     */
    protected static $path = 'Ipp/Services/Seeders/Hazardous';

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $seeders = File::allFiles(app_path(static::$path));

        foreach ($seeders as $class) {
            $class = str_replace(
                ['/', '.php'],
                ['\\', ''],
                Str::after($class->getPathname(), app_path().DIRECTORY_SEPARATOR)
            );
            if (is_subclass_of($class, BaseActivity::class) &&
                ! (new ReflectionClass($class))->isAbstract()) {
                $this->getCommand()->info("Seeding: $class");
                (new $class)->handle();
            }
        }
    }
}
