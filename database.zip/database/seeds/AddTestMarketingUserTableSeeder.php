<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class AddTestMarketingUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Marketing Specialist (Test)',
            'email' => 'marketing@jdlife.co.nz',
            'password' => 'marketing',
        ]);

        $user->addRoles(Role::whereName('marketing_specialist')->first());

        $user->profile()->create([
            'fsp_number' => '00000',
            'telephone_number' => '000 000 0000',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
        ]);
    }
}
