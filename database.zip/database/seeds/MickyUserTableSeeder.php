<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class MickyUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Charanpreet (Mickey) Singh',
            'email' => 'mickey@jdlife.co.nz',
            'password' => 'mic51ngh'
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '657231',
            'physical_address' => '1/367a Avonnhead Christchurch 8042 New Zealand',
            'telephone_number' => '022 342 3989',
            'signature_filename' => 'micky-signature.png',
        ]);
    }
}
