<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class BannyUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $banny = User::create([
            'name' => 'Barjinder Jit (Banny) Singh',
            'email' => 'banny@jdlife.co.nz',
            'password' => 'banny',
        ]);

        $banny->addRoles(Role::whereName('advisor')->first());

        $banny->profile()->create([
            'fsp_number' => '625689',
            'physical_address' => '220 Mt Pleasant Road, Mt Pleasant Christchurch, 8081',
            'telephone_number' => '022 689 7743',
            'signature_filename' => 'barjinder-jit-signature.png',
        ]);
    }
}
