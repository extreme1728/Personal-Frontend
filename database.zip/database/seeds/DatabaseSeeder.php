<?php

use Faker\Generator as Faker;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Faker generator instance.
     *
     * @var \Faker\Generator
     */
    protected $faker;

    /**
     * Create new DatabaseSeeder instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->faker = resolve(Faker::class);
    }

    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(MedicalCategoryTableSeeder::class);
        $this->call(HazardousActivityCategoryTableSeeder::class);
        $this->call(InsuranceProvidersTableSeeder::class);
        $this->call(InsuranceProviderCoverTypeCommentTableSeeder::class);
        $this->call(RolesTableSeeder::class);
        $this->call(UsersTableSeeder::class);
        $this->call(UserProfileTableSeeder::class);
        $this->call(BannyUserTableSeeder::class);
        $this->call(BhagiUserTableSeeder::class);
        $this->call(SimonUserTableSeeder::class);
        $this->call(MickyUserTableSeeder::class);
        $this->call(SaviUserTableSeeder::class);
        $this->call(AlexUserTableSeeder::class);
        $this->call(ManniUserTableSeeder::class);
        $this->call(MineshUserTableSeeder::class);
        $this->call(NimeshUserTableSeeder::class);
        $this->call(ShwetaUserTableSeeder::class);
        $this->call(AddAccNumberToUserProfileTableSeeder::class);
        $this->call(AddDefaultFirstAndLastNamesToUserProfileTableSeeder::class);

        $this->call(AddMarketingSpecialistRoleSeeder::class);
        $this->call(AddTestMarketingUserTableSeeder::class);
    }

    /**
     * Get the output implementation.
     *
     * @return \Illuminate\Console\Command
     */
    protected function getCommand()
    {
        return $this->command;
    }
}
