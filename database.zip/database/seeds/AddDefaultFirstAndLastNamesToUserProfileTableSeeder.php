<?php

use Illuminate\Database\Seeder;

use Ipp\Models\User;

class AddDefaultFirstAndLastNamesToUserProfileTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $jaz = User::whereEmail('service@jdlife.co.nz')->firstOrFail();
        $jaz->profile()->update([
            'first_name' => 'Jaspal',
            'last_name' => 'Dosanjh',
        ]);

        $banny = User::whereEmail('banny@jdlife.co.nz')->firstOrFail();
        $banny->profile()->update([
            'first_name' => 'Barjinder Jit',
            'last_name' => 'Singh',
        ]);
    }
}
