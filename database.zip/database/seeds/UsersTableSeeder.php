<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, Role };

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $administrator = User::create([
            'name' => 'Jaspal (Jaz) Singh Dosanjh',
            'email' => 'service@jdlife.co.nz',
            'password' => 'secret',
        ]);

        $administrator->addRoles(Role::whereName('administrator')->first());

        $advisor = User::create([
            'name' => 'Advisor JDLife',
            'email' => 'advisor@jdlife.co.nz',
            'password' => 'secret',
        ]);

        $advisor->addRoles(Role::whereName('advisor')->first());
    }
}
