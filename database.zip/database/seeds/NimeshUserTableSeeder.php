<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class NimeshUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Nimesh',
            'email' => 'nimesh@jdlife.co.nz',
            'password' => 'nimesh'
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([]);
    }
}
