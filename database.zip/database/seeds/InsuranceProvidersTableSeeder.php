<?php

use Illuminate\Support\Str;
use Ipp\Models\InsuranceProvider;
use Illuminate\Support\Facades\File;
use Ipp\Services\Seeders\BaseProvider;

class InsuranceProvidersTableSeeder extends DatabaseSeeder
{
    /**
     * Constant defining provider seeder directory.
     *
     * @var string
     */
    const PROVIDER_SEEDER_PATH = 'Ipp/Services/Seeders';

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $providers = File::allFiles(app_path(self::PROVIDER_SEEDER_PATH));
        foreach ($providers as $provider) {
            $provider = str_replace(
                ['/', '.php'],
                ['\\', ''],
                Str::after($provider->getPathname(), app_path().DIRECTORY_SEPARATOR)
            );
            if (is_subclass_of($provider, BaseProvider::class) &&
                ! (new ReflectionClass($provider))->isAbstract()) {
                $this->getCommand()->info("Seeding: $provider");
                (new $provider)->handle();
            }
        }
    }
}
