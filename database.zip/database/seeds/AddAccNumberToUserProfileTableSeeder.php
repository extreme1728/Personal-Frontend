<?php

use Illuminate\Database\Seeder;
use Ipp\Models\User;

class AddAccNumberToUserProfileTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $jaz = User::whereEmail('service@jdlife.co.nz')->first();
        $jaz->profile()->update([
            'acc_number' => 'XN864554',
        ]);

        $banny = User::whereEmail('banny@jdlife.co.nz')->first();
        $banny->profile()->update([
            'acc_number' => 'XN864554',
        ]);
    }
}
