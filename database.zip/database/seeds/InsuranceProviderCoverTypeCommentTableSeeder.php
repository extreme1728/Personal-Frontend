<?php

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Ipp\Services\Seeders\Comments\BaseComment;

class InsuranceProviderCoverTypeCommentTableSeeder extends DatabaseSeeder
{
    /**
     * Constant defining provider seeder directory.
     *
     * @var string
     */
    const COMMENT_SEEDER_PATH = 'Ipp/Services/Seeders/Comments';

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $comments = File::allFiles(app_path(self::COMMENT_SEEDER_PATH));

        foreach ($comments as $comment) {
            $comment = str_replace(
                ['/', '.php'],
                ['\\', ''],
                Str::after($comment->getPathname(), app_path().DIRECTORY_SEPARATOR)
            );
            if (is_subclass_of($comment, BaseComment::class) &&
                ! (new ReflectionClass($comment))->isAbstract()) {
                $this->getCommand()->info("Seeding: $comment");
                (new $comment)->handle();
            }
        }
    }
}
