<?php

use Ipp\Models\{ User, Role };
use Illuminate\Database\Seeder;

class ManniUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Manbir (Manni) Singh',
            'email' => 'manni@jdlife.co.nz',
            'password' => 'manni',
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '678911',
            'telephone_number' => '021 029 67080',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
            'signature_filename' => 'manni-signature.png',
        ]);
    }
}
