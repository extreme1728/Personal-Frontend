<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile };

class UserProfileTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $administrator = User::whereEmail('service@jdlife.co.nz')->first();

        $administrator->profile()->create([
            'fsp_number' => '417986',
            'physical_address' => '1/367a Avonnhead Christchurch 8042 New Zealand',
            'telephone_number' => '027 385 8666',
            'signature_filename' => 'jaspal-dosanjh-signature.png',
        ]);

        $advisor = User::whereEmail('advisor@jdlife.co.nz')->first();
        $advisor->profile()->create();
    }
}
