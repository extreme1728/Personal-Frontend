<?php

use Ipp\Models\{ User, Role };
use Illuminate\Database\Seeder;

class BhagiUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Bhagirath (Bhagi) Gadhavi',
            'email' => 'bhagi@jdlife.co.nz',
            'password' => 'bhagi',
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '648729',
            'telephone_number' => '022 580 0660',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
        ]);
    }
}
