<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, Role };

class SimonUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Simon Chhabra',
            'email' => 'simon@jdlife.co.nz',
            'password' => 'latesimon',
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '654571',
            'telephone_number' => '021 133 6673',
            'signature_filename' => 'simon-signature.png',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
        ]);
    }
}
