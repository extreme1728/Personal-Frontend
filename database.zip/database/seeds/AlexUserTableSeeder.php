<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class AlexUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Alakesh (Alex) Bhagawati',
            'email' => 'alex@jdlife.co.nz',
            'password' => 'alex'
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
            'telephone_number' => '022 395 2534',
            'signature_filename' => 'alakesh-bhagawati.png',
        ]);
    }
}
