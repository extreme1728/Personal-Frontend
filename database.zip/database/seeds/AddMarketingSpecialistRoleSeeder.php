<?php

use Illuminate\Database\Seeder;
use Ipp\Models\Role;

class AddMarketingSpecialistRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::create([
            'name' => 'marketing_specialist'
        ]);
    }
}
