<?php

use Illuminate\Database\Seeder;
use Ipp\Models\{ User, UserProfile, Role };

class SaviUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Sukhwinder (Savi) Singh',
            'email' => 'savi@jdlife.co.nz',
            'password' => 'savi1234',
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '659551',
            'telephone_number' => '027 269 9019',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
            'signature_filename' => 'sukhwinder-signature.png',
        ]);
    }
}
