<?php

use Ipp\Models\{ User, Role };
use Illuminate\Database\Seeder;

class ShwetaUserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Shweta Deol',
            'email' => 'shweta@jdlife.co.nz',
            'password' => 'jdlife01',
        ]);

        $user->addRoles(Role::whereName('advisor')->first());

        $user->profile()->create([
            'fsp_number' => '679351',
            'telephone_number' => '021 027 35160',
            'physical_address' => '1/367a Withells Road Avonhead, Christchurch',
            'signature_filename' => 'shweta-signature.png',
        ]);
    }
}
