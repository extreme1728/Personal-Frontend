<?php

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Ipp\Services\Seeders\Conditions\BaseCondition;

class MedicalCategoryTableSeeder extends DatabaseSeeder
{
    /**
     * Property indicating seeder path to be executed.
     *
     * @var string
     */
    protected static $path = 'Ipp/Services/Seeders/Conditions';

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // @TODO: Extract this to a method
        // @see InsuranceProviderCoverTypeCommentTableSeeder

        $seeders = File::allFiles(app_path(static::$path));

        foreach ($seeders as $class) {
            $class = str_replace(
                ['/', '.php'],
                ['\\', ''],
                Str::after($class->getPathname(), app_path().DIRECTORY_SEPARATOR)
            );
            if (is_subclass_of($class, BaseCondition::class) &&
                ! (new ReflectionClass($class))->isAbstract()) {
                $this->getCommand()->info("Seeding: $class");
                (new $class)->handle();
            }
        }
    }
}
