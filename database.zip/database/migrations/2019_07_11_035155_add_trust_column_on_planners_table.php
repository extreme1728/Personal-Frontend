<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTrustColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_have_trust', ['yes', 'no'])
                ->after('client_passive_amount')
                ->nullable(true)
                ->default(null);
            $table
                ->enum('partner_have_trust', ['yes', 'no'])
                ->after('partner_passive_amount')
                ->nullable(true)
                ->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn(['client_have_trust', 'partner_have_trust']);
        });
    }
}
