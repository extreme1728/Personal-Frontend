<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsForUpdateOfResidencyQuestionsPartner extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('partner_three_months_left_visa', ['yes','no'])
                ->after('partner_work_visa_greater_two_years')
                ->nullable(true);
            $table
                ->enum('partner_applying_permanent_residency', ['yes','no'])
                ->after('partner_three_months_left_visa')
                ->nullable(true);
            $table
                ->enum('partner_NZ_sole_country_residence', ['yes','no'])
                ->after('partner_applying_permanent_residency')
                ->nullable(true);
            $table
                ->enum('partner_plan_leaving_NZ_in_five_years', ['yes','no'])
                ->after('partner_NZ_sole_country_residence')
                ->nullable(true);
            $table
                ->text('partner_state_vested_interest_in_NZ')
                ->after('partner_plan_leaving_NZ_in_five_years')
                ->nullable(true);
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn('partner_three_months_left_visa');
            $table->dropColumn('partner_applying_permanent_residency');
            $table->dropColumn('partner_NZ_sole_country_residence');
            $table->dropColumn('partner_plan_leaving_NZ_in_five_years');
            $table->dropColumn('partner_state_vested_interest_in_NZ');
        });
    }
}
