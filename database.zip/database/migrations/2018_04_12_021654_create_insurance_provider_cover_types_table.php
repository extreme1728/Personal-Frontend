<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInsuranceProviderCoverTypesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('insurance_provider_cover_types', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('insurance_provider_id');
            $table->string('name');
            $table->boolean('health_cover')->default(false);
            $table->foreign('insurance_provider_id')
                ->references('id')
                ->on('insurance_providers')
                ->onDelete('CASCADE');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('insurance_provider_cover_types');
    }
}
