<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeClientAndPartnerHazardousActiviyColumnTypeOnPlannersTable extends Migration
{
    protected static $COLUMNS = [
        'client_hazardous_activity' => 'client_have_any_hazardous_activity',
        'partner_hazardous_activity' => 'partner_have_any_hazardous_activity',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->dropColumn($column);
            }
        });
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->json($column)->after($after)->nullable(true);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->dropColumn($column);
            }
        });
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->string($column)->after($after)->nullable(true);
            }
        });
    }
}
