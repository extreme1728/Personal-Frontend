<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTaxColumnOnPlannerCalculatorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planner_calculators', function (Blueprint $table) {
            $table
                ->text('tax')
                ->after('mortgage_repayment_income_protection_and_hec')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planner_calculators', function (Blueprint $table) {
            $table->dropColumn('tax');
        });
    }
}
