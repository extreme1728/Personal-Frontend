<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerBodyMassIndexColumnsOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_has_increased_height_and_weight', ['yes', 'no'])
                ->after('client_hazardous_activity')
                ->default('no');
            $table
                ->json('client_body_mass_index')
                ->after('client_has_increased_height_and_weight')
                ->nullable(true);
            $table
                ->enum('partner_has_increased_height_and_weight', ['yes', 'no'])
                ->after('partner_hazardous_activity')
                ->default('no');
            $table
                ->json('partner_body_mass_index')
                ->after('partner_has_increased_height_and_weight')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $COLUMNS = [
            'client_does_increased_height_and_weight',
            'client_body_mass_index',
            'partner_has_increased_height_and_weight',
            'partner_body_mass_index',
        ];

        if (Schema::hasColumns('planners', $COLUMNS)) {
            Schema::table('planners', function (Blueprint $table) {
                $table->dropColumn($COLUMNS);
            });
        }
    }
}
