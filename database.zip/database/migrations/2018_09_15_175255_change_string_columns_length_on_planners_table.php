<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Support\Facades\Schema;
use Ipp\Models\Planner;

class ChangeStringColumnsLengthOnPlannersTable extends Migration
{
    /**
     * Property defining table name
     *
     * @var string
     */
    protected static $TABLENAME;

    /**
     * Array defining varchar columns that has
     * A 'yes/no' values and will be changed to enum
     *
     * @var array key value pairs of column name and default value
     */
    protected static $BOOLEAN_COLUMNS  = [
        'employed_how_long' => 'yes',
        'on_tools' => 'no',
        'has_corporate_partner' => 'no',
        'client_smoking_status' => 'no',
        'partner_smoking_status' => 'no',
        'have_childrens' => 'no',
        'is_partner_shareholder_or_directory' => 'yes',
        'is_partner_account_tax_splitting' => 'yes',
        'partner_on_tools' => 'no',
        'client_has_will_in_place' => 'no',
        'client_has_attorney' => 'no',
        'client_passive_income' => 'no',
        'client_have_been_to_doctor' => 'no',
        'client_have_any_hazardous_activity' => 'no',
        'client_smoked_in_last_twelve_months' => 'no',
        'client_citizen_or_pr' => 'no',
        'client_student_or_work' => 'no',
        'client_work_visa_greater_two_years' => 'no',
        'partner_has_will_in_place' => 'no',
        'partner_has_attorney' => 'no',
        'partner_passive_income' => 'no',
        'partner_have_been_to_doctor' => 'no',
        'partner_have_any_hazardous_activity' => 'no',
        'partner_smoked_in_last_twelve_months' => 'no',
        'partner_citizen_or_pr' => 'no',
        'partner_student_or_work' => 'no',
        'partner_work_visa_greater_two_years' => 'no',
        'when_business_started' => 'no',
        'partner_employed_how_long' => 'no',
        'partner_is_working' => 'no',
        'partner_is_working_for_business' => 'no'
    ];

    /**
     * Create migration instance.
     *
     * @return void
     */
    public function __construct()
    {
        static::$TABLENAME = static::getModelInstance()->getTable();
    }

    /**
     * Planner instance.
     *
     * @return \Ipp\Models\Planner
     */
    protected static function getModelInstance()
    {
        return new Planner;
    }

    /**
     * Fill automatically boolean column defined from the array.
     *
     * @return void
     */
    protected static function fillBooleanColumnNullValues()
    {
        $instance = static::getModelInstance();
        $sql = $instance
                    ->exclude($instance->getDeletedAtColumn())
                    ->getQuery()
                    ->toSql();
        $models = DB::select(DB::raw($sql)->getValue());

        foreach ($models as $model) {
            $model = (new Planner)->newFromBuilder($model);
            foreach (static::$BOOLEAN_COLUMNS as $column => $value) {
                // Check if column exists in the database
                if (Schema::hasColumn(static::$TABLENAME, $column)) {
                    // Get the attribute from the model
                    $attribute = trim($model->{$column});

                    if (is_null($attribute) || empty($attribute)) {
                        // We are forcing to fill the column with the value defined
                        $model->forceFill([$column => $value])->update();
                        continue;
                    }

                    // There are instances that the attribute has been
                    // Changed to the application layer but the data is incorrect
                    if ((!is_null($attribute) || !empty($attribute))
                        && !in_array($attribute, ['yes', 'no'], TRUE)) {
                        // We are forcing to fill the column with the value defined
                        $model->forceFill([$column => $value])->update();
                        continue;
                    }
                }
            }
        }
    }

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        static::fillBooleanColumnNullValues();

        Schema::table(static::$TABLENAME, function (Blueprint $table) {
            // Change varchar boolean values (yes/no) to enum
            foreach (static::$BOOLEAN_COLUMNS as $column => $default) {
                DB::statement("ALTER TABLE `" .static::$TABLENAME. "` MODIFY COLUMN `" .$column. "`  enum('yes','no') NOT NULL DEFAULT '" .$default. "';");
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        static::fillBooleanColumnNullValues();

        Schema::table(static::$TABLENAME, function (Blueprint $table) {
            $length = Builder::$defaultStringLength;
            // We are rolling back the data type again without loosing any values
            foreach (static::$BOOLEAN_COLUMNS as $column => $default) {
                DB::statement("ALTER TABLE `". static::$TABLENAME ."` MODIFY COLUMN `" .$column. "`  varchar({$length}) NOT NULL DEFAULT '{$default}';");
            }
        });
    }
}
