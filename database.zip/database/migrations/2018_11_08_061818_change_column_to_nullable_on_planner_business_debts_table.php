<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeColumnToNullableOnPlannerBusinessDebtsTable extends Migration
{
    /**
     * Property defining columns to be change
     *
     * @var array
     */
    protected static $COLUMNS = [
        'personal_guarantees_in_place',
        'any_long_term_contracts',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planner_business_debts', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table
                    ->string($column)
                    ->default(null)
                    ->nullable(true)
                    ->change();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planner_business_debts', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table
                    ->string($column)
                    ->default('no')
                    ->nullable(true)
                    ->change();
            }
        });
    }
}
