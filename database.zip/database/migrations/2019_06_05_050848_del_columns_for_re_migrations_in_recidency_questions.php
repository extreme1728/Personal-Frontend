<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DelColumnsForReMigrationsInRecidencyQuestions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn('client_twelve_months_left_visa');
            $table->dropColumn('client_applied_another_visa');
            $table->dropColumn('client_intend_another_visa');
            $table->dropColumn('client_when_applying_visa');
            $table->dropColumn('partner_applied_another_visa');
            $table->dropColumn('partner_intend_another_visa');
            $table->dropColumn('partner_when_applying_visa');
            $table->dropColumn('partner_twelve_months_left_visa');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_twelve_months_left_visa',['yes','no'])
                ->after('client_state_vested_interest_in_NZ')
                ->nullable(true);
            $table
                ->enum('client_applied_another_visa',['yes','no'])
                ->after('client_twelve_months_left_visa')
                ->nullable(true);
            $table
                ->enum('client_intend_another_visa',['yes','no'])
                ->after('client_applied_another_visa')
                ->nullable(true);
            $table
                ->enum('client_when_applying_visa',['yes','no'])
                ->after('client_intend_another_visa')
                ->nullable(true);
            $table
                ->enum('partner_applied_another_visa',['yes','no'])
                ->after('partner_state_vested_interest_in_NZ')
                ->nullable(true);
            $table
                ->enum('partner_intend_another_visa',['yes','no'])
                ->after('partner_state_vested_interest_in_NZ')
                ->nullable(true);
            $table
                ->enum('partner_when_applying_visa',['yes','no'])
                ->after('partner_intend_another_visa')
                ->nullable(true);
            $table
                ->enum('partner_twelve_months_left_visa',['yes','no'])
                ->after('partner_when_applying_visa')
                ->nullable(true);
        });
    }
}
