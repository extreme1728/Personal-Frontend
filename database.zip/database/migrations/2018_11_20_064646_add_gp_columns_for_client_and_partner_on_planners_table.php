<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddGpColumnsForClientAndPartnerOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->string('client_medical_usual_general_practitioner', 50)
                ->after('client_passive_amount')
                ->nullable(true);
            $table
                ->string('client_medical_name_general_practitioner_medical_center', 50)
                ->after('client_medical_usual_general_practitioner')
                ->nullable(true);
            $table
                ->string('client_medical_general_practitioner_address', 100)
                ->after('client_medical_name_general_practitioner_medical_center')
                ->nullable(true);

            $table
                ->string('partner_medical_usual_general_practitioner', 50)
                ->after('partner_passive_amount')
                ->nullable(true);
            $table
                ->string('partner_medical_name_general_practitioner_medical_center', 50)
                ->after('partner_medical_usual_general_practitioner')
                ->nullable(true);
            $table
                ->string('partner_medical_general_practitioner_address', 100)
                ->after('partner_medical_name_general_practitioner_medical_center')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_medical_usual_general_practitioner',
                'client_medical_name_general_practitioner_medical_center',
                'client_medical_general_practitioner_address',
                'partner_medical_usual_general_practitioner',
                'partner_medical_name_general_practitioner_medical_center',
                'partner_medical_general_practitioner_address',
            ]);
        });
    }
}
