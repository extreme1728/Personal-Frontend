<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInsuranceProviderCoverTypeNotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('insurance_provider_cover_type_notes', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('insurance_provider_cover_type_id');
            $table->foreign('insurance_provider_cover_type_id', 'insurance_provider_cover_type_notes_foreign_id')
                ->references('id')
                ->on('insurance_provider_cover_types')
                ->onDelete('CASCADE');
            $table->text('note');
            $table->text('image')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('insurance_provider_cover_type_notes');
    }
}
