<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerKeyPeopleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_key_people', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uid');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('name');
            $table->string('role_in_business')->nullable(true);
            $table->string('date_of_birth')->nullable(true);
            $table->string('smoking_status')->default('no');
            $table->string('income');
            $table->string('payment_frequency')->default('annually');
            $table->string('gross_income');
            $table->integer('income_percentage');
            $table->text('insurance_calculations')->nullable(true);
            $table->string('income_needing_to_be_protected')->nullable(true);
            $table->text('notes')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_key_people');
    }
}
