<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangePartnerAndClientColumnCorrectDataTypeOnPlannersTable extends Migration
{
    /**
     * Property defining array of columns to change.
     *
     * @var array
     */
    private static $COLUMNS = [
        'client_employed_work_exp_year',
        'client_employed_work_exp_month',
        'partner_company_full_name',
        'partner_employed_schedule_type',
        'partner_employed_annual_income',
        'partner_employed_how_long',
        'partner_employed_work_exp_month',
        'partner_employed_work_exp_year',
        'partner_employed_occupation',
    ];

    public function __construct()
    {
        DB::getDoctrineSchemaManager()
            ->getDatabasePlatform()
            ->registerDoctrineTypeMapping('enum', 'string');
    }
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table->string($column)->nullable(true)->change();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table->text($column)->nullable(true)->change();
            }
        });
    }
}
