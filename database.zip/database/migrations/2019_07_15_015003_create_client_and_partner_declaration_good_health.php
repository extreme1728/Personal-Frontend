<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientAndPartnerDeclarationGoodHealth extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_declaration_good_health', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')
                    ->references('id')
                    ->on('users')
                    ->onDelete('CASCADE');

            foreach ($this->stringFields() as $field) {
                $table->string($field)->nullable(true);
            }

            foreach ($this->dateFields() as $field) {
                $table->timestamp($field)->default(null)->nullable(true);
            }

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_declaration_good_health');
    }

    protected function stringFields()
    {
        return [
            'client_policy_number',
            'client_full_name_life_assured',
            'client_height_life',
            'client_weight_life',
            'client_health_problem',
            'client_give_details_health_problem',
            'client_any_advised',
            'client_give_details_any_advised',
            'client_occupation_changed',
            'client_give_details_occupation_changed',
            'client_hazardous_occupation',
            'client_give_details_hazardous_occupation',
            'client_family_medical_history',
            'client_give_details_family_medical_history',
            'client_application_declined',
            'client_give_details_application_declined',
            'client_circumstance_affect',
            'client_give_details_circumstance_affect',
            'client_smoked_twelve_months',
            'client_give_details_smoked_twelve_months',
            'client_application_annual_income',
            'client_claim_disablity_policy',
            'client_give_details_claim_disablity_policy',
            'client_first_name',
            'client_middle_name',
            'client_sur_name',
            'client_stop_smoking',
            'client_suffered_illness',
            'client_give_details_suffered_illness',
            'client_family_altered',
            'client_give_details_family_altered',
            'client_visited_doctor',
            'client_give_details_visited_doctor',
            'client_applied_insurance',
            'client_give_details_applied_insurance',
            'client_name_and_address_doctor',
            'client_circumstances',
            'client_give_details_circumstances',
            'client_changed_occupation',
            'client_give_details_changed_occupation',
            'client_intend_fly',
            'client_give_details_intend_fly',
            'client_engage_military',
            'client_give_details_engage_military',
            'client_engage_sports',
            'client_give_details_engage_sports',
            'client_travel_abroad',
            'client_give_details_travel_abroad',
            'client_full_name_guardian',
            'client_occupation_life_assured',
            'client_application_number',
            'client_suffered_injury',
            'client_give_details_suffered_injury',
            'client_medical_attention',
            'client_give_reason_medical_attention',
            'client_good_state_health',
            'client_give_details_good_state_health',
            'client_first_degree_relative',
            'client_give_details_first_degree_relative',
            'client_occupational_status',
            'client_give_details_occupational_status',
            'client_financial_circumstances',
            'client_give_details_financial_circumstances',
            'client_organised_sports',
            'client_give_details_organised_sports',
            'client_submitted_any_company',
            'client_give_details_submitted_any_company',
            'client_cover_accepted',
            'client_give_details_cover_accepted',
            'client_proposal_number',
            'client_date_proposal_signed',
            'client_good_health_employment',
            'client_give_details_good_health_employment',
            'client_suffered_any_illness',
            'client_give_details_suffered_any_illness',
            'client_consulted_attended_doctor',
            'client_give_details_consulted_attended_doctor',
            'client_advised_treatment',
            'client_give_details_advised_treatment',
            'client_relations_suffered',
            'client_give_details_relations_suffered',
            'client_change_occupation_proposal',
            'client_give_details_change_occupation_proposal',
            'client_proposal_assurance_life',
            'client_give_details_proposal_assurance_life',
            'client_hazardous_pastime',
            'client_give_details_hazardous_pastime',
            'client_smoke_tobacco',
            'client_give_details_smoke_tobacco',
            'client_income_varied_proposal',
            'client_give_details_income_varied_proposal',
            'client_spouse_claim_proposal',
            'client_give_details_spouse_claim_proposal',
        ];
    }

    protected function textFields()
    {
        return [
            'notes',
            'client_signature',
            'partner_signature',
        ];
    }

    protected function dateFields()
    {
        return [
            'client_date_of_original_application',
            'client_date_of_birth_application',
            'client_proposal_dated',
        ];
    }

}
