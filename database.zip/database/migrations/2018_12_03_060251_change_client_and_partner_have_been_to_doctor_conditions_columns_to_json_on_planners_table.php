<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeClientAndPartnerHaveBeenToDoctorConditionsColumnsToJsonOnPlannersTable extends Migration
{
    protected static $COLUMNS = [
        'client_have_been_to_doctor_conditions' => 'client_have_been_to_doctor',
        'partner_have_been_to_doctor_conditions' => 'partner_have_been_to_doctor',
    ];

    public function __construct()
    {
        DB::getDoctrineSchemaManager()
            ->getDatabasePlatform()
            ->registerDoctrineTypeMapping('enum', 'string');
    }

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->dropColumn($column);
            }
        });

        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->json($column)->after($after)->nullable(true);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->dropColumn($column);
            }
        });

        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->string($column, 100)->after($after)->nullable(true);
            }
        });
    }
}
