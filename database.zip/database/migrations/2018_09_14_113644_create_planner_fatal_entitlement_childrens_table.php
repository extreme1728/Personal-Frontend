<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerFatalEntitlementChildrensTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_fatal_entitlement_childrens', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uid');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('name')->nullable(true);
            $table->integer('age')->default(0)->nullable(true);
            $table->string('date_of_birth')->nullable(true);
            $table->boolean('studying')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_fatal_entitlement_childrens');
    }
}
