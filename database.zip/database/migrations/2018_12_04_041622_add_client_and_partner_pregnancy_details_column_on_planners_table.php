<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerPregnancyDetailsColumnOnPlannersTable extends Migration
{
    protected static $COLUMNS = [
        'client_pregnancy_details' => 'client_have_been_to_doctor_conditions',
        'partner_pregnancy_details' => 'partner_have_been_to_doctor_conditions',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->json($column)->after($after)->nullable(true);
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $after) {
                $table->dropColumn($column);
            }
        });
    }
}
