<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHazardousActivityCategoryQuestionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hazardous_activity_category_questions', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('hazardous_activity_category_id');
            $table
                ->foreign('hazardous_activity_category_id', 'hazardous_activity_category_foreign_id')
                ->references('id')
                ->on('hazardous_activities')
                ->onDelete('CASCADE');
            $table->text('question');
            $table->string('field_name', 199)->nullable(true)->unique();
            $table->string('field_type', 15);
            $table->json('properties')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hazardous_activity_category_questions');
    }
}
