<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerHowManyYearsColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->string('business_how_many_years', 3)
                ->after('when_business_started')
                ->nullable(true);
            $table
                ->string('partner_business_how_many_years', 3)
                ->after('partner_when_business_started')
                ->nullable(true);

            $table
                ->string('partner_how_many_boys', 3)
                ->after('how_many_boys')
                ->nullable(true);

            $table
                ->enum('partner_has_corporate_partner', ['yes', 'no'])
                ->after('has_corporate_partner')
                ->nullable(true)
                ->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'business_how_many_years',
                'partner_business_how_many_years',
                'partner_how_many_boys',
                'partner_has_corporate_partner',
            ]);
        });
    }
}
