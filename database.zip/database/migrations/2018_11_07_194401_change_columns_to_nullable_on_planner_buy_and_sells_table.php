<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeColumnsToNullableOnPlannerBuyAndSellsTable extends Migration
{
    /**
     * Property defining columns to be changed.
     *
     * @var array
     */
    protected static $COLUMNS = [
        'smoking_status',
        'any_other_siblings',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planner_buy_and_sells', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table
                    ->string($column)
                    ->nullable(true)
                    ->default(null)
                    ->change();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planner_buy_and_sells', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table
                    ->string($column)
                    ->nullable(false)
                    ->default('no')
                    ->change();
            }
        });
    }
}
