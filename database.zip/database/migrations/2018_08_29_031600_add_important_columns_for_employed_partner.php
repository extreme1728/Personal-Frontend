<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddImportantColumnsForEmployedPartner extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->text('partner_company_full_name')
                ->after('partner_employment_position_type')
                ->nullable(true);
            $table
                ->text('partner_employed_schedule_type')
                ->after('partner_company_full_name')
                ->nullable(true);
            $table
                ->text('partner_employed_annual_income')
                ->after('partner_employed_schedule_type')
                ->nullable(true);
            $table
                ->text('partner_employed_occupation')
                ->after('partner_employed_annual_income')
                ->nullable(true);
            $table
                ->text('partner_employed_how_long')
                ->after('partner_employed_annual_income')
                ->nullable(true);
            $table
                ->text('partner_employed_work_exp_month')
                ->after('partner_employed_how_long')
                ->nullable(true);
            $table
                ->text('partner_employed_work_exp_year')
                ->after('partner_employed_work_exp_month')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'partner_company_full_name',
                'partner_employed_schedule_type',
                'partner_employed_annual_income',
                'partner_employed_occupation',
                'partner_employed_how_long',
                'partner_employed_work_exp_month',
                'partner_employed_work_exp_year',
            ]);
        });
    }
}
