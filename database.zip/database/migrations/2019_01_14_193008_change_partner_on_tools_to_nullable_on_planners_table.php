<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangePartnerOnToolsToNullableOnPlannersTable extends Migration
{
    protected static $TABLENAME = 'planners';

    protected static $columns = [
        'on_tools' => 'yes',
        'partner_on_tools' => 'yes',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$columns as $column => $default) {
                DB::statement("ALTER TABLE `" .static::$TABLENAME. "` MODIFY COLUMN `" .$column. "`  enum('yes','no') NULL DEFAULT NULL;");
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table(static::$TABLENAME, function (Blueprint $table) {
            foreach (static::$columns as $column => $default) {
                DB::statement("ALTER TABLE `" .static::$TABLENAME. "` MODIFY COLUMN `" .$column. "`  enum('yes','no') NOT NULL DEFAULT '" .$default. "';");
            }
        });
    }
}
