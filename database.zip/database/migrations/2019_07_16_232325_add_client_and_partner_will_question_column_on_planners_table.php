<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerWillQuestionColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_wills_reflect_situation', ['yes', 'no'])
                ->after('client_has_will_in_place')
                ->nullable(true)
                ->default(null);
            $table
                ->enum('client_has_guardianship_of_children', ['yes', 'no'])
                ->after('client_wills_reflect_situation')
                ->nullable(true)
                ->default(null);
            $table
                ->enum('partner_wills_reflect_situation', ['yes', 'no'])
                ->after('partner_has_will_in_place')
                ->nullable(true)
                ->default(null);
            $table
                ->enum('partner_has_guardianship_of_children', ['yes', 'no'])
                ->after('partner_wills_reflect_situation')
                ->nullable(true)
                ->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_wills_reflect_situation',
                'client_has_guardianship_of_children',
                'partner_wills_reflect_situation',
                'partner_has_guardianship_of_children'
            ]);
        });
    }
}
