<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnForUpdateOfResidencyQuestions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_three_months_left_visa', ['yes','no'])
                ->after('client_work_visa_greater_two_years')
                ->nullable(true);
            $table
                ->enum('client_applying_permanent_residency', ['yes','no'])
                ->after('client_three_months_left_visa')
                ->nullable(true);
            $table
                ->enum('client_NZ_sole_country_residence', ['yes','no'])
                ->after('client_applying_permanent_residency')
                ->nullable(true);
            $table
                ->enum('client_plan_leaving_NZ_in_five_years', ['yes','no'])
                ->after('client_NZ_sole_country_residence')
                ->nullable(true);
            $table
                ->text('client_state_vested_interest_in_NZ')
                ->after('client_plan_leaving_NZ_in_five_years')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn('client_three_months_left_visa');
            $table->dropColumn('client_applying_permanent_residency');
            $table->dropColumn('client_NZ_sole_country_residence');
            $table->dropColumn('client_plan_leaving_NZ_in_five_years');
            $table->dropColumn('client_state_vested_interest_in_NZ');
        });
    }
}
