<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerOnAnyPrescriptionMedicineConditionsColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->json('client_on_any_prescription_medicine_conditions')
                ->after('client_on_any_prescription_medicine')
                ->nullable(true);
            $table
                ->json('partner_on_any_prescription_medicine_conditions')
                ->after('partner_on_any_prescription_medicine')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_on_any_prescription_medicine_conditions',
                'partner_on_any_prescription_medicine_conditions',
            ]);
        });
    }
}
