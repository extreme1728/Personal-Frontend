<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerAccLevyCalculationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_acc_levy_calculations', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('type', 50); // client or partner
            $table->string('property'); // plan, on_tools, existing.
            $table->json('values'); // raw response from automation service
            $table->json('coverplus_cover');
            $table->json('coverplus_extra_standard');
            $table->json('coverplus_extra_llwc')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_acc_levy_calculations');
    }
}
