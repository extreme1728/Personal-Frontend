<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerItemRecommendationImagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_item_recommendation_images', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_item_recommendation_id');
            $table
                ->foreign('planner_item_recommendation_id', 'planner_item_recommendation_foreign_id')
                ->references('id')
                ->on('planner_item_recommendations')
                ->onDelete('CASCADE');
            $table->string('name');
            $table->boolean('visible')->default(true);
            $table->text('description')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_item_recommendation_images');
    }
}
