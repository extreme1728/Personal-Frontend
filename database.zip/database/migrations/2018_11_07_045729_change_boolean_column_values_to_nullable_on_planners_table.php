<?php

require_once '2018_09_15_175255_change_string_columns_length_on_planners_table.php';

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class ChangeBooleanColumnValuesToNullableOnPlannersTable extends ChangeStringColumnsLengthOnPlannersTable
{
    /**
     * Create migration instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Get boolean columns.
     *
     * @return \Illuminate\Support\Collection
     */
    protected static function getBooleanColumns()
    {
        return Collection::make(static::$BOOLEAN_COLUMNS)
            ->merge([
                'client_has_increased_height_and_weight' => 'no',
                'partner_has_increased_height_and_weight' => 'no',
            ]);
    }

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table(static::$TABLENAME, function (Blueprint $table) {
            $except = ['on_tools', 'partner_on_tools'];
            foreach (
                static::getBooleanColumns()
                ->except($except)
                ->keys()
                as $column
            ) {
                DB::statement("ALTER TABLE `" .static::$TABLENAME. "` MODIFY COLUMN `" .$column. "`  enum('yes','no') NULL DEFAULT NULL;");
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table(static::$TABLENAME, function (Blueprint $table) {
            foreach (static::getBooleanColumns() as $column => $default) {
                DB::statement("ALTER TABLE `" .static::$TABLENAME. "` MODIFY COLUMN `" .$column. "`  enum('yes','no') NOT NULL DEFAULT '" .$default. "';");
            }
        });
    }
}
