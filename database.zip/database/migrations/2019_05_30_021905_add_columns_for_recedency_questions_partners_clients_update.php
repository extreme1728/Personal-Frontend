<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Builder;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsForRecedencyQuestionsPartnersClientsUpdate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->string('client_applied_another_visa', Builder::$defaultStringLength)
                ->after('client_state_vested_interest_in_NZ')
                ->nullable(true);
            $table
                ->string('client_intend_another_visa', Builder::$defaultStringLength)
                ->after('client_applied_another_visa')
                ->nullable(true);
            $table
                ->string('client_when_applying_visa', Builder::$defaultStringLength)
                ->after('client_intend_another_visa')
                ->nullable(true);
            $table
                ->string('client_duration_reason_travel', Builder::$defaultStringLength)
                ->after('client_when_applying_visa')
                ->nullable(true);
            $table
                ->string('partner_applied_another_visa', Builder::$defaultStringLength)
                ->after('partner_state_vested_interest_in_NZ')
                ->nullable(true);
            $table
                ->string('partner_intend_another_visa', Builder::$defaultStringLength)
                ->after('partner_applied_another_visa')
                ->nullable(true);
            $table
                ->string('partner_when_applying_visa', Builder::$defaultStringLength)
                ->after('partner_intend_another_visa')
                ->nullable(true);
            $table
                ->string('partner_duration_reason_travel', Builder::$defaultStringLength)
                ->after('partner_when_applying_visa')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn('client_applied_another_visa');
            $table->dropColumn('client_intend_another_visa');
            $table->dropColumn('client_when_applying_visa');
            $table->dropColumn('client_duration_reason_travel');
            $table->dropColumn('partner_applied_another_visa');
            $table->dropColumn('partner_intend_another_visa');
            $table->dropColumn('partner_when_applying_visa');
            $table->dropColumn('partner_duration_reason_travel');
        });
    }
}
