<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerOnAnyPrescriptionMedicineColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->json('client_on_any_prescription_medicine')
                ->after('client_have_been_to_doctor_conditions')
                ->nullable(true);

            $table
                ->json('partner_on_any_prescription_medicine')
                ->after('partner_have_been_to_doctor_conditions')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_on_any_prescription_medicine',
                'partner_on_any_prescription_medicine',
            ]);
        });
    }
}
