<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsForClientAndPartnerResidencyQuestions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->enum('client_twelve_months_left_visa', ['yes','no'])
                ->after('client_three_months_left_visa')
                ->nullable(true);
            $table
                ->enum('partner_twelve_months_left_visa', ['yes','no'])
                ->after('partner_three_months_left_visa')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_twelve_months_left_visa',
                'partner_twelve_months_left_visa',
            ]);
        });
    }
}
