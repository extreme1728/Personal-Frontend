
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddClientAndPartnerIrdNumberPersonalOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table
                ->string('ird_number_personal')
                ->after('acc_number_personal')
                ->nullable(true);
            $table
                ->string('partner_ird_number_personal')
                ->after('partner_acc_number_personal')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'ird_number_personal',
                'partner_ird_number_personal',
            ]);
        });
    }
}
