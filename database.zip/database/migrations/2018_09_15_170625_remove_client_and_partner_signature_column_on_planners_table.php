<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveClientAndPartnerSignatureColumnOnPlannersTable extends Migration
{
    /**
     * Property defining columns to modify.
     *
     * @var array
     */
    private static $COLUMNS = ['client_signature', 'partner_signature'];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasColumns('planners', static::$COLUMNS)) {
            Schema::table('planners', function (Blueprint $table) {
                $table->dropColumn(static::$COLUMNS);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (! Schema::hasColumns('planners', static::$COLUMNS)) {
            Schema::table('planners', function (Blueprint $table) {
                foreach (static::$COLUMNS as $column)
                    $table->text($column)->nullable(true);
            });
        }
    }
}
