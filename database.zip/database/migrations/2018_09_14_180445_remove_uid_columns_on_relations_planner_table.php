<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveUidColumnsOnRelationsPlannerTable extends Migration
{
    private static $TABLES = [
        'planner_key_people',
        'planner_buy_and_sells',
        'planner_fatal_entitlement_childrens',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        foreach (static::$TABLES as $table) {
            Schema::table($table, function (Blueprint $table) {
                $table->dropColumn('uid');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        foreach (static::$TABLES as $table) {
            Schema::table($table, function (Blueprint $table) {
                $table->string('uid')->after('id');
            });
        }
    }
}
