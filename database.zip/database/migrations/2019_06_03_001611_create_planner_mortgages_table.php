<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerMortgagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_mortgages', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_id');
            $table->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('mortgage_amount')->nullable(true);
            $table
                ->enum('does_rental_income_cover_mortgage_repayments', ['yes', 'no'])
                ->nullable(true)
                ->default(null);
            $table->string('shortfall_amount')->nullable(true);
            $table->text('how_long_will_shortfall_last')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_mortgages');
    }
}
