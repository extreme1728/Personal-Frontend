<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveColumnsToPlannersTable extends Migration
{
    /**
     * Property defining columns to be migrated
     *
     * @var array
     */
    private static $COLUMNS = [
        'key_persons',
        'buy_and_sells',
        'fatal_entitlement_childrens',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn(static::$COLUMNS);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column) {
                $table->text($column)->nullable(true);
            }
        });
    }
}
