<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeColumnsToNullableOnPlannerKeyPeopleTable extends Migration
{
    /**
     * Property defining columns to be changed.
     *
     * @var array
     */
    protected static $COLUMNS = [
        'smoking_status' => 'no',
        'payment_frequency' => 'annually',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planner_key_people', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $default) {
                $table
                    ->string($column)
                    ->nullable(true)
                    ->default(null)
                    ->change();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planner_key_people', function (Blueprint $table) {
            foreach (static::$COLUMNS as $column => $default) {
                $table
                    ->string($column)
                    ->nullable(false)
                    ->default($default)
                    ->change();
            }
        });
    }
}
