<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Builder;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ModifyAccAndIrdPersoanlNumberColumnsOnPlannersTable extends Migration
{
    /**
     * Constant defining table name.
     *
     * @var string
     */
    const TABLENAME = 'planners';

    /**
     * Property defining the default table length.
     *
     * @var integer
     */
    private static $STRINGLENGTH;

    /**
     *
     */
    public function __construct()
    {
        static::$STRINGLENGTH = Builder::$defaultStringLength;
    }

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table(self::TABLENAME, function (Blueprint $table) {
            DB::statement("ALTER TABLE `" .self::TABLENAME. "` CHANGE `acc_or_ird_number_personal` `acc_number_personal` VARCHAR(" .static::$STRINGLENGTH. ") DEFAULT NULL;");
            DB::statement("ALTER TABLE `" .self::TABLENAME. "` CHANGE `partner_acc_or_ird_number_personal` `partner_acc_number_personal` VARCHAR(" .static::$STRINGLENGTH. ") DEFAULT NULL;");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table(self::TABLENAME, function (Blueprint $table) {
            DB::statement("ALTER TABLE `" .self::TABLENAME. "` CHANGE `acc_number_personal` `acc_or_ird_number_personal` VARCHAR(" .static::$STRINGLENGTH. ") DEFAULT NULL;");
            DB::statement("ALTER TABLE `" .self::TABLENAME. "` CHANGE `partner_acc_number_personal` `partner_acc_or_ird_number_personal` VARCHAR(" .static::$STRINGLENGTH. ") DEFAULT NULL;");
        });
    }
}
