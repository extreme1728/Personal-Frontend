<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerAlterationAdvicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_alteration_advices', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->json('policies')->nullable(true); // benefit, from, to and category
            $table->string('effective_at')->nullable(true);
            $table->string('new_annual_premium_amount')->nullable(true);
            $table->json('payment_frequency')->nullable(true);
            $table->string('payment_frequentcy_other_description')->nullable(true);
            $table->string('paying_by_direct_debit_type')->default('existing');
            $table->string('company_full_name')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_alteration_advices');
    }
}
