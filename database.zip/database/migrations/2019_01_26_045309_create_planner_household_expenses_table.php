<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerHouseholdExpensesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_household_expenses', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_id');
            $table->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('name');
            $table->string('frequency', 20);
            $table->string('value');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_household_expenses');
    }
}
