<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerBuyAndSellsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_buy_and_sells', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uid');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('business_valuation')->nullable(true);
            $table->string('life_assured')->nullable(true);
            $table->string('date_of_birth')->nullable(true);
            $table->string('smoking_status')->default('no');
            $table->string('income')->nullable(true);
            $table->text('owner_of_shares')->nullable(true);
            $table->integer('percentage_needed');
            $table->text('person_purchasing_share')->nullable(true);
            $table->string('sum_assured')->nullable(true);
            $table->text('notes')->nullable(true);
            $table->boolean('any_other_siblings')->default(false);
            $table->string('required_for_other_siblings')->nullable(true);
            $table->text('name_of_siblings')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_buy_and_sells');
    }
}
