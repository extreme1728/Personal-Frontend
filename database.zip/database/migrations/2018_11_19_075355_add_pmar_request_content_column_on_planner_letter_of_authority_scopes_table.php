<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddPmarRequestContentColumnOnPlannerLetterOfAuthorityScopesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planner_letter_of_authority_scopes', function (Blueprint $table) {
            $table
                ->longText('pmar_request_content')
                ->after('values')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planner_letter_of_authority_scopes', function (Blueprint $table) {
            $table->dropColumn('pmar_request_content');
        });
    }
}
