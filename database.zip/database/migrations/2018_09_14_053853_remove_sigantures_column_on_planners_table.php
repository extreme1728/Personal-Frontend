<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveSiganturesColumnOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            if (Schema::hasColumn('planners', 'client_signature')) {
                $table->dropColumn('client_signature');
            }
            if (Schema::hasColumn('planners', 'partner_signature')) {
                $table->dropColumn('partner_signature');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            if (! Schema::hasColumn('planners', 'client_signature')) {
                $table
                    ->longText('client_signature')
                    ->after('assets_notes')
                    ->nullable(true);
            }

            if (! Schema::hasColumn('planners', 'partner_signature')) {
                $table
                    ->longText('partner_signature')
                    ->after('client_signature')
                    ->nullable(true);
            }
        });
    }
}
