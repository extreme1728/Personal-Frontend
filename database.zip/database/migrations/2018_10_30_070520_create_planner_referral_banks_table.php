<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerReferralBanksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_referral_banks', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_id');
            $table
                ->foreign('planner_id')
                ->references('id')
                ->on('planners')
                ->onDelete('CASCADE');
            $table->string('full_name', 80);
            $table->string('email')->nullable(true);
            $table->string('address', 150)->nullable(true);
            $table->string('mobile_phone', 25)->nullable(true);
            $table->string('company_name', 150)->nullable(true);
            $table->longText('notes')->nullable(true);
            $table->timestamps();
            $table->index('email');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_referral_banks');
    }
}
