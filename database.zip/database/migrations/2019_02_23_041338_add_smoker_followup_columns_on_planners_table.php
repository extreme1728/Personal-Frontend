<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddSmokerFollowupColumnsOnPlannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('planners', function (Blueprint $table) {
            $options = ['yes', 'no'];
            $table
                ->enum('client_smoking_when_took_out_previous_risk_insurance', $options)
                ->after('client_smoked_in_last_twelve_months')
                ->nullable(true);
            $table
                ->enum('partner_smoking_when_took_out_previous_risk_insurance', $options)
                ->after('partner_smoked_in_last_twelve_months')
                ->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('planners', function (Blueprint $table) {
            $table->dropColumn([
                'client_smoking_when_took_out_previous_risk_insurance',
                'partner_smoking_when_took_out_previous_risk_insurance'
            ]);
        });
    }
}
