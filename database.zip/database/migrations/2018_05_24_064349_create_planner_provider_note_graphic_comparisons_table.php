<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlannerProviderNoteGraphicComparisonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planner_provider_note_graphic_comparisons', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('planner_provider_note_comparison_id');
            $table->foreign('planner_provider_note_comparison_id', 'planner_provider_note_comparison_id_foreign')
                ->references('id')
                ->on('planner_provider_note_comparisons')
                ->onDelete('CASCADE');
            $table->string('path');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planner_provider_note_graphic_comparisons');
    }
}
