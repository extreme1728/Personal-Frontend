# resumetemplate
An online resume template in reactjs  
Instruction to run:-  
1)Clone the repo  

2)Edit the resumeData.js file in src folder  

3)Generate build using command:  
 ```npm run build```
 
4)Deploy the build folder to any server of your choice. 

For detailed instructions on how the resume template was created go to post below:  
[Medium Article](https://medium.com/technoetics/create-a-developer-portfolio-using-reactjs-d34ea1bfb18e)
