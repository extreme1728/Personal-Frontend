<template lang="pug">
q-layout(view="lhr LpR lFf")
  q-header(reveal)
    q-toolbar
      q-toolbar-title Insurance Planner and Plan
      q-btn(
        flat
        round
        dense
        icon="more_vert"
      )
        q-menu
          div(class="row no-wrap q-pa-md")
            div(class="column")
              div(class="text-h6 q-mb-md") Settings
              q-list
                q-item(:to="{ name: 'dashboard.app' }" v-ripple v-close-popup)
                  q-item-section(avatar)
                    q-icon(name="dashboard")
                  q-item-section
                    q-item-label Dashboard
                    q-item-label(caption) Overview
                q-item(:to="getPlannerUrl" v-ripple v-close-popup)
                  q-item-section(avatar)
                    q-icon(name="note")
                  q-item-section
                    q-item-label Planner
                    q-item-label(caption) Generate
                template(v-if="!isMarketingSpecialist")
                  q-item(:to="{ name: 'dashboard.referral' }" v-ripple v-close-popup)
                    q-item-section(avatar)
                      q-icon(name="how_to_reg")
                    q-item-section
                      q-item-label Referral
                      q-item-label(caption) Bank
                  q-item(:to="{ name: 'dashboard.classification.units' }" v-ripple v-close-popup)
                    q-item-section(avatar)
                      q-icon(name="table_chart")
                    q-item-section
                      q-item-label Classification
                      q-item-label(caption) Units
                  q-item(
                    v-if="isAdministrator"
                    :to="{ name: 'dashboard.insurance' }"
                    v-ripple
                    v-close-popup
                  )
                    q-item-section(avatar)
                      q-icon(name="verified_user")
                    q-item-section
                      q-item-label Insurance
                      q-item-label(caption) Providers
            q-separator(vertical inset class="q-mx-lg")
            div(class="column items-center")
              q-icon(size="72px" name="person" color="faded")
              div(class="text-subtitle1 q-my-xs") {{ currentUserModel.name }}
              div(class="text-faded text-subtitle2 q-my-xs") {{ currentUserModel.email }}
              q-btn(
                v-close-popup
                color="secondary"
                class="q-my-md"
                label="Logout"
                push
                size="sm"
                @click="logout"
              )
  q-page-container
    transition(
      appear
      enter="fadeIn"
      leave="fadeOut"
    )
      router-view
</template>

<script>
import { eq, isEmpty } from 'lodash';
import { Loading, QSpinnerGears } from 'quasar';
import { mapGetters, mapActions, mapMutations } from 'vuex';
import { initialState as insuranceProviderState } from 'src/store/modules/insuranceProvider/state';
import { initialState as plannerCollectionState } from 'src/store/modules/plannerCollection/state';
import { initialState as classificationUnitState } from 'src/store/modules/classificationUnit/state';
import { initialState as insuranceProviderCoverTypeCommentState  } from 'src/store/modules/insuranceProviderCoverTypeComment/state';

export default {
  name: 'dashboard-layout',
  data: () => ({
    showLeft: false,
  }),
  preFetch({ store, previousRoute }) {
    if (!eq(previousRoute.name, 'auth')) {
      Loading.show({
        spinner: QSpinnerGears,
        size: 250,
        message: 'Updating dependencies...',
      });
    }

    const { plannerCollection: planners } = store.state;
    let requests = [
        store.dispatch('medicalCategories/requestMedicalCategories'),
        store.dispatch('insuranceProvider/requestInsuranceProviders'),
        store.dispatch('classificationUnit/requestClassificationUnits'),
        store.dispatch('hazardousActivitiyCategories/requestHazardousActivityCategories'),
        store.dispatch('insuranceProviderCoverTypeComment/requestInsuranceProviderCoverTypeComments'),
    ];

    if (isEmpty(planners.data)
      || isEmpty(planners.links)
      || isEmpty(planners.meta)) {
      requests = [
        ...requests,
        ...[store.dispatch('plannerCollection/requestPlannersFromApi')]
      ];
    }

    const promise = Promise.all(requests);

    if (!eq(previousRoute.name, 'auth')) {
      promise.then(() => Loading.hide());
    }

    return promise;
  },
  methods: {
    ...mapActions('user', ['userClearAll']),
    ...mapMutations('classificationUnit', ['SAVE_DATA']),
    ...mapMutations('plannerCollection', ['ASSIGN_PLANNER_COLLECTION']),
    ...mapMutations('insuranceProvider', ['SAVE_INSURANCE_PROVIDERS']),
    ...mapMutations('insuranceProviderCoverTypeComment', ['ASSIGN_COVER_TYPE_COMMENTS']),
    logout() {
      this.userClearAll();
      this.SAVE_DATA(classificationUnitState());
      this.SAVE_INSURANCE_PROVIDERS(insuranceProviderState());
      this.ASSIGN_PLANNER_COLLECTION(plannerCollectionState());
      this.ASSIGN_COVER_TYPE_COMMENTS(insuranceProviderCoverTypeCommentState());
      this.$router.replace({ name: 'auth' });
    },
  },
  computed: {
    ...mapGetters('planner', ['plan']),
    ...mapGetters('user', [
      'isMarketingSpecialist',
      'isAdministrator',
      'currentUserModel',
    ]),
    getPlannerUrl() {
      return `/dashboard/planner/${this.plan.id}`;
    },
  },
};
</script>
