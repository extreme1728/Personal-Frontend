<template lang="pug">
q-layout
  q-page-container
    transition(
      appear
      enter="fadeIn"
      leave="fadeOut"
    )
      router-view
</template>
