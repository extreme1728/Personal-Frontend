import { cloneDeep, debounce, get } from 'lodash';
import { floatFixer, numberWithCommas } from 'src/config/utils';
import CalculatorNoteService from 'src/services/ipp/calculators/NoteService';
import CalculatorDescription from 'src/components/ipp/calculators/blocks/CalculatorDescription';
import LevelOptionInput from 'src/components/ipp/calculators/blocks/LevelOptionInput';

export default {
  inject: {
    tabProvider: {
      from: 'data',
      default() {
        return { tabName: null };
      },
    },
  },
  props: {
    recentValuesPayload: Object, // interface @Object { alias, payload }.
    syncFromPayload: Object, // payload FROM the another calculator instance.
    payload: Object,
    readonly: {
      type: Boolean,
      default: false,
    },
    income: {
      type: [String, Number],
      default: 0,
    },
  },
  watch: {
    calculationFields: {
      handler: 'onCalculationFieldsPersist',
      deep: true,
    },
  },
  methods: {
    onCalculationFieldsPersist: debounce(function (values) { // eslint-disable-line func-names
      const { tabName } = this.tabProvider;
      if (!this.readonly && tabName) {
        this.$emit('save', cloneDeep(values), tabName);
      }
    }, 500),
    __calculateByPercentage: (value, percentage) =>
      floatFixer(numberWithCommas(value, false) * (percentage / 100)),
    __calculateByYears: (value, years) =>
      floatFixer(numberWithCommas(value, false) * (years || 0)),
    __calculateNannyCost({ rate_per_hour: hour, hours_per_week: week }) {
      const weeksPerYear = 52;
      hour = numberWithCommas(hour, false);
      const total = ((hour * week) * weeksPerYear);
      return floatFixer(total);
    },
    __calculateCaregiverCost({ value, years_needed: years }) {
      if (!value) return 0;
      if (!years) return value;
      const val = numberWithCommas(value, false);
      let total = val * years;
      const age = get(this, 'age', false);
      if (years === 65 && age) {
        total = val * (65 - age);
      }
      return floatFixer(total);
    },
    __calculateDisabilityIncome({ value, years_needed: years, percentage }) {
      if (!value) return 0;
      if (!years) return value;
      const val = numberWithCommas(value, false);
      let total = val * years;
      const age = get(this, 'age', false);
      if (years === 65 && age) {
        total = val * (65 - age);
      }
      return floatFixer(total * (percentage / 100));
    },
  },
  computed: {
    getIncomeAmount() {
      return numberWithCommas(this.income, false);
    },
    getBlockQuoteFontStyle: () => ({
      'font-size': '0.9em',
    }),
    orientation: () => ('vertical'),
    mortgageRepaymentTypes: () => ([
      { label: 'Interest', value: 'interest' },
      { label: 'Principal + Interest', value: 'principal_interest' },
    ]),
    indexes: () => ([
      { label: 'Indexed', value: 'Indexed' },
      { label: 'Indexed with Minimum 2%', value: 'Indexed 2%' },
      { label: 'Indexed with Minimum 5%', value: 'Indexed 5%' },
      { label: 'Not Indexed', value: 'Not Indexed' },
    ]),
    levelOptions: () => ([
      { label: 'Stepped', value: 'Stepped' },
      { label: 'Level for 10 years', value: 'Level for 10 years' },
      { label: 'Level to age 65', value: 'Level to age 65' },
      { label: 'Level to age 80', value: 'Level to age 80' },
      { label: 'Level to age 100', value: 'Level to age 100' },
      { label: 'Level for __ years', value: 'Level for __ years' },
    ]),
    caregiverCostYearsNeededOptions: () => ([
      { label: '1 year', value: 1 },
      { label: '2 years', value: 2 },
      { label: '5 years', value: 5 },
      { label: 'Till age 65', value: 65 },
    ]),
    noteServices() {
      return (type, attr) => (new CalculatorNoteService(type, attr));
    },
  },
  components: {
    LevelOptionInput,
    CalculatorDescription,
  },
};
