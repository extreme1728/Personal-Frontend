import { isArray, cloneDeep, split } from 'lodash';
import { mapGetters, mapActions, mapMutations } from 'vuex';

export default {
  methods: {
    ...mapMutations('planner', ['ASSIGN_PLANNER']),
    ...mapMutations('plannerCollection', ['ADD_PLANNER_COLLECTION']),
    ...mapActions('planner', ['updatePlanFieldAction', 'persistPlanner']),
    async onHandlePersist() {
      try {
        this.$q.notify({
          message: 'Saving',
          color: 'primary',
          icon: 'save',
          timeout: 1000,
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
        const { data: payload } = await this.persistPlanner(this.plan);
        this.ASSIGN_PLANNER(payload);
        this.ADD_PLANNER_COLLECTION(payload);
        this.$q.notify({
          message: 'Saved',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
        await this.$router.replace({
          name: 'dashboard.planner',
          params: {
            id: payload.id,
          },
          query: {
            step: this.currentStep,
            stage: payload.stage,
          },
        });
      }
      catch (e) {} // eslint-disable-line
    },
    async updatePlanField(value, field) {
      if (isArray(value)) value = cloneDeep(value);
      await this.updatePlanFieldAction({ value, field, remove: false });
    },
    updatePlanRelationField(value, field) {
      if (!this.plan.id) this.onHandlePersist();
      if (isArray(value)) value = cloneDeep(value);
      return this.persistPlanner({
        planner: this.plan,
        mutationPayload: { value, field, remove: false },
      }).then(({ data }) => {
        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);
        return data;
      });
    },
    async removePlanRelationInstanceField(value, field) {
      if (!this.plan.id) await this.onHandlePersist();
      const { data } = await this.persistPlanner({
        planner: this.plan,
        mutationPayload: { value, field, remove: true },
      });
      this.ASSIGN_PLANNER(data);
      this.ADD_PLANNER_COLLECTION(data);
      return data;
    },
    convertToNonReactive(payload) {
      return JSON.parse(JSON.stringify(payload));
    },
  },
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
      hasClientExists: 'hasClientExists',
      hasPartnerExists: 'hasPartnerExists',
    }),
    ...mapGetters('liabilityRates', {
      liabilityRequirement: 'requirements',
    }),
    ...mapGetters('site', {
      currentStep: 'getPlannerStep',
    }),
    getClientName() {
      return this.hasClientExists
        ? this.plan.client_full_name
        : 'Client';
    },
    getPartnerName() {
      return this.hasPartnerExists
        ? this.plan.partner_name
        : 'Partner';
    },
    getClientNameOnly() {
      const name = split(this.getClientName, ' ');
      return name.length > 2 ? `${name[0]} ${name[1]}` : name[0];
    },
    getPartnerNameOnly() {
      const name = split(this.getPartnerName, ' ');
      return name.length > 2 ? `${name[0]} ${name[1]}` : name[0];
    },
  },
};
