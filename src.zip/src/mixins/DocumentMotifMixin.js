export default {
  data: () => ({
    colorPicker: {
      dialog: {
        show: false,
      },
      color: '#42a5f5',
    },
  }),
  computed: {
    colorStyle() {
      return { color: this.colorPicker.color };
    },
    backgroundStyle() {
      return { background: this.colorPicker.color };
    },
    frontTitleBlockStyle() {
      return { 'background-color': this.colorPicker.color };
    },
    frontTitleHeaderStyle() {
      return {
        color: this.colorPicker.color,
      };
    },
    frontTitleBorderStyle() {
      return {
        'max-height': '200px',
        'border-left': `10px solid ${this.colorPicker.color}`,
      };
    },
    documentHeaderTitleStyle() {
      return {
        color: this.colorPicker.color,
        'border-bottom': `2px solid ${this.colorPicker.color}`,
      };
    },
    documentLineBreakStyle() {
      return {
        'margin-top': '1em',
        border: `1px solid ${this.colorPicker.color}`,
      };
    },
  },
};
