import { mapGetters } from 'vuex';
import { isEmpty, toNumber } from 'lodash';
import { switchcase, floatFixer, numberWithCommas } from 'src/config/utils';

export default {
  methods: {
    getSovereignIncomeMaximum(grossIncome, incomePercentage) {
      const limit = 600000;
      // eslint-disable-next-line
      const total = (this.getCalculatedIncomeMaximum(grossIncome, incomePercentage, false) * 1);
      return (total > limit) ? limit : total;
    },
    getAsteronIncomeMaximum(grossIncome, incomePercentage) {
      const limit = (grossIncome * 1.5);
      // eslint-disable-next-line
      const total = (this.getCalculatedIncomeMaximum(grossIncome, incomePercentage, false) * 1);
      return (total > limit) ? limit : total;
    },
    getAiaIncomeMaximum(grossIncome, incomePercentage) {
      const limit = 600000;
      // eslint-disable-next-line
      const total = (this.getCalculatedIncomeMaximum(grossIncome, incomePercentage, false) * 1);
      return (total > limit) ? limit : total;
    },
    getPartnersLifeIncomeMaximum(grossIncome, incomePercentage) {
      const limit = 360000;
      // eslint-disable-next-line
      const total = (this.getCalculatedIncomeMaximum(grossIncome, incomePercentage, false) * 0.8);
      return (total > limit) ? limit : total;
    },
    getFidelityIncomeMaximum(grossIncome, incomePercentage) {
      const limit = 360000;
      // eslint-disable-next-line
      const total = (this.getCalculatedIncomeMaximum(grossIncome, incomePercentage, false) * 1);
      return (total > limit) ? limit : total;
    },
    getCalculatedIncomeMaximum(grossIncome, incomePercentage) {
      if (isEmpty(grossIncome) || !incomePercentage) return 0;
      const total = window
        .parseFloat(floatFixer(grossIncome) * (incomePercentage / 100))
        .toFixed(2);
      return toNumber(total);
    },
    getIncomeNeedingToBeProtected(income, paymentFrequency) {
      const determinePaymentByFrequency = switchcase({
        weekly: 52,
        fortnightly: 26,
        monthly: 12,
        annually: 1,
      })(false);
      const payment = determinePaymentByFrequency(paymentFrequency);
      return numberWithCommas(numberWithCommas(income, false) * payment);
    },
  },
  computed: {
    ...mapGetters('resources', [
      'booleanValues',
      'mortgageRepaymentMethods',
    ]),
    booleanValuesOptions() {
      return [
        { label: 'Yes', value: true },
        { label: 'No', value: false },
      ];
    },
    incomeInsuranceProviders() {
      return [
        { label: 'AIA', value: 'aia' },
        { label: 'Asteron', value: 'asteron' },
        { label: 'Fidelity', value: 'fidelity' },
        { label: 'Partners Life', value: 'partners_life' },
        { label: 'Sovereign', value: 'sovereign' },
      ];
    },
  },
};
