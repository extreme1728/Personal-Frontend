import { map, get } from 'lodash';
import { mapGetters } from 'vuex';
import * as StepComponents from 'src/pages/dashboard/planner/steps';

export default {
  computed: {
    ...mapGetters('planner', ['isEmployed', 'isSelfEmployed']),
    ...mapGetters('user', ['isMarketingSpecialist']),
    ...mapGetters('insuranceProviderReport', ['hasFidelityOnPolicyProviderResults']),
    items() {
      return [
        {
          title: 'Income',
          caption: 'Details',
          icon: 'attach_money',
          name: 'income-details',
        },
        {
          title: 'Tax',
          icon: 'euro_symbol',
          caption: 'Splitting',
          name: 'tax-splitting',
          condition: this.isSelfEmployed,
        },
        {
          icon: 'info_outline',
          title: 'Important',
          caption: 'Info',
          name: 'important-info',
        },
        {
          icon: 'business',
          title: 'Business',
          caption: 'Needs',
          name: 'business-needs',
          condition: this.isSelfEmployed && !this.isMarketingSpecialist,
        },
        {
          title: 'Calculators',
          caption: 'Covers',
          icon: 'dialpad',
          name: 'calculators',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'star',
          title: 'Scope of',
          caption: 'Engagements',
          name: 'scope-of-engagements',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'bubble_chart',
          title: 'Item',
          caption: 'Recommendations',
          name: 'item-recommendations',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'bookmark',
          title: 'Insurance',
          caption: 'Planner',
          name: 'insurance-planner',
        },
        {
          title: 'Acc',
          icon: 'grid_on',
          caption: 'Offsets',
          name: 'acc-offsets',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'receipt',
          title: 'Common',
          caption: 'Tax Issues',
          name: 'common-tax-issues',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'local_atm',
          title: 'Passive',
          caption: 'Income Issues',
          name: 'passive-income-issues',
          condition: !this.hasFidelityOnPolicyProviderResults && !this.isMarketingSpecialist,
        },
        {
          title: 'Fatal',
          caption: 'Entitlements',
          icon: 'person_add',
          name: 'fatal-entitlements',
          condition: this.isSelfEmployed && !this.isMarketingSpecialist,
        },
        {
          title: 'Insurance',
          caption: 'Plan',
          icon: 'send',
          name: 'insurance-plan',
          condition: !this.isMarketingSpecialist,
        },
        {
          title: 'Referral',
          caption: 'Program',
          icon: 'how_to_reg',
          name: 'referrals',
          condition: !this.isMarketingSpecialist,
        },
        {
          title: 'Alteration',
          caption: 'advice',
          icon: 'ballot',
          name: 'alteration-advice',
          condition: !this.isMarketingSpecialist,
        },
        {
          icon: 'info_outline',
          title: 'Declaration of Continued',
          caption: 'Good Health',
          name: 'declaration-good-health',
        },
      ];
    },
    plannerStepComponents() {
      return map(this.items, (step, index) => ({
        ...step,
        ...{ order: index + 1 },
        ...{ condition: get(step, 'condition', true) },
        ...{ caption: get(step, 'caption', undefined) },
      })).filter(step => step.condition);
    },
  },
  components: StepComponents,
};
