/* eslint-disable */
import canvg from 'canvg';
import { uid } from 'quasar';

export default {
  data: () => ({
    loaded: true,
  }),
  methods: {
    svgToCanvas(done, targetElem = this.$el) {
      this.loaded = false;
      const svgElems = targetElem.querySelectorAll('svg');
      const self = this;
      /* eslint-disable */
      let i = -1;
      const next = (function() {
        if (++i < svgElems.length) {
          self.processCanvas(svgElems[i], next());
        }
        else {
          if (done) {
            self.loaded = true;
            done();
          }
        }
      });
      next();
      /* eslint-enable */
    },
    processCanvas(node) {
      const nodesToRecover = [];
      const nodesToRemove = [];
      const { parentNode } = node;
      const el = parentNode.getElementsByTagName('svg')[0];
      if (!el) return;
      const { width, height } = el.getBoundingClientRect();
      const serializer = new XMLSerializer();
      const svg = serializer.serializeToString(el);
      const canvas = document.createElement('canvas');
      canvas.id = `ipp-canvas-svg-${uid()}`;
      canvas.className = 'center-block';
      canvas.width = width;
      canvas.height = height;
      canvg(canvas, svg, {
        log: true,
        ignoreDimensions: true,
        renderCallback: () => {
          nodesToRecover.push({
            parent: parentNode,
            child: node,
          });
          parentNode.removeChild(node);

          nodesToRemove.push({
            parent: parentNode,
            child: canvas,
          });

          parentNode.appendChild(canvas);
        },
      });
    },
  },
};
