import { scroll } from 'quasar';

const SCROLL_DURATION = 1;
const CLASS_NAME = 'with-modal';

export default {
  methods: {
    __modalOnShow() {
      const { mobile } = this.$q.platform.is;
      if (mobile) {
        document.body.classList.add(CLASS_NAME);
        this.$nextTick(() => {
          scroll.setScrollPosition(window, 0, SCROLL_DURATION);
        });
      }
    },
    __modalOnClose() {
      const element = document.body;
      if (element.classList.contains(CLASS_NAME)) {
        element.classList.remove(CLASS_NAME);
      }
    },
  },
};
