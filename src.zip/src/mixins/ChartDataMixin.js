export default {
  computed: {
    getChartDataOptions() {
      return {
        scales: {
          yAxes: [{
            stacked: true,
            ticks: {
              beginAtZero: true,
              callback(value) {
                return `$ ${value}`;
              },
            },
          }],
          xAxes: [{
            gridLines: {
              display: false,
            },
          }],
        },
        responsive: true,
        maintainAspectRatio: false,
      };
    },
  },
};
