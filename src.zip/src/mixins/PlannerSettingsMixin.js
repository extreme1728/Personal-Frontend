import { merge } from 'lodash';
import plannerSteps from 'src/config/plannerSteps';
import { mapGetters, mapActions, mapMutations } from 'vuex';
import { initialState as plannerInitialState } from 'src/store/modules/planner/state';

export default {
  methods: {
    ...mapActions('planner', ['updatePlanFieldAction', 'persistPlanner', 'persistReplicatePlanner']),
    ...mapMutations('plannerCollection', ['ADD_PLANNER_COLLECTION']),
    ...mapActions('plannerCollection', ['requestRemovePlanner']),
    ...mapMutations('site', ['UPDATE_PLANNER_STEP']),
    ...mapMutations('planner', ['ASSIGN_PLANNER']),
    onHandleReplicateInstance({ id: planner, client_full_name: clientName }) {
      this.$q.dialog({
        title: 'Replicate Insurance Planner As',
        message: 'Client Name',
        color: 'blue-5',
        cancel: true,
        prompt: {
          model: clientName,
          type: 'text',
        },
      }).onOk((name) => {
        if (!name) return;
        this.$q.notify({
          message: 'Duplicating Planner',
          color: 'primary',
          icon: 'hourglass_full',
        });
        this.persistReplicatePlanner({ planner, name });
        this.$q.notify({
          message: 'Planner Generated',
          color: 'secondary',
          icon: 'check',
        });
      });
    },
    onHandleNewInstance() {
      const state = plannerInitialState();
      this.$q.dialog({
        title: 'Create Insurance Planner',
        message: 'Client Name',
        color: 'primary',
        cancel: true,
        persistent: true,
        prompt: {
          model: null,
          type: 'text',
        },
      }).onOk((name) => {
        if (!name) return;
        const payload = merge(state, { client_full_name: name });
        this.$q.notify({
          message: 'Generating Planner',
          color: 'primary',
          icon: 'hourglass_full',
        });
        this.persistPlanner(payload)
          .then(({ data }) => {
            this.ASSIGN_PLANNER(data);
            this.ADD_PLANNER_COLLECTION(data);
            const { value: step } = plannerSteps[0];
            this.UPDATE_PLANNER_STEP(step);
            this.$router.push({
              params: { id: data.id },
              name: 'dashboard.planner',
              query: { step, stage: data.stage },
            });
          });
      });
    },
    onHandleModifyPlannerStage() {
      this.$q.dialog({
        title: 'Planner Stage',
        message: 'You are about to change the planner stage',
        cancel: true,
        color: 'teal',
        preventClose: true,
        options: {
          type: 'radio',
          model: this.plan.stage,
          items: [
            { label: 'First Appointment', value: 'first_appointment', color: 'red-5' },
            { label: 'Second Appointment', value: 'second_appointment', color: 'amber' },
          ],
        },
      }).onOk((selected) => {
        this.updatePlanFieldAction({ value: { stage: selected } });
        const { stage, id } = this.plan;
        this.$router.replace({
          name: 'dashboard.planner',
          params: { id },
          query: {
            step: this.currentStep,
            stage,
          },
        });
      });
    },
    handleOnPlannerRemove({ id }) {
      this.$q.dialog({
        title: 'Delete Planner',
        message: 'This action cannot be undone and will result of losing data. Continue action?',
        color: 'primary',
        cancel: true,
        options: {
          type: 'checkbox',
          model: [],
          items: [
            { label: 'Remove permanently', value: true, color: 'primary' },
          ],
        },
      }).onOk(([force]) => {
        this.$q.notify({
          message: 'Deleting...',
          color: 'primary',
          icon: 'hourglass_full',
        });
        this.requestRemovePlanner({ id, ...{ force: !!force } })
          .then(() => {
            this.$q.notify({
              message: 'Deleted',
              color: 'secondary',
              icon: 'done',
            });
          });
      });
    },
    async onHandlerSkip() {
      try {
        const options = {
          type: 'radio',
          model: this.currentStep,
          items: this.mapDeterminedStepList,
        };
        const step = await this.$q.dialog({
          options,
          title: 'Skip',
          cancel: true,
          preventClose: true,
          color: 'secondary',
          message: 'Select a tab to skip',
        });
        this.UPDATE_PLANNER_STEP(step);
      }
      catch (e) { console.error(e); } // eslint-disable-line
    },
  },
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
      mapDeterminedStepList: 'mapDeterminedStepList',
    }),
    ...mapGetters('site', {
      currentStep: 'getPlannerStep',
    }),
  },
};
