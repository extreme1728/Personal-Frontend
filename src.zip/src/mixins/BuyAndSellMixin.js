import { isEmpty } from 'lodash';
import { mapGetters } from 'vuex';
import { floatFixer, numberWithCommas } from 'src/config/utils';

export default {
  methods: {
    getCalculatedSumAssured(valuation, percentage) {
      if (isEmpty(valuation) || !percentage) return 0;
      const total = window
        .parseFloat(floatFixer(valuation) * (percentage / 100))
        .toFixed(2);
      return numberWithCommas(total);
    },
  },
  computed: {
    ...mapGetters('resources', ['booleanValues']),
    booleanValuesOptions() {
      return [
        { label: 'Yes', value: true },
        { label: 'No', value: false },
      ];
    },
  },
};
