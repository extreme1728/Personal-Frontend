import Fuse from 'fuse.js';
import { isEmpty, lowerCase, toString } from 'lodash';

export default {
  methods: {
    filterByValueFn(terms, { value, label }) {
      return lowerCase(toString(value)).indexOf(toString(terms)) > -1
        || lowerCase(toString(label)).indexOf(lowerCase(terms)) > -1;
    },
    fuzzSearchAutocomplete(terms, { list }) {
      const opts = {
        keys: ['value', 'label', 'bic_code'],
      };
      if (isEmpty(terms)) return list;
      const fuse = new Fuse(list, opts);
      const result = fuse.search(terms);
      return result;
    },
  },
};
