<template lang="pug">
div(
  class="q-field row no-wrap items-start q-input q-field--standard q-field--labeled"
  :class="classes"
)
  div(class="q-field__inner relative-position col self-stretch column justify-center")
    div(:class="`q-field__control relative-position row no-wrap text-${color}`")
      div(class="q-field__control-container col relative-position row no-wrap q-anchor--skip text-faded")
        cleave(
          :raw="raw"
          :value="value"
          @input="__input"
          :options="options"
          :readonly="readonly"
          class="q-field__native"
          @focus.native="_ => focused = true"
          @blur="_ => focused = false"
          :placeholder="placeholder"
        )
        div(v-if="label" class="q-field__label no-pointer-events absolute ellipsis") {{ label }}
</template>

<script>
import Cleave from 'vue-cleave-component';

export default {
  name: `ipp-${Cleave.name}`,
  data: () => ({
    focused: false,
  }),
  extends: {
    props: {
      ...Cleave.props,
    },
  },
  props: {
    color: {
      type: String,
      defualt: 'primary',
    },
    label: String,
    readonly: Boolean,
    placeholder: String,
  },
  methods: {
    __input(value) {
      this.$emit('input', value);
      this.$nextTick(() => this.$emit('change', value));
    },
  },
  computed: {
    classes() {
      const { focused, value } = this;
      return {
        'q-field--focused': focused || value,
        'q-field--float': focused || value,
      };
    },
  },
  components: {
    Cleave,
  },
};
</script>
