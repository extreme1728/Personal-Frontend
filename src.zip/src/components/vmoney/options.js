export default {
  prefix: '',
  suffix: '',
  thousands: ',',
  decimal: '.',
  precision: 2,
};
