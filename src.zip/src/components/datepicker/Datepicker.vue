<template lang="pug">
div(
  class="q-field row no-wrap items-start q-input q-field--standard q-field--labeled"
  :class="classes"
)
  div(class="q-field__inner relative-position col self-stretch column justify-center")
    div(class="q-field__control relative-position row no-wrap text-tertiary")
      div(class="q-field__control-container col relative-position row no-wrap q-anchor--skip text-faded")
        date-picker(
          typeable
          :lang="lang"
          :value="value"
          :inline="inline"
          :disabled="disabled"
          :clear-button="clearable"
          :input-class="inputClass"
          :placeholder="placeholder"
          :format="getInputDateFormat"
          :calendar-class="calendarClass"
          :format-typed-date="formatTypedDate"
          :cleave-options="getCleaveOptions"
          @input="onHandleChange"
          @selected="onHandleChange"
          @showCalendar="_ => focused = true"
          @closeCalendar="_ => focused = false"
        )
        div(v-if="label" class="q-field__label no-pointer-events absolute ellipsis") {{ label }}
</template>

<script>
import { debounce } from 'lodash';
import DatePicker from 'vuejs-datepicker';

export default {
  name: 'ipp-date-picker',
  data: () => ({
    focused: false,
  }),
  props: {
    calendarClass: [String, Object, Array],
    label: String,
    inline: {
      type: Boolean,
      default: false,
    },
    clearable: {
      type: Boolean,
      default: false,
    },
    value: {
      type: [String, Date],
      default: null,
    },
    inputClass: {
      type: String,
      default: 'q-field__native'
    },
    lang: {
      type: [String, Object],
      default: 'en',
    },
    format: {
      type: String,
      default: null,
    },
    placeholder: {
      type: String,
      default: 'DD/MM/YYYY',
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    onHandleChange: debounce(function (value) {
      this.$emit('input', value);
      this.$emit('change', value);
    }, 1000),
    formatTypedDate(dateString) {
      const result = dateString.split('/');
      return result[2] + '-' + result[1] + '-' + result[0];
    },
  },
  computed: {
    classes() {
      return {
        'q-field--focused': !this.disabled,
        'q-field--float': true,
        'q-field--readonly no-pointer-events': this.disabled,
      };
    },
    getInputDateFormat() {
      return this.format || 'dd/MM/yyyy';
    },
    getCleaveOptions() {
      const defaultOptions = {
        date: true,
        datePattern: ['d', 'm', 'Y'],
        delimiter: '/',
      };
      return this.cleaveOptions || defaultOptions;
    },
  },
  components: {
    DatePicker,
  },
};
</script>

<style lang="stylus">
.vdp-datepicker,
.vdp-datepicker input
  width 100%

.vdp-datepicker__clear-button
  position absolute
  right 0
  top 50%
  width 15px

.vdp-datepicker__calendar .cell.selected
  color #fafafa !important
  background $primary

.vdp-datepicker__calendar .cell:not(.blank):not(.disabled).day:hover,
.vdp-datepicker__calendar .cell:not(.blank):not(.disabled).month:hover,
.vdp-datepicker__calendar .cell:not(.blank):not(.disabled).year:hover
  border 1px solid $primary !important
</style>
