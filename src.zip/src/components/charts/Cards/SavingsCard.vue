<template lang="pug">
  q-card(
    :color="color"
    :square="square"
    :flat="flat"
  )
    q-card-main
      div(class="row md-gutter")
        div
          q-icon(
            :size="iconSize"
            :name="iconName"
          )
        div
          p(
            class="text-italic"
            v-text="title"
          )
          h5 $ {{ amount }}
</template>

<script>
  import {
    QCard,
    QCardMain,
    QIcon
  } from 'quasar'

  export default {
    props: {
      color: {
        type: [String, Boolean],
        default: 'purple-10'
      },
      square: {
        type: Boolean,
        default: false
      },
      flat: {
        type: Boolean,
        default: false
      },
      iconName: {
        type: String,
        required: true
      },
      iconSize: {
        type: String,
        default: '54px'
      },
      title: {
        type: String,
        required: true
      },
      amount: {
        type: [Number, String],
        required: true
      }
    },
    components: {
      QCard,
      QCardMain,
      QIcon
    }
  }
</script>
