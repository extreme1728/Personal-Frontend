<template>
  <div class="row">
    <div class="col-md-4">
      <p class="text-faded text-center">ACC Cover Plus</p>
      <div ref="$DocumentPreviewContentFatalEntitlements">
        <one-hundred :amount="coverPlusAmount" :w="w" :h="h"></one-hundred>
      </div>
    </div>
    <div class="col-md-4">
      <p class="text-faded text-center">ACC Cover Plus Extra</p>
      <forty :amount="coverPlusExtraAmount" :w="w" :h="h"></forty>
    </div>
    <div class="col-md-4">
      <p class="text-faded text-center">Changes in Cover</p>
      <eighty :amount="changesInCover" :w="w" :h="h"></eighty>
    </div>
  </div>
</template>

<script>
import BaseFamilies from './BaseFamilies';
import * as NoChild from './blocks/NoChild';

export default {
  mixins: [BaseFamilies],
  components: {
    ...NoChild,
  },
}
</script>
