<template>
  <div class="row">
    <div class="col-md-4">
      <p class="text-faded text-center">ACC Cover Plus</p>
      <one-hundred :amount="coverPlusAmount" :w="w" :h="h"></one-hundred>
    </div>
    <div class="col-md-4">
      <p class="text-faded text-center">ACC Cover Plus Extra</p>
      <forty :amount="coverPlusExtraAmount" :w="w" :h="h"></forty>
    </div>
    <div class="col-md-4">
      <p class="text-faded text-center">Changes in Cover</p>
      <eighty :amount="changesInCover" :w="w" :h="h"></eighty>
    </div>
  </div>
</template>

<script>
import BaseFamilies from './BaseFamilies'
import * as GreaterThanTwoChildren from './blocks/GreaterThanTwoChildren'

export default {
  mixins: [BaseFamilies],
  components: {
    ...GreaterThanTwoChildren
  }
}
</script>
