import Empty from './Empty';
import Forty from './Forty';
import Eighty from './Eighty';
import OneHundred from './OneHundred';

export {
  Empty,
  Forty,
  Eighty,
  OneHundred,
};
