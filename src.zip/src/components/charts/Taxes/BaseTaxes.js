export default {
  props: {
    w: {
      type: [String, Number],
      default: '100%',
    },
    h: {
      type: [String, Number],
      default: '50vh',
    },
  },
};
