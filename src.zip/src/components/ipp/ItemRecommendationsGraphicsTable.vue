<template lang="pug">
  div
    table(
      :id="id"
      cellpadding="0"
      cellspacing="0"
      v-if="values.length"
      class="q-html-table text-tertiary"
    )
      thead(slot="header")
        tr
          th(
            class="text-center report-item__header"
            :class="titleClass"
            colspan="1"
          ) {{ title }}
      tbody
          tr(v-for="(note, index) in values")
            td
              q-card(
                flat
                inline
                class="no-padding graphics-card-max-width"
              )
                q-card-media(v-if="note.image")
                  svg-filter-image(:src="note.image")
                q-card-title {{ note.note }}
                q-card-actions(align="center")
                  q-btn(
                    round
                    flat
                    dense
                    icon="remove"
                    color="negative"
                    @click="$emit('remove', index)"
                  )
                    q-tooltip(
                      anchor="center right"
                      self="center left"
                    ) Remove
</template>

<script>
  import _ from 'lodash';
  import SvgFilterImage from 'src/components/vlazyimage/SvgFilterImage';

  export default {
    name: 'item-recommendation-graphics-table',
    props: {
      title: {
        type: String,
        default: 'Existing',
      },
      titleClass: {
        type: String,
        default: 'text-primary',
      },
      values: {
        type: Array,
        required: true,
      },
      id: {
        type: String,
        default: 'item-recommendation-graphics-table'
      },
    },
    components: {
      SvgFilterImage,
    },
  };
</script>

<style lang="stylus" scoped>
td
  word-wrap break-word

.report-item__header
  font-size 2em !important

.graphics-card-max-width
  max-width 320px !important
</style>
