<template lang="pug">
  q-dialog(
    v-model="show"
    prevent-close
    @show="$emit('show')"
    @hide="$emit('close')"
  )
    span(slot="title") Save Report As
    div(slot="body")
      q-field(
        class="q-mt-md"
        label="Name"
        orientation="vertical"
      )
        q-input(v-model="rawModel.name")
      q-field(
        class="q-mt-md"
        label="Category"
        orientation="vertical"
      )
        q-select(
          :options="getReportCategories"
          v-model="rawModel.category"
        )
      q-field(
        class="q-mt-md"
        label="Insurance Plan Type"
        orientation="vertical"
      )
        q-select(
          :options="getReportInsurancePlanTypes"
          v-model="rawModel.insurance_plan_type"
        )
      q-field(
        class="q-mt-md"
        label="Description"
        orientation="vertical"
      )
        q-input(
          type="textarea"
          v-model="rawModel.description"
          placeholder="(Optional)"
        )
    template(slot="buttons" slot-scope="props")
      q-btn(flat @click="$emit('close')") Cancel
      q-btn(outline @click="onSave") Save
</template>

<script>
import { head, get } from 'lodash';
import { mapState, mapGetters } from 'vuex';

export default {
  data: () => ({
    rawModel: {
      name: null,
      category: null,
      description: null,
      insurance_plan_type: null,
    }
  }),
  created() {
    this.rawModel = {
      description: this.description,
      name: this.name || this.clientName,
      insurance_plan_type: this.insurancePlanType || get(head(this.getReportInsurancePlanTypes), 'value', 'personal'),
      category: this.category || get(head(this.getReportCategories), 'value', 'Apples for apples'),
    };
  },
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    description: {
      type: [String, Object],
      default: null,
    },
    name: {
      type: [String, Object],
      default: null,
    },
    category: {
      type: String,
      default: null,
    },
    insurancePlanType: {
      type: String,
      default: null,
    },
  },
  methods: {
    onSave() {
      this.$emit('save', {
        ...this.rawModel,
        id: this.id,
      });
    },
  },
  computed: {
    ...mapState('planner', {
      id: state => state.id,
      clientName: state => state.client_full_name,
    }),
    ...mapGetters('insuranceProviderReport', {
      getReportCategories: 'getReportCategories',
      getReportInsurancePlanTypes: 'getReportInsurancePlanTypes',
    }),
  },
};
</script>
