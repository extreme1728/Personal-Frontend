<template lang="pug">
  div
    q-card(flat)
      q-card-title Select
      q-card-main
        q-field(label="Provider")
          q-select(
            :value="providerId"
            :options="mapInsuranceProvidersById"
            @change="v => $emit('change-provider-id', v)"
          )
        q-field(label="Cover Type" class="q-mt-md")
          q-select(
            :value="coverTypeId"
            :options="getSelectedProviderCoverTypes"
            @change="v => $emit('change-cover-type-id', v)"
          )
</template>

<script>
  import _ from 'lodash';
  import { mapGetters } from 'vuex';

  export default {
    name: 'insurance-provider-selection',
    props: {
      providerId: {
        type: Number,
        required: true,
      },
      coverTypeId: {
        type: Number,
        default: 0,
      },
      chunkNumber: {
        type: Number,
        default: 0,
      },
      flat: {
        type: Boolean,
        default: true
      },
    },
    watch: {
      getSelectedProviderCoverTypeNotes: {
        handler (values) {
          this.$emit('change-cover-type-notes', values);
        },
        deep: true,
      },
      getSelectedProviderCoverTypes: {
        handler (values) {
          this.$emit('change-cover-types', values);
        },
        deep: true,
      },
    },
    computed: {
      ...mapGetters('insuranceProvider', {
        providers: 'providers',
        mapInsuranceProvidersById: 'mapInsuranceProvidersById',
      }),
      getSelectedProviderCoverTypeNotes: {
        get() {
          if (_.isEmpty(this.providers)) return [];

          if (_.isEmpty(_.toString(this.providerId))
              || _.isEmpty(_.toString(this.coverTypeId))) return [];

          const getProviderInstance = _.find(this.providers, ['id', this.providerId]);
          if (_.isEmpty(getProviderInstance)) return [];

          const { covers } = getProviderInstance;
          if (_.isEmpty(covers)) return [];

          const getProviderCoverTypeInstance = _.find(covers, ['id', this.coverTypeId]);

          if (_.isEmpty(getProviderCoverTypeInstance)) return [];
          const { notes_collection } = getProviderCoverTypeInstance;

          if (this.chunkNumber) {
            return _.chunk(notes_collection, this.chunkNumber);
          }

          return notes_collection;
        },
      },
      getSelectedProviderCoverTypes: {
        get() {
          if (_.isEmpty(this.providers)) return [];
          if (_.isEmpty(_.toString(this.providerId))) return [];

          const getProviderInstance = _.find(this.providers, ['id', this.providerId]);
          if (_.isEmpty(getProviderInstance)) return [];

          const { covers } = getProviderInstance;
          if (_.isEmpty(covers)) return [];

          return _.map(covers, o => ({
            label: o.name,
            value: o.id,
          }));
        },
      },
    },
  };
</script>
