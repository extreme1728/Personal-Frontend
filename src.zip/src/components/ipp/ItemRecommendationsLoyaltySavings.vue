<template lang="pug">
q-markup-table(flat separator="horizontal")
    thead
      tr
        th(colspan="4" class="text-center item__table--background") {{ insuranceProvider | inputFormatter }} Loyalty Savings Calculation
      tr
        th Years cover is in place
        th Annual Premium
        th Loyalty discount
        th Savings
    tbody
      tr(v-for="saving in getTotalSavings" class="text-center")
        td {{ saving.order + getOrdinalSuffix(saving.order) }}
        td ${{ saving.annualPremium | numberComma }}
        td {{ Math.round(saving.loyaltyDiscount * 100) }}%
        td ${{ saving.savings | numberComma }}
    tfoot
      tr(class="item__table--background")
        td(colspan="3" class="text-bold") Estimated Savings
        td(class="text-bold") $ {{ getEstimatedTotalSavings(getTotalSavings) }}
</template>

<script>
import { floatFixer, floatTotals } from 'src/config/utils';
import { range, toNumber, map, camelCase, eq } from 'lodash';

export default {
  name: 'item-recommendations-loyalty-savings',
  props: {
    start: {
      type: Number,
      default: 2,
    },
    end: {
      type: Number,
      default: 12,
    },
    annualPremium: {
      type: [Number, String],
      required: true,
    },
    initialPercentage: {
      type: Number,
      default: 0.01,
    },
    insuranceProvider: {
      type: String,
      default: 'Partners Life',
    },
  },
  methods: {
    getOrdinalSuffix(n) {
      return['st','nd','rd'][((n+90)%100-10)%10-1]||'th';
    },
    getEstimatedTotalSavings(savings) {
      const totals = map(savings, ({ savings }) => savings);
      return window.parseFloat(floatTotals(totals)).toFixed(2);
    },
  },
  computed: {
    getTotalSavings() {
      const savings = [];
      let annualPremium = floatFixer(floatFixer(this.annualPremium) * 12);
      let percentage = this.initialPercentage;
      const items = range(this.start, this.end);
      const isFidelity = eq('fidelity', this.getFormattedInsuranceProvider);
      for (const [index, value] of items.entries()) {
        const fidelityPercentage = (index <= 3) ? 0 : (index === items.length - 1) ? 0.1 : 0.05;
        savings.push({
          order: value,
          loyaltyDiscount: percentage = isFidelity ? fidelityPercentage : percentage,
          annualPremium: annualPremium,
          savings: toNumber((annualPremium * percentage).toFixed(2)),
        });
        percentage = toNumber((this.initialPercentage + percentage).toFixed(2));
      }
      return savings;
    },
    getFormattedInsuranceProvider() {
      return camelCase(this.insuranceProvider);
    }
  },
};
</script>

<style lang="stylus" scoped>
.item__table--background
  background $table-stripe-color
</style>
