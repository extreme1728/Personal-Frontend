<template lang="pug">
div
  div(
    v-for="child in values"
    :key="child.id"
    class="row q-my-sm q-col-gutter-md"
  )
    div(class="col-md-3")
      q-input(
        placeholder="Name"
        :value="child.name"
        @input="value => modifyChildren(value, child, 'name')"
      )
    div(class="col-md-2")
      q-select(
        emit-value
        map-options
        :options="genders"
        placeholder="Gender"
        :value="child.gender"
        @input="value => modifyChildren(value, child, 'gender')"
      )
    div(class="col-md-2")
      date-picker(
        :inline="false"
        :value="child.date_of_birth"
        @close-calendar="modifyChildren(child.date_of_birth, child, 'modifyChildren')"
        @input="value => modifyChildren(value, child, 'date_of_birth')"
      )
    div(class="col-md-2")
      q-input(
        type="tel"
        placeholder="Age"
        :value="__getAge(child)"
        :disable="!!child.date_of_birth"
        @input="value => modifyChildren(value, child, 'age')"
      )
    div(class="col-md-2 q-my-md text-center")
      q-toggle(
        label="Studying"
        :value="child.studying"
        @input="value => modifyChildren(value, child, 'studying')"
      )
    div(class="col-md-1 q-my-md")
      q-btn(
        icon="remove"
        color="secondary"
        class="full-width"
        @click="removeChildren(child)"
      )
</template>

<script>
import moment from 'moment';
import { mapGetters } from 'vuex';
import { set, debounce } from 'lodash';
import DatePicker from 'src/components/datepicker/DatePicker';

export default {
  name: 'children-details',
  props: {
    values: Array,
  },
  methods: {
    modifyChildren: debounce(function (value, child, field) {
      if (field === 'date_of_birth') {
        set(child, 'age', this.$filters.getAgeByDate(value));
        set(child, field, value);
      }
      else {
        set(child, field, value);
      }
      this.$emit('change', this.values);
    }, 1000),
    removeChildren(child) {
      this.$emit('remove', child);
      // this.rawValues.splice(this.rawValues.indexOf(child), 1);
    },
    __getAge({ date_of_birth, age }) {
      if (age) return age;
      const viaFilterService = this.$filters.getAgeByDate(date_of_birth);
      if (viaFilterService) return viaFilterService;
      const m = moment(date_of_birth);
      return m.isValid()
        ? m.fromNow(true)
        : null;
    },
  },
  computed: mapGetters('resources', ['genders']),
  components: {
    DatePicker,
  },
};
</script>
