<template lang="pug">
div(class="buy-and-sells")
  div(
    v-for="(persons, chunkIndex) in getChunkedValues"
    :class="{ 'q-mt-sm': chunkIndex !== 0 }"
    class="row q-col-gutter-md"
    :key="chunkIndex"
  )
    div(
      :class="{ 'col-md-6': persons.length > 1, 'col-md-12': persons.length == 1 }"
      v-for="person in persons"
      :key="person.id"
    )
      q-card(:flat="flat" class="full-width relative-position")
        q-card-section
          p(class="text-faded text-h6") {{ person.life_assured || 'Buy and Sell' }}
        q-card-section(class="card-main")
          q-input(
            prefix="$"
            type="tel"
            v-money="{}"
            align="right"
            class="q-my-md"
            :readonly="readonly"
            label="Business Valuation"
            :value="person.business_valuation"
            @input="value => modifyPerson(value, person, 'business_valuation')"
          )
          share-holders-list(
            v-if="keyPersons && keyPersons.length"
            :values="keyPersons"
            :orientation="getDeterminedOrientation"
            :business-valuation-value="person.business_valuation"
          )
          q-input(
            class="q-my-md"
            label="Life Assured"
            :readonly="readonly"
            :value="person.life_assured"
            @input="value => modifyPerson(value, person, 'life_assured')"
          )
          date-picker(
            label="Date of Birth"
            class="q-my-md"
            :disabled="readonly"
            :value="person.date_of_birth"
            @change="value => modifyPerson(value, person, 'date_of_birth')"
          )
          q-select(
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            label="Smoker Status"
            :options="booleanValues"
            :value="person.smoking_status"
            @input="value => modifyPerson(value, person, 'smoking_status')"
          )
          q-select(
            multiple
            use-chips
            use-input
            hide-dropdown-icon
            new-value-mode="add-unique"
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :value="person.owner_of_shares"
            label="Owner of shares to be purchased"
            hint="Press Enter to persist changes"
            @input="value => modifyPerson(value, person, 'owner_of_shares')"
          )
          p(class="text-faded") Percentage Needed to be Purchased
          q-slider(
            snap
            markers
            :min="1"
            :max="100"
            :step="0.5"
            :decimals="1"
            label-always
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :value="person.percentage_needed"
            :label-value="`${person.percentage_needed}%`"
            @input="value => modifyPerson(value, person, 'percentage_needed')"
          )
          q-select(
            multiple
            use-chips
            use-input
            :color="color"
            class="q-my-md"
            hide-dropdown-icon
            :readonly="readonly"
            new-value-mode="add-unique"
            label="Person(s) Purchasing Share"
            hint="Press Enter to persist changes"
            :value="person.person_purchasing_share"
            @input="value => modifyPerson(value, person, 'person_purchasing_share')"
          )
          q-input(
            label="Sum Assured"
            prefix="$"
            type="tel"
            v-money="{}"
            align="right"
            class="q-my-md"
            :readonly="readonly"
            :value="person.sum_assured"
            hint="Clicking the icon will override the value based on the given calculation"
            @input="value => modifyPerson(value, person, 'sum_assured')"
          )
            template(v-slot:append)
              q-icon(name="autorenew" class="cursor-pointer" @click="sumAssuredHandler(person)")
          q-input(
            label="Notes"
            class="q-my-md"
            type="textarea"
            :max-height="100"
            :readonly="readonly"
            :value="person.notes"
            @input="value => modifyPerson(value, person, 'notes')"
          )
          q-select(
            emit-value
            map-options
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            label="Any other siblings?"
            :options="booleanValuesOptions"
            :value="person.any_other_siblings"
            @input="value => modifyPerson(value, person, 'any_other_siblings')"
          )
          div(v-if="person.any_other_siblings")
            q-input(
              prefix="$"
              type="tel"
              v-money="{}"
              align="right"
              class="q-my-md"
              :readonly="readonly"
              :value="person.required_for_other_siblings"
              label="How much is required for other sibling?"
              @input="value => modifyPerson(value, person, 'required_for_other_siblings')"
            )
            q-select(
              multiple
              use-input
              use-chips
              class="q-my-md"
              hide-dropdown-icon
              label="Name of sibling(s)"
              new-value-mode="add-unique"
              :value="person.name_of_siblings"
              hint="Press Enter to persist changes"
              @input="value => modifyPerson(value, person, 'name_of_siblings')"
            )
        q-card-actions(v-if="!readonly" class="absolute-bottom")
          q-btn(
            flat
            icon="remove"
            label="remove"
            color="negative"
            class="full-width"
            @click="e => removeBuyAndSell(person)"
          )
</template>

<script>
import { BuyAndSellMixin } from 'src/mixins';
import { set, chunk, debounce } from 'lodash';
import { QInput } from 'src/components/quasar';
import { ShareHoldersList } from 'src/components/ipp/planner';
import DatePicker from 'src/components/datepicker/DatePicker';

export default {
  name: 'buy-and-sells',
  mixins: [BuyAndSellMixin],
  props: {
    values: {
      type: Array,
      required: true,
    },
    readonly: {
      type: Boolean,
      default: false,
    },
    flat: {
      type: Boolean,
      default: false,
    },
    keyPersons: {
      type: Array,
      default: () => [],
    },
    color: {
      type: String,
      default: 'primary',
    },
  },
  mounted() {
    if (this.readonly) {
      this.$nextTick(() => {
        const selector = '.buy-and-sells .vdp-datepicker__calendar .cell.day.selected';
        const elements = Array.from(document.querySelectorAll(selector));
        if (!elements) return;
        elements.forEach((el) => {
          el.classList.add(`bg-${this.color}`);
        });
      });
    }
  },
  methods: {
    sumAssuredHandler(person) {
      const { business_valuation, percentage_needed } = person;
      const value = this.getCalculatedSumAssured(business_valuation, percentage_needed);
      this.modifyPerson(value, person, 'sum_assured');
    },
    modifyPerson: debounce(function (value, person, field) {
      set(person, field, value);
      this.$emit('input', this.values);
      this.$emit('change', this.values);
    }, 500),
    async removeBuyAndSell(person) {
      try {
        await this.$q.dialog({
          cancel: true,
          title: 'Prompt',
          preventClose: true,
          message: 'This action cannot be undone and will result of losing data.',
        });
        this.$emit('remove', person);
      }
      catch (e) {}
    },
  },
  computed: {
    getChunkedValues() {
      return chunk(this.values, 2);
    },
    getDeterminedOrientation() {
      return this.values.length > 1 ? 'vertical' : 'horizontal';
    },
  },
  components: {
    QInput,
    DatePicker,
    ShareHoldersList,
  },
};
</script>

<style lang="stylus">
.buy-and-sells
  .date-picker-field
    >.row.col
      height 400px !important
  .card-main
    padding-bottom 4em
</style>
