import KeyPersonCovers from './KeyPersonCovers';
import ShareHoldersList from './ShareHoldersList';
import BuyAndSells from './BuyAndSells';
import BodyMassIndexInput from './BodyMassIndexInput';
import ChildrenDetailsImportantInfo from './ChildrenDetails';
import MedicalConditionInput from './MedicalConditionInput/Index';
import BusinessPartnerImportantInfo from './BusinessPartnerImportantInfo/Index';

export {
  KeyPersonCovers,
  ShareHoldersList,
  BuyAndSells,
  BodyMassIndexInput,
  MedicalConditionInput,
  ChildrenDetailsImportantInfo,
  BusinessPartnerImportantInfo,
};
