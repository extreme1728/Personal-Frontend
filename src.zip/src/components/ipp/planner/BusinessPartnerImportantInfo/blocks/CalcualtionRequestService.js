/* eslint-disable */
import { get, isEmpty } from 'lodash';
import { floatFixer } from 'src/config/utils';
import CalculationModelService from './CalculationModelService';
import LevyCalculationService from 'src/services/ipp/levy/LevyCalculationService';

export default class CalcualtionRequestService extends CalculationModelService {
  constructor(payload) {
    super(payload);
    this.response = {};
  }

  async __requestOnTools() {
    const classificationUnit = get(this, 'selectedClassificationunitOnTools');
    if (isEmpty(classificationUnit) && this.isTheSameClassificationUnit)
      return Promise.resolve();
    const payload = {
      income: floatFixer(get(this.payload, 'income', 0)),
      cover: floatFixer(get(this.payload, 'nominated_cover_amount', 0)),
      cuccode: get(classificationUnit, 'code', null),
    };
    const service = new LevyCalculationService(payload);
    const response = await service.requestCalculations();
    this.response = {
      ...this.response,
      on_tools: {
        values: response,
        coverplus_cover: service.hydrateValues('coverplus_cover'),
        coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
      },
    };
    return Promise.resolve(response);
  }

  async __requestExisting() {
    const cover = get(this.payload, 'existing_nominated_cover_amount');
    const income = floatFixer(get(this.payload, 'income', 0));
    const classificationUnit = this.selectedClassificationUnit;
    if (isEmpty(classificationUnit)
      || !cover
      || !income
      || !this.isAlreadyOnAccCoverPlusExtra) return Promise.resolve();
    const payload = {
      cover,
      income,
      cuccode: get(classificationUnit, 'code', null),
    };
    const service = new LevyCalculationService(payload);
    const response = await service.requestCalculations();
    this.response = {
      ...this.response,
      existing: {
        values: response,
        coverplus_cover: service.hydrateValues('coverplus_cover'),
        coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
      },
    };
    return Promise.resolve(response);
  }

  async __requestPlan() {
    const classificationUnit = this.selectedClassificationUnit;
    const cover = floatFixer(get(this.payload, 'nominated_cover_amount', 0));
    const income = floatFixer(get(this.payload, 'income', 0));
    if (isEmpty(classificationUnit)
      || !cover
      || !income) return Promise.resolve();
    const payload = {
      income,
      cover,
      cuccode: get(classificationUnit, 'code', null),
    };
    const service = new LevyCalculationService(payload);
    const response = await service.requestCalculations();
    this.response = {
      ...this.response,
      plan: {
        values: response,
        coverplus_cover: service.hydrateValues('coverplus_cover'),
        coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
      },
    };
    return Promise.resolve(response);
  }

  async __requestAll() {
    return Promise.all([
      this.__requestOnTools(),
      this.__requestExisting(),
      this.__requestPlan(),
    ]);
  }
}
