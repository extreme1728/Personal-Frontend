<template lang="pug">
q-list
  q-expansion-item(opened label="Income Details" icon="attach_money")
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :options="taxMethodValues"
      :value="model.income_tax_method"
      label="Are you taking Drawings or Paye?"
      @input="value => __change(value, model, 'income_tax_method')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :options="booleanValues"
      :value="model.when_business_started"
      label="Been in business in more than 3 years?"
      @input="value => __change(value, model, 'when_business_started')"
    )
    q-input(
      v-if="model.when_business_started === 'yes'"
      class="q-my-md"
      type="tel"
      maxlength="3"
      label="How many years?"
      :value="model.business_how_many_years"
      @input="value => __change(value, model, 'business_how_many_years')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      label="Working full time?"
      :options="employmentScheduleValues"
      :value="model.employed_schedule_type"
      @input="value => __change(value, model, 'employed_schedule_type')"
    )
    q-input(
      type="tel"
      maxlength="3"
      class="q-my-md"
      :value="model.how_many_boys"
      label="How many staff do you have working for you?"
      @input="value => __change(value, model, 'how_many_boys')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :value="model.on_tools"
      :options="booleanValues"
      label="Now, Are you on tools?"
      @input="value => __change(value, model, 'on_tools')"
    )
    q-select(
      v-if="model.on_tools === 'no'"
      use-input
      emit-value
      class="q-my-md"
      input-debounce="0"
      @filter="__filterFn"
      hint="Search Classification Code"
      :options="classificationUnitOptions"
      :value="model.what_you_do_in_business"
      label="What is it that you do? (Project Management or Office)"
      @input="value => __change(value, model, 'what_you_do_in_business')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :options="booleanValues"
      :value="model.has_corporate_partner"
      label="Is there any other shareholders/director that are not on the tools?"
      @input="value => __change(value, model, 'has_corporate_partner')"
    )
    q-input(
      class="q-my-md"
      prefix="$"
      v-money="{}"
      align="right"
      :readonly="readonly"
      :value="model.income"
      label="How much income did you take out last year from the business?"
      @input="value => __change(value, model, 'income')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="accCoverPlanTypes"
      :value="model.acc_cover_plan_type"
      label="What ACC cover plan do you have?"
      @input="value => __change(value, model, 'acc_cover_plan_type')"
    )
    q-input(
      v-if="model.acc_cover_plan_type === 'cover_plus_extra'"
      class="q-my-md"
      prefix="$"
      v-money="{}"
      align="right"
      :readonly="readonly"
      :value="model.existing_nominated_cover_amount"
      label="How much is your current ACC Cover Plus Extra nominated amount?"
      @input="value => __change(value, model, 'existing_nominated_cover_amount')"
    )
    q-input(
      prefix="$"
      v-money="{}"
      align="right"
      class="q-my-md"
      :readonly="readonly"
      :value="model.nominated_cover_amount"
      label="Your nominated Cover Plus Extra cover amount"
      @input="value => __change(value, model, 'nominated_cover_amount')"
    )
    q-select(
      use-input
      emit-value
      class="q-my-md"
      input-debounce="0"
      @filter="__filterFn"
      :value="model.classification_unit"
      hint="Search Classification Code"
      :options="classificationUnitOptions"
      label="Just to ensure you are on the right classification code with ACC, what does your business do?"
      @input="value => __change(value, model, 'classification_unit')"
    )
    q-btn(
      v-if="!readonly"
      class="q-mt-md full-width"
      color="primary"
      icon="settings"
      label="Calculate Levy"
      :loading="calculating"
      @click="calculateLevy"
    )
    include ./income-results
    income-levy-calculation-notes(
      v-if="service.showCalculatedLevy"
      :client-name="model.full_name"
      :income-tax-method="model.income_tax_method"
      :cover-plus-calculation="service.coverPlusCalculation"
      :is-already-on-acc-cover-plus-extra="service.isAlreadyOnAccCoverPlusExtra"
      :cover-plus-extra-calculation="service.determinedCoverPlusExtraCalculation"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { QSpinnerGears } from 'quasar';
import { FilterableMixin } from 'src/mixins';
import { lowerCase, toString } from 'lodash';
import { QInput } from 'src/components/quasar';
import { IncomeLevyCalculationNotes } from 'src/components/ipp';
import CalculationModelService from './CalculationModelService';
import { PigBank, PigSavings } from 'src/components/charts/Pigs';
import CalcualtionRequestService from './CalcualtionRequestService';

export default {
  name: 'acc-details',
  mixins: [FilterableMixin],
  data: () => ({
    calculating: false,
    classificationUnitOptions: [],
  }),
  created() {
    this.classificationUnitOptions = this.mapClassificationUnitValues;
  },
  props: {
    model: Object,
    color: String,
    readonly: Boolean,
  },
  methods: {
    __filterFn(val, update) {
      if (val === '') {
        update(() => {
          this.classificationUnitOptions = this.mapClassificationUnitValues;
        });
        return;
      }
      update(() => {
        const needle = lowerCase(val);
        this.classificationUnitOptions = this.mapClassificationUnitValues.filter(({ value, label }) => {
          return lowerCase(toString(value)).indexOf(toString(needle)) > -1
            || lowerCase(toString(label)).indexOf(lowerCase(needle)) > -1;
        });
      });
    },
    __change(value, model, field) {
      this.$emit('change', value, model, field);
    },
    async calculateLevy() {
      try {
        const service = new CalcualtionRequestService(this.model);
        this.calculating = true;
        this.$q.loading.show({
          message: 'Calculating.... Please wait.',
          spinner: QSpinnerGears,
        });
        await service.__requestAll();
        this.__change(service.response, this.model, 'calculations');
      } catch (e) {
        console.error(e);
      } finally {
        this.$q.loading.hide();
        this.calculating = false;
      }
    },
  },
  computed: {
    ...mapGetters('resources', [
      'booleanValues',
      'taxMethodValues',
      'accCoverPlanTypes',
      'employmentScheduleValues',
    ]),
    ...mapGetters('classificationUnit', ['mapClassificationUnitValues']),
    service() {
      const instance = new CalculationModelService(this.model);
      console.log(instance);
      return instance;
    },
    getDeterminedPigColumnClass() {
      const hasPercentage = this.service.pigSavingsPercentage > 0;
      return !hasPercentage ? {
        'col-md-8': true,
        'offset-md-2': true,
      } : { 'col-md-6': true };
    }
  },
  components: {
    QInput,
    PigBank,
    PigSavings,
    IncomeLevyCalculationNotes,
  }
};
</script>
