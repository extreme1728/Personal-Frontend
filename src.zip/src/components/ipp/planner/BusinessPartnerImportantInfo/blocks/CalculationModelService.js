/* eslint-disable */
import store from 'src/store';
import { get, eq, find, isEmpty } from 'lodash';
import { getPercentageValue, floatFixer, floatDiff } from 'src/config/utils';

export default class CalculationModelService {
  constructor(payload) {
    this.payload = payload;
  }

  get classificationUnit() {
    return get(store.state, ['classificationUnit', 'data'], []);
  }

  get isTheSameClassificationUnit() {
    return eq(get(this.payload, 'on_tools', null), 'yes');
  }

  get selectedClassificationunitOnTools() {
    return this.__findClassificationUnitByField('what_you_do_in_business');
  }

  __findClassificationUnitByField(field) {
    return find(this.classificationUnit, ['code', get(this.payload, field, 0)]) || null;
  }

  get selectedClassificationUnit() {
    return this.__findClassificationUnitByField('classification_unit');
  }

  get isAlreadyOnAccCoverPlusExtra() {
    return eq(get(this.payload, 'acc_cover_plan_type'), 'cover_plus_extra');
  }

  get calculationPlanFromServer() {
    return get(this.payload, ['calculations', 'plan']);
  }

  get calculationOnToolsFromServer() {
    return get(this.payload, ['calculations', 'on_tools']);
  }

  get calculationExistingFromServer() {
    return get(this.payload, ['calculations', 'existing']);
  }

  get determinedCalculationHeaderLabel() {
    if (!this.isTheSameClassificationUnit
      && !isEmpty(this.selectedClassificationUnit)
      && !isEmpty(this.selectedClassificationunitOnTools))
      return `From ${get(this.selectedClassificationUnit, 'name')} to ${get(this.selectedClassificationunitOnTools, 'name')}`
    return get(this.selectedClassificationUnit, 'name');
  }

  get pigSavingsPercentage() {
    return getPercentageValue(
      get(this.coverPlusCalculation, 'totalAmountPayableToAccIncludingGst', 0),
      get(this.determinedCoverPlusExtraCalculation, 'totalAmountPayableToAccIncludingGst', 0),
    );
  }

  get showCalculatedLevy() {
    return !isEmpty(this.coverPlusCalculation)
      && !isEmpty(this.determinedCoverPlusExtraCalculation);
  }

  get determinedCoverPlusExtraCalculation() {
    return this.isTheSameClassificationUnit
      ? this.coverPlusExtraCalculation
      : this.coverPlusExtraCalculationOnTools;
  }

  get totalIncomeProtectionAmount() {
    return floatDiff(
      get(this.coverPlusCalculation, 'nominatedCoverAmount', 0),
      floatFixer(get(this.payload, 'nominated_cover_amount', 0))
    );
  }

  get existingCoverPlusExtraCalculation() {
    if (!this.isAlreadyOnAccCoverPlusExtra) return null;
    const income = floatFixer(get(this.payload, 'income', 0));
    const cover = floatFixer(get(this.payload, 'existing_nominated_cover_amount', 0));
    const calculationFromServer = this.calculationExistingFromServer;
    if (isEmpty(calculationFromServer)) return null;
    const code = get(this.selectedClassificationUnit, 'code');
    const result = get(calculationFromServer, 'coverplus_extra_standard', {});
    return eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, income)
      && eq(result.rawNominatedCoverAmount, cover)
      ? result
      : null;
  }

  get coverPlusExtraCalculationOnTools() {
    const calculationFromServer = this.calculationOnToolsFromServer;
    const classificationUnit = this.selectedClassificationunitOnTools;
    if (isEmpty(calculationFromServer)) return null;
    const cover = floatFixer(get(this.payload, 'nominated_cover_amount', 0));
    const income = floatFixer(get(this.payload, 'income', 0));
    const code = get(classificationUnit, 'code');
    const result = get(calculationFromServer, 'coverplus_extra_standard', {});
    return eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, income)
      && eq(result.rawNominatedCoverAmount, cover)
      ? result
      : null;
  }

  get coverPlusExtraCalculation() {
    const calculationFromServer = this.calculationPlanFromServer;
    if (isEmpty(calculationFromServer)) return null;
    const cover = floatFixer(get(this.payload, 'nominated_cover_amount', 0));
    const income = floatFixer(get(this.payload, 'income', 0));
    const code = get(this.selectedClassificationUnit, 'code');
    const result = get(calculationFromServer, 'coverplus_extra_standard', {});
    return eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, income)
      && eq(result.rawNominatedCoverAmount, cover)
      ? result
      : null;
  }

  get coverPlusCalculation() {
    if (this.isAlreadyOnAccCoverPlusExtra)
      return this.existingCoverPlusExtraCalculation;
    const calculationFromServer = this.calculationPlanFromServer;
    if (isEmpty(calculationFromServer)) return null;
    const cover = floatFixer(get(this.payload, 'nominated_cover_amount', 0));
    const income = floatFixer(get(this.payload, 'income', 0));
    const code = get(this.selectedClassificationUnit, 'code');
    const result = get(calculationFromServer, 'coverplus_cover', {});
    return eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, income)
      && eq(result.rawNominatedCoverAmount, cover)
      ? result
      : null;
  }
}
