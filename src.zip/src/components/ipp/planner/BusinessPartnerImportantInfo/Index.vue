<template lang="pug">
div(class="business-partner-important-info")
  div(
    v-for="(partners, partnersIndex) in getChunkedValues"
    :class="{ 'q-mt-sm': partnersIndex !== 0 }"
    class="row q-col-gutter-md"
    :key="partnersIndex"
  )
    div(
      :class="getPartnersColumnClass(partners)"
      v-for="(partner, index) in partners"
      :key="index"
    )
      q-card(
        square
        :flat="flat"
        class="full-width relative-position"
      )
        q-card-section
         p(class="text-faded text-h6" v-text="partner.full_name")
        q-card-section
          q-input(
            required
            class="q-my-md"
            label="Full Name"
            :readonly="readonly"
            :value="partner.full_name"
            @input="value => __change(value, partner, 'full_name')"
          )
          q-input(
            class="q-my-md"
            label="ACC number"
            :readonly="readonly"
            :value="partner.acc_number_personal"
            @input="value => __change(value, partner, 'acc_number_personal')"
          )
          q-input(
            class="q-my-md"
            label="IRD number"
            :readonly="readonly"
            :value="partner.ird_number_personal"
            @input="value => __change(value, partner, 'ird_number_personal')"
          )
          date-picker(
            clearable
            :inline="false"
            class="q-my-md"
            :readonly="readonly"
            label="Date of Birth"
            :value="partner.date_of_birth"
            @change="value => __change(value, partner, 'date_of_birth')"
          )
          acc-details(
            :color="color"
            :model="partner"
            :readonly="readonly"
            @change="__change"
          )
          q-input(
            class="q-my-md"
            :readonly="readonly"
            label="Mobile Number"
            :value="partner.mobile_number"
            @input="value => __change(value, partner, 'mobile_number')"
          )
          q-input(
            type="email"
            class="q-my-md"
            :readonly="readonly"
            label="Email Address"
            :value="partner.email_address"
            @input="value => __change(value, partner, 'email_address')"
          )
          q-input(
            class="q-my-md"
            label="Address"
            :readonly="readonly"
            :value="partner.address"
            @input="value => __change(value, partner, 'address')"
          )
          q-select(
            emit-value
            map-options
            class="q-my-md"
            :color="color"
            label="Smoker?"
            :readonly="readonly"
            :options="booleanValues"
            :value="partner.smoking_status"
            @input="value => __change(value, partner, 'smoking_status')"
          )
          q-select(
            multiple
            use-chips
            emit-value
            map-options
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :options="existingCovers"
            label="Existing Insurance Providers"
            :value="partner.insurance_providers"
            @input="value => __change(value, partner, 'insurance_providers')"
          )
          q-select(
            multiple
            use-chips
            use-input
            :color="color"
            class="q-my-md"
            hide-dropdown-icon
            input-debounce="500"
            :readonly="readonly"
            new-value-mode="add-unique"
            label="Specify Insurance Providers"
            hint="Press Enter to persist changes"
            :value="partner.custom_insurance_providers"
            @input="value => __change(value, partner, 'custom_insurance_providers')"
          )
          q-select(
            emit-value
            map-options
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :options="booleanValues"
            :value="partner.has_will_in_place"
            label="Do you have a will in place?"
            @input="value => __change(value, partner, 'has_will_in_place')"
          )
          q-select(
            emit-value
            map-options
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :options="booleanValues"
            :value="partner.has_attorney"
            label="Do you have an enduring power of attorney will in place?"
            @input="value => __change(value, partner, 'has_attorney')"
          )
</template>

<script>
import { mapGetters } from 'vuex';
import AccDetails from './blocks/AccDetails';
import { set, chunk, debounce } from 'lodash';
import { QInput } from 'src/components/quasar';
import DatePicker from 'src/components/datepicker/DatePicker';

export default {
  name: 'business-partner-important-info',
  data: () => ({
    rawValues: [],
  }),
  created() {
    this.rawValues = this.values;
  },
  mounted() {
    if (this.readonly) {
      this.$nextTick(() => {
        const selector = '.business-partner-important-info .vdp-datepicker__calendar .cell.day.selected';
        const elements = Array.from(document.querySelectorAll(selector));
        if (!elements) return;
        elements.forEach((el) => {
          el.classList.add(`bg-${this.color}`);
        });
      });
    }
  },
  props: {
    values: {
      type: Array,
      required: true,
    },
    flat: {
      type: Boolean,
      default: false,
    },
    color: {
      type: String,
      default: 'primary',
    },
    readonly: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    __change: debounce(function (value, partner, field) {
      set(partner, field, value);
      this.$emit('change', this.rawValues);
    }, 500),
    getPartnersColumnClass(partners) {
      return {
        'col-md-6': partners.length > 1,
        'col-md-12': partners.length == 1,
        flex: true,
      };
    },
  },
  computed: {
    ...mapGetters('resources', [
      'booleanValues',
      'existingCovers',
      'inputDateFormat',
    ]),
    ...mapGetters('classificationUnit', ['mapClassificationUnitValues']),
    getChunkedValues() {
      return chunk(this.rawValues, 2);
    },
    orientation() {
      return this.values.length > 1
        ? 'vertical'
        : 'horizontal';
    },
  },
  components: {
    AccDetails,
    DatePicker,
  },
};
</script>
