<template lang="pug">
div
  p(class="text-faded no-margin-bottom") Shareholders
  div(
    class="row q-col-gutter-md"
    v-for="(person, index) in values"
    :class="{ 'q-my-md': index !== 0 }"
    :key="person.id"
  )
    div(class="col-md-4")
      q-input(readonly label="Name" :value="person.name")
    div(class="col-md-4")
      q-input(readonly suffix="%" label="Share Percentage" :value="person.income_percentage")
    div(class="col-md-4")
      q-input(
        readonly
        type="tel"
        prefix="$"
        label="Share Value"
        :value="getShareValue(person) | numberComma"
      )
</template>
<script>
import { QInput } from 'src/components/quasar';
import { floatFixer } from 'src/config/utils';

export default {
  name: 'share-holders-list',
  props: {
    orientation: {
      type: String,
      default: 'horizontal',
    },
    values: {
      type: Array,
      default: () => [],
    },
    businessValuationValue: String,
  },
  methods: {
    getShareValue({ income_percentage: percentage }) {
      const value = floatFixer(this.businessValuationValue, false);
      return floatFixer(value * (percentage / 100));
    },
  },
  components: {
    QInput,
  },
};
</script>
