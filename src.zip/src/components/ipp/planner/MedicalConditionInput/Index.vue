<template lang="pug">
div
  q-select(
    multiple
    use-chips
    use-input
    :color="color"
    :label="label"
    :value="__getVal"
    hide-dropdown-icon
    :readonly="readonly"
    @focusin.native="onModalShow"
  )
  div(v-if="readonly")
    include blocks/input
  div(v-else)
    q-dialog(
      full-width
      persistent
      no-backdrop-dismiss
      @show="__modalOnShow"
      @hide="onModalClose"
      v-model="showInputModal"
      :content-style="contentCss"
    )
      q-layout(container class="bg-white")
        q-header(class="bg-primary")
          q-toolbar
            q-btn(
              flat
              round
              v-close-popup
              color="tertiary"
              icon="keyboard_arrow_left"
            )
            q-toolbar-title {{ title }}
        q-page-container
          q-page(padding)
            div(class="row")
              include blocks/input
</template>

<script>
import { mapGetters } from 'vuex';
import { ModalToggleMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import Cleave from 'src/components/cleave/Cleave';
import { some, slice, cloneDeep, get, debounce, isArray, castArray, compact, last } from 'lodash';

export default {
  name: 'medical-condition-input',
  mixins: [ModalToggleMixin],
  data: () => ({
    showInputModal: false,
  }),
  props: {
    label: String,
    color: {
      type: String,
      default: 'primary',
    },
    title: {
      type: String,
      default: 'Medical Conditions',
    },
    categories: {
      type: Array,
      required: true,
    },
    payload: {
      type: Object,
      required: true,
    },
    field: {
      type: String,
      default: 'conditions',
    },
    readonly: Boolean,
  },
  methods: {
    onModalShow() {
      if (!this.readonly) {
        this.showInputModal = true;
      }
    },
    onModalClose() {
      this.__modalOnClose();
      this.showInputModal = false;
    },
    __visible({ field_name, field_type }, index, questions) {
      if (!this.readonly) return true;
      if (this.payload.answers[field_name]) return true;
      if(['caption'].includes(field_type)) {
        const remainingQuestions = slice(questions, index);
        return some(remainingQuestions, ({ field_name: field }) => {
          return !!this.payload.answers[field];
        });
      }
    },
    __setPayload: debounce(function (value, field) {
      const fields = field.split('.');
      if (fields.includes('answers')) {
        this.$set(this.payload['answers'], last(fields), value);
      }
      else {
        this.$set(this.payload, field, value);
      }

      if (!this.readonly && value) {
        const payload = this.payload;
        this.$emit('input', payload);
        this.$emit('change', payload);
      }
    }, 1),
    __getDefaultValue(value, input) {
      return ['radio'].includes(input) ? value : cloneDeep(compact(castArray(value)))
    }
  },
  computed: {
    contentCss: () => ({
      minHeight: '90vh',
      minWidth: '100%',
    }),
    showDateInput() {
      return this.readonly
        ? true
        : this.showInputModal;
    },
    __getVal() {
      return get(this.payload, this.field, []);
    },
  },
  components: {
    QInput,
    Cleave,
  },
};
</script>
