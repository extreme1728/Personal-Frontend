<template lang="pug">
div
  q-input(
    :label="label"
    :readonly="readonly"
    :value="rawValue.result"
    @focus="showInputModal = true"
  )
  q-dialog(
    full-width
    persistent
    no-backdrop-dismiss
    @show="onModalShow"
    @hide="onModalClose"
    v-model="showInputModal"
    :content-style="{ minHeight: '90vh'}"
  )
    q-layout(container class="bg-white")
      q-header(class="bg-primary")
        q-toolbar
          q-btn(
            flat
            round
            v-close-popup
            color="tertiary"
            icon="keyboard_arrow_left"
          )
          q-toolbar-title Calculate Body Mass Index
      q-page-container
        q-page(padding)
          div(class="row q-col-gutter-md")
            template(v-if="rawValue.height.imperial")
              div(class="col-md-4")
                q-input(label="Feet" v-model="rawValue.height.feet" type="number" :readonly="readonly")
              div(class="col-md-4")
                q-input(label="Inches" v-model="rawValue.height.inches" type="number" :readonly="readonly")
            template(v-else)
              div(class="col-md-8")
                q-input(label="Centimeters" v-model="rawValue.height.centimeters" type="number" :readonly="readonly")
            div(class="col-md-4")
              q-toggle(
                left-label
                :readonly="readonly"
                v-model="rawValue.height.imperial"
                :label="getHeightMeasuringUnitLabel"
              )
          div(class="row q-col-gutter-md q-mt-sm")
            div(class="col-md-8" v-if="rawValue.weight.imperial")
              q-input(label="Pounds" v-model="rawValue.weight.pounds" type="number" :readonly="readonly")
            div(class="col-md-8" v-else)
              q-input(label="Kilograms" v-model="rawValue.weight.kilograms" type="number" :readonly="readonly")
            div(class="col-md-4")
              q-toggle(
                left-label
                :readonly="readonly"
                v-model="rawValue.weight.imperial"
                :label="getWeightMeasuringUnitLabel"
              )
          q-item(class="q-my-md" v-if="calculation")
            q-item-section(side)
              q-icon(name="accessibility_new")
            q-item-section
              p(class="text-faded") Body Mass Index
              q-slider(
                readonly
                label-always
                :min="0"
                color="primary"
                :max="maximumBmiValue"
                v-model="calculation.value"
              )
          transition(
            tag="div"
            class="row q-mt-md"
            enter-active-class="animated fadeIn"
            leave-active-class="animated fadeOut"
          )
            q-banner(class="bg-amber text-white col-md-12" v-show="bmiLoadings.life.show && bmiLoadings.livingAssurance.show")
              template(v-slot:avatar)
                q-icon(name="warning" color="white")
              p(class="no-margin") Warning: Potential Loadings may apply.
              p(class="no-margin") Percentages indicative only and depend on other health factors.
          transition-group(
            tag="div"
            enter-active-class="animated fadeIn"
            leave-active-class="animated fadeOut"
            class="row q-col-gutter-md q-mt-lg justify-center"
          )
            div(class="col-md-6" key="life" v-show="bmiLoadings.life.show")
              p(class="text-faded") Life
              q-knob(
                show-value
                readonly
                size="12em"
                color="primary"
                track-color="grey-3"
                :thickness="0.2"
                :value="bmiLoadings.life.value"
                :max="bmiLoadings.life.max"
              )
                p(class="text-faded text-center" style="font-size: 45%") {{ bmiLoadings.life.label || `${bmiLoadings.life.value}%` }}
            div(class="col-md-6" key="livingAssurance" v-show="bmiLoadings.livingAssurance.show")
              p(class="text-faded") Living Assurance
              q-knob(
                show-value
                readonly
                size="12em"
                color="primary"
                track-color="grey-3"
                :thickness="0.2"
                :value="bmiLoadings.livingAssurance.value"
                :max="bmiLoadings.livingAssurance.max"
              )
                p(class="text-faded text-center" style="font-size: 45%") {{ bmiLoadings.livingAssurance.label || `${bmiLoadings.livingAssurance.value}%` }}
          transition-group(
            tag="div"
            enter-active-class="animated fadeIn"
            leave-active-class="animated fadeOut"
            class="row q-col-gutter-md q-mt-lg justify-center"
          )
            div(class="col-md-6" key="disabilityBenefits" v-show="bmiLoadings.disabilityBenefits.show")
              p(class="text-faded") Disability Benefits
              q-knob(
                show-value
                readonly
                size="12em"
                color="primary"
                track-color="grey-3"
                :thickness="0.2"
                :value="bmiLoadings.disabilityBenefits.value"
                :max="bmiLoadings.disabilityBenefits.max"
              )
                p(class="text-faded text-center" style="font-size: 45%") {{ bmiLoadings.disabilityBenefits.label || `${bmiLoadings.disabilityBenefits.value}%` }}
            div(class="col-md-6" key="tpd" v-show="bmiLoadings.tpd.show")
              p(class="text-faded") TPD
              q-knob(
                show-value
                readonly
                size="12em"
                color="primary"
                track-color="grey-3"
                :thickness="0.2"
                :value="bmiLoadings.tpd.value"
                :max="bmiLoadings.tpd.max"
              )
                p(class="text-faded text-center" style="font-size: 45%") {{ bmiLoadings.tpd.label || `${bmiLoadings.tpd.value}%` }}
</template>

<script>
import { ModalToggleMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { cloneDeep, toNumber, merge } from 'lodash';
import InsuranceDecisionGuideService from 'src/services/ipp/bmi/InsuranceDecisionGuideService';

const bodyMassIndexSchema = {
  height: {
    imperial: true,
    feet: 0,
    inches: 0,
    centimeters: 0,
  },
  weight: {
    imperial: true,
    pounds: 0,
    kilograms: 0,
  },
  result: null,
};

export default {
  name: 'body-mass-index-input',
  mixins: [ModalToggleMixin],
  data: () => ({
    showInputModal: false,
    maximumBmiValue: 50,
    rawValue: cloneDeep(bodyMassIndexSchema),
  }),
  created() {
    this.mergeRawValues();
  },
  props: {
    label: String,
    value: {
      type: [Object, Array],
      default: () => cloneDeep(bodyMassIndexSchema),
    },
    readonly: Boolean,
  },
  methods: {
    mergeRawValues() {
      if (this.value instanceof Object
        && this.value.constructor === Object) {
        this.rawValue = {
          ...this.rawValue,
          ...this.value
        };
      }
    },
    onModalShow() {
      this.__modalOnShow();
      this.mergeRawValues();
    },
    onModalClose() {
      this.__modalOnClose();
      if (! this.readonly) {
        this.$emit('input', this.rawValue);
        this.$emit('change', this.rawValue);
      }
      this.showInputModal = false;
    },
    calculateBMI(weight, height) {
      const result = (weight / Math.pow((height / 100), 2))
      const value = Math.round(result * 10000) / 10000;
      const defaults = {
        result: 0,
        value: 0,
      };
      if (!window.isFinite(value)
        || !window.isFinite(result)) return defaults;
      return merge({}, defaults, { result, value });
    },
  },
  computed: {
    getHeightMeasuringUnitLabel() {
      const { height: { imperial } } = this.rawValue;
      return imperial ? 'Imperial' : 'Metric';
    },
    getWeightMeasuringUnitLabel() {
      const { weight: { imperial } } = this.rawValue;
      return imperial ? 'Imperial' : 'Metric';
    },
    metricHeight() {
      const { height } = this.rawValue;
      const toMetrict = (feet = 0, inch = 0) => (feet * 30.48 + inch * 2.54);
      return height.imperial
        ? toMetrict(height.feet, height.inches)
        : (height.centimeters);
    },
    metrictWeight() {
      const { weight } = this.rawValue;
      const toMetrict = (pound = 0) => (pound * 0.453592);
      return weight.imperial
        ? toMetrict(weight.pounds)
        : weight.kilograms;
    },
    calculation() {
      const bmi = this.calculateBMI(this.metrictWeight, this.metricHeight);
      this.rawValue.result = bmi.value;
      return { value: bmi.value };
    },
    bmiLoadings() {
      const { calculation: { value: bmi } } = this;
      const { all } = (new InsuranceDecisionGuideService(bmi));
      return all;
    },
  },
  components: {
    QInput,
  },
};
</script>
