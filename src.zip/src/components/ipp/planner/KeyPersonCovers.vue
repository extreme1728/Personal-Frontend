<template lang="pug">
div(class="key-cover-persons")
  div(
    v-for="(persons, personsIndex) in getChunkedValues"
    :class="{ 'q-mt-sm': personsIndex !== 0 }"
    class="row q-col-gutter-md"
    :key="personsIndex"
  )
    div(
      :class="getPersonsColumnClass(persons)"
      v-for="(person, index) in persons"
      :key="person.id"
    )
      q-card(:flat="flat" class="full-width relative-position")
        q-card-section
          p(class="text-faded text-h6") {{ person.name || 'Key Person' }}
        q-card-section(class="card-main")
          q-input(
            label="Name"
            class="q-my-md"
            :readonly="readonly"
            :value="person.name"
            @input="value => modifyPerson(value, person, 'name')"
          )
          q-input(
            class="q-my-md"
            :readonly="readonly"
            label="Role in business"
            :value="person.role_in_business"
            @input="value => modifyPerson(value, person, 'role_in_business')"
          )
          date-picker(
            class="q-my-md"
            :disabled="readonly"
            label="Date of Birth"
            :value="person.date_of_birth"
            @change="value => modifyPerson(value, person, 'date_of_birth')"
          )
          q-select(
            emit-value
            map-options
            class="q-my-md"
            label="Smoking Status"
            :options="booleanValues"
            :value="person.smoking_status"
            @input="value => modifyPerson(value, person, 'smoking_status')"
          )
          q-input(
            prefix="$"
            type="tel"
            v-money="{}"
            align="right"
            label="Income"
            class="q-my-md"
            :value="person.income"
            @input="value => modifyPerson(value, person, 'income')"
          )
          q-select(
            emit-value
            map-options
            class="q-my-md"
            label="Payment frequency"
            :value="person.payment_frequency"
            :options="mortgageRepaymentMethods"
            @input="value => modifyPerson(value, person, 'payment_frequency')"
          )
          q-input(
            prefix="$"
            type="tel"
            v-money="{}"
            align="right"
            class="q-my-md"
            :value="person.gross_income"
            label="Gross Income of the Business"
            @input="value => modifyPerson(value, person, 'gross_income')"
          )
          p(class="text-faded") Gross Income Percentage Responsible for
          q-slider(
            snap
            markers
            :min="1"
            :step="0.5"
            label-always
            :decimals="1"
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            :value="person.income_percentage"
            :max="getMaxiumGrossIncomePercentage"
            :label-value="`${person.income_percentage}%`"
            @input="value => modifyPerson(value, person, 'income_percentage')"
          )
          q-select(
            multiple
            use-chips
            emit-value
            map-options
            :color="color"
            class="q-my-md"
            :readonly="readonly"
            label="Insurance Providers"
            :options="incomeInsuranceProviders"
            :value="person.insurance_calculations"
            @input="value => modifyPerson(value, person, 'insurance_calculations')"
          )
          q-input(
            v-show="person.insurance_calculations.includes('fidelity')"
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="Fidelity Life Income Maximum"
            :value="getFidelityIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            v-show="person.insurance_calculations.includes('partners_life')"
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="Partners Life Income Maximum"
            :value="getPartnersLifeIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            v-show="person.insurance_calculations.includes('aia')"
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="AIA Income Maximum"
            :value="getAiaIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            v-show="person.insurance_calculations.includes('asteron')"
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="Asteron Income Maximum"
            :value="getAsteronIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            v-show="person.insurance_calculations.includes('sovereign')"
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="Sovereign Income Maximum"
            :value="getSovereignIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            readonly
            prefix="$"
            align="right"
            class="q-my-md"
            label="Income Maximum"
            :value="getCalculatedIncomeMaximum(person.gross_income, person.income_percentage) | numberComma"
          )
          q-input(
            prefix="$"
            align="right"
            v-money="{}"
            class="q-my-md"
            :readonly="readonly"
            label="Replacement cost of person in business"
            hint="Clicking the icon will override the value based on the given calculation."
            :value="person.income_needing_to_be_protected"
            @input="value => modifyPerson(value, person, 'income_needing_to_be_protected')"
          )
            template(v-slot:append)
              q-icon(name="autorenew" class="cursor-pointer" @click="incomeNeedingToBeProtectedHandler(person)")
          q-input(
            label="Notes"
            class="q-my-md"
            type="textarea"
            :max-height="100"
            :readonly="readonly"
            :value="person.notes"
            @input="value => modifyPerson(value, person, 'notes')"
          )
        q-card-actions(v-if="!readonly" class="absolute-bottom")
          q-btn(
            flat
            icon="remove"
            label="Remove"
            color="negative"
            class="full-width"
            @click="e => removeKeyPersonCover(person)"
          )
</template>

<script>
import { mapGetters } from 'vuex';
import { set, chunk, debounce } from 'lodash';
import { QInput } from 'src/components/quasar';
import { KeyPersonCoverMixin } from 'src/mixins';
import DatePicker from 'src/components/datepicker/DatePicker';

export default {
  name: 'key-cover-persons',
  mixins: [KeyPersonCoverMixin],
  props: {
    values: {
      type: Array,
      required: true,
    },
    readonly: {
      type: Boolean,
      default: false,
    },
    flat: {
      type: Boolean,
      default: false,
    },
    color: {
      type: String,
      default: 'primary',
    },
  },
  mounted() {
    if (this.readonly) {
      this.$nextTick(() => {
        const selector = '.key-cover-persons .vdp-datepicker__calendar .cell.day.selected';
        const elements = Array.from(document.querySelectorAll(selector));
        if (!elements) return;
        elements.forEach((el) => {
          el.classList.add(`bg-${this.color}`);
        });
      });
    }
  },
  methods: {
    getPersonsColumnClass(persons) {
      return {
        'col-md-6': persons.length > 1,
        'col-md-12': persons.length == 1,
        flex: true,
      };
    },
    incomeNeedingToBeProtectedHandler(person) {
      const { income, payment_frequency } = person;
      const value =this.getIncomeNeedingToBeProtected(income, payment_frequency);
      this.modifyPerson(value, person, 'income_needing_to_be_protected');
    },
    modifyPerson: debounce(function (value, person, field) {
      set(person, field, value);
      this.$emit('input', this.values);
      this.$emit('change', this.values);
    }, 500),
    async removeKeyPersonCover(person) {
      try {
        await this.$q.dialog({
          cancel: true,
          title: 'Prompt',
          preventClose: true,
          message: 'This action cannot be undone and will result of losing data.',
        });
        this.$emit('remove', person);
      } catch (e) {}
    },
  },
  computed: {
    ...mapGetters('resources', {
      mortgageRepaymentMethods: 'mortgageRepaymentMethods',
    }),
    getChunkedValues() {
      return chunk(this.values, 2);
    },
    getMaxiumGrossIncomePercentage() {
      const limit = 100;
      const persons = this.values;
      if (persons.length && persons.length > 1)
        return Math.floor(limit / persons.length);
      return limit;
    },
  },
  components: {
    QInput,
    DatePicker,
  },
};
</script>

<style lang="stylus">
.key-cover-persons
  .date-picker-field
    >.row.col
      height 400px !important
  .card-main
    padding-bottom 4em
</style>
