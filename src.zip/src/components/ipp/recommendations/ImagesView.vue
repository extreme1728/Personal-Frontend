<template lang="pug">
q-dialog(
  :value="show"
  @show="$emit('show')"
  @cancel="$emit('cancel')"
  :content-style="getContentStyles"
)
  div(class="modal-header")
    h6(slot="header" class="text-faded no-margin-top") Images
  div(class="modal-body modal-message")
    div(
      class="row q-my-md items-center"
      v-for="(image, index) in images"
      :key="index + 1"
    )
      div(class="offset-md-1 col-md-10")
        div(style="width: 400px; margin: 0 auto")
          svg-filter-image(:src="image.url" :img-styles="imgStyles")
        div(class="row q-col-gutter-md")
          div(class="col-md-10")
            q-field(label="Filename" class="q-my-md" :orientation="orientation")
              q-input(disable :value="image.name")
          div(class="col-md-2")
            q-field(label="Visible" class="q-my-md" :orientation="orientation")
              q-toggle(
                :value="image.visible"
                @change="_ => modifyReportItem(_, image, 'visible')"
              )
        q-field(label="Description (optional)" :orientation="orientation")
          q-input(
            type="textarea"
            row="170"
            :value="image.description"
            @change="_ => modifyReportItem(_, image, 'description')"
          )
        q-field(class="q-my-md")
          q-btn(
            class="full-width"
            color="red-5"
            label="Remove"
            icon="remove"
            @click="onRemove(image)"
          )
  div(class="modal-buttons row q-mt-md")
    q-btn(outline color="primary" label="Close" @click="$emit('cancel')")
</template>

<script>
import { get, set, cloneDeep } from 'lodash';
import SvgFilterImage from 'src/components/vlazyimage/SvgFilterImage';

export default {
  name: 'item-recommendations-images-view',
  props: {
    show: Boolean,
    report: {
      type: Object,
      required: true,
    },
  },
  methods: {
    modifyReportItem(value, image, field) {
      const payload = set(image, field, value);
      this.$emit('change', cloneDeep(payload));
    },
    async onRemove(image) {
      try {
        await this.$q.dialog({
            title: 'Confirm',
            message: 'This action cannot be undone and will result of losing data. Would you like to continue?',
            cancel: true,
            preventClose: true,
        });
        this.$emit('remove', image);
      } catch (e) {
        console.error(e);
      }
    },
  },
  computed: {
    images() {
      return get(this.report, 'images', []);
    },
    getContentStyles() {
      return {
        minWidth: '80vw',
        minHeight: '30vw',
      };
    },
    imgStyles: () => ({
      height: 'auto',
      width: '100%',
      display: 'block',
      margin: '0 auto'
    }),
    orientation: () => ('vertical'),
  },
  components: {
    SvgFilterImage,
  },
};
</script>
