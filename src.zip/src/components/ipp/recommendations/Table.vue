<template lang="pug">
div(class="item__table position-relative")
  div(id="item__table--header-container")
    div(class="row align-top")
      div(class="col-md-2")
      template(v-if="!isPreAndPostUnderwriting")
        div(class="col-md-5")
          h6(:class="headerClasses" class="text-header-existing" v-show="showExistingTitle") Existing
        div(class="col-md-5")
          h6(:class="headerClasses" class="text-header-proposed") Proposed
      template(v-else)
        div(class="col-md-5")
          h6(:class="headerClasses" class="text-header-existing" v-show="showExistingTitle") Pre-Underwriting
        div(class="col-md-5")
          h6(:class="headerClasses" class="text-header-proposed") Post Underwriting
  div(id="item__table--container")
    div(v-for="(value, valueIndex) in mapValues")
      div(class="row align-top q-mt-md")
        div(class="col-md-12")
            h6(class="text-left no-margin" v-if="readOnly" v-text="value[0]")
            q-input(
              v-else
              filled
              align="center"
              :value="value[0]"
              class="full-width text-weight-bold"
            )
      div(class="row q-col-gutter-xs align-top q-mt-md")
        div(class="col-md-2 policy-header-column")
          template(v-for="(length, lengthIndex) in rangeValueRow(value[1])")
            div(
              class="row text-center policy-header-item"
              :class="{'item__table--background': (lengthIndex % 2)}"
            )
              div(class="col-md-12")
                include blocks/policy-headers
        div(
          v-if="!isPreAndPostUnderwriting"
          :class="getDeterminedColumnClass(value[1])['existing']"
        )
          template(v-for="provider in filterByType(value[1], ['offer_type', 'existing'])")
            div(
              class="row policy-item"
              v-for="(policy, policyIndex) in provider.policies"
              :class="{'item__table--background': (policyIndex % 2)}"
            )
              div(class="col-md-12")
                include blocks/policy-item-table-template
        div(:class="getDeterminedColumnClass(value[1])[isPreAndPostUnderwriting ? 'existing' : 'proposed']")
          template(v-for="provider in filterByType(value[1], ['offer_type', 'proposed'])")
            div(
              class="row policy-item"
              v-for="(policy, policyIndex) in provider.policies"
              :class="{'item__table--background': (policyIndex % 2)}"
            )
              div(class="col-md-12")
                include blocks/policy-item-table-template
        div(
          v-if="isPreAndPostUnderwriting"
          :class="getDeterminedColumnClass(value[1])['proposed']"
        )
          template(v-for="provider in filterByType(value[1], ['offer_type', 'underwriting'])")
            div(
              class="row policy-item"
              v-for="(policy, policyIndex) in provider.policies"
              :class="{'item__table--background': (policyIndex % 2)}"
            )
              div(class="col-md-12")
                include blocks/policy-item-table-template
  div(class="row" id="item__table-footer")
    div(class="offset-md-2 col-md-5" v-if="showExistingTitle")
      p(class="text-weight-bold" style="font-size: 0.9em") Total Monthly Premium
      p {{ getTotalMonthlyPremiumFromArray.existing | tableMoneyFormat }}
    div(:class="[showExistingTitle ? 'col-md-5' : 'col-md-10 offset-md-2']")
      p(class="text-weight-bold" style="font-size: 0.9em") Total Monthly Premium
      p {{ getTotalMonthlyPremiumFromArray.proposed | tableMoneyFormat }}
  div(
    v-if="readOnly && (rawValues.comments && rawValues.comments.length)"
    class="row q-my-md"
  )
    div(class="col-md-12")
      p(class="text-faded") Comment/Explanation
      p(class="description" v-html="nltobr(rawValues.comments)")
  div(
    v-if="shouldShowReasons"
    class="row"
  )
    div(class="col-md-12")
      p(class="text-faded") Reason/s for replacement of existing cover
      p(class="description" v-html="nltobr(rawValues.reasons)")
  div(
    class="row q-my-md"
    v-if="readOnly"
    v-for="image in rawValues.images"
  )
    div(class="col-md-12")
      div(class="full-width" style="margin: 0 auto")
        img(:src="image.url" :style="imgStyles")
</template>

<script>
import { dom } from 'quasar';
import { mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { recommendationSchema } from 'src/services/ipp/reports/recommendations/Service';
import { nltobr, floatFixer, floatTotals, numberWithCommas, groupBy } from 'src/config/utils';
import { set, isEmpty, some, pick, lowerCase, filter, max, range, cloneDeep, castArray, chunk, indexOf, flatMap, find } from 'lodash';
import SvgFilterImage from 'src/components/vlazyimage/SvgFilterImage';

export default {
  name: 'item-recommendations-table',
  data: () => ({
    rawValues: cloneDeep(recommendationSchema),
  }),
  created() {
    this.rawValues = this.values;
  },
  mounted() {
    this.$emit('load');
  },
  updated() {
    if (!this.readOnly) {
      this.updateTableHeight();
    }
  },
  watch: {
    rawValues: {
      handler: 'rawValuesHandler',
      deep: true,
    },
    values: {
      handler: 'valuesHandler',
      deep: true,
    },
  },
  props: {
    values: {
      type: Object,
      required: true,
    },
    readOnly: {
      type: Boolean,
      default: false,
    },
    partnerName: {
      type: String,
      default: null,
    },
    showPartnerValues: Boolean,
    isPreAndPostUnderwriting: Boolean,
  },
  methods: {
    updateTableHeight(includeMargin = false) {
      try {
        const { name: routeName } = this.$route;
        const footerPaddingTop = this.readOnly && routeName === 'document.plan.preview'
          ? '10em' : this.readOnly
          ? '0' : '10em';

        const footerElement = document.getElementById('item__table-footer');
        dom.css(footerElement, {
          'padding-top': footerPaddingTop,
        });

        const outerHeight = (el) => {
          const padding = this.readOnly ? 5 : 0;
          let height = el.offsetHeight;
          const style = getComputedStyle(el);
          if (includeMargin) {
            height += window.parseInt(style.marginTop) + window.parseInt(style.marginBottom);
          }
          return height + padding;
        };

        const container = document.getElementById('item__table--container');
        // console.log(container);
        const existing = container.getElementsByClassName('existing-column');
        const proposed = container.getElementsByClassName('proposed-column');
        const headerColumn = container.getElementsByClassName('policy-header-column');

        // @TODO: Determine if who has the most items on each column.
        let determinedColumn = 'existing';
        let existingPolicyItemCount = 0;
        let proposedPolicyItemCount = 0;

        [...existing].forEach(el => {
          existingPolicyItemCount += el.getElementsByClassName('policy-item').length || 0;
        });

        [...proposed].forEach(el => {
          proposedPolicyItemCount += el.getElementsByClassName('policy-item').length || 0;
        });

        determinedColumn = (existingPolicyItemCount > proposedPolicyItemCount)
                            ? 'existing'
                            : 'proposed';

        [...eval(determinedColumn)].forEach((el, wrapperIndex) => {
          const itemColumns = determinedColumn === 'existing'
                            ? ['existingItems', 'proposedItems']
                            : ['proposedItems', 'existingItems'];

          const existingItems = existing[wrapperIndex].getElementsByClassName('policy-item');
          const proposedItems = proposed[wrapperIndex].getElementsByClassName('policy-item');

          [...eval(itemColumns[0])].forEach((element, index) => {
            const rowOneHeight = outerHeight(element, includeMargin);
            const rowTwo = eval(itemColumns[1])[index];
            const rowTwoHeight = isEmpty(rowTwo)
                                ? rowOneHeight
                                : outerHeight(rowTwo, includeMargin);
            const commentSection = isEmpty(proposedItems[index])
                                  ? null
                                  : proposedItems[index].getElementsByClassName('comment-section')[0];
            const commentSectionHeight = isEmpty(commentSection)
                                        ? 0 : outerHeight(commentSection, includeMargin);
            const totalHeight = max([rowOneHeight, rowTwoHeight]) + commentSectionHeight;
            const headerRow = headerColumn[wrapperIndex].getElementsByClassName('policy-header-item')[index];
            // if (isEmpty(headerRow)) return;

            const height = `${totalHeight}px`;
            const marginTop = this.readOnly ? '1em' : '4em';
            dom.css(element, { height, marginTop });
            dom.css(headerRow, { height, marginTop });

            if (isEmpty(rowTwo)) return;
            dom.css(rowTwo, { height, marginTop });
          });
        });
      }
      catch (e) { console.error(e); }
    },
    rangeValueRow(values) {
      const existingKey = this.isPreAndPostUnderwriting ? 'proposed' : 'existing';
      const existing = this.filterByType(values, ['offer_type', existingKey]);
      const proposedKey = this.isPreAndPostUnderwriting ? 'underwriting' : 'proposed';
      const proposed = this.filterByType(values, ['offer_type', proposedKey]);
      const existingItems = ((existing[0] && existing[0].policies) || []);
      const proposedItems = ((proposed[0] && proposed[0].policies) || []);
      const row = max([existingItems.length, proposedItems.length]);
      return range(row);
    },
    filterByType(values, predicate) {
      return filter(values, predicate);
    },
    valuesHandler(values) {
      this.rawValues = values;
    },
    rawValuesHandler(values) {
      this.$emit('change', values);
    },
    modifyFields(policy, value, field) { set(policy, field, value); },
    removePolicyItem(type, valueIndex, policyIndex) {
      const item = this.rawValues[type][valueIndex]['policies'][policyIndex];
      const items = this.rawValues[type][valueIndex]['policies'];
      items.splice(indexOf(items, item), 1);
    },
    shouldShowComment(policy) {
      if ((this.readOnly && this.hasComments)
        && some(pick(policy, ['comments']), isEmpty)) return false;
      return this.hasComments;
    },
    getCommentSectionClasses({ offer_type }) {
      const offerTypeKey = this.isPreAndPostUnderwriting ? 'underwriting' : 'proposed';
      const show = offer_type === offerTypeKey && this.readOnly;
      return {
        'comment-section': show,
        'q-pt-md': show,
        'q-pb-lg': show,
      };
    },
    getDeterminedColumnClass(value) {
      const existingKey = this.isPreAndPostUnderwriting ? 'proposed' : 'existing';
      const existingValues = this.filterByType(value, ['offer_type', existingKey]);
      let existing = { 'col-md-5': true, 'existing-column': true };
      let proposed = { 'col-md-5': true, 'proposed-column' : true  };
      if (isEmpty(existingValues)) {
        existing = {
          ...existing,
          ...{ 'hidden': true  },
        };
        proposed = {
          ...proposed,
          ...{
            'col-md-5': false,
            'col-md-10': true,
          },
        };
      }
      return { existing, proposed };
    },
    getDeterminedSumAssuredLabel(key, values) {
      const policies = flatMap(castArray(values), ({ policies }) => policies[key] || []);
      let isHealthCover = false;
      for (let i = 0; i < policies.length; i++) {
        const { cover_type, provider } = policies[i];
        if (isEmpty(cover_type) && isEmpty(provider)) continue;
        const providerInstance = find(this.insuranceProviders, ['name', provider]);
        if (!isEmpty(providerInstance) && providerInstance.health_cover) {
          isHealthCover = true;
          continue;
        }
        const coverTypeInstance = find(this.insuranceProvidersCovers, ['name', cover_type]);
        if (!isEmpty(coverTypeInstance) && coverTypeInstance.health_cover) {
          isHealthCover = true;
          continue;
        }
        isHealthCover = false;
      }
      return isHealthCover ? 'Excess' : 'Sum Assured';
    },
    nltobr: nltobr,
  },
  filters: {
    lowerCase(value) {
      return lowerCase(value);
    },
    tableMoneyFormat(v) {
      return `$${numberWithCommas(v)}`;
    },
  },
  computed: {
    ...mapGetters('insuranceProvider', {
      insuranceProviders: 'providers',
      insuranceProvidersCovers: 'providerCovers',
    }),
    headerClasses() {
      return {
        'report-item__header': true,
        'no-margin': true,
        'text-center': !this.readOnly
      }
    },
    mapValues() {
      return Array.from(groupBy(this.filteredValues, value => value.name));
    },
    filteredValues() {
      const { existing, proposed, underwriting } = this.rawValues;
      let values = this.isPreAndPostUnderwriting
        ? [...castArray(proposed), ...castArray(underwriting)]
        : [...castArray(existing), ...castArray(proposed)];
      return filter(values, ({ name }) => {
        if (this.showPartnerValues) return true;
        return name != this.partnerName;
      });
    },
    getTotalMonthlyPremiumFromArray() {
      let { existing, proposed, underwriting } = this.rawValues;
      existing = filter(existing, ({ name }) => {
        if (this.showPartnerValues) return true;
        return name != this.partnerName;
      });
      proposed = filter(proposed, ({ name }) => {
        if (this.showPartnerValues) return true;
        return name != this.partnerName;
      });
      underwriting = filter(underwriting, ({ name }) => {
        if (this.showPartnerValues) return true;
        return name != this.partnerName;
      });
      const existingTotals = [];
      const proposedTotals = [];
      const underwritingTotals = [];
      existing.forEach(({ policies }) => {
        if (!isEmpty(policies) && policies instanceof Array) {
          policies.forEach(({ premium }) => {
            existingTotals.push(Math.abs(numberWithCommas(premium, false)));
          });
        }
      });
      proposed.forEach(({ policies }) => {
        if (!isEmpty(policies) && policies instanceof Array) {
          policies.forEach(({ premium }) => {
            proposedTotals.push(Math.abs(numberWithCommas(premium, false)));
          });
        }
      });
      underwriting.forEach(({ policies }) => {
        if (!isEmpty(policies) && policies instanceof Array) {
          policies.forEach(({ premium }) => {
            underwritingTotals.push(Math.abs(numberWithCommas(premium, false)));
          });
        }
      });
      const existingTotalAmount = this.isPreAndPostUnderwriting
        ? proposedTotals
        : existingTotals;
      const proposedTotalAmount = this.isPreAndPostUnderwriting
        ? underwritingTotals
        : proposedTotals;
      return {
        existing: floatFixer(floatTotals(existingTotalAmount)),
        proposed: floatFixer(floatTotals(proposedTotalAmount)),
      };
    },
    showExistingTitle() {
      const offerTypeKey = this.isPreAndPostUnderwriting
        ? 'proposed'
        : 'existing';
      return some(this.mapValues, function(value) {
        return !isEmpty(filter(value[1], ['offer_type', offerTypeKey]));
      });
    },
    shouldShowReasons() {
      const { reasons } = this.rawValues;
      return this.readOnly
        && (reasons && reasons.length)
        && !this.isPreAndPostUnderwriting;
    },
    imgStyles: () => ({
      height: 'auto',
      width: '100%',
      display: 'block',
      margin: '0 auto'
    }),
    policyHeaderStyles() {
      return {
        'font-size': '0.9em',
        'height': this.readOnly ? 'auto' : '56px',
      };
    },
  },
  components: {
    QInput,
    SvgFilterImage,
  },
};
</script>

<style lang="stylus" scoped>

.description
  font-size 0.9em
  text-align justify

.policy-item, .policy-header-item
  margin-top 1em
  margin-bottom 1em

.policy-item
  .row
      padding-left 0.5em
      padding-right 0.5em
  .row:nth-last-child(1)
    padding-bottom 0.5em

.item__table__body
  margin-top 1.2em
  margin-bottom 2em

.item__table--background
  .background
    background $table-stripe-color
    margin-top 0px
    padding-top 16px

.report-item__header
  font-size 2em !important

.align-top
  vertical-align top

.bottom-less
  position absolute !important
  bottom -5em

.comment-section
  background #ffffff
  position absolute
  left 0
</style>
