<template lang="pug">
q-dialog(
  full-width
  :value="show"
  @show="$emit('show')"
  @cancel="$emit('cancel')"
  :content-style="getContentStyles"
)
  q-card
    q-card-section
      p(class="text-h6 text-faded") Planner Reports
    q-card-section
      div(
        v-if="getChunkedReports.length"
        class="row q-col-gutter-md justify-center"
        v-for="(reports, reportsIndex) in getChunkedReports"
        :key="reportsIndex"
      )
        div(class="col-md-4" v-for="report in reports" :key="report.id")
          q-card(square)
            q-card-section
              div(class="row items-center no-wrap")
                div(class="col")
                  q-input(
                    debounce="500"
                    label="Report Name"
                    :value="report.name"
                    @input="value => modifyReportItem(value, report, 'name')"
                  )
                div(class="col-auto")
                  q-chip(icon="photo_library" color="cyan" text-color="white") Images {{ report.images.length || 0 }}
            q-card-section
              q-select(
                emit-value
                map-options
                class="q-my-md"
                label="Category"
                :value="report.category"
                :options="getReportCategories"
                @input="value => modifyReportItem(value, report, 'category')"
              )
              q-select(
                emit-value
                map-options
                class="q-my-md"
                label="Insurance Plan Type"
                :value="report.insurance_plan_type"
                :options="getReportInsurancePlanTypes"
                @input="value => modifyReportItem(value, report, 'insurance_plan_type')"
              )
              q-input(
                :rows="4"
                debounce="500"
                type="textarea"
                class="q-my-md"
                :max-height="90"
                label="Description"
                :value="report.description || 'No Description'"
                @input="value => modifyReportItem(value, report, 'description')"
              )
            q-card-actions(align="around")
              q-btn(flat icon="remove" color="secondary" label="Remove" @click="e => onHandleReportRemove(report)")
              q-btn(icon="open_in_new" color="amber" label="Preview" @click="e => onHandleReportViewRedirect(report)")
              q-btn(icon="check" color="primary" label="Apply" @click="e => $emit('select', report)")
      div(class="text-center" v-if="!getChunkedReports.length")
        p
          img(
            src="~assets/sad.svg"
            style="width:30vw; max-width:150px;"
          )
        p(class="text-faded") No Reports Found Yet...
    q-card-actions(align="right")
      q-btn(flat color="secondary" label="Close" v-close-popup)
</template>

<script>
import { openURL } from 'quasar';
import { mapGetters } from 'vuex';
import { chunk, set, cloneDeep } from 'lodash';

export default {
  name: 'item-recommendations-reports-view',
  props: {
    show: Boolean,
    reports: {
      type: Array,
      default: () => cloneDeep([]),
    },
  },
  methods: {
    async onHandleReportRemove(report) {
      try {
        await this.$q.dialog({
            title: 'Confirm',
            message: 'This action cannot be undone and will result of losing data. Would you like to continue?',
            cancel: true,
            preventClose: true,
        });
        await this.$emit('remove', report);
      } catch (e) {}
    },
    onHandleReportViewRedirect({ id: reportId, insurance_plan_type: type }) {
      const { id: plannerId } = this.plan;
      const { href } = this.$router.resolve({
        name: 'document.open.plan.report.preview',
        params: {
          plannerId,
          reportId,
        },
        query: {
          type,
        },
      });
      openURL(href);
    },
    modifyReportItem(value, report, field) {
      const payload = set(report, field, value);
      this.$emit('change', cloneDeep(payload));
    },
  },
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    ...mapGetters('insuranceProviderReport', {
      getReportCategories: 'getReportCategories',
      getReportInsurancePlanTypes: 'getReportInsurancePlanTypes',
    }),
    getChunkedReports() {
      return chunk(this.reports, 3);
    },
    getContentStyles() {
      return {
        minWidth: '80vw',
        minHeight: '30vw',
      };
    },
  },
};
</script>
