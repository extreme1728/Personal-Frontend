<template lang="pug">
q-card(flat class="full-wdith")
  q-card-section {{ getTitle | inputFormatter }} for
    q-select(
      emit-value
      map-options
      v-model="model.name"
      :options="mapClientAndPartnerNameValues"
    )
  q-card-section
    div(class="row q-col-gutter-sm")
      div(class="col-md-6")
        q-select(
          use-input
          emit-value
          map-options
          input-debounce="0"
          @filter="__filterFn"
          label="Policy Provider"
          v-model="model.policy.provider"
          :options="policyProviderOptions"
        )
      div(class="col-md-6")
        q-select(
          use-input
          emit-value
          map-options
          label="Cover Type"
          input-debounce="0"
          @filter="__filterFn"
          :hide-dropdown-icon="!getMapCurrentSelectedInsuranceProviderCoverTypes.length"
          new-value-mode="add-unique"
          v-model="model.policy.cover_type"
          hint="Press Enter to persist changes"
          :options="getMapCurrentSelectedInsuranceProviderCoverTypes"
        )
    div(class="row q-col-gutter-sm")
      div(class="col-md-6")
        q-input(
          type="tel"
          prefix="$"
          align="right"
          v-money="getVMoneyInputOptions"
          v-model="model.policy.sum_assured"
          :label="getDeterminedSumAssuredLabel"
        )
      div(class="col-md-6")
        q-input(
          type="tel"
          prefix="$"
          align="right"
          label="Monthly Premium"
          v-model="model.policy.premium"
          v-money="getVMoneyInputOptions"
        )
    div(class="row q-col-gutter-sm")
      div(class="col-md-12")
        q-input(
          label="Notes"
          type="textarea"
          :max-height="170"
          v-model="model.policy.notes"
        )
          template(v-slot:append)
            q-icon(name="sync" class="cursor-pointer" @click="generateCoverTypeNotes")
  q-card-actions(align="between")
    q-btn(
      outline
      label="Add"
      color="secondary"
      @click="addItemPolicyProvider"
      v-show="model.name && model.name.length"
    )
    q-btn(
      flat
      color="primary"
      label="Clear All"
      @click="clearInputs"
    )
    q-toggle(
      left-label
      :value="force"
      color="secondary"
      :label="getForceToggleLabel"
      @input="_ => $emit('change:force', _)"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { ModalToggleMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { isEmpty, toString, find, map, cloneDeep, set, join, merge, lowerCase } from 'lodash';
import { recommendationItemSchema } from 'src/services/ipp/reports/recommendations/Service';

export default {
  name: 'item-recommendation-input',
  mixins: [ModalToggleMixin],
  data: () => ({
    model: cloneDeep(recommendationItemSchema),
    policyProviderOptions: [],
  }),
  created() {
    this.policyProviderOptions = this.mapInsuranceProviders;
  },
  props: {
    title: String,
    type: {
      type: String,
      required(value) {
        return value.includes(['existing', 'proposed', 'underwriting']);
      },
    },
    force: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    __filterFn(val, update) {
      const stringOptions = this.mapInsuranceProviders;
      if (val === '') {
        update(() => {
          this.policyProviderOptions = stringOptions;
        });
        return;
      }

      update(() => {
        const needle = val.toLowerCase();
        this.policyProviderOptions = stringOptions.filter(({ value, label }) => {
          return lowerCase(toString(value)).indexOf(toString(needle)) > -1
            || lowerCase(toString(label)).indexOf(lowerCase(needle)) > -1;
        });
      })
    },
    addItemPolicyProvider() {
      const { cover_type } = this.model.policy;
      const model = cloneDeep(this.model);
      const item = merge(model, { offer_type: this.type });
      this.$emit('change:item', cloneDeep(item));
    },
    clearInputs() {
      set(this, 'model', cloneDeep(recommendationItemSchema));
    },
    convertArrayToNewLine(text = [], delimiter = '\n\n') {
      return join(text, delimiter);
    },
    async generateCoverTypeNotes() {
      const { policy: { provider, cover_type, notes } } = this.model;
      if (!isEmpty(toString(cover_type))) {
        const instance = this.getCurrentSelectedCoverTypeInstance;
        if (!isEmpty(instance)) {
          const { notes: coverTypeNotes } = instance;
          if (isEmpty(notes) && !isEmpty(coverTypeNotes)) {
            set(
                this.model,
                ['policy', 'notes'],
                this.convertArrayToNewLine(coverTypeNotes),
            );
          }
          else if (isEmpty(coverTypeNotes)) {
            this.$q.notify({
              message: 'There are no existing notes attached to this product',
              color: 'red-5',
              icon: 'warning',
              timeout: 1000,
              position: 'top-right',
            });
          }
          else {
            // We are confirming that the user wants to override the notes.
            try {
              this.$q.dialog({
                title: 'Override Notes',
                message: 'This action cannot be undone and will result of losing data. Continue action?',
                color: 'amber',
                cancel: true,
              }).onOk(() => {
                set(
                    this.model,
                    ['policy', 'notes'],
                    this.convertArrayToNewLine(coverTypeNotes),
                );
              });
            }
            catch (e) {}
          }
        }
        else {
          // Cover type does not exists it must be
          // A custom (from input) cover type
        }
      }
      else {
        this.$q.notify({
          message: 'Cover type is empty',
          color: 'red-5',
          icon: 'warning',
          timeout: 1000,
          position: 'top-right',
        });
      }
    },
  },
  computed: {
    ...mapGetters('insuranceProvider', {
      insuranceProviders: 'providers',
      insuranceProvidersCovers: 'providerCovers',
      mapInsuranceProviders: 'mapInsuranceProviders',
    }),
    ...mapGetters('planner', ['mapClientAndPartnerNameValues']),
    getTitle() {
      return this.title || this.type;
    },
    getForceToggleLabel() {
      return 'Force add to opposite table';
    },
    getVMoneyInputOptions() {
      return { precision: 2 };
    },
    getDeterminedSumAssuredLabel() {
      const provider = this.getCurrentSelectedProviderInstance;
      if (!isEmpty(provider) && provider.health_cover) return 'Excess';
      const coverType = this.getCurrentSelectedCoverTypeInstance;
      if (!isEmpty(coverType) && coverType.health_cover) return 'Excess';
      return 'Sum Assured';
    },
    getCurrentSelectedProviderInstance() {
      const { policy: { provider} } = this.model;
      if (isEmpty(toString(provider))) return null;
      return find(this.insuranceProviders, ['name', toString(provider)]) || null;
    },
    getCurrentSelectedInsuranceProviderCoverTypes() {
      const providerInstance = this.getCurrentSelectedProviderInstance;
      if (isEmpty(providerInstance)) return [];
      const { covers } = providerInstance;
      if (isEmpty(covers)) return [];
      return covers;
    },
    getMapCurrentSelectedInsuranceProviderCoverTypes() {
      return map(this.getCurrentSelectedInsuranceProviderCoverTypes, o => ({
        label: o.name,
        value: o.name,
      }));
    },
    getCurrentSelectedCoverTypeInstance() {
      const { policy: { cover_type } } = this.model;
      return find(
          this.getCurrentSelectedInsuranceProviderCoverTypes,
          ['name', toString(cover_type)],
      ) || null;
    },
  },
  components: {
    QInput,
  },
};
</script>
