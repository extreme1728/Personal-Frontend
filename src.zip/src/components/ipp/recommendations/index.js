import ItemRecommendationsTable from './Table';
import ItemRecommendationsInputs from './Input';
import ItemRecommendationsImagesView from './ImagesView';
import ItemRecommendationsSaveDialog from './SaveDialog';
import ItemRecommendationsReportsView from './ReportsView';
import ItemRecommendationsCommentInput from './CommentInput';

export {
  ItemRecommendationsTable,
  ItemRecommendationsInputs,
  ItemRecommendationsSaveDialog,
  ItemRecommendationsImagesView,
  ItemRecommendationsReportsView,
  ItemRecommendationsCommentInput,
};
