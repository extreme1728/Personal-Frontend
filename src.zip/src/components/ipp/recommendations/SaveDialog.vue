<template lang="pug">
q-dialog(
  persistent
  :value="show"
  @show="$emit('show')"
  @cancel="$emit('cancel')"
)
  q-card(style="width: 700px; max-width: 80vw;")
    q-card-section
      p(class="text-h6") Save report as
    q-card-section
      q-input(
        label="Name"
        class="q-my-md"
        :disable="disable"
        v-model="rawValue.name"
      )
      q-select(
        emit-value
        map-options
        class="q-my-md"
        label="Category"
        :disable="disable"
        v-model="rawValue.category"
        :options="getReportCategories"
      )
      q-select(
        emit-value
        map-options
        class="q-my-md"
        :disable="disable"
        label="Insurance Plan Type"
        v-model="rawValue.insurance_plan_type"
        :options="getReportInsurancePlanTypes"
      )
      q-input(
        class="q-my-md"
        type="textarea"
        :disable="disable"
        label="Description"
        placeholder="(Optional)"
        v-model="rawValue.description"
      )
    q-card-actions(align="right" class="bg-white")
      q-btn(flat v-close-popup :disable="disable") Close
      q-btn(color="secondary" :loading="disable" @click="onHandleSave(rawValue)") Save
</template>

<script>
import { mapGetters, mapState } from 'vuex';
import { cloneDeep, get, head } from 'lodash';
import { QInput } from 'src/components/quasar';

export default {
  name: 'item-recommendation-save-dialog',
  data: () => ({
    rawValue: {},
  }),
  created() {
    const name = this.value.name || this.clientName;
    const category = this.value.category || get(head(this.getReportCategories), 'value', 'Apples for Apples');
    const insurance_plan_type = this.value.insurance_plan_type || get(head(this.getReportInsurancePlanTypes), 'value', 'personal');

    this.rawValue = {
      ...this.value,
      name,
      category,
      insurance_plan_type,
      description: this.value.description,
    };
  },
  destroyed() {
    this.rawValue = {};
  },
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    value: {
      type: Object,
      required: true,
    },
    disable: Boolean,
  },
  methods: {
    onHandleSave(rawValue) {
      this.$emit('save', rawValue);
    },
  },
  computed: {
    ...mapState('planner', {
      clientName: state => state.client_full_name,
    }),
    ...mapGetters('insuranceProviderReport', {
      getReportCategories: 'getReportCategories',
      getReportInsurancePlanTypes: 'getReportInsurancePlanTypes',
    }),
  },
  components: {
    QInput,
  },
};
</script>
