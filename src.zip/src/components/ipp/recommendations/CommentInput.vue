<template lang="pug">
div
  q-input(
    :value="value"
    class="q-my-md"
    type="textarea"
    :max-height="170"
    label="Comment/Explanation"
    hint="Click to amend the content"
    @click="commentModalShow = true"
  )
    template(v-slot:prepend)
      q-icon(name="edit")
  q-dialog(
    full-width
    persistent
    no-backdrop-dismiss
    @show="__modalOnShow"
    @hide="__modalOnClose"
    v-model="commentModalShow"
    :content-style="{ minWidth: '90vw', minHeight: '80vh' }"
    class="comments-input-modal"
  )
    q-layout(container class="bg-white")
      q-header(class="bg-primary")
        q-toolbar
          q-btn(
            flat
            round
            v-close-popup
            color="tertiary"
            icon="keyboard_arrow_left"
          )
          q-toolbar-title Comments/Explanation - Template Generator
      q-page-container
        q-page(padding)
          div(class="row q-col-gutter-md")
            div(class="col-md-2")
              q-list(separator)
                q-item-label(header) Cover Types
                q-item(
                  v-for="provider in comments"
                  :key="provider.id"
                  tag="label"
                  clickable
                  v-ripple
                )
                  q-item-section(side)
                    q-checkbox(
                      v-model="selectedProviders"
                      :val="provider"
                      :label="provider.name"
                    )
            div(class="col-md-6")
              template(v-if="selectedProviders.length")
                div(class="row q-mb-md")
                  div(class="col-md-12")
                    q-input(
                      clearable
                      icon="search"
                      v-model="commentQuery"
                      :hint="getCommentQueryFieldMessage"
                    )
                div(class="row")
                  q-list(
                    striped
                    no-border
                    class="col-md-12"
                    v-for="comment in getMapSelectedProvidersComments"
                    :key="comment.name"
                  )
                    q-item-label(header) {{ comment.name }}
                    q-item(v-for="(content, index) in comment.values" :key="index")
                      q-item-section(side)
                        q-btn(
                          flat
                          round
                          color="red-5"
                          icon="keyboard_arrow_up"
                          @click="amendComment(content, 'before')"
                        )
                          q-tooltip Prepend
                      q-item-section
                        q-item-section(label) {{ content }}
                        q-item-label(
                          caption
                          v-show="selectedProviders.length > 1"
                        ) {{ comment.name }}
                      q-item-section(side)
                        q-btn(
                          flat
                          round
                          color="cyan"
                          icon="keyboard_arrow_down"
                          @click="amendComment(content, 'after')"
                        )
                          q-tooltip Append
              template(v-else)
                h6(class="text-faded text-center") Select Provider Cover types
            div(class="col-md-4")
              q-input(
                rows="8"
                label="Amend"
                type="textarea"
                debounce="500"
                :value="value"
                @input="_ => $emit('change', _)"
              )
</template>

<script>
import Fuse from 'fuse.js';
import { mapGetters } from 'vuex';
import { ModalToggleMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { isEmpty, map, pick, join, merge, chunk } from 'lodash';

export default {
  name: 'item-recommendations-comment-input',
  mixins: [ModalToggleMixin],
  data: () => ({
    commentModalShow: false,
    commentValueModel: null,
    selectedProviders: [],
    commentQuery: '',
  }),
  props: {
    value: {
      required: true,
    },
  },
  methods: {
    amendComment(content, position) {
      const comment = this.value;
      if (position.includes('before')) {
        const payload = this.convertArrayToNewLine([
          content,
          comment,
        ]);
        this.$emit('change', payload);
      }

      if (position.includes('after')) {
        const payload = this.convertArrayToNewLine([
          comment,
          content,
        ]);
        this.$emit('change', payload);
      }
    },
    convertArrayToNewLine(text = [], delimiter = '\n\n') {
      return join(text, delimiter);
    },
  },
  computed: {
    ...mapGetters('insuranceProviderCoverTypeComment', {
      comments: 'comments',
    }),
    getMapSelectedProvidersComments() {
      const providers = this.selectedProviders;
      if (!providers.length) return [];
      const KEYS = ['values', 'name'];
      const list = map(providers, (value) => pick(value, KEYS));
      const terms = this.commentQuery;
      if (isEmpty(terms)) return list;
      const fuse = new Fuse(list, { keys: KEYS });
      return fuse.search(terms);
    },
    getCommentQueryFieldMessage() {
      const total = this.getMapSelectedProvidersComments.length;
      return `Search for keywords or indexes - total of (${total}) items.`;
    },
  },
  components: {
    QInput,
  },
};
</script>

<style lang="stylus">
.comments-input-modal
  .layout-padding
    padding 1em
    margin auto
  .q-layout-footer
    box-shadow none !important
</style>
