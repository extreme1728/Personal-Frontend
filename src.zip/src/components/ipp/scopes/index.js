import ScopeOfServices from './EngagementServices';
import LetterOfAuthorityScopes from './LetterOfAuthorityScopes';

export {
  ScopeOfServices,
  LetterOfAuthorityScopes,
};
