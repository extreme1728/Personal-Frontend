<template lang="pug">
div
  p(class="text-faded" v-text="getDeterminedName")
  q-option-group(
    :options="services"
    type="checkbox"
    :color="color"
    :readonly="readonly"
    v-model="payload.values"
  )
  q-editor(
    class="q-my-md"
    toolbar-flat
    toolbar-bg="primary"
    toolbar-text-color="white"
    v-if="hasPmarRequest"
    v-model="payload.pmar_request_content"
    :definitions="definitions"
    :toolbar="toolbar"
    :fonts="fonts"
  )
  div(class="row q-col-gutter-md q-my-md" v-if="!readonly")
    div(class="col-md-4")
      q-btn(
        class="full-width"
        label="Save"
        icon="save"
        :color="color"
        @click="save"
      )
    div(class="col-md-4")
      q-btn(
        class="full-width"
        label="Preview LOA"
        color="cyan"
        icon="open_in_new"
        @click="generate(false)"
      )
    div(class="col-md-4")
      q-btn(
        class="full-width"
        color="secondary"
        label="Download"
        icon="cloud_download"
        @click="generate(true)"
      )
  div(class="row q-col-gutter-md q-my-md" v-if="!readonly && scopeHas('acc_1766') || scopeHas('acc_5937')")
    div(class="col-md-6" v-if="scopeHas('acc_1766')")
      q-btn(
        icon="picture_as_pdf"
        class="full-width"
        label="ACC 1766"
        color="red-5"
        @click="__redirectToAccLoa('acc_1766')"
      )
    div(class="col-md-6" v-if="scopeHas('acc_5937')")
      q-btn(
        icon="picture_as_pdf"
        class="full-width"
        color="blue-5"
        label="ACC 5937"
        @click="__redirectToAccLoa('acc_5937')"
      )
  div(class="row q-col-gutter-md q-my-md" v-if="!readonly && scopeHas('combined_insurance')")
    div(class="col-md-6")
      q-btn(
        icon="picture_as_pdf"
        class="full-width"
        label="Combined Insurance"
        color="red-5"
        @click="__redirectCombineInsurance('combined_insurance')"
      )
</template>

<script>
import qs from 'qs';
import { openURL } from 'quasar';
import { mapGetters } from 'vuex';
import { merge, upperFirst, cloneDeep, get } from 'lodash';
import PmarTemplate from 'src/services/ipp/loa/pmar/template';

const LetterOfAuthorityScopesSchema = {
  id: 0,
  planner_id: 0,
  type: null,
  values: [],
  pmar_request_content: '',
};

export default {
  name: 'letter-of-authority-scopes',
  created() {
    merge(this.payload, { type: this.type });
  },
  props: {
    readonly: Boolean,
    displayName: String,
    signature: String,
    color: {
      type: String,
      default: 'primary',
    },
    type: {
      type: String,
      required: (value) => {
        return ['client', 'partner'].includes(value);
      },
    },
    payload: {
      type: Object,
      default: () => cloneDeep(LetterOfAuthorityScopesSchema),
    },
  },
  methods: {
    generate(download = false) {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { values } = this.payload;
      const url = `${WEB_ENDPOINT}/document/letter-of-authority/${planner}/preview`;
      const query = qs.stringify({ values, type: this.type, download });
      const payload = [url, query].join('?');
      this.$emit('redirect', payload);
      openURL(payload);
      this.save();
    },
    __redirectToAccLoa(service) {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { id: user } = this.currentUserModel;
      const { type } = this;
      const url = `${WEB_ENDPOINT}/document/acc/${user}/loa/${planner}/${service}/${type}/preview`;
      const query = qs.stringify({ type });
      const payload = [url, query].join('?');
      this.$emit('redirect', payload);
      openURL(payload);
      this.save();
    },
    __redirectCombinedInsurance(service) {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { id: user } = this.currentUserModel;
      const { type } = this;
      const url = `${WEB_ENDPOINT}/document/combinedinsurance/${user}/loa/${planner}/${service}/${type}/preview`;
      const query = qs.stringify({ type });
      const payload = [url, query].join('?');
      this.$emit('redirect', payload);
      openURL(payload);
      this.save();
    },
    save() {
      const payload = merge(this.payload, { type: this.type });
      this.$emit('save', payload);
    },
  },
  computed: {
    ...mapGetters('resources', ['letterOfAuthorityOptions']),
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('planner', ['plan']),
    getDeterminedName() {
      const name = this.displayName || this.type;
      return upperFirst(name);
    },
    services() {
      return this.letterOfAuthorityOptions.map(item => {
        return merge(item, {
          val: item.value,
          color: this.color,
        });
      });
    },
    hasPmarRequest() {
      const { values } = this.payload;
      return (values && !this.readonly) && values.includes('pmar_request');
    },
    definitions() {
      return {
        generate: {
          tip: 'Generate Template',
          icon: 'sync',
          handler: () => {
            this.payload.pmar_request_content = this.pmarTemplate;
            this.save();
          },
        },
        preview: {
          tip: 'Save and Preview',
          icon: 'open_in_new',
          label: 'Preview',
          handler: () => {

          },
        }
      };
    },
    toolbar() {
      return [
        [ { label: 'Align', icon: 'format_align_justify', options: ['left', 'center', 'right', 'justify'] } ],
        [ { label: 'Styles', icon: 'format_bold', options: ['bold', 'italic', 'strike', 'underline', 'subscript', 'superscript'] } ],
        ['hr', 'link'],
        ['print', 'generate'],
      ];
    },
    fonts: () => ({
      arial: 'Arial',
      arial_black: 'Arial Black',
      courier_new: 'Courier New',
      impact: 'Impact',
      lucida_grande: 'Lucida Grande',
      times_new_roman: 'Times New Roman',
      verdana: 'Verdana',
    }),
    pmarTemplate() {
      return (new PmarTemplate(this.type, this.plan, this.signature)).render();
    },
    scopeHas() {
      const values = get(this.payload, 'values', []);
      return (needle) => {
        return values.includes(needle);
      };
    }
  },
};
</script>
