<template lang="pug">
div
  p(class="text-faded" v-text="getDeterminedName")
  div(class="row q-col-gutter-xs")
    div(class="col-md-4")
      q-option-group(
        :color="color"
        type="checkbox"
        :options="adviceTypesOptions"
        :value="payload.advices"
        @input="_ => __save(_, 'advices')"
      )
    div(class="col-md-4")
      q-option-group(
        :color="color"
        type="checkbox"
        :options="services"
        :value="payload.values"
        @input="_ => __save(_, 'values')"
      )
    div(class="col-md-4")
      q-option-group(
        :color="color"
        type="checkbox"
        :options="covers"
        :value="payload.providers"
        @input="_ => __save(_, 'providers')"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { each, upperFirst, cloneDeep, set, includes, map } from 'lodash';

const scopeOfServicesSchema = {
  id: 0,
  planner_id: 0,
  type: null,
  values: [],
  providers: [],
  advices: [],
};

export default {
  name: 'scope-of-engagement-services',
  created() {
    set(this.payload, 'type', this.type);

    // Normalize values
    each(this.payload, (value, key) => {
      if (['values', 'providers', 'advices'].includes(key)) {
        if (!Array.isArray(value)) {
          this.__save([], key);
        }
      }
    });
  },
  props: {
    displayName: String,
    type: {
      type: String,
      required: (value) => {
        return ['client', 'partner'].includes(value);
      },
    },
    payload: {
      type: Object,
      default: () => cloneDeep(scopeOfServicesSchema),
    },
    color: {
      type: String,
      default: 'primary',
    },
    readonly: Boolean,
  },
  methods: {
    __save(values, field) {
      const payload = set(this.payload, field, values);
      this.$emit('save', payload);
    },
  },
  computed: {
    ...mapGetters('resources', [
      'existingCovers',
      'adviceTypesOptions',
      'scopeOfEngagementsOptions',
    ]),
    getDeterminedName() {
      const name = this.displayName || this.type;
      return upperFirst(name);
    },
    services() {
      return map(this.scopeOfEngagementsOptions, value => ({ label: value, value: value }));
    },
    covers() {
      const only = [
        'AA',
        'AIL',
        'Asteron',
        'AIA',
        'Fidelity',
        'Partners Life',
        'Sovereign',
        'Accuro',
        'NIB',
        'Southern Cross',
        'No Existing Insurances Specified',
        'One Path',
      ];
      return this.existingCovers.map(({ label, value }) => {
        return {
          label,
          value,
        };
      }).filter(({ value: name }) => includes(only, name));
    },
  },
};
</script>
