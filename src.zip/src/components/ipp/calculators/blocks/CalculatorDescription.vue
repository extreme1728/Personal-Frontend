<template lang="pug">
div(class="q-mb-md")
  blockquote(:class="blockquoteClasses" v-if="readonly && value.description")
    p(class="text-tertiary" style="white-space: pre-line;" v-text="value.description")
  div(class="row" v-else)
    div(class="col-md-12")
      q-input(
        :hint="helper"
        debounce="500"
        type="textarea"
        label="Description"
        :readonly="readonly"
        :value="value.description"
        @input="_ => __change(_, value, 'description')"
      )
        template(v-slot:append v-if="notes.length && !readonly")
          q-icon(name="sync" class="cursor-pointer" @click="__descriptionHandler(value)")
</template>

<script>
import { get, set } from 'lodash';
import { QInput } from 'src/components/quasar';
import CalculatorNoteService from 'src/services/ipp/calculators/NoteService';

export default {
  name: 'calculator-description',
  props: {
    value: Object,
    readonly: Boolean,
    field: {
      type: String,
      required: true,
    },
    currentName: String,
    currentAge: Number,
    currentTab: String,
  },
  created() {
    const description = get(this.value, 'description', null);
    if (!description && !this.readonly) {
      const value = get(this, 'notes', []).join('\n\n');
      this.__change(value, this.value, 'description');
    }
  },
  methods: {
    __change(value, model, field) {
      set(model, field, value);
      this.$emit('change', value);
    },
    __descriptionHandler(model) {
      const value = get(this, 'notes', []);
      this.__change(value.join('\n\n'), model, 'description');
    },
  },
  computed: {
    blockquoteClasses: () => ({
      'note-border-primary': true,
      'text-weight-regular': true,
      'text-justify': true,
    }),
    helper() {
      return this.notes.length
        ? 'Click the icon to generate default wordings.'
        : null;
    },
    notes() {
      const { value, field } = this;
      return new CalculatorNoteService(field, value, this.currentName, this.currentAge, this.currentTab);
    },
  },
  components: {
    QInput,
  },
};
</script>
