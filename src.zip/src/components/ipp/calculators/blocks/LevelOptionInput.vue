<template lang="pug">
div
  display-input(
    v-if="readonly"
    hint="Premium Structure"
    :value="value | inputFormatter"
  )
  q-select(
    v-else
    use-input
    emit-value
    :label="label"
    :value="value"
    input-debounce="0"
    hide-dropdown-icon
    :readonly="readonly"
    :options="levelOptions"
    hint="Premium Structure"
    new-value-mode="add-unique"
    @input="_ => $emit('input', _)"
  )
    template(v-slot:after)
      q-btn(icon="create" round dense flat class="cursor-pointer")
        q-popup-proxy(ref="$Q_POPUP_PROXY")
          q-input(class="q-pa-md" v-model="val" type="number" :label="`Level for ${val} years`" :min="0")
            template(v-slot:after)
              q-btn(icon="edit" flat round dense @click="__input")
</template>

<script>
import { mapGetters } from 'vuex';
import { DisplayInput } from 'src/components/ipp';

export default {
  name: 'level-option-input',
  data: () => ({
    val: 0,
  }),
  props: ['value', 'label', 'readonly'],
  methods: {
    __input() {
      if (!this.val) return;
      const value = `Level for ${this.val} years`;
      this.$emit('input', value);

      if (this.$refs.$Q_POPUP_PROXY) {
        this.$refs.$Q_POPUP_PROXY.hide();
      }
    },
  },
  computed: {
    levelOptions: () => ([
      { label: 'Stepped', value: 'Stepped' },
      { label: 'Level for 10 years', value: 'Level for 10 years' },
      { label: 'Level to age 65', value: 'Level to age 65' },
      { label: 'Level to age 80', value: 'Level to age 80' },
      { label: 'Level to age 100', value: 'Level to age 100' },
    ]),
  },
  components: {
    DisplayInput,
  },
};
</script>
