<template lang="pug">
div
  div(class="q-my-md")
    h6(class="text-h6 no-margin text-faded") Mortgage Repayment, Income Protection and House Hold Expense Cover
  div(class="row q-mt-md" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") We strive hard to take care of those that we love, earning to put food on the table, looking after rental/mortgage repayments and other unexpected expenses that prop up from time to time.
        p(:style="getBlockQuoteFontStyle") What is it that your income provides for you? Remembering all the things that income provides for you and your family, what if it stopped overnight?
        p(:style="getBlockQuoteFontStyle") Nobody is bullet proof. We all get sick and injured. It can sometimes affect our ability to work and more importantly, those that depend on our income. Income protection provides for you and your family when you can't.
        p(:style="getBlockQuoteFontStyle") It’s time to start thinking about your income as an asset – something valuable that you need to look after. You wouldn’t take the risk of owning a home, driving a car, or even travelling overseas without insurance, so why risk your income? After all, without it, the home, car, and holiday are almost impossible.
        p(:style="getBlockQuoteFontStyle" class="text-weight-bolder") Insuring your income
        p(:style="getBlockQuoteFontStyle") Income protection insurance means having protection for your greatest asset, even if the worst happens. Unlike life insurance, which only pays out once you die, income protection covers you for injury or illness so you can maintain your lifestyle if you’re not able to work.
        p(:style="getBlockQuoteFontStyle") Not being able to work has a huge impact – not just financially, but emotionally and psychologically as well. With income protection, you can use your time off to recover, without the financial stress of spending savings, borrowing money, or even having to downsize your house and sell off your assets.
        p(:style="getBlockQuoteFontStyle" class="text-weight-bolder") Mistakes and misconceptions
        p(:style="getBlockQuoteFontStyle") Most of us focus on wealth creation throughout our lives, but wealth protection is equally important. It would be tragic to lose the assets earned through a lifetime of hard work because of an unexpected event – particularly if that loss could have been prevented.
        p(:style="getBlockQuoteFontStyle") We generally start to worry about disease and disability as we age, but younger people can be hit harder by loss of income – they don’t tend to have the savings older people have.
        p(:style="getBlockQuoteFontStyle") ACC is also misunderstood – people assume that it will cover them for loss of income. But this will only happen if you’re injured in an accident, and ACC won’t necessarily cover your income at its current level.
        p(:style="getBlockQuoteFontStyle" class="text-weight-bolder") Getting it right
        p(:style="getBlockQuoteFontStyle") Protecting your income is one of the most important financial decisions you can make.
        p(:style="getBlockQuoteFontStyle") Let's explore what we may need in the event that your lifeline income stops and how to cover that gap without ACC offsets...
        p(:style="getBlockQuoteFontStyle") Let's get started.
  div(class="row")
    div(class="col-md-12")
      display-input(
        v-if="readonly"
        prefix="$"
        class="q-my-md"
        label="Gross Income"
        :value="calculationFields.income"
      )
      q-input(
        v-else
        type="tel"
        prefix="$"
        v-money="{}"
        class="q-my-md"
        label="Gross Income"
        v-model="calculationFields.income"
      )
        template(v-slot:append v-if="!readonly")
          q-icon(name="sync" class="cursor-pointer" @click="getIncomeHandler")
  div(class="row q-my-md q-col-gutter-md")
    div(class="col-md-7")
      display-input(
        v-if="readonly"
        from-options
        :options="getMortgageIncomeProtectionCategories"
        :value="calculationFields.mortgage_income_protection_category"
      )
      q-select(
        v-else
        emit-value
        map-options
        :color="color"
        label="Mortgage Income Protection"
        :options="getMortgageIncomeProtectionCategories"
        v-model="calculationFields.mortgage_income_protection_category"
      )
    div(class="col-md-5")
      display-input(
        v-if="readonly"
        prefix="$"
        :value="calculationFields.mortgage_income_protection_amount"
      )
      q-input(
        v-else
        type="tel"
        prefix="$"
        v-money="{}"
        align="right"
        v-model="calculationFields.mortgage_income_protection_amount"
      )
        template(v-slot:append v-if="!readonly")
          q-icon(name="sync" class="cursor-pointer" @click="getMortgageIncomeProtectionHandler")
  div(class="row q-my-md q-col-gutter-md")
    div(class="offset-md-7 col-md-5")
      display-input(
        v-if="readonly"
        prefix="$"
        label="Monthly Basis"
        :value="calculationFields.mortgage_income_protection_amount_month || '0'"
      )
      q-input(
        v-else
        type="tel"
        prefix="$"
        v-money="{}"
        align="right"
        label="Monthly Basis"
        v-model="calculationFields.mortgage_income_protection_amount_month"
      )
        template(v-slot:append v-if="!readonly")
          q-icon(name="sync" class="cursor-pointer" @click="getMortgageIncomeProtectionHandlerMonth")
  div(class="row q-my-md q-col-gutter-md")
    div(class="col-md-7")
      display-input(
        v-if="readonly"
        from-options
        label="Household Expenses Cover"
        :options="getHouseholdExpenseCoverTypes"
        :value="calculationFields.household_expense_cover_type"
      )
      q-select(
        v-else
        emit-value
        map-options
        :color="color"
        label="Household Expenses Cover"
        :options="getHouseholdExpenseCoverTypes"
        v-model="calculationFields.household_expense_cover_type"
      )
    div(class="col-md-5")
      display-input(
        prefix="$"
        :value="getHouseHoldExpenseCover | toNumberFixed | numberComma"
      )
  div(class="row q-my-md q-col-gutter-md")
    div(class="offset-md-7 col-md-5")
      display-input(
        prefix="$"
        label="Monthly Basis"
        :value="getHouseHoldExpenseCoverMonth | toNumberFixed | numberComma"
      )
  display-input(
    prefix="$"
    class="q-my-md"
    label="Income Protection Indemnity Maximum Additional Cover"
    :value="getIncomeProtectionIndemnityMaximumAdditionalCover | toNumberFixed | numberComma"
  )
  display-input(
    prefix="$"
    class="q-my-md"
    label="Monthly Basis"
    :value="getIncomeProtectionIndemnityMaximumAdditionalCoverMonth | toNumberFixed | numberComma"
  )
  display-input(
    prefix="$"
    class="q-my-md"
    label="Income Protection Agreed Maximum Additional Cover"
    :value="getIncomeProtectionAgreedMaximumAdditionalCover | toNumberFixed | numberComma"
  )
  display-input(
    prefix="$"
    class="q-my-md"
    label="Monthly Basis"
    :value="getIncomeProtectionAgreedMaximumAdditionalCoverMonth | toNumberFixed | numberComma"
  )
</template>

<script>
import { CalculableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { cloneDeep, eq, isEmpty } from 'lodash';
import { DisplayInput } from 'src/components/ipp';
import { numberWithCommas, floatFixer } from 'src/config/utils';

const calculationFieldSchema ={
  income: 0,
  household_expense_cover_type: null,
  mortgage_income_protection_amount: 0,
  mortgage_income_protection_amount_month: 0,
  mortgage_income_protection_category: null,
};

export default {
  name: 'mortgage-repayment-income-protection-and-house-expense-cover',
  mixins: [CalculableMixin],
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'mortgage-repayment-income-protection-and-hec',
      }),
    },
  },
  data: () => ({
    calculationFields: cloneDeep(calculationFieldSchema),
  }),
  created() {
    if (!isEmpty(this.payload)) {
      this.calculationFields = cloneDeep(this.payload);
    }
  },
  props: {
    color: {
      type: String,
      default: 'primary',
    },
    mortgageRepaymentAmount: {
      type: Number,
      default: 0,
    },
    mortgagePercentage: {
      type: Number,
      default: 0.45,
    },
    houseHoldExpensePercentage: {
      type: Number,
      default: 0.05,
    },
    incomeIndemnityPercentage: {
      type: Number,
      default: 0.75,
    },
    incomeAgreedPercentage: {
      type: Number,
      default: 0.625,
    },
    totalHouseholdExpense: {
      type: Number,
      default: 0,
    },
  },
  methods: {
    getMortgageIncomeProtectionHandler() {
      this.calculationFields.mortgage_income_protection_amount = numberWithCommas(this.getMortgageIncomeProtection);
    },
    getMortgageIncomeProtectionHandlerMonth() {
      this.calculationFields.mortgage_income_protection_amount_month = numberWithCommas(this.getMortgageIncomeProtectionMonth);
    },
    getIncomeHandler() {
      this.calculationFields.income = numberWithCommas(this.getIncomeAmount);
    },
  },
  computed: {
    getMortgageIncomeProtection() {
      const { income, mortgage_income_protection_category, mortgage_income_protection_amount } = this.calculationFields;

      if (eq(mortgage_income_protection_category, 'mortgage_repayment')) {
        return numberWithCommas(this.mortgageRepaymentAmount, false);
      }

      return (numberWithCommas(income, false) * this.mortgagePercentage);
    },
    getMortgageIncomeProtectionMonth() {
      const { income, mortgage_income_protection_category, mortgage_income_protection_amount_month } = this.calculationFields;

      if (eq(mortgage_income_protection_category, 'mortgage_repayment')) {
        return numberWithCommas(this.mortgageRepaymentAmount, false);
      }

      return (numberWithCommas(income, false) * this.mortgagePercentage / 12);
    },
    getHouseHoldExpenseCover() {
      const { income, household_expense_cover_type: type } = this.calculationFields;
      if (!type) return 0;
      return eq(type, 'income')
        ? floatFixer(numberWithCommas(income, false) * this.houseHoldExpensePercentage)
        : this.totalHouseholdExpense;
    },
    getHouseHoldExpenseCoverMonth() {
      const { income, household_expense_cover_type: type } = this.calculationFields;
      if (!type) return 0;
      return eq(type, 'income')
        ? floatFixer(numberWithCommas(income, false) * this.houseHoldExpensePercentage / 12)
        : floatFixer(this.totalHouseholdExpense / 12);
    },
    getIncomeProtectionIndemnityMaximumAdditionalCover() {
      const { income, mortgage_income_protection_amount } = this.calculationFields;
      const sumOfHouseholdExpenseAndMortgage = (this.getHouseHoldExpenseCover + this.getMortgageIncomeProtection);
      return (this.getIncomeAmount - (sumOfHouseholdExpenseAndMortgage / this.incomeAgreedPercentage)) * this.incomeIndemnityPercentage;
    },
    getIncomeProtectionIndemnityMaximumAdditionalCoverMonth() {
      const { income, mortgage_income_protection_amount } = this.calculationFields;
      const sumOfHouseholdExpenseAndMortgage = (this.getHouseHoldExpenseCover + this.getMortgageIncomeProtection);
      return (this.getIncomeAmount - (sumOfHouseholdExpenseAndMortgage / this.incomeAgreedPercentage)) * this.incomeIndemnityPercentage / 12;
    },
    getIncomeProtectionAgreedMaximumAdditionalCover() {
      const { income, mortgage_income_protection_amount } = this.calculationFields;
      return ((numberWithCommas(income, false) * this.incomeAgreedPercentage) - numberWithCommas(mortgage_income_protection_amount, false) - this.getHouseHoldExpenseCover);
    },
    getIncomeProtectionAgreedMaximumAdditionalCoverMonth() {
      const { income, mortgage_income_protection_amount } = this.calculationFields;
      return floatFixer(((numberWithCommas(income, false) * this.incomeAgreedPercentage) - numberWithCommas(mortgage_income_protection_amount, false) - this.getHouseHoldExpenseCover) / 12);
    },
    getMortgageIncomeProtectionCategories: () => ([
      { label: 'Based on Income', value: 'income' },
      { label: 'Based on Mortgage Repayments', value: 'mortgage_repayment' },
    ]),
    getHouseholdExpenseCoverTypes: () => ([
      { label: 'Total of household expenses', value: 'household' },
      { label: '5% income basis', value: 'income' },
    ]),
  },
  components: {
    QInput,
    DisplayInput,
  },
};
</script>
