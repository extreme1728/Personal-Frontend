<template lang="pug">
div
  div(class="q-my-md")
    h6(class="no-margin text-faded") Mortgage Repayment and Income Protection
  div(class="row q-mt-md" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") We strive hard to take care of those that we love, earning to put food on the table, looking after rental/mortgage repayments and other unexpected expenses that prop up from time to time.
        p(:style="getBlockQuoteFontStyle") What is it that your income provides for you? Remembering all the things that income provides for you and your family, what if stopped overnight?
        p(:style="getBlockQuoteFontStyle") Nobody is bullet proof. We all get sick and injured. It can sometimes affect our ability to work and more importantly, those that depend on our income. Income protection provides for you and your family when you can't.
        p(:style="getBlockQuoteFontStyle") Let's explore what we may need in the event that your lifeline income stops and how to cover that gap without ACC offsets...
        p(:style="getBlockQuoteFontStyle") Let's get started.
  div(class="row")
    div(class="col-md-12")
      div
        display-input(
          v-if="readonly"
          class="q-my-md"
          :value="calculationFields.insurance_provider | inputFormatter"
        )
        q-select(
          v-else
          emit-value
          map-options
          class="q-my-md"
          label="Insurance Provider"
          v-model="calculationFields.insurance_provider"
          :options="getInsuranceProvidersForMortgageRepaymentIncomeProtection"
        )
      div
        display-input(
          v-if="readonly"
          class="q-my-md"
          label="Liable Earnings"
          :value="income | numberComma"
        )
        q-input(
          v-else
          type="tel"
          prefix="$"
          align="right"
          v-money="{}"
          class="q-my-md"
          :value="income"
          class="q-my-md"
          label="Liable Earnings"
          @input="value => $emit('income:change', value)"
        )
      p(class="text-faded no-margin-bottom") Annualised Mortgage and Rent Cover
      div(class="row q-col-gutter-md")
        div(class="col-md-7")
          display-input(
            v-if="readonly"
            from-options
            :options="getAnnualisationCategories"
            :value="calculationFields.annualised_mortgage_category"
          )
          q-select(
            v-else
            emit-value
            map-options
            :color="color"
            label="Category"
            :options="getAnnualisationCategories"
            v-model="calculationFields.annualised_mortgage_category"
          )
        div(class="col-md-5")
          display-input(
            v-if="readonly"
            prefix="$"
            label="Amount"
            :value="calculationFields.annualised_mortgage_amount"
          )
          q-input(
            v-else
            type="tel"
            prefix="$"
            align="right"
            v-money="{}"
            label="Amount"
            v-model="calculationFields.annualised_mortgage_amount"
          )
            template(v-slot:append)
              q-icon(name="sync" class="cursor-pointer" @click="getAnnualisedMortgageHandler")
      display-input(
        prefix="$"
        class="q-my-md"
        label="Indemnity value maximum additional benefit amount"
        :value="getCalculatedIndemnityValueMaximum | numberComma"
      )
      display-input(
        prefix="$"
        class="q-my-md"
        label="Agreed value maximum additional benefit amount"
        :value="getCalculatedAgreedValueMaximum | numberComma"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { CalculableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { DisplayInput } from 'src/components/ipp';
import AiaTaxCalculation from 'src/services/aos/tax/insurance/Aia';
import PercentageRange from 'src/services/aos/providers/PercentageRange';
import { numberWithCommas, switchcase, floatFixer } from 'src/config/utils';
import FidelityTaxCalculation from 'src/services/aos/tax/insurance/Fidelity';
import { cloneDeep, toNumber, snakeCase, camelCase, eq, isEmpty } from 'lodash';

const calculationFieldSchema ={
  annualised_mortgage_category: null,
  annualised_mortgage_amount: 0,
  insurance_provider: null,
};

export default {
  name: 'mortgage-repayment-income-protection',
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'mortgage-repayment-and-income-protection',
      }),
    },
  },
  data: () => ({
    calculationFields: cloneDeep(calculationFieldSchema),
  }),
  created() {
    if (!isEmpty(this.payload)) {
      this.calculationFields = cloneDeep(this.payload);
    }

    if (isEmpty(this.payload)) {
      if (this.getDeterminedIncome > this.getDeterminedMortgageRepayment) {
        this.calculationFields.annualised_mortgage_amount = numberWithCommas(this.getDeterminedIncome);
      }
      else {
        this.calculationFields.annualised_mortgage_amount = numberWithCommas(this.getDeterminedMortgageRepayment);
      }
    }
  },
  mixins: [CalculableMixin],
  props: {
    color: {
      type: String,
      default: 'primary',
    },
    mortgageRepaymentAmount: {
      type: Number,
      default: 0,
    },
  },
  methods: {
    getAnnualisedMortgageHandler() {
      this.calculationFields.annualised_mortgage_amount = numberWithCommas(this.getDeterminedAnnualisedMortgageAmount);
    },
  },
  computed: {
    ...mapGetters('resources', ['getInsuranceProvidersForMortgageRepaymentIncomeProtection']),
    getDeterminedMortgageRepayment() {
      const { insurance_provider } = this.calculationFields;
      const provider = camelCase(insurance_provider);
      const amount = floatFixer(this.mortgageRepaymentAmount);

      switch (provider) {
        case 'fidelity':
        case 'asteron':
          return floatFixer(amount * (110 / 100));
        case 'partnersLife':
          return floatFixer(amount * (100 / 100));
        case 'sovereign':
        case 'aia':
          return floatFixer(amount * (115 / 100));
      }

      return amount;
    },
    getDeterminedIncome() {
      const { insurance_provider } = this.calculationFields;
      const provider = camelCase(insurance_provider);
      const amount = floatFixer(this.getIncomeAmount);
      switch (provider) {
        case 'fidelity':
          return floatFixer(amount * (40 / 100));
        case 'aia':
        case 'asteron':
        case 'sovereign':
        case 'partnersLife':
          return floatFixer(amount * (45 / 100));
      }
      return amount;
    },
    getDeterminedAnnualisedMortgageAmount() {
      const { annualised_mortgage_category: category } = this.calculationFields;
      const amount = switchcase({
        'mortgage_repayment': this.getDeterminedMortgageRepayment,
        'income': this.getDeterminedIncome,
      })(this.getIncomeAmount);
      return amount(category);
    },
    getFormattedInsuranceProviderCategoryPercentage() {
      const { insurance_provider: provider } = this.calculationFields;
      const percentages = switchcase({
        sovereign: 0.625,
        aia: 0.625,
        asteron: 0.55,
        fidelity: 0.625,
        partners_life: 0.625,
       })(0.55);
       return percentages(snakeCase(provider));
    },
    getCalculatedAnnualisedMortgageAmount() {
      // This is the value of anualised mortgage
      // Divided by percentage of the provider
      const { annualised_mortgage_amount } = this.calculationFields;
      return toNumber((numberWithCommas(annualised_mortgage_amount, false) / this.getFormattedInsuranceProviderCategoryPercentage).toFixed(2));
    },
    getCalculatedLessIncomeAmount() {
      // This is the Actual income less annualised
      // divide by percentage of the provider
      const annualisedAmount=  this.getCalculatedAnnualisedMortgageAmount;
      return toNumber(this.getIncomeAmount - annualisedAmount);
    },
    getCalculatedIndemnityValueMaximum() {
      // Less income amount multiply by percentage of the provider 75%
      const percentage = 0.75;
      const lessIncomeAmount =  this.getCalculatedLessIncomeAmount;
      return toNumber((lessIncomeAmount * percentage).toFixed(2));
    },
    getCalculatedAgreedValueMaximum() {
      // Less income amount multiply by percentage of the provider
      const { insurance_provider, annualised_mortgage_amount } = this.calculationFields;
      const provider = camelCase(insurance_provider);
      const income = this.getIncomeAmount;
      const annualisedMortgageAmount = numberWithCommas(annualised_mortgage_amount, false);

      switch (provider) {
        case 'fidelity':
            return (new FidelityTaxCalculation(income, annualisedMortgageAmount)).totalAgreedValue;
          break;
        case 'sovereign':
        case 'aia':
            return (new AiaTaxCalculation(income, annualisedMortgageAmount)).totalAgreedValue;
          break;
      }

      let percentage = 0;
      try {
        percentage = (new PercentageRange(this.getIncomeAmount))[provider]();
      }
      catch (e) { percentage = 0.625; }
      return toNumber((this.getCalculatedLessIncomeAmount * percentage).toFixed(2));
    },
    getAnnualIndenmnityMaxCoverAmount() {
      // Indemnity maximum value annually
      const months = 12;
      return toNumber((this.getCalculatedIndemnityValueMaximum / months).toFixed(2));
    },
    getAnnualisationCategories() {
      return [
        { label: 'Based on Income', value: 'income' },
        { label: 'Based on Mortgage Repayments', value: 'mortgage_repayment' },
      ];
    },
  },
  components: {
    QInput,
    DisplayInput,
  },
};
</script>
