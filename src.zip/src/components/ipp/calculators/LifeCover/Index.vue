<template lang="pug">
div
  div(class="q-my-md text-faded" v-if="readonly")
    h6(class="text-h6 no-margin text-faded") Life Cover
    p(class="text-subtitle1 no-margin") What do you want as your legacy?
  div(class="row" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="q-my-md note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") Wouldn't it be nice to live forever? Unfortunately we're human and whilst medical science can make us live longer, it hasn't caught up to make us live forever.
        p(:style="getBlockQuoteFontStyle") Until medical science catches up with our perfect world ideology, we need to consider "How would I want my family to live without me being able to take care of them?" &amp; "To what extent do I want my widow to grieve with dignity?".
        p(:style="getBlockQuoteFontStyle") Protect your loved ones with personalised life insurance from the JD Life experts. Make the most of life, but set yourself up with peace of mind in case things don't go to plan. Let's consider how much your family would need financially without your income keeping in mind things such as being able to pay the bills, mortgage or rent if you’re not around.
        p(:style="getBlockQuoteFontStyle") Let's get started.
      blockquote(class="note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") Did you know? Accidents make up only around 6% of all deaths.
  q-card(square :flat="readonly")
    q-card-section(v-if="!readonly" style="height: 100px" :class="`bg-${color}`")
    q-card-section(class="relative-position" v-if="!readonly")
      p(class="text-faded text-h6 q-my-md") Life Cover
      p(class="text-faded text-caption no-margin") Did you know? Accidents make up only around 6% of all deaths.
      div(class="q-gutter-md")
        q-toggle(
          label="Show Recommendations"
          :value="calculationFields.show_recommendations"
          @input="_ => __change(_, calculationFields, 'show_recommendations')"
        )
        q-toggle(
          label="Show Considerations"
          :value="calculationFields.show_considerations"
          @input="_ => __change(_, calculationFields, 'show_considerations')"
        )
      q-btn(
        fab
        color="secondary"
        icon="add"
        class="absolute calculator-card--button"
        @click="__showOptionList"
      )
    q-card-section
      q-list
        include blocks/mortgage-amount
        include blocks/mortgage-amount-rental-investment-property
        include blocks/remaining-mortgage-repayments
        include blocks/personal-loan
        include blocks/business-debt
        include blocks/family-fund
        include blocks/fatal-entitlements
        include blocks/funeral-cover
        include blocks/repatriation-benefit
        include blocks/educational-fund
        include ../TraumaCover/blocks/nanny-cost-annually
        include ../TraumaCover/blocks/nanny-cost
        include blocks/investment
        include blocks/charity
        include blocks/young-adult-life-cover
        include blocks/inheritance
        include blocks/others
        include blocks/total-sum-assured
        div(v-show="calculationFields.show_considerations")
          include blocks/considerations
  premium-structure(
    v-if="curatedData"
    class="q-my-md"
    :style="chartStyles"
    :options="chartOptions"
    :chart-data="chartData"
  )
  include ../blocks/selections-dialog
</template>

<script>
import { uid } from 'quasar';
import { mapGetters } from 'vuex';
import { CalculableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { DisplayInput } from 'src/components/ipp';
import { floatTotals, floatFixer, numberWithCommas, groupBy, floatDiff } from 'src/config/utils';
import { last, cloneDeep, eq, set, get, each, filter, merge, every, isEmpty, startCase, kebabCase, flatMap, chain, isArray, debounce, toString } from 'lodash';
import PremiumStructure from '../blocks/PremiumStructure';

const calculationModels = {
  mortgage_amount: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  mortgage_amount_rental_investment_property: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  remaining_mortgage_repayments: {
    uid: null,
    years_income: 1,
    percentage: 100,
    type: 'interest',
    index: null,
    level: null,
    principal_percentage: 100,
    description: null,
  },
  personal_loan: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  business_debt: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  family_fund: {
    uid: null,
    index: null,
    level: null,
    years_income: 1,
    value: 0,
    description: null,
  },
  funeral_cover: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  repatriation_benefit: {
    uid: null,
    index: null,
    level: null,
    value: '50,000',
    country: null,
    description: null,
  },
  fatal_entitlements: {
    uid: null,
    index: null,
    level: null,
    value: '50,000',
    description: null,
  },
  educational_fund: {
    uid: null,
    child_name: [],
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  nanny_cost_annually: {
    uid: null,
    value: 0, // annual cost
    years_needed: 0,
    index: null,
    level: null,
    description: null,
  },
  nanny_cost: { // hourly basis
    uid: null,
    rate_per_hour: 20,
    hours_per_week: 0,
    index: null,
    level: null,
    years_needed: 0,
    description: null,
  },
  investment: {
    uid: null,
    index: null,
    level: null,
    value: 0, // Gross Income
    frequency: null,
    time_period: 0, // Years
    collateral: null,  // Bank...
    interest_rate_achieved: 0, // Percentage
    inflation_rate: 0, // Percentage
    description: null,
  },
  charity: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  young_adult_life_cover: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  inheritance: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  others: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
};

const calculationFieldSchema = {
  show_recommendations: true,
  show_considerations: false,
  mortgage_amount: [],
  mortgage_amount_rental_investment_property: [],
  remaining_mortgage_repayments: [],
  personal_loan: [],
  business_debt: [],
  family_fund: [],
  educational_fund: [],
  nanny_cost_annually: [],
  nanny_cost: [],
  investment: [],
  charity: [],
  young_adult_life_cover: [],
  inheritance: [],
  funeral_cover: [],
  repatriation_benefit: [],
  income_needed: [],
  fatal_entitlements: [],
  others: [],
};

export default {
  name: 'life-cover-calculator',
  mixins: [CalculableMixin],
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'life-cover',
      }),
    },
  },
  data: () => ({
    selections: [],
    showSelectionsDialog: false,
    calculationFields: cloneDeep(calculationFieldSchema),
    calculationModels: cloneDeep(calculationModels),
  }),
  created() {
    if (!isEmpty(this.payload)) this.calculationFields = merge(cloneDeep(this.calculationFields), cloneDeep(this.payload));
  },
  props: {
    age: Number,
    color: {
      type: String,
      default: 'primary',
    },
    youngestChildAge: {
      type: Number,
      default: 0,
    },
    changesInCover: {
      type: Number,
      default: 0,
    },
    currentName: String,
  },
  methods: {
    __calculateInvestment({ value, interest_rate_achieved, inflation_rate }) {
      const toPercentage = x => (x / 100);
      const grossIncome = floatFixer(value);
      let total = 0;
      total = floatFixer(grossIncome / toPercentage(interest_rate_achieved));
      if (inflation_rate) {
        total = total + floatFixer(grossIncome * toPercentage(inflation_rate));
      }
      return floatFixer(total);
    },
    __calculateByRemainingMortgageRepayments({ percentage, years_income, principal_percentage, type }) {
      const totalAmount = this.getRemainingMortgageRepaymentsLess * (percentage / 100);
      return eq(type, 'interest')
        ? totalAmount * years_income
        : (totalAmount * years_income) + this.getRemainingMortgageRepaymentsLess * (principal_percentage / 100);
    },
    __showOptionList() { this.showSelectionsDialog = true },
    __change: debounce(function (value, item, field) {
      return set(item, field, value);
    }, 500),
    __createField(field) {
      let payload = {};
      let item = get(this.calculationModels, field);
      if (isArray(field)) {
        each(field, cover => {
          item = get(this.calculationModels, cover);
          if (!item) throw new Error('Item not found');
          payload = cloneDeep(merge(item, { uid: uid() }));
          this.calculationFields[cover].push(payload);
        });
      }
      else {
        if (!item) throw new Error('Item not found');
        payload = cloneDeep(merge(item, { uid: uid() }));
        this.calculationFields[field].push(payload);
      }
    },
    __selectFields() {
      this.__createField(this.selections);
      this.showSelectionsDialog = false;
      this.selections = [];
    },
    __removeField(field, uid) {
      if (!uid) return;
      const items = filter(this.calculationFields[field], ({ uid: id }) => id !== uid);
      this.$set(this.calculationFields, field, items);
    },
    __familyFundIncomeAfterIcons(item) {
      return [
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            const value = numberWithCommas(this.getIncomeAmount);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __othersAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { others } } = this.recentValuesPayload;
            if (!others && !others.length) return;
            const { value } = last(others);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __educationalFundAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { educational_fund } } = this.recentValuesPayload;
            if (!educational_fund && !educational_fund.length) return;
            const { value } = last(educational_fund);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __mortgageAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { mortgage_amount } } = this.recentValuesPayload;
            if (!mortgage_amount && !mortgage_amount.length) return;
            const { value, percentage } = last(mortgage_amount);
            this.__change(value, item, 'value');
            this.__change(percentage, item, 'percentage');
          },
        },
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            if (!this.syncFromPayload) return;
            const { mortgage_amount } = this.syncFromPayload;
            if (!mortgage_amount && !mortgage_amount.length) return;
            const { value } = last(mortgage_amount);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __fatalEntitlementsAfterIcons(item) {
      return [
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            const value = numberWithCommas(this.changesInCover);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __personalLoanAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { personal_loan } } = this.recentValuesPayload;
            if (!personal_loan && !personal_loan.length) return;
            const { value, percentage } = last(personal_loan);
            this.__change(value, item, 'value');
            this.__change(percentage, item, 'percentage');
          },
        },
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            if (!this.syncFromPayload) return;
            const { personal_loan } = this.syncFromPayload;
            if (!personal_loan && !personal_loan.length) return;
            const { value } = last(personal_loan);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
  },
  computed: {
    ...mapGetters('liabilityRates', ['fatal']),
    ...mapGetters('planner', ['mapChildrensName']),
    ...mapGetters('resources', ['mortgageRepaymentMethods']),
    selectAll: {
      get() {
        return every(this.calculatorCovers, ({ value }) => {
          return this.selections.includes(value);
        })
      },
      set(value) {
        let selected = [];
        const options = flatMap(this.calculatorCovers, 'value');
        if (value) {
          selected = [...this.selections, ...options];
        }
        else {
          selected = filter(this.selections, value => !options.includes(value));
        }
        this.__change(selected, this, 'selections');
      },
    },
    childrenNames() {
      return this.mapChildrensName.map(item => ({
        label: item,
        value: item,
      }));
    },
    getRecentValuesHelperLabel() {
      if (!this.recentValuesPayload) return null;
      let { alias } = this.recentValuesPayload;
      alias = startCase(kebabCase(alias).replace(/-/g, ' '));
      return `Track values from ${alias} calculator.`;
    },
    getFatalEntitlementsAmountValue() {
      if (!this.tabProvider.tabName.includes('life-cover')) return 0;
      const { fatal_entitlements } = this.calculationFields;
      const items = [];
      each(fatal_entitlements, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getFuneralCoverAmountValue() {
      if (!this.tabProvider.tabName.includes('life-cover')) return 0;
      const { funeral_cover } = this.calculationFields;
      const items = [];
      each(funeral_cover, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getRepatriationBenefitAmountValue() {
      const { repatriation_benefit } = this.calculationFields;
      const items = [];
      each(repatriation_benefit, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getInvestmentAmountValue() {
      const { investment } = this.calculationFields;
      const items = [];
      each(investment, item => {
        items.push(this.__calculateInvestment(item));
      });
      return floatTotals(items);
    },
    getCharityAmountValue() {
      const { charity } = this.calculationFields;
      const items = [];
      each(charity, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getInheritanceAmountValue() {
      const { inheritance } = this.calculationFields;
      const items = [];
      each(inheritance, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getOthersAmountValue() {
      const { others } = this.calculationFields;
      const items = [];
      each(others, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getEducationalFundAmountValue() {
      const { educational_fund } = this.calculationFields;
      const items = [];
      each(educational_fund, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getNannyCostAnnuallyAmountValue() {
      const { nanny_cost_annually } = this.calculationFields;
      const items = [];
      each(nanny_cost_annually, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getNannyCostAmountValue() {
      const { nanny_cost } = this.calculationFields;
      const items = [];
      each(nanny_cost, item => {
        items.push(this.__calculateNannyCost(item));
      });
      return floatTotals(items);
    },
    getFamilyFundAmountValue() {
      const { family_fund } = this.calculationFields;
      const items = [];
      each(family_fund, ({ value, years_income }) => {
        items.push(this.__calculateByYears(value, years_income));
      });
      return floatTotals(items);
    },
    getPersonalLoanAmountValue() {
      const { personal_loan } = this.calculationFields;
      const items = [];
      each(personal_loan, ({ value, percentage }) => {
        items.push(this.__calculateByPercentage(value, percentage));
      });
      return floatTotals(items);
    },
    getBusinessDebtAmountValue() {
      const { business_debt } = this.calculationFields;
      const items = [];
      each(business_debt, ({ value, percentage }) => {
        items.push(this.__calculateByPercentage(value, percentage));
      });
      return floatTotals(items);
    },
    getMortgageAmountValue() {
      const { mortgage_amount } = this.calculationFields;
      const items = [];
      each(mortgage_amount, ({ value, percentage }) => {
        items.push(this.__calculateByPercentage(value, percentage));
      });
      return floatTotals(items);
    },
    getMortgageAmountRentalInvestmentProperty() {
      const { mortgage_amount_rental_investment_property } = this.calculationFields;
      const items = [];
      each(mortgage_amount_rental_investment_property, ({ value, percentage }) => {
        items.push(this.__calculateByPercentage(value, percentage));
      });
      return floatTotals(items);
    },
    getRemainingMortgageRepaymentsValue() {
      const { remaining_mortgage_repayments } = this.calculationFields;
      const items = [];
      each(remaining_mortgage_repayments, item => {
        items.push(this.__calculateByRemainingMortgageRepayments(item));
      });
      return floatTotals(items);
    },
    getRemainingMortgageRepaymentsLess() {
      const { mortgage_amount, mortgage_amount_rental_investment_property } = this.calculationFields;
      const sumAssured = floatTotals([
        this.getMortgageAmountValue,
        this.getMortgageAmountRentalInvestmentProperty,
      ]);
      const items = [];
      each(mortgage_amount, ({ value }) => {
        items.push(floatFixer(value));
      });
      each(mortgage_amount_rental_investment_property, ({ value }) => {
        items.push(floatFixer(value));
      });
      const totalAmount = floatTotals(items);
      return floatDiff(totalAmount, sumAssured);
    },
    totalRecommendedLabel: () => ('Total Recommended Life Cover'),
    calculatorCovers: () => ([
      { label: 'Mortgage Amount - Residential', value: 'mortgage_amount' },
      { label: 'Mortgage Amount - Rental/Investment Property', value: 'mortgage_amount_rental_investment_property' },
      { label: 'Remaining Mortgage Repayments if A Lump Sum Paid Off', value: 'remaining_mortgage_repayments' },
      { label: 'Personal Loan (inc Car Loan and Credit Card Debit)', value: 'personal_loan' },
      { label: 'Business Debt (inc Business Loans, Property Mortgages etc)', value: 'business_debt' },
      { label: 'Replace a Lost Income', value: 'family_fund' },
      { label: 'Funeral Cover', value: 'funeral_cover' },
      { label: 'Repatriation Benefit', value: 'repatriation_benefit' },
      { label: 'Fatal Entitlements', value: 'fatal_entitlements' },
      { label: 'Educational Fund (Private School, University Fees etc)', value: 'educational_fund' },
      { label: 'Nanny Cost (Annually)', value: 'nanny_cost_annually' },
      { label: 'Caregiver Cost (Hourly Basis)', value: 'nanny_cost' },
      { label: 'Investment', value: 'investment' },
      { label: 'Charity', value: 'charity' },
      { label: 'Young Adult Life Cover', value: 'young_adult_life_cover' },
      { label: 'Inheritance', value: 'inheritance' },
      { label: 'Others', value: 'others' },
    ]),
    collateralTypes: () => ([
      { label: 'Bank', value: 'Bank' },
      { label: 'Stock Market', value: 'Stock Market' },
      { label: 'Property', value: 'Property' },
      { label: 'Investments', value: 'Investments' },
      { label: 'Business', value: 'Business' },
    ]),
    showTotalSumAssured() {
      return !every(this.calculationFields, isEmpty);
    },
    getTotalSumAssured() {
      const total = floatTotals([
        this.getMortgageAmountValue,
        this.getMortgageAmountRentalInvestmentProperty,
        this.getFamilyFundAmountValue,
        this.getPersonalLoanAmountValue,
        this.getBusinessDebtAmountValue,
        this.getRemainingMortgageRepaymentsValue,
        this.getFuneralCoverAmountValue,
        this.getRepatriationBenefitAmountValue,
        this.getEducationalFundAmountValue,
        this.getNannyCostAnnuallyAmountValue,
        this.getNannyCostAmountValue,
        this.getFatalEntitlementsAmountValue,
        this.getInvestmentAmountValue,
        this.getCharityAmountValue,
        this.getInheritanceAmountValue,
        this.getOthersAmountValue,
      ]);
      return floatFixer(total);
    },
    curatedData() {
      let items = [];

      each(this.calculationFields, (values, key) => {
        const __key = toString(key);
        if (! eq(__key, 'show_recommendations')) {
          let data = filter(values, ({ level, value }) => {
            if (['nanny_cost', 'remaining_mortgage_repayments'].includes(__key) && level) return true;
            return !isEmpty(level) && !isEmpty(value);
          });
          data = data.map(item => {
            if ([
              'mortgage_amount',
              'mortgage_amount_rental_investment_property',
              'personal_loan',
              'business_debt',
              'home_modifications',
            ].includes(__key)) {
              return {
                ...item,
                value: this.__calculateByPercentage(item.value, item.percentage)
              };
            }

            if (['remaining_mortgage_repayments'].includes(__key)) {
              return {
                ...item,
                value: this.__calculateByRemainingMortgageRepayments(item)
              };
            }

            if (['family_fund', 'income_needed'].includes(__key)) {
              return {
                ...item,
                value: this.__calculateByYears(item.value, item.years_income)
              };
            }

            if (['nanny_cost'].includes(__key)) {
              return {
                ...item,
                value: this.__calculateNannyCost(item),
              };
            }

            if (['caregiver_cost_annually'].includes(__key)) {
              return {
                ...item,
                value: this.__calculateCaregiverCost(item),
              };
            }

            if (['investment'].includes(__key)) {
              return {
                ...item,
                value: this.__calculateInvestment(item),
              };
            }

            return { ...item, value: floatFixer(item.value) };
          });

          items.push(data);
        }
      });

      items = flatMap(filter(items, v => v && v.length));
      if (!items.length) return null;

      items = Array.from(groupBy(items, value => value.level));
      // extract keys and parse the value
      let models = {};
      each(items, value => {
        const total = floatTotals(value[1].map(({ value }) => floatFixer(value)));
        models = {...models, [value[0]] : total };
      });
      //return models;
      const sortModels = {
        "Level to age 100": null,
        "Level to age 80": null,
        "Level to age 65": null,
        "Level for 10 years": null,
        "Stepped": null
      };

      Object.keys(sortModels).map(keySort => {
        Object.keys(models).map(key => {
          if ( eq(keySort,key) ) {
            sortModels[keySort] = models[key]
          }
        })
      })
      // Sort the values of models instead of the keys 
      // Object.keys(models)
      //   .map(key => [key, models[key]])
      //   .sort((a,b) => a[1] < b[1] ? 1 : a[1] > b[1] ? -1 : 0)
      //   .forEach(data => sortModels[data[0]] = data[1]);
      
      return sortModels;
      // sort by value instead of key
      // const sorted = chain(models)
      //   .invert()
      //   .value();
      // return sorted; // { value: key }
    },
    chartData() {
      if (!this.curatedData) return null;
      const labels = chain(this.curatedData)
        .keys()
        .value();
      const data = chain(this.curatedData).values().value();
      return {
        labels,
        datasets: [
          {
            data,
            label: 'Amount',
            borderWidth: 2,
          },
        ],
      };
    },
    chartStyles: () => ({
      height: 200,
      position: 'relative',
    }),
    chartOptions: () => ({
      elements: {
        rectangle: {
          borderWidth: 2,
        },
      },
      responsive: true,
      maintainAspectRatio: false,
      legend: { position: 'right' },
      title: {
        display: true,
        text: 'Premium Structure',
      },
      scales: {
        xAxes: [{
          stacked: true,
          ticks: {
            beginAtZero: true,
            callback(value) {
              return `$${numberWithCommas(value)}`;
            },
          },
          gridLines: {
            display: false,
          },
        }],
      },
    }),
  },
  components: {
    QInput,
    DisplayInput,
    PremiumStructure,
  },
};
</script>

<style lang="stylus" scoped>
.calculator-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
