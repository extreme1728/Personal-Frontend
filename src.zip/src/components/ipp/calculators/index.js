import Tpd from './TPD/Index';
import LifeCover from './LifeCover/Index';
import TaxCalculator from './TaxCalculator';
import HealthCover from './HealthCover/Index';
import TraumaCover from './TraumaCover/Index';
import IncomeProtection from './IncomeProtection';
import MortgageRepaymentIncomeProtection from './MortgageRepaymentIncomeProtection';
import MortgageRepaymentIncomeProtectionAndHouseExpenseCover from './MortgageRepaymentIncomeProtectionAndHouseExpenseCover';

export {
  Tpd,
  LifeCover,
  TraumaCover,
  HealthCover,
  TaxCalculator,
  IncomeProtection,
  MortgageRepaymentIncomeProtection,
  MortgageRepaymentIncomeProtectionAndHouseExpenseCover,
};
