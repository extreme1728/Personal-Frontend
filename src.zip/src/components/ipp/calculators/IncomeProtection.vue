<template lang="pug">
div
  div(class="q-my-md")
    h6(class="no-margin text-faded") Income Protection
  div(class="row q-my-md" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") We strive hard to take care of those that we love, earning to put food on the table, looking after rental/mortgage repayments and other unexpected expenses that prop up from time to time.
        p(:style="getBlockQuoteFontStyle") What is it that your income provides for you? Remembering all the things that income provides for you and your family, what if it stopped overnight?
        p(:style="getBlockQuoteFontStyle") Nobody is bullet proof. We all get sick and injured. It can sometimes affect our ability to work and more importantly, those that depend on our income. Income protection provides for you and your family when you can't.
        p(:style="getBlockQuoteFontStyle") Let's explore what we may need in the event that your lifeline income stops and how to cover that gap...
        p(:style="getBlockQuoteFontStyle") Let's get started.
  div(class="row")
    div(class="col-md-12")
      div
        display-input(
          v-if="readonly"
          prefix="$"
          label="Income"
          class="q-my-md"
          :value="income | numberComma"
        )
        q-input(
          v-else
          type="tel"
          prefix="$"
          v-money="{}"
          align="right"
          label="Income"
          :value="income"
          debounce="500"
          class="q-my-md"
          :readonly="readonly"
          @input="value => $emit('income:change', value)"
        )
      div
        display-input(
          v-if="readonly"
          label="Insurer"
          :value="category"
        )
        q-select(
          v-else
          emit-value
          map-options
          label="Insurer"
          class="q-my-md"
          :value="category"
          :readonly="readonly"
          :options="getInsuranceProvidersForTaxIssues"
          @input="value => $emit('category:change', value)"
        )
      display-input(
        type="tel"
        prefix="$"
        class="q-my-md"
        :value="incomeProtectionIndemnityAmount | numberComma"
        label="Income Protection Indemnity value Maximum Benefit Amount"
      )
      display-input(
        prefix="$"
        class="q-my-md"
        :value="incomeProtectionAgreedAmount | numberComma"
        label="Income Protection Agreed value Maximum Benefit Amount"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { CalculableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { DisplayInput } from 'src/components/ipp';

export default {
  name: 'income-protection',
  mixins: [CalculableMixin],
  inject: {
    tabProvider: {
      from: 'data',
      default() {
        return { tabName: 'income-protection' };
      },
    },
  },
  props: {
    category: {
      type: String,
      default: null,
    },
    incomeProtectionAgreedAmount: {
      type: Number,
      default: 0,
    },
    incomeProtectionIndemnityAmount: {
      type: Number,
      default: 0,
    },
  },
  computed: mapGetters('resources', {
    getInsuranceProvidersForTaxIssues: 'getInsuranceProvidersForTaxIssues',
  }),
  components: {
    QInput,
    DisplayInput,
  },
};
</script>
