<template lang="pug">
div
  div(class="q-my-md")
    h6(class="text-h6 no-margin text-faded") Tax Calculator
  div(class="row q-my-md")
    div(class="col-md-12")
      display-input(
        v-if="readonly"
        prefix="$"
        :value="income"
        label="Gross Income"
      )
      q-input(
        v-else
        type="tel"
        prefix="$"
        v-money="{}"
        align="right"
        :value="income"
        label="Gross Income"
        @input="value => $emit('income:change', value)"
      )
  div(class="row" v-if="!readonly")
    div(class="col-md-12")
      q-toggle(
        label="Company Tax Rate"
        :value="calculationFields.show_company_tax_rate"
        :label="calculationFields.show_company_tax_rate ? 'Hide' : 'Show'"
        @input="_ => __change(_, calculationFields, 'show_company_tax_rate')"
      )
  div(
    v-if="calculationFields.show_company_tax_rate"
    class="row q-col-gutter-md q-my-md"
  )
    div(class="col-md-5")
      display-input(
        prefix="$"
        :value="income"
      )
    div(class="col-md-2")
      display-input(
        suffix="%"
        :value="COMPANY_TAX_RATE"
      )
    div(class="col-md-5")
      display-input(
        prefix="$"
        :value="companyTaxRateCalculation | numberComma"
      )
  div(v-else class="row q-col-gutter-md q-my-md")
    div(class="col-md-5")
      p(class="text-faded") Tax Bracket
      display-input(
        v-for="(bracket, index) in taxCalculationResult.taxBrackets"
        :key="index"
        prefix="$"
        class="q-my-md"
        :value="bracket | numberComma"
      )
    div(class="col-md-2")
      p(class="text-faded") Tax Rate
      display-input(
        v-for="(rate, index) in taxCalculationResult.taxRates"
        :key="index"
        prefix="$"
        :value="rate"
        class="q-my-md"
      )
    div(class="col-md-5")
      p(class="text-faded") Tax
      display-input(
        v-for="(result, index) in taxCalculationResult.taxResults"
        :key="index"
        prefix="$"
        class="q-my-md"
        :value="result | numberComma"
      )
      display-input(
        prefix="$"
        class="q-my-md"
        hint="Total Amount"
        :value="taxCalculationResult.totalTax | numberComma"
      )
</template>

<script>
import { CalculableMixin } from 'src/mixins';
import { floatFixer } from 'src/config/utils';
import { QInput } from 'src/components/quasar';
import { DisplayInput } from 'src/components/ipp';
import { cloneDeep, merge, isEmpty, set } from 'lodash';

const calculationFieldSchema = {
  show_company_tax_rate: false,
};

export default {
  name: 'tax-calculator',
  mixins: [CalculableMixin],
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'tax',
      }),
    },
  },
  data: () => ({
    COMPANY_TAX_RATE: 28,
    calculationFields: cloneDeep(calculationFieldSchema),
  }),
  created() {
    if (!isEmpty(this.payload)) this.calculationFields = merge(cloneDeep(this.calculationFields), cloneDeep(this.payload));
  },
  props: {
    taxCalculationResult: {
      type: Object,
      required: true,
    },
  },
  methods: {
    __change: (value, item, field) => set(item, field, value),
  },
  computed: {
    companyTaxRateCalculation() {
      const percentage = this.COMPANY_TAX_RATE / 100;
      return floatFixer(floatFixer(this.income) * percentage);
    },
  },
  components: {
    QInput,
    DisplayInput,
  },
};
</script>
