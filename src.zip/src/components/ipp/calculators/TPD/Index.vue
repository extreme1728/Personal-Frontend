<template lang="pug">
div
  div(class="q-my-md text-faded" v-if="readonly")
    h6(class="text-h6 no-margin text-faded") Total and Permanent Disablement
    p(class="text-subtitle1 no-margin") Never being able to work again - total incapacity. Just imagine then.
  div(class="row q-my-md" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") Protecting your loved ones means being prepared for anything. Sometimes when we’re sick or injured, the outcome is more serious and long-lasting. Sometimes we have to think about the unthinkable. Otherwise known as “The big what if?”
        p(:style="getBlockQuoteFontStyle") You may already have health insurance and income protection, but what if you were left permanently disabled, and unable to work ever again?
        p(:style="getBlockQuoteFontStyle") How would your family's day-to-day life and those that rely upon you change? If you have a business, how would your business cope? Do you have a plan to provide for them? What would happen to your future, and theirs?
        p(:style="getBlockQuoteFontStyle") Let's get started.
  q-card(square :flat="readonly")
    q-card-section(v-if="!readonly" style="height: 100px" :class="`bg-${color}`")
    q-card-section(class="relative-position" v-if="!readonly")
      p(class="text-faded text-h6 q-my-md") Total and Permanent Disablement
      div(class="q-gutter-md")
        q-toggle(
          label="Show Recommendations"
          :value="calculationFields.show_recommendations"
          @input="_ => __change(_, calculationFields, 'show_recommendations')"
        )
        q-toggle(
          label="Show Considerations"
          :value="calculationFields.show_considerations"
          @input="_ => __change(_, calculationFields, 'show_considerations')"
        )
      q-btn(
        fab
        color="secondary"
        icon="add"
        class="absolute calculator-card--button"
        @click="__showOptionList"
      )
    q-card-section
      q-list
        include blocks/home-modifications
        include blocks/caregiver-cost-annually
        include blocks/disability-income-protection
        include ../LifeCover/blocks/mortgage-amount
        include ../LifeCover/blocks/mortgage-amount-rental-investment-property
        include ../LifeCover/blocks/remaining-mortgage-repayments
        include ../LifeCover/blocks/personal-loan
        include ../LifeCover/blocks/business-debt
        include ../LifeCover/blocks/family-fund
        include ../LifeCover/blocks/educational-fund
        include ../LifeCover/blocks/others
        include ../LifeCover/blocks/total-sum-assured
  premium-structure(
    v-if="curatedData"
    class="q-my-md"
    :style="chartStyles"
    :options="chartOptions"
    :chart-data="chartData"
  )
  include ../blocks/selections-dialog
</template>

<script>
import LifeCover from '../LifeCover/Index';
import { cloneDeep, each, isEmpty, merge } from 'lodash';
import { floatTotals, floatFixer } from 'src/config/utils';

const calculationModels = {
  home_modifications: {
    uid: null,
    index: null,
    level: null,
    percentage: 100,
    value: '50,000',
    description: null,
  },
  mortgage_amount: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  mortgage_amount_rental_investment_property: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  remaining_mortgage_repayments: {
    uid: null,
    years_income: 1,
    percentage: 100,
    type: 'interest',
    index: null,
    level: null,
    principal_percentage: 100,
    description: null,
  },
  personal_loan: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  business_debt: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  disability_income_protection: {
    uid: null,
    years_needed: 0,
    percentage: 25,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  family_fund: {
    uid: null,
    index: null,
    level: null,
    years_income: 1,
    value: 0,
    description: null,
  },
  educational_fund: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  caregiver_cost_annually: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    years_needed: 0,
    description: null,
  },
  others: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
};

const calculationFieldSchema = {
  show_recommendations: true,
  show_considerations: true,
  home_modifications: [],
  mortgage_amount: [],
  mortgage_amount_rental_investment_property: [],
  remaining_mortgage_repayments: [],
  personal_loan: [],
  business_debt: [],
  disability_income_protection: [],
  family_fund: [],
  educational_fund: [],
  caregiver_cost_annually: [],
  others: [],
};

export default {
  name: 'tpd-calculator',
  extends: LifeCover,
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'tpd',
      }),
    },
  },
  data: () => ({
    selections: [],
    showSelectionsDialog: false,
    calculationFields: cloneDeep(calculationFieldSchema),
    calculationModels: cloneDeep(calculationModels),
  }),
  created() {
    if (!isEmpty(this.payload)) this.calculationFields = merge(cloneDeep(this.calculationFields), cloneDeep(this.payload));
  },
  methods: {
    __disabilityIncomeAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { disability_income_protection } } = this.recentValuesPayload;
            if (!disability_income_protection && !disability_income_protection.length) return;
            const { value, percentage } = last(disability_income_protection);
            this.__change(value, item, 'value');
            this.__change(percentage, item, 'percentage');
          },
        },
      ];
    },
  },
  computed: {
    getDisabilityIncomeAmountValue() {
      const { disability_income_protection } = this.calculationFields;
      const items = [];
      each(disability_income_protection, item => {
        items.push(this.__calculateDisabilityIncome(item));
      });
      return floatTotals(items);
    },
    getHomeModificationsValue() {
      const { home_modifications } = this.calculationFields;
      const items = [];
      each(home_modifications, ({ value, percentage }) => {
        items.push(this.__calculateByPercentage(value, percentage));
      });
      return floatTotals(items);
    },
    getCaregiverCostAnnually() {
      const { caregiver_cost_annually } = this.calculationFields;
      const items = [];
      each(caregiver_cost_annually, item => {
        items.push(this.__calculateCaregiverCost(item));
      });
      return floatTotals(items);
    },
    getTotalSumAssured() {
      const total = floatTotals([
        this.getHomeModificationsValue,
        this.getMortgageAmountValue,
        this.getMortgageAmountRentalInvestmentProperty,
        this.getFamilyFundAmountValue,
        this.getPersonalLoanAmountValue,
        this.getBusinessDebtAmountValue,
        this.getRemainingMortgageRepaymentsValue,
        this.getEducationalFundAmountValue,
        this.getCaregiverCostAnnually,
        this.getDisabilityIncomeAmountValue,
        this.getOthersAmountValue,
      ]);
      return floatFixer(total);
    },
    totalRecommendedLabel: () => ('Total Recommended Total Permanent Disability'),
    calculatorCovers: () => ([
      { label: 'Home Modifications', value: 'home_modifications' },
      { label: 'Caregiver Cost (Annually)', value: 'caregiver_cost_annually' },
      { label: 'Mortgage Amount - Residential', value: 'mortgage_amount' },
      { label: 'Mortgage Amount - Rental/Investment Property', value: 'mortgage_amount_rental_investment_property' },
      { label: 'Remaining Mortgage Repayments if A Lump Sum Paid Off', value: 'remaining_mortgage_repayments' },
      { label: 'Personal Loan (inc Car Loan and Credit Card Debit)', value: 'personal_loan' },
      { label: 'Business Debt (inc Business Loans, Property Mortgages etc)', value: 'business_debt' },
      { label: 'Top Up Disability Income Protection', value: 'disability_income_protection' },
      { label: 'Family Fund', value: 'family_fund' },
      { label: 'Educational Fund (Private School, University Fees etc)', value: 'educational_fund' },
      { label: 'Others', value: 'others' },
    ]),
    homeModificationsConsiderationWordings() {
      const items = [
        { label: 'A Tale of A Tragedy'},
        {
          label: 'Picture This- Heart Attack',
          contents: ['Your husband/wife, partner, grandmother/grandfather, has just suffered a heart attack. This has had a significant impact on both immediate family as well as the now fragile loved one – his/her independence has now been impacted and the need for additional care is now a part of their daily routine.'],
        },
        {
          label: 'Decision Time - Home Alterations or Cared Lifestyle?',
          contents: [
            'A decision that will impact the loved ones remaining living life needs to be made – to make the alterations to the home and the cost associated with it, or to look to alternate opportunities such as a cared lifestyle within a retirement home or via a nanny/caretaker.',
            'It has been decided that we will proceed down the route of home alterations.'
          ],
        },
        {
          label: 'Any Assistance Available For Those Disabled?',
          contents: [
            'Upper limit available funding of $15,334 incl. GST, which includes mobility access between floors.*',
            'This funding can be utilised for ramps, platform lifts, and through floor-lifts – it doesn’t allow for door widening and level access showers.*',
            '*Ministry of Health Financial Assistance Funding for Housing Modifications'
          ],
        },
        {
          label: 'Cost to retrofit your bathroom',
          contents: [
            '$20,000 +',
            'The bathroom remodel alone could easily cost $20,000+',
            'Includes:',
            'Widening the doorway for wheelchairs to pass',
            'Creating a walk-in shower',
            'Adding grab bars in the shower and by the toilet (Vertical Grab rail on side walls)',
            'Lowering the sink and medicine cabinet for easy reach from a wheelchair.',
            'Moving walls so enough room in bathroom for a wheelchair to rotate 360 degrees ie allow sufficient space for manoeuvrability and assistance',
            'Bath edge height too high',
            'WC pan height too high or too low',
            'A shower hob - installing a hand-held shower head',
            'Provide a level access (i.e. no hob) to provide easier access.',
            'Relocate Poorly located fixtures & fittings',
            'Poorly selected fittings (such as taps that are difficult for people are disabled or with arthritis to use)',
            'Select a textured or slip-resistant finish.',
            'If installing a seat, locate on the wall adjacent to the shower head and ensure that controls are within reach.',
          ],
        },
        {
          label: 'What about Toilet Accessibilty?',
          contents: [
            'Include features that facilitate toilet accessibility:',
            'Install the toilet at a height to suit the predominant use, i.e. people in wheelchairs prefer to transfer at the same height as the seat of their wheelchair; older people prefer a higher seat.',
            'Allow a clear space on one side to transfer to the toilet.',
            'Locate the toilet at the correct distance to enable grab rail use',
            'Not having a slope on the area of floor that is used to allow the occupant to transfer from the wheelchair to the toilet.',
            'Locate the toilet paper dispenser below the grab rail so it does not interfere with grab rail use.',
            'Ensure the grab rail is securely fixed to the structure.',
          ],
        },
        {
          label: 'Include features that facilitate basin or vanity accessibility:',
          contents: [
            'Set the vanity or basin height at 750 mm or to suit.',
            'Allow leg space underneath to suit.',
            'Install a single, lever-action tap.',
            'Avoid using pop-up plugs as they can be difficult to operate.',
            'Ensure that water supply pipes and waste outlets do not encroach on the required leg space underneath.',
          ],
        },
      ];
      return items.map(item => {
        return {
          label: item.label,
          contents: item.contents || [],
        };
      });
    }
  },
};
</script>

<style lang="stylus" scoped>
.img-responsive
  width 100%
  height auto
  max-width 720px
.calculator-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
