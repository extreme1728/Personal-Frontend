<template lang="pug">
div
  div(class="q-my-md text-faded" v-if="readonly")
    h6(class="text-h6 no-margin text-faded") Trauma Cover
    p(class="text-subtitle1 no-margin") Life after a major health set back.
  div(class="row" v-if="readonly")
    div(class="col-md-12")
      blockquote(class="q-my-md note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") Nobody wants to think about the possibility of experiencing a heart attack, stroke or even a cancer? What would you like to happen if a life changing event occurred?
        p(:style="getBlockQuoteFontStyle") Major illness is tough news and tough to deal with, without the added financial impact that can come with it for you and your family?
        p(:style="getBlockQuoteFontStyle") Give yourself, and your children, the best chance of recovery. If you were seriously ill, could you cover the cost of your treatment, and pay the regular household bills, while taking the time off you need to recover?
        p(:style="getBlockQuoteFontStyle") Let's get started.
      blockquote(class="q-my-md note-border-primary text-weight-regular text-justify")
        p(:style="getBlockQuoteFontStyle") Did you know? Every day 57 people in New Zealand are diagnosed with Cancer. That is 7 people each hour of the working day, 1 every 9 minutes.
  q-card(square :flat="readonly")
    q-card-section(v-if="!readonly" style="height: 100px" :class="`bg-${color}`")
    q-card-section(class="relative-position" v-if="!readonly")
      p(class="text-faded text-h6 q-my-md") Trauma Cover
      p(class="text-faded text-caption no-margin") Did you know? Every day 57 people in New Zealand are diagnosed with Cancer. That is 7 people each hour of the working day, 1 every 9 minutes.
      div(class="q-gutter-md")
        q-toggle(
          label="Show Recommendations"
          :value="calculationFields.show_recommendations"
          @input="_ => __change(_, calculationFields, 'show_recommendations')"
        )
        q-toggle(
          label="Show Considerations"
          :value="calculationFields.show_considerations"
          @input="_ => __change(_, calculationFields, 'show_considerations')"
        )
      q-btn(
        fab
        color="secondary"
        icon="add"
        class="absolute calculator-card--button"
        @click="__showOptionList"
      )
    q-card-section
      q-list
        include ../LifeCover/blocks/mortgage-amount
        include ../LifeCover/blocks/mortgage-amount-rental-investment-property
        include ../LifeCover/blocks/remaining-mortgage-repayments
        include blocks/bucket-list
        include ../LifeCover/blocks/personal-loan
        include ../LifeCover/blocks/business-debt
        include blocks/income-needed
        include ../TPD/blocks/caregiver-cost-annually
        include blocks/nanny-cost-annually
        include blocks/nanny-cost
        include blocks/non-pharmac-drug-cost
        include blocks/limited-income-protection
        include ../LifeCover/blocks/others
        include ../LifeCover/blocks/total-sum-assured
  premium-structure(
    v-if="curatedData"
    class="q-my-md"
    :style="chartStyles"
    :options="chartOptions"
    :chart-data="chartData"
  )
  include ../blocks/selections-dialog
</template>

<script>
import LifeCover from '../LifeCover/Index';
import { trim, cloneDeep, each, isEmpty, merge, startCase, kebabCase } from 'lodash';
import { numberWithCommas, floatTotals, floatFixer } from 'src/config/utils';

const calculationModels = {
  mortgage_amount: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  mortgage_amount_rental_investment_property: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  remaining_mortgage_repayments: {
    uid: null,
    years_income: 1,
    percentage: 100,
    type: 'interest',
    index: null,
    level: null,
    principal_percentage: 100,
    description: null,
  },
  personal_loan: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  business_debt: {
    uid: null,
    percentage: 100,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  bucket_list: {
    uid: null,
    index: null,
    level: null,
    wishes: [],
    value: 0,
    description: null,
  },
  income_needed: {
    uid: null,
    index: null,
    level: null,
    years_income: 1,
    value: 0,
    description: null,
  },
  caregiver_cost_annually: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    years_needed: 0,
    description: null,
  },
  nanny_cost_annually: {
    uid: null,
    value: 0, // annual cost
    years_needed: 0,
    index: null,
    level: null,
    description: null,
  },
  nanny_cost: { // hourly basis
    uid: null,
    rate_per_hour: 20,
    hours_per_week: 0,
    index: null,
    level: null,
    description: null,
  },
  non_pharmac_drug_cost: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  limited_income_protection: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
  others: {
    uid: null,
    index: null,
    level: null,
    value: 0,
    description: null,
  },
};

const calculationFieldSchema = {
  show_recommendations: true,
  show_considerations: true,
  mortgage_amount: [],
  mortgage_amount_rental_investment_property: [],
  remaining_mortgage_repayments: [],
  personal_loan: [],
  business_debt: [],
  bucket_list: [],
  income_needed: [],
  caregiver_cost_annually: [],
  nanny_cost_annually: [],
  nanny_cost: [],
  non_pharmac_drug_cost: [],
  limited_income_protection: [],
  others: [],
};

export default {
  name: 'trauma-cover',
  extends: LifeCover,
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'trauma-cover',
      }),
    },
  },
  data: () => ({
    selections: [],
    showSelectionsDialog: false,
    calculationFields: cloneDeep(calculationFieldSchema),
    calculationModels: cloneDeep(calculationModels),
  }),
  created() {
    if (!isEmpty(this.payload)) this.calculationFields = merge(cloneDeep(this.calculationFields), cloneDeep(this.payload));
  },
  methods: {
    __LimitedAmountAfterIcons(item) {
      return [
        {
          icon: 'track_changes',
          condition: !this.readonly,
          handler: () => {
            if (!this.recentValuesPayload) return;
            const { payload: { limited_income_protection } } = this.recentValuesPayload;
            if (!limited_income_protection && !limited_income_protection.length) return;
            const { value } = last(limited_income_protection);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __handleBucketListWishesBlur(e, ref) {
      const { value } = e.target;
      if (trim(value)) {
        if (this.$refs[ref][0]) {
          this.$refs[ref][0].add();
        }
      }
    },
    __incomeNeededAmountAfterIcons(item) {
      return [
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            const value = numberWithCommas(this.getIncomeAmount);
            this.__change(value, item, 'value');
          },
        },
      ];
    },
    __incomeNeededYearsAfterIcons(item) {
      return [
        {
          icon: 'sync',
          condition: !this.readonly,
          handler: () => {
            const { age_income_requirement } = this.fatal;
            const determinedAge = this.youngestChildAge ? (age_income_requirement - this.youngestChildAge) : 0;
            this.__change(determinedAge, item, 'years_income');
          },
        },
      ];
    },
  },
  computed: {
    getRecentValuesHelperLabel() {
      if (!this.recentValuesPayload) return null;
      let { alias } = this.recentValuesPayload;
      alias = startCase(kebabCase(alias).replace(/-/g, ' '));
      return `Track values from ${alias} calculator.`;
    },
    getLimitedIncomeAmountValue() {
      const { limited_income_protection } = this.calculationFields;
      const items = [];
      each(limited_income_protection, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getNonPharmacDrugCostAmountValue() {
      const { non_pharmac_drug_cost } = this.calculationFields;
      const items = [];
      each(non_pharmac_drug_cost, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getBucketListAmountValue() {
      const { bucket_list } = this.calculationFields;
      const items = [];
      each(bucket_list, ({ value }) => {
        items.push(numberWithCommas(value, false));
      });
      return floatTotals(items);
    },
    getIncomeNeededAmountValue() {
      const { income_needed } = this.calculationFields;
      const items = [];
      each(income_needed, ({ value, years_income }) => {
        items.push(this.__calculateByYears(value, years_income));
      });
      return floatTotals(items);
    },
    getCaregiverCostAnnually() {
      const { caregiver_cost_annually } = this.calculationFields;
      const items = [];
      each(caregiver_cost_annually, item => {
        items.push(this.__calculateCaregiverCost(item));
      });
      return floatTotals(items);
    },
    getTotalSumAssured() {
      const total = floatTotals([
        this.getMortgageAmountValue,
        this.getMortgageAmountRentalInvestmentProperty,
        this.getRemainingMortgageRepaymentsValue,
        this.getBucketListAmountValue,
        this.getPersonalLoanAmountValue,
        this.getBusinessDebtAmountValue,
        this.getIncomeNeededAmountValue,
        this.getCaregiverCostAnnually,
        this.getNannyCostAnnuallyAmountValue,
        this.getNannyCostAmountValue,
        this.getNonPharmacDrugCostAmountValue,
        this.getLimitedIncomeAmountValue,
        this.getOthersAmountValue,
      ]);
      return floatFixer(total);
    },
    totalRecommendedLabel: () => ('Total Recommended Trauma Sum Assured'),
    calculatorCovers: () => ([
      { label: 'Mortgage Amount - Residential', value: 'mortgage_amount' },
      { label: 'Mortgage Amount - Rental/Investment Property', value: 'mortgage_amount_rental_investment_property' },
      { label: 'Remaining Mortgage Repayments if A Lump Sum Paid Off', value: 'remaining_mortgage_repayments' },
      { label: 'Bucket List', value: 'bucket_list' },
      { label: 'Personal Loan', value: 'personal_loan' },
      { label: 'Business Debt (inc Business Loans, Property Mortgages etc)', value: 'business_debt' },
      { label: 'Time Needed Off Work', value: 'income_needed' },
      { label: 'Caregiver Cost (Annually)', value: 'caregiver_cost_annually' },
      { label: 'Nanny Cost (Annually)', value: 'nanny_cost_annually' },
      { label: 'Caregiver Cost (Hourly Basis)', value: 'nanny_cost' },
      { label: 'Non-Pharmac Drug Cost', value: 'non_pharmac_drug_cost' },
      { label: 'Limited Condition Income Protection', value: 'limited_income_protection' },
      { label: 'Others', value: 'others' },
    ]),
    nonPharmacDrugCostConsiderationWordings() {
      const items = [
        {
          label: [
            'Cancer Accounts for almost one third of all deaths in New Zealand',
          ],
          contents: [
            '*Qualifying Products. One or more Life ($300,000), Trauma ($100,000) or Total & Permanent Disablement',
            '**Source New Zealand Ministry of Health, NZ Cancer Plan 2015-2018',
          ],
        },
        {
          label: [
            'United Kingdom',
            'Public Funding model National Institute for Health and Care Excellence (NICE)',
          ],
          contents: [
            '86.7% of modern medicines registered in the UK are publicly funded',
            'It takes on average 128 days for a modern medicine to be publicly funded after registration',
            'The UK ranks 2nd out of 20 OECD countries for access to modern medicines',
          ],
        },
        {
          label: [
            'Australia',
            'Public funding model Pharmaceutical Benefits Scheme (PBS)',
          ],
          contents: [
            '46.4% of modern medicines registered in Australia are public funded',
            'It takes on average 352 days to publicly fund the same modern medicines as New Zealand after registration',
            'Australia ranks 17 out of 20 OECD countries for across to modern medicines',
          ],
        },
        {
          label: [
            'New Zealand',
            'Public funding model Pharmaceutical Management Agency(PHARMAC)'
          ],
          contents: [
            '23.5% of modern medicines registered in the New Zealand are publicly funded',
            'It takes on average 599 days to publicly fund the same modern medicines as Australia after registration',
            'New Zealand ranks last out of 20 OECD countries for access to modern medicines',
          ],
        },
      ];
      return items.map(item => {
        return {
          label: item.label || [],
          contents: item.contents || [],
        };
      });
    }
  },
};
</script>

<style lang="stylus" scoped>
.img-responsive
  width 100%
  height auto
  max-width 720px
.calculator-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
