<template lang="pug">
div
  div(class="q-my-md text-faded" v-if="readonly")
    h6(class="text-h6 no-margin text-faded") Health Cover
    p(class="text-subtitle1 no-margin") Access the best medical care today. With JD Life, you can access NZ private medical care where it suits you.
  q-card(square :flat="readonly")
    q-card-section(v-if="!readonly" style="height: 100px" :class="`bg-${color}`")
    q-card-section(class="relative-position" v-if="!readonly")
      p(class="text-faded text-h6 q-my-md") Health Cover
      p(class="text-faded text-caption no-margin") Access the best medical care today. With JD Life, you can access NZ private medical care where it suits you.
      div(class="q-gutter-md")
        q-toggle(
          label="Show Recommendations"
          :value="calculationFields.show_recommendations"
          @input="_ => __change(_, calculationFields, 'show_recommendations')"
        )
        q-toggle(
          label="Show Considerations"
          :value="calculationFields.show_considerations"
          @input="_ => __change(_, calculationFields, 'show_considerations')"
        )
      q-btn(
        fab
        color="secondary"
        icon="add"
        class="absolute calculator-card--button"
        @click="__showOptionList"
      )
    q-card-section
      q-list
        include blocks/insurance-provider
        include blocks/check-list
        include blocks/excess
        include blocks/general-practitioner
        include blocks/medical-dental
        include blocks/hospital-cost
        div(v-show="calculationFields.show_considerations")
          include blocks/considerations
  include ../blocks/selections-dialog
</template>

<script>
import { openURL } from 'quasar';
import { mapGetters } from 'vuex';
import TraumaCover from '../TraumaCover/Index';
import { numberWithCommas } from 'src/config/utils';
import { eq, some, cloneDeep, filter, includes, uniq, isEmpty, map } from 'lodash';
import HealthCoverInsuranceProviderService from 'src/services/ipp/calculators/HealthCoverInsuranceProviderService';

const calculationModels = {
  insurance_provider: {
    uid: null,
    does_any_exclusions_on_existing_health_insurance: null,
    any_exclusions_on_existing_health_insurance_description: null,
    does_had_any_health_issues: null,
    had_any_health_issues_description: null,
    does_had_any_previous_medical_issues: null,
    had_any_previous_medical_issues_description: null,
    provider: null,
    excess_base_plan: null,
    does_include_pharmac: null,
    has_pre_existing_conditions_covered: false,
    does_include_specialist_and_diagnostics: null,
    specialist_and_diagnostics_excess: null,
    description: null,
  },
  check_list: {
    uid: null,
    value: null,
    excess: null,
    description: null,
  },
  excess: {
    uid: null,
    value: '0',
    description: null,
  },
  general_practitioner: {
    uid: null,
    value: null,
    description: null,
  },
  medical_and_dental: {
    uid: null,
    value: null,
    description: null,
  },
  hospital_cost: {
    uid: null,
    value: null,
    description: null,
  },
};

const calculationFieldSchema = {
  show_recommendations: true,
  show_considerations: false,
  non_pharmac_drug_cost: [],
  insurance_provider: [],
  excess: [],
  check_list: [],
  general_practitioner: [],
  medical_and_dental: [],
  hospital_cost: [],
};

export default {
  name: 'health-cover-calculator',
  extends: TraumaCover,
  inject: {
    tabProvider: {
      from: 'data',
      default: () => ({
        tabName: 'health-cover',
      }),
    },
  },
  data: () => ({
    selections: [],
    showSelectionsDialog: false,
    calculationFields: cloneDeep(calculationFieldSchema),
    calculationModels: cloneDeep(calculationModels),
  }),
  props: {
    type: {
      type: String,
      default: 'client',
    },
  },
  methods: {
    openURL,
    __providers(item) {
      return (new HealthCoverInsuranceProviderService(item, this.isCitizen)).providers();
    },
    __getInsuranceProviderDocument({ provider }) {
      try {
        return require(`assets/documents/health-cover/${provider}.pdf`);
      }
      catch (e) {
        return false;
      }
      return false;
    },
  },
  computed: {
    ...mapGetters('planner', ['plan']),
    ...mapGetters('resources', ['existingCovers', 'booleanValues']),
    providerLabel() {
      return this.isCitizen
        ? 'Chosen Health Insurance Provider'
        : 'Would you prefer Accuro or Southern Cross Cover?';
    },
    totalRecommendedLabel: () => ('Total Recommended Health Sum Assured'),
    calculatorCovers() {
      let options = [
        { label: 'Insurance Provider', value: 'insurance_provider' },
        { label: 'Checklist', value: 'check_list' },
        { label: 'Excess', value: 'excess' },
      ];
      if (this.isCitizen) {
        options = [
          ...options,
          { label: 'General Practitioner', value: 'general_practitioner' },
          { label: 'Medical and Dental', value: 'medical_and_dental' },
          { label: 'Hospital Cost', value: 'hospital_cost' },
        ];
      }
      return options;
    },
    checkListOptions: () => ([
      { label: 'Non Pharmac', value: 'Non Pharmac' },
      { label: 'Specialist and Diagnostics', value: 'Specialist and Diagnostics' },
    ]),
    insuranceProviderOptions() {
      return {
        pharmac: ['Include Non Pharmac', 'Do Not include Non Pharmac'],
        specialist_and_diagnostics: ['Include', 'Not Include'],
        excess_on_specialist_and_diagnostics: [{ label: '$0', value: '0' }, { label: '$250', value: '250' }],
      };
    },
    excessOptions() {
      let opts = [
        { label: '$0', value: '0' },
        { label: '$250', value: '250' },
        { label: '$500', value: '500' },
        { label: '$600', value: '600' },
        { label: '$750', value: '750' }, // AIA
        { label: '$1,000', value: '1,000' },
        { label: '$2,000', value: '2000' },
        { label: '$4,000', value: '4000' }, // AIA
        { label: '$5,000', value: '5,000' },
        { label: '$6,000', value: '6,000' },
        { label: '$8,000', value: '8,000' },
      ];
      if (this.isCitizen) {
        opts = [
          ...opts,
          ...[{ label: '$10,000', value: '10,000' }],
        ];
      }
      return opts;
    },
    isCitizen() {
      const { plan, type } = this;
      if (this.isCitizenOrPrEmpty) return true;
      if (eq(plan[`${type}_citizen_or_pr`], 'yes')) return true;
      return eq(plan[`${type}_citizen_or_pr`], 'no')
        && eq(plan[`${type}_student_or_work`], 'yes')
        && eq(plan[`${type}_work_visa_greater_two_years`], 'yes')
        && eq(plan[`${type}_twelve_months_left_visa`], 'yes');
    },
    isCitizenOrPrEmpty() {
      return isEmpty(this.plan[`${this.type}_citizen_or_pr`]);
    },
    booleanValuesWithNoExistingCover() {
      return [
        ...this.booleanValues,
        ...[{ label: 'No existing health cover', value: 'no existing health cover' }],
      ];
    },
  },
};
</script>

<style lang="stylus" scoped>
.calculator-card--button
  top 0
  right 8px
  transform translateY(-50%)
.img-responsive
  width 100%
  height auto
  max-width 720px
</style>
