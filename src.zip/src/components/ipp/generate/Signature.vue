<template lang="pug">
div
  div
    h6(class="text-faded") Client Signature
    p(
      v-if="disclosure"
      v-text="disclosure"
      class="text-center"
    )
    div(class="signature-container client")
      vue-signature(
        h="40vh"
        ref="clientSignature"
        :sigOption="signatureConfig.option"
      )
    div(class="row q-col-gutter-md")
      div(class="col-md-4")
        q-btn(
          flat
          color="secondary"
          class="full-width"
          @click="onSignatureClear('client')"
        ) Clear
      div(class="col-md-4")
        q-btn(
          flat
          color="secondary"
          class="full-width"
          @click="onSignatureUndo('client')"
        ) Undo
      div(class="col-md-4")
        q-btn(
          v-if="hasClientIncome"
          color="secondary"
          class="full-width"
          @click="onSignatureSave('client')"
        ) Save
  div
    h6(class="text-faded") Partner Signature
    div(class="signature-container partner")
      vue-signature(
        h="40vh"
        ref="partnerSignature"
        :sigOption="signatureConfig.option"
      )
    div(class="row md-gutter")
      div(class="col-md-4")
        q-btn(
          flat
          color="secondary"
          class="full-width"
          @click="onSignatureClear('partner')"
        ) Clear
      div(class="col-md-4")
        q-btn(
          flat
          color="secondary"
          class="full-width"
          @click="onSignatureUndo('partner')"
        ) Undo
      div(class="col-md-4")
        q-btn(
          v-if="hasClientIncome"
          color="secondary"
          class="full-width"
          @click="onSignatureSave('partner')"
        ) Save
</template>

<script>
import { isEmpty } from 'lodash';
import { mapGetters } from 'vuex';

export default {
  name: 'generate-signature',
  props: {
    clientSignature: String,
    partnerSignature: String,
    disclosure: String,
  },
  mounted() {
    const { clientSignature, partnerSignature } = this;
    this.$nextTick().then(() => {
      if (!isEmpty(clientSignature))
        this.$refs['clientSignature'].fromDataURL(clientSignature);
      if (!isEmpty(partnerSignature))
        this.$refs['partnerSignature'].fromDataURL(partnerSignature);
    });
  },
  methods: {
    onSignatureClear(type) {
      this.$refs[`${type}Signature`].clear();
      // this.$emit('clear', type);
      this.$emit('save', { data: null, type });
    },
    onSignatureUndo(type) {
      this.$refs[`${type}Signature`].undo();
      this.$emit('undo', type);
    },
    onSignatureSave(type) {
      const { format } = this.signatureConfig;
      const data = this.$refs[`${type}Signature`].save(format);
      this.$emit('save', { data, type });
    },
  },
  computed: {
    ...mapGetters('resources', {
      signatureConfig: 'signatureConfig',
    }),
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
    }),
  },
};
</script>


<style lang="stylus" scoped>
.signature-container
  border 1px dotted $tertiary
  margin-top .5em
  margin-bottom .5em
  &.partner
    margin-top 1em
</style>
