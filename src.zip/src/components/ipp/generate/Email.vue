<template lang="pug">
div
  h4(class="text-tertiary") Send Mail
  q-field(label="Attach File")
    q-uploader(
      url=""
      send-raw
      multiple
      auto-expand
      extensions=".pdf"
      hide-upload-button
      hide-upload-progress
      ref="$DocumentUpload"
      @add="files => email.attachments = files"
      @remove:cancel="onFileRemove"
    )
  q-field(label="Send to" class="q-mt-lg")
    q-chips-input(v-model="email.to")
  q-field(label="Subject" class="q-mt-lg")
    q-input(v-model="email.subject")
  q-field(label="Body" class="q-mt-lg")
    q-input(type="textarea" v-model="email.body")
  q-field(label="Submit" class="q-mt-lg")
    q-btn(
      flat
      color="secondary"
      class="full-width"
      @click="onEmailSend"
      :loading="btn.loading"
      icon="send"
      label="Send"
    )
      q-spinner-dots(slot="loading")
</template>

<script>
import { each, filter, eq } from 'lodash';
import { HTTP_API } from 'src/services/http/http';

export default {
  name: 'generate-email',
  data: () => ({
    btn: {
      loading: false,
    },
    email: {
      to: ['service@jdlife.co.nz'],
      attachments: [],
      subject: null,
      body: null,
    },
    axios: {
      config: {
        headers: {
           Accept: 'application/json',
          'Content-Type': 'multipart/form-data'
        }
      },
    },
  }),
  methods: {
    onFileRemove({ name }) {
      this.email.attachments = filter(
        this.email.attachments,
        ({ name: fileName }) => !eq(name, fileName)
      );
    },
    async onEmailSend () {
      try {
        this.btn.loading = true;

        this.$q.notify({
          message: 'Sending Email',
          color: 'secondary',
          timeout: 1000,
          icon: 'send',
        });

        const bodyFormData = new FormData;
        each(this.email.attachments, file => {
          bodyFormData.append('attachments[]', file);
        });
        bodyFormData.set('to', this.email.to);
        bodyFormData.set('body', this.email.body);
        bodyFormData.set('subject', this.email.subject);

        await HTTP_API().post(`/planners/${this.plan.id}/mailer/send`, bodyFormData, this.axios.config);

        this.$q.notify({
          message: 'Email Sent',
          color: 'secondary',
          timeout: 1000,
          icon: 'check',
        });
      }
      catch (e) {}
      finally {
        this.btn.loading = false;
      }
    },
  },
};
</script>
