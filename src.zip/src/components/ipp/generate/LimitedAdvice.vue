<template lang="pug">
div(class="row justify-center layout-padding")
  div(class="limited-adivce-wrapper")
    h6(class="text-h6 text-faded") Limitations
    q-checkbox(
      :value="hasLimitations"
      label="Are there any limitations?"
      @input="value => onUpdateLimitedAdviceField(value, 'has_limitations')"
    )
    h6(class="text-subtitle1 text-faded") Limitations
    q-checkbox(
      class="q-my-md"
      :value="limitations.instructed"
      @input="value => onUpdateLimitedAdviceField(value, ['limitations', 'instructed'])"
      label="You have instructed me not to determine the suitablity of my financial adviser services to your particular circumstances"
    )
    q-checkbox(
      class="q-my-md"
      :value="limitations.acknowledge"
      @input="value => onUpdateLimitedAdviceField(value, ['limitations', 'acknowledge'])"
      label="You acknowledge that you have chosen not to disclose all of the information sought by me and that the suitablity of my financial adviser services to your circumstances is based only upon that information which you have provided"
    )
    h6(class="text-subtitle1 text-faded") Generate Advice
    q-btn(
      outline
      class="full-width"
      label="Generate"
      color="primary"
      icon="picture_as_pdf"
      @click="onLimitedAdvicePreview"
    )
</template>

<script>
import { openURL } from 'quasar';
import { mapState, mapMutations } from 'vuex';

export default {
  name: 'generate-limited-advice',
  methods: {
    ...mapMutations('limitedAdivce', ['UPDATE_LIMITED_ADVICE_FIELD']),
    onUpdateLimitedAdviceField(value, field) {
      this.UPDATE_LIMITED_ADVICE_FIELD({ value, field });
    },
    onLimitedAdvicePreview() {
      const name = 'document.limited.advices.preview';
      const { href } = this.$router.resolve({ name });
      openURL(href);
    },
  },
  computed: {
    ...mapState('limitedAdivce', {
      hasLimitations: state => state.has_limitations,
      limitations: state => state.limitations,
    }),
  },
};
</script>

<style lang="stylus" scoped>
.limited-adivce-wrapper
  width 800px
  max-width 800px
</style>
