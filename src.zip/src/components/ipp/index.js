import InsuranceProviderSelection from './InsuranceProviderSelection';
import InsuranceProviderNoteEditor from './InsuranceProviderNoteEditor';

import ItemRecommendationReportDialog from './ItemRecommendationReportDialog';
import ItemRecommendationsGraphicsTable from './ItemRecommendationsGraphicsTable';
import ItemRecommendationsLoyaltySavings from './ItemRecommendationsLoyaltySavings';

import IncomeLevyCalculationNotes from './notes/IncomeLevyCalculation';
import CommonTaxIssuesNotes from './notes/CommonTaxIssues';
import AccOffsetsNotes from './notes/AccOffsets';

import GenerateEmail from './Generate/Email';
import GenerateSignature from './Generate/Signature';
import GenerateLimitedAdvice from './Generate/LimitedAdvice';

import DisplayInput from './documents/DisplayInput';
import PrintableDialog from './documents/PrintableDialog';
import SectionSelections from './documents/SectionSelections';

export {
  InsuranceProviderSelection,
  InsuranceProviderNoteEditor,

  ItemRecommendationReportDialog,
  ItemRecommendationsGraphicsTable,
  ItemRecommendationsLoyaltySavings,

  IncomeLevyCalculationNotes,
  CommonTaxIssuesNotes,
  AccOffsetsNotes,

  GenerateEmail,
  GenerateSignature,
  GenerateLimitedAdvice,

  DisplayInput,
  PrintableDialog,
  SectionSelections,
};
