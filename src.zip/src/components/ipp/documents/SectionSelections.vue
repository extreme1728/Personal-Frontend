<template lang="pug">
div(class="q-pa-md row q-col-gutter-sm")
  div(class="col-md-4")
    p(class="text-h6 text-faded") Statement Sections
    q-option-group(
      type="checkbox"
      :options="documentSections.statementDocumentSections"
      :disable="disables.includes('statement')"
      :value="getDeterminedSelections"
      @input="__change"
    )
  div(class="col-md-4")
    p(class="text-h6 text-faded") Policy Wordings
    q-select(
      v-else
      emit-value
      map-options
      label="Insurer"
      class="q-my-md"
      :value="plan.client_tax_issues_insurance_provider"
      readonly
      :options="getInsuranceProvidersForPolicyWordings"
      @input="value => updatePlanField(value, 'client_tax_issues_insurance_provider')"
    )
    q-select(
      multiple
      use-chips
      emit-value
      input-debounce="0"
      label="Policy Provider"
      :value="getDeterminedSelections"
      :options="documentSections.policyDocumentSections"
      :disable="disables.includes('policy')"
      @input="__change"
    )
    q-option-group(
      v-if="plan.client_tax_issues_insurance_provider==='sovereign'"
      type="checkbox"
      :options="getDocumentSelections"
      :disable="disables.includes('sovereign')"
      :value="getDeterminedSelections"
      @input="__change"
    )
    q-option-group(
      v-if="aia"
      type="checkbox"
      :options="getDocumentSelections"
      :disable="disables.includes('aia')"
      :value="getDeterminedSelections"
      @input="__change"
    )
    q-option-group(
      v-if="partners"
      type="checkbox"
      :options="getDocumentSelections"
      :disable="disables.includes('partners')"
      :value="getDeterminedSelections"
      @input="__change"
    )
    q-option-group(
      v-if="fidelity"
      type="checkbox"
      :options="getDocumentSelections"
      :disable="disables.includes('fidelity')"
      :value="getDeterminedSelections"
      @input="__change"
    )
  div(class="col-md-4")
    p(class="text-h6 text-faded") Graphic Sections
    q-option-group(
      v-if="report"
      type="checkbox"
      :options="getDocumentSelections"
      :disable="disables.includes('graphics')"
      :value="getDeterminedSelections"
      @input="__change"
    )
    q-option-group(
      type="checkbox"
      :options="documentSections.commonDocumentSections"
      :disable="disables.includes('graphics')"
      :value="getDeterminedSelections"
      @input="__change"
    )
  div(class="col-md-4")
    p(class="text-h6 text-faded") Client Calculators
    q-checkbox(v-model="selectAllClientCalculators" label="Select All")
    q-option-group(
      type="checkbox"
      :options="documentSections.clientCalculatorOptions"
      :disable="disables.includes('client-calculators')"
      :value="getDeterminedSelections"
      @input="__change"
    )
  div(class="col-md-4")
    p(class="text-h6 text-faded") Partner Calculators
    q-checkbox(v-model="selectAllPartnerCalculators" label="Select All")
    q-option-group(
      type="checkbox"
      :options="documentSections.partnerCalculatorOptions"
      :disable="disables.includes('partner-calculators')"
      :value="getDeterminedSelections"
      @input="__change"
    )
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import * as RecommendationSections from 'src/config/recommendationSections';
import { isEmpty, uniq, get, castArray, includes, every, filter, map } from 'lodash';
import { QInput } from 'src/components/quasar';

export default {
  name: 'section-selections',
  props: {
    report: Object,
    fromServer: Boolean,
    payload: Array,
    disables: {
      type: Array,
      // required: (value) => {
      //   const valid = [
      //     'statement',
      //     'policy',
      //     'sovereign',
      //     'aia',
      //     'partners',
      //     'fidelity',
      //     'graphics',
      //     'client-calculators',
      //     'partner-calculators',
      //   ];
      // return includes(valid, value);
      // },
      default: () => [],
    },
    category: {
      type: String,
      default: null,
    },
  },
  methods: {
    ...mapActions('documentRecommendation', ['setRecommendationSelection']),
    __change(value) {
      if (this.fromServer) {
        this.$emit('change', value);
      }
      else {
        this.setRecommendationSelection(value);
      }
    },
  },
  created() {
    if (!isEmpty(this.report)) {
      const payload = [
        ...this.getDeterminedSelections,
        ...[get(this.documentSections.itemDocumentSections[0], 'value')],
      ];
      this.__change(uniq(payload));
    }
    if (!isEmpty(this.policy)) {
      const payload = [
        ...this.getDeterminedSelections,
        ...[get(this.documentSections.policyDocumentSections[0], 'value')],
      ];
      this.__change(uniq(payload));
    }
  },
  computed: {
    documentSections: () => RecommendationSections,
    ...mapGetters('documentRecommendation', ['getSelectedSections']),
    ...mapGetters('resources', {
    getInsuranceProvidersForPolicyWordings: 'getInsuranceProvidersForPolicyWordings',
    }),
    getDocumentSelections() {
      return this.report
        ? [this.documentSections.itemDocumentSections[1]]
        : this.documentSections.itemDocumentSections;
      return this.policy
        ? [this.documentSections.policyDocumentSections[1]]
        : this.documentSections.policyDocumentSections; 
      return this.sovereign
        ? [this.documentSections.sovereignDocumentSections[1]]
        : this.documentSections.sovereignDocumentSections;
      return this.aia
        ? [this.documentSections.aiaDocumentSections[1]]
        : this.documentSections.aiaDocumentSections;
      return this.partners
        ? [this.documentSections.partnersDocumentSections[1]]
        : this.documentSections.partnersDocumentSections;
      return this.fidelity
        ? [this.documentSections.fidelityDocumentSections[1]]
        : this.documentSections.fidelityDocumentSections;
    },
    getDeterminedSelections() {
      return this.fromServer
        ? castArray(this.payload)
        : this.getSelectedSections;
    },
    selectAllClientCalculators: {
      get() {
        return every(this.documentSections.clientCalculatorOptions, ({ value }) => {
          return this.getDeterminedSelections.includes(value);
        });
      },
      set(value) {
        let selected = [];
        let { clientCalculatorOptions: options } = this.documentSections;
        options = map(options, 'value');
        if (value) {
          selected = [...this.getDeterminedSelections, ...options];
        }
        else {
          selected = filter(this.getDeterminedSelections, value => !options.includes(value));
        }
        this.__change(selected);
      },
    },
    selectAllPartnerCalculators: {
      get() {
        return every(this.documentSections.partnerCalculatorOptions, ({ value }) => {
          return this.getDeterminedSelections.includes(value);
        });
      },
      set(value) {
        let selected = [];
        let { partnerCalculatorOptions: options } = this.documentSections;
        options = map(options, 'value');
        if (value) {
          selected = [...this.getDeterminedSelections, ...options];
        }
        else {
          selected = filter(this.getDeterminedSelections, value => !options.includes(value));
        }
        this.__change(selected);
      },
    },
  },
  components: {
    QInput,
  },
};
</script>
