<template lang="pug">
div(
  class="q-field row no-wrap items-start q-field--standard q-field--auto-height q-field--readonly"
  :class="classes"
)
  div(class="q-field__inner relative-position col self-stretch column justify-center")
    div(class="q-field__control relative-position row no-wrap")
      div(class="q-field__control-container col relative-position row no-wrap q-anchor--skip")
        div(v-if="label" class="q-field__label no-pointer-events absolute custom-input__label" v-text="label")
        div(v-if="prefix" class="q-field__prefix no-pointer-events row items-center") {{ prefix }}
        div(class="q-field__native row" v-if="value")
          div(class="self-center full-width no-outline" v-text="__val")
        div(v-if="suffix" class="q-field__suffix no-pointer-events row items-center" v-text="suffix")
        div(class="q-field__bottom row items-start q-field__bottom--animated" v-if="hint")
          div(class="q-field__messages col" v-text="hint")
</template>

<script>
import { find, get, isArray, join } from 'lodash';

export default {
  name: 'display-input',
  props: {
    capitalized: {
      type: Boolean,
      default: false,
    },
    fromOptions: Boolean,
    options: Array,
    money: Boolean,
    prefix: String,
    label: String,
    hint: String,
    suffix: String,
    value: [String, Number, Array],
  },
  computed: {
    classes() {
      return {
        'q-field--float q-field--labeled': this.value,
        'q-field--with-bottom': this.hint,
      };
    },
    __val() {
      if (isArray(this.value)) return join(this.value, ', ');
      if (this.fromOptions) {
        if (!this.options) return null;
        const valObj = find(this.options, ['value', this.value]);
        return get(valObj, 'label', null);
      }
      if (this.money)
        return this.$filters.numberComma(
          this.$filters.toNumberFixed(this.value)
        );
      if (this.capitalized)
        return this.$filters.inputFormatter(this.value);
      return this.value;
    },
  },
};
</script>

<style lang="stylus" scoped>
.custom-input__label
  transform none !important
  top -2px
  font-size 12px
</style>
