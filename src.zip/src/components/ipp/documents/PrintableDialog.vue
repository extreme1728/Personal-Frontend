<template lang="pug">
div
  q-dialog(v-model="showDialog")
    q-card(style="width: 700px; max-width: 80vw;")
      q-card-section
        p(class="text-h6 text-faded" v-text="getPrintTitle")
        q-input(
          label="File Name"
          v-model="printable.filename"
          :error="$v.printable.filename.$error"
        )
      q-card-section
        div(class="row q-col-gutter-md")
          div(class="col-md-4")
            q-select(
              emit-value
              map-options
              color="red-5"
              label="Format"
              :options="getPageFormats"
              v-model="printable.jsPDF.format"
            )
          div(class="col-md-4")
            q-select(
              emit-value
              map-options
              color="red-5"
              label="Orientation"
              :options="getPageOrientations"
              v-model="printable.jsPDF.orientation"
            )
          div(class="col-md-4")
            q-select(
              emit-value
              map-options
              label="Unit"
              color="red-5"
              :options="getPageUnits"
              v-model="printable.jsPDF.unit"
            )
        p(class="row q-mt-md no-margin-bottom text-subtitle1") Margin
        div(class="row q-col-gutter-md justify-center")
          div(class="col-md-3")
            q-input(
              required
              type="number"
              :hint="`Top (${printable.jsPDF.unit})`"
              :error="$v.printable.margin.$each[0].$error"
              v-model.number="printable.margin[0]"
            )
          div(class="col-md-3")
            q-input(
              type="number"
              :hint="`Bottom (${printable.jsPDF.unit})`"
              :error="$v.printable.margin.$each[2].$error"
              v-model.number="printable.margin[2]"
            )
        div(class="row q-col-gutter-md q-pt-sm justify-center")
          div(class="col-md-3")
            q-input(
              type="number"
              :hint="`Left (${printable.jsPDF.unit})`"
              :error="$v.printable.margin.$each[1].$error"
              v-model.number="printable.margin[1]"
            )
          div(class="col-md-3")
            q-input(
              type="number"
              :helper="`Right (${printable.jsPDF.unit})`"
              :error="$v.printable.margin.$each[3].$error"
              v-model.number="printable.margin[3]"
            )
        div(class="row")
          div(class="col-md-12")
            p(class="text-faded") Quality
            div(class="group")
              q-radio(
                label="Low"
                color="red-5"
                class="q-mr-md"
                :val="scaleRatios.min"
                v-model="printable.html2canvas.scale"
              )
              q-radio(
                label="High"
                color="red-5"
                :val="scaleRatios.max"
                v-model="printable.html2canvas.scale"
              )
      q-card-actions(align="between")
        q-btn(flat color="tertiary" label="Close" :disable="printing" v-close-popup)
        q-btn(
          no-ripple
          color="red-5"
          label="Print"
          :loading="printing"
          :disable="$v.$error"
          @click="printDocument"
        )
          q-spinner-gears(slot="loading")

  q-page-sticky(:position="position" :offset="offset")
    q-btn(
      round
      size="lg"
      icon="print"
      color="red-5"
      @click="showDialog = true"
      v-shortkey="['ctrl', 'p']"
      @shortkey.native="showDialog = true"
    )
</template>

<script>
import JSZip from 'jszip';
import html2pdf from 'html2pdf.js';
import { validationMixin } from 'vuelidate';
import { saveAs } from 'file-saver/FileSaver';
import { QInput } from 'src/components/quasar';
import { mapGetters, mapMutations } from 'vuex';
import { required } from 'vuelidate/lib/validators';
import { trimEnd, upperFirst, debounce, cloneDeep, castArray, toString, isObject, map, merge, isEmpty, every } from 'lodash';

export default {
  name: 'printable-dialog',
  mixins: [validationMixin],
  data: () => ({
    printable: {}, // Configurations
    printing: false,
    showDialog: false,
  }),
  created() {
    this.printable = {
      ...this.printable,
      ...this.documentServiceOptions,
      ...{ filename: this.plan.client_full_name },
      ...{ html2canvas: { scale: this.scaleRatios.max } },
      ...{ pagebreak: { mode: 'avoid-all', before: ['.document__page-break'], after: ['.document__page-break--after'] } },
    };
  },
  mounted() {
    this.$v.printable.$touch();
  },
  props: {
    filename: {
      type: String,
      default: () => null,
    },
    compressed: Boolean,
    persist: {
      type: Boolean,
      default: true,
    },
    elementId: {
      type: [String, Array],
      default: () => ['document-preview-page'],
    },
    position: {
      type: String,
      default: 'bottom-right',
    },
    offset: {
      type: Array,
      default: () => [18, 18],
    },
  },
  watch: {
    printable: {
      handler: debounce(function (values) {
        if (this.persist)
          this.DOCUMENT_RECOMMENDATION_MERGE(cloneDeep(values));
        else
          this.$emit('change', cloneDeep(values));
      }, 500),
      deep: true,
    },
  },
  methods: {
    ...mapMutations('documentRecommendation', ['DOCUMENT_RECOMMENDATION_MERGE']),
    async printDocument() {
      try {
        this.printing = true;

        const zip = new JSZip();
        const sections = this.mapSections;
        let __fileName = trimEnd('' + this.printable.filename.replace(/\./g, '-'), '-');
        for (let i = sections.length - 1; i >= 0; i--) {
          const item = sections[i];
          const page = document.getElementById(item.element);
          if (this.compressed) {
            const payload = await html2pdf()
                .from(page)
                .using(this.printable)
                .toPdf()
                .get('pdf')
                .then((pdf) => {
                  if (! every(item.footer, isEmpty)) {
                    const x = 0.5;
                    const y = pdf.internal.pageSize.getHeight() - 0.1;
                    for (let pageIndex = 0; pageIndex < pdf.internal.pages.length; pageIndex++) {
                      if (! item.footer.excludes.includes(pageIndex)) {
                        pdf.setPage(pageIndex);
                        pdf.setFontSize(9);
                        pdf.setTextColor(151, 151, 151);
                        pdf.text(item.footer.text, x, y);
                      }
                    }
                  }
                })
                .outputPdf('blob');
            zip.file(`${item.filename}.pdf`, payload);
          }
          else {
            await html2pdf().from(page).using(this.printable).save(__fileName);
          }
        }

        if (this.compressed) {
          const content = await zip.generateAsync({ type:'blob' });
          saveAs(content, `${__fileName}.zip`);
        }
      } catch (e) {
        this.$q.notify({
          message: toString(e),
          icon: 'warning',
          color: 'negative',
          position: 'top-right',
        });
      } finally {
        this.printing = false;
      }
    },
  },
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    ...mapGetters('documentRecommendation', {
      documentServiceOptions: 'getDocumentServiceOptions',
    }),
    mapSections() {
      const sections = castArray(this.elementId);
      return map(sections, (item) => {
        let filename = trimEnd('' + (item.filename || item.element || item).replace(/\./g, '-'), '-');
        const options = {
          filename,
          element: null,
          footer: {
            excludes: [],
            text: null,
          },
        };
        if (isObject(item)) return merge({}, options, item);
        return merge({}, options, { element: item, filename: item });
      });
    },
    getPrintTitle() {
      const type = this.compressed ? 'Compressed' : 'File';
      return `Print Settings (${type})`;
    },
    getPageFormats() {
      return [
        'A4',
        'A5',
        'legal',
        'letter',
      ].map(v => ({ value: v, label: upperFirst(v) }));
    },
    getPageOrientations() {
      return ['portrait', 'landscape'].map(v => ({ value: v, label: upperFirst(v) }));
    },
    getPageUnits() {
      return [
        'pt',
        'mm',
        'cm',
        'in',
        'px',
        'pc',
        'em',
        'ex',
      ].map(v => ({ value: v, label: v }));
    },
    scaleRatios() {
      const { realPixelRatio: scale } = this.getPixelRatio;
      return {
        min: scale,
        max: scale + 1,
      };
    },
    getPixelRatio() {
      const STEP = 0.05;
      const MAX = 5;
      const MIN = 0.5;
      const mediaQuery = (v) => `(-webkit-min-device-pixel-ratio: ${v}),
      (min--moz-device-pixel-ratio: ${v}),
      (min-resolution: ${v}dppx)`;

      // * 100 is added to each constants because of JS's float handling and
      // numbers such as `4.9-0.05 = 4.8500000000000005`
      let maximumMatchingSize;
      for (let i = MAX * 100; i >= MIN * 100; i -= STEP * 100) {
        if (window.matchMedia(mediaQuery(i / 100)).matches ) {
          maximumMatchingSize = i / 100;
          break;
        }
      }

      return {
        isZoomed: window.devicePixelRatio === undefined
          ? 'unknown'
          : window.parseFloat(window.devicePixelRatio) !== window.parseFloat(maximumMatchingSize),
        devicePixelRatio: window.devicePixelRatio,
        realPixelRatio: maximumMatchingSize,
      };
    },
    getFilename() {
      const { client_full_name, id } = this.plan;
      const { jsPDF: { format, orientation }, html2canvas: { scale } } = this.printable;
      return `${client_full_name} #${id} ${format} ${orientation} quality: (${scale})`;
    },
  },
  validations() {
    return {
      printable: {
        filename: {
          required,
        },
        margin: {
          $each: {
            required,
          },
        },
      },
    };
  },
  components: {
    QInput,
  },
};
</script>
