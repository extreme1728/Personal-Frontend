export default {
  props: {
    clientName: {
      type: [String, Object],
      default: '[Client Name]',
    },
  },
  computed: {
    getLineHeightStyle: () => ({
      'font-size': '0.9em',
    }),
  },
};
