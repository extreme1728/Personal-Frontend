<template lang="pug">
div(class="row q-mt-md")
  div(class="col-md-12")
    blockquote(class="note-border-primary text-weight-regular text-justify")
      p(:style="getLineHeightStyle") {{ clientName }}'s ACC Cover Plus/Workplace Cover amount will be 80% of income amounting to ${{ coverPlusAmountWithoutTax | numberComma }} (${{ coverPlusAmount | numberComma }} after tax)*. In the event of an accident, {{ clientName }} will receive compensation from ACC which will then be offset on his Income Protection cover. If the Income Protection benefit amount is less than the ACC Cover Plus amount, {{ clientName }} will not be able to claim on the Income Protection.
      p(:style="getLineHeightStyle") If {{ clientName }} has taken Monthly Mortgage Repayment cover instead or in combination with the Income Protection cover, the ACC Cover Plus/Workplace cover amount of ${{ coverPlusAmount | numberComma }} will not offset the benefit amount from Monthly Mortgage Repayment cover amount of ${{ monthlyMortgageAmount | numberComma }} in the event of an accident. In this situation {{ clientName }} will have ability to claim from both parties.
      p(:style="getLineHeightStyle") Please note also that ACC has a 1 week waiting period before you can get the claim as opposed to the Income Protection and Monthly Mortgage Repayment cover which has a minimum waiting period of 2 weeks and options of 4 weeks, 8 weeks, 13 weeks, 26 weeks, 52 weeks and 104 weeks.
      p(:style="getLineHeightStyle") * Tax Assumption: Assuming this is total personal tax amount received at existing personal tier system. Subject to Changes. This is estimation only.
      p(:style="getLineHeightStyle") * JD LIfe Ltd and its affiliates do not provide tax, legal or accounting advice. This material has been prepared for information purposes only, and is not  intended to provide and should not be relied on for, tax, legal or accounting advice. You should consult your own tax, legal and accounting advisors before engaging in any transaction.
</template>

<script>
import BaseNotes from './BaseNotes';

export default {
  extends: BaseNotes,
  props: {
    coverPlusAmountWithoutTax: {
      type: [String, Number],
      default: 0,
    },
    coverPlusAmount: {
      type: [String, Number],
      default: 0,
    },
    monthlyMortgageAmount: {
      type: [String, Number],
      default: 0,
    }
  },
};
</script>
