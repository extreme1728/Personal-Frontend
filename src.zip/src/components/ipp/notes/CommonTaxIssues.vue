<template lang="pug">
div(class="row q-mt-md")
  div(class="col-md-12")
    blockquote(class="note-border-primary text-weight-regular text-justify")
      p(:style="getLineHeightStyle") It is our understanding that the Income Protection Indemnity Value contract is taxable. Based on {{ clientName }}'s income and on the {{ yearNow }} tax rates personal tax rates (assuming no other income), the tax will amount to ${{ taxAmount | numberComma }}, this will be reduced from ${{ indemnityAmount | numberComma }} claim payment with payment to IRD payable and so the total claim amount will be $64,355 (after tax). If Income Protection Agreed Value contract is taken instead, it is our understanding that there will be no tax reduction on the benefit amount and so {{ clientName }} will be able to claim the full ${{ totalClaimAmount | numberComma }} (after tax). If the Income Protection taken is with the benefit period up to the age of {{ MAX_AGE }}, i.e. for {{ getCoverTermPeriod }} years from today, you will receive ${{ totalBenefitPeriod | numberComma }} more benefit amount with Agreed Value contract.
      p(:style="getLineHeightStyle") * JD LIfe Ltd and its affiliates do not provide tax, legal or accounting advice. This material has been prepared for information purposes only, and is not  intended to provide and should not be relied on for, tax, legal or accounting advice. You should consult your own tax, legal and accounting advisors before engaging in any transaction.
</template>

<script>
import BaseNotes from './BaseNotes';
import { numberWithCommas } from 'src/config/utils';
import { getAgeByDate } from 'src/services/filters/formatter';
export default {
  extends: BaseNotes,
  name: 'common-tax-issues-notes',
  props: {
    taxAmount: {
      type: [String, Number],
      default: 0,
    },
    indemnityAmount: {
      type: [String, Number],
      default: 0,
    },
    agreedAmount: {
      type: [String, Number],
      default: 0,
    },
    totalClaimAmount: {
      type: [String, Number],
      default: 0,
    },
    dateOfBirth: {
      type: [Date, String],
      default: () => (new Date),
    },
  },
  computed: {
    yearNow() {
      return (new Date).getFullYear();
    },
    getClientAge() {
      return getAgeByDate((new Date(this.dateOfBirth)));
    },
    MAX_AGE() {
      return 65;
    },
    getCoverTermPeriod() {
      return (this.MAX_AGE - this.getClientAge) >> 0;
    },
    totalBenefitPeriod() {
      const agreedAmountTotal = (numberWithCommas(this.agreedAmount, false) * this.getCoverTermPeriod);
      const indemnityAmountTotal = (numberWithCommas(this.indemnityAmount, false) * this.getCoverTermPeriod);
      return indemnityAmountTotal - agreedAmountTotal;
    },
  },
};
</script>
