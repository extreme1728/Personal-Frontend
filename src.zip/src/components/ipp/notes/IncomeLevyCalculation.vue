<template lang="pug">
div(class="row q-mt-md" v-if="showNotes")
  div(class="col-md-12")
    blockquote(class="note-border-primary text-weight-regular text-justify")
      p(
        :style="getLineHeightStyle"
        v-if="isAlreadyOnAccCoverPlusExtra"
      ) {{ clientName }} has existing ACC Cover Plus Extra cover of ${{ coverPlusCalculation.rawNominatedCoverAmount | numberComma }}. Reducing {{ clientName }}’s  ACC Cover Plus Extra cover to ${{ coverPlusExtraCalculation.rawNominatedCoverAmount | numberComma }} will result to cover difference of ${{ getNominatedCoverPlusExtraAmountDifference | numberComma }}. {{ clientName }}`s ACC levies will also drop from ${{ coverPlusCalculation.totalAmountPayableToAccIncludingGst | numberComma }} to ${{ coverPlusExtraCalculation.totalAmountPayableToAccIncludingGst | numberComma }} giving savings of ${{ getTotalLevySavings | numberComma }}. The difference in the ACC cover could now be covered by personalised illness and accident cover.
      p(
        :style="getLineHeightStyle"
        v-else-if="getTotalLevySavings < 1"
      ) If {{ clientName }} is taking drawings of ${{ getIncomeFromBusiness | numberComma }}, this makes {{ clientName }} eligible for ACC Cover Plus Extra. With the existing ACC Workplace/Cover Plus cover {{ clientName }} will be covered with ${{ coverPlusCalculation.nominatedCoverAmount| numberComma }} a year. Transferring to ACC Cover Plus Extra cover with ${{ coverPlusCalculation.rawNominatedCoverAmount | numberComma }} agreed value, this gives a cover difference of ${{ coverPlusCalculation.incomeDifferenceToNominatedAmount | numberComma }}. {{ clientName }}`s ACC levies will also increase from ${{ coverPlusTotalAmount| numberComma }} to ${{ coverPlusExtraCalculation.totalAmountPayableToAccIncludingGst | numberComma }} which means that {{ clientName }} will need to call ${{ getTotalLevySavings | numberComma }}. The difference in the ACC cover could now be covered by personalised illness and accident cover.
      p(
        :style="getLineHeightStyle"
        v-else
      ) If {{ clientName }} is taking drawings of ${{ getIncomeFromBusiness | numberComma }}, this makes {{ clientName }} eligible for ACC Cover Plus Extra. With the existing ACC Workplace/Cover Plus cover {{ clientName }} will be covered with ${{ coverPlusCalculation.nominatedCoverAmount| numberComma }} a year. Transferring to ACC Cover Plus Extra cover with ${{ coverPlusCalculation.rawNominatedCoverAmount | numberComma }} agreed value, this gives a cover difference of ${{ coverPlusCalculation.incomeDifferenceToNominatedAmount | numberComma }}. {{ clientName }}`s ACC levies will also drop from ${{ coverPlusTotalAmount| numberComma }} to ${{ coverPlusExtraCalculation.totalAmountPayableToAccIncludingGst | numberComma }} giving savings of ${{ getTotalLevySavings | numberComma }}. The difference in the ACC cover could now be covered by personalised illness and accident cover.
        template(v-if="isPartner")
          |&nbsp;It shall be discussed whether you feel that this difference in cover amount shall be covered by a personalised illness and accident cover. Only upon stating that you wish to cover this difference we shall put in a recommendation for such cover.
      p(
        style="line-height: 1.2"
        v-show="showIncomeTaxNote"
      ) To be eligible for Cover Plus Extra {{ clientName }} should be taking out drawings from the business. Since {{ clientName }} is taking PAYE/combination of PAYE and drawings, the amounts presented above is based on the idea that {{ clientName }} is willing to change over to drawings.
      p(:style="getLineHeightStyle") The amounts presented above are estimated values and are subject to changes based on the clients income and ACC levy rates.
      p(:style="getLineHeightStyle") * JD Life Ltd and its affiliates do not provide tax, legal or accounting advice. This material has been prepared for information purposes only, and is not  intended to provide and should not be relied on for, tax, legal or accounting advice. You should consult your own tax, legal and accounting advisors before engaging in any transaction.
      p(:style="getLineHeightStyle") Should you decide to cancel Cover Plus Extra or the Cover Plus Extra be cancelled due to non payment in a timely manner, JD Life shall not be found to be liable for any loss incurred.
      p(:style="getLineHeightStyle") A JD Life Ltd adviser shall only put a client onto Cover Plus Extra and possibly dial down the ACC cover amount after specific instruction from the client and on the provision that suitable disability income protection is taken out. Should the client at a later stage decide to cancel that disability income protection coverage, JD Life Ltd nor it's representatives shall NOT be found liable for any potential loss.
</template>

<script>
import { mapGetters } from 'vuex';
import { includes } from 'lodash';
import BaseNotes from './BaseNotes';
import { floatDiff } from 'src/config/utils';

export default {
  extends: BaseNotes,
  props: {
    isAlreadyOnAccCoverPlusExtra: Boolean,
    isPartner: {
      type: Boolean,
      default: false,
    },
    incomeTaxMethod: {
      type: String,
      default: 'drawings',
    },
    coverPlusCalculation: {
      type: Object,
      required: true,
    },
    coverPlusExtraCalculation: {
      type: Object,
      required: true,
    },
    coverPlusTotalAmountPayable: {
      type: [String, Number],
      default: 0,
    },
  },
  computed: {
    ...mapGetters('planner', [
      'clientGrossIncome',
      'partnerGrossIncome',
    ]),
    getIncomeFromBusiness() {
      return this.isPartner
        ? this.partnerGrossIncome
        : this.clientGrossIncome;
    },
    coverPlusTotalAmount() {
      const { totalAmountPayableToAccIncludingGst: coverPlus } = this.coverPlusCalculation;
      return this.coverPlusTotalAmountPayable || coverPlus;
    },
    getTotalLevySavings() {
      const { totalAmountPayableToAccIncludingGst: coverPlusExtra } = this.coverPlusExtraCalculation;
      return floatDiff(this.coverPlusTotalAmount, coverPlusExtra);
    },
    showIncomeTaxNote() {
      return includes(['paye', 'combination-of-drawings-and-paye'], this.incomeTaxMethod);
    },
    getNominatedCoverPlusExtraAmountDifference() {
      return floatDiff(
        this.coverPlusCalculation.rawNominatedCoverAmount,
        this.coverPlusExtraCalculation.rawNominatedCoverAmount,
      );
    },
    showNotes() {
      if (!this.coverPlusCalculation || !this.coverPlusExtraCalculation) return false;
      return true;
    },
  }
};
</script>
