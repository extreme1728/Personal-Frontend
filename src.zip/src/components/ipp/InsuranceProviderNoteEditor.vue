<template lang="pug">
  q-card(
    :flat="flat"
    :inline="inline"
    class="no-padding"
  )
    q-card-media(v-if="rawModel.image")
      svg-filter-image(:src="rawModel.image")
    q-card-main
      q-field(label="Image URL" orientation="vertical")
        q-input(v-model="rawModel.image")
      q-field(class="q-mt-md" label="Note" orientation="vertical")
        q-input(
          type="textarea"
          v-model="rawModel.note"
        )
    q-card-actions(align="around")
      slot(name="card-actions" :model="rawModel")
        q-btn(
          flat
          dense
          round
          icon="update"
          color="primary"
          @click="handleNoteUpdate"
        )
          q-tooltip(
            anchor="center right"
            self="center left"
          ) Update
        q-btn(
          flat
          dense
          round
          icon="close"
          color="negative"
        )
          q-tooltip(
            anchor="center right"
            self="center left"
          ) Remove
</template>

<script>
  import { QInput } from 'src/components/quasar';
  import SvgFilterImage from 'src/components/vlazyimage/SvgFilterImage';

  export default {
    name: 'insurance-provider-note-editor',
    data: () => ({
      rawModel: {
        id: null,
        note: null,
        image: null,
        cover_id: null,
        provider_id: null,
      },
    }),
    created() {
      this.rawModel.image = this.imageUrl;
      this.rawModel.note = this.note;
      this.rawModel.id = this.noteId;
      this.rawModel.cover_id = this.coverId;
      this.rawModel.provider_id = this.providerId;
    },
    props: {
      flat: {
        type: Boolean,
        default: false,
      },
      inline: {
        type: Boolean,
        default: true,
      },
      imageUrl: {
        type: String,
        required: false,
      },
      note: {
        type: String,
        required: false,
      },
      coverId: {
        type: [String, Number],
        required: true,
      },
      providerId: {
        type: [String, Number],
        required: true,
      },
      noteId: {
        type: [String, Number],
        required: true,
      },
    },
    methods: {
      handleNoteUpdate() {
        this.$emit('update', this.rawModel);
      },
    },
    components: {
      SvgFilterImage,
      QInput,
    },
  };
</script>

<style lang="stylus" scoped>
.note-card
  max-width 300px
</style>
