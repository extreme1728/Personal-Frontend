export default [
  {
    label: 'Income Details',
    value: 'income-details',
    employed: true,
  },
  {
    label: 'Tax Splitting',
    value: 'tax-splitting',
    employed: false,
  },
  {
    label: 'Important Info',
    value: 'important-info',
    employed: true,
  },
  {
    label: 'Business Needs',
    value: 'business-needs',
    employed: false,
  },
  {
    label: 'Calculators',
    value: 'calculators',
    employed: true,
  },
  {
    label: 'Insurance Planner',
    value: 'insurance-planner',
    employed: true,
  },
  {
    label: 'Scope of Engagements',
    value: 'scope-of-engagements',
    employed: true,
  },
  {
    label: 'Item Recommendations',
    value: 'item-recommendations',
    employed: true,
  },
  {
    label: 'Acc Offsets',
    value: 'acc-offsets',
    employed: true,
    selfEmployed: true,
  },
  {
    label: 'Common Tax Issues',
    value: 'common-tax-issues',
    employed: true,
  },
  {
    label: 'Passive Income Issues',
    value: 'passive-income-issues',
    employed: true,
  },
  {
    label: 'Fatal Entitlements',
    value: 'fatal-entitlements',
    employed: false,
  },
  {
    label: 'Insurance Plan',
    value: 'insurance-plan',
    employed: true,
  },
  {
    label: 'Referral Program',
    value: 'referrals',
    employed: true,
  },
  {
    label: 'Alteration Advice',
    value: 'alteration-advice',
    employed: true,
  },
  {
    label: 'Declaration of Continued Good Health',
    value: 'declaration-good-health',
    employed: true,
  },
];
