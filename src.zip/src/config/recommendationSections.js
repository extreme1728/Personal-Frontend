export const clientCalculatorOptions = [
  {
    label: 'TPD',
    value: 'client-tpd',
    sublabel: 'Client',
  },
  {
    label: 'Life Cover',
    value: 'client-life-cover',
    sublabel: 'Client',
  },
  {
    label: 'Trauma Cover',
    value: 'client-trauma-cover',
    sublabel: 'Client',
  },
  {
    label: 'Income Protection',
    value: 'client-income-protection',
    sublabel: 'Client',
  },
  {
    label: 'Mortgage Repayment and Income Protection',
    value: 'client-mortgage-repayment-and-income-protection',
    sublabel: 'Client',
  },
  {
    label: 'Mortgage Repayment, Income Protection and House Hold Expense Cover',
    value: 'client-mortgage-repayment-income-protection-and-house-expense-cover',
    sublabel: 'Client',
  },
  {
    label: 'Health Cover',
    value: 'client-health-cover',
    sublabel: 'Client',
  },
  {
    label: 'Tax Calculator',
    value: 'client-tax-calculator',
    sublabel: 'Client',
  },
];

export const partnerCalculatorOptions = [
  {
    label: 'TPD',
    value: 'partner-tpd',
    sublabel: 'Partner',
  },
  {
    label: 'Life Cover',
    value: 'partner-life-cover',
    sublabel: 'Partner',
  },
  {
    label: 'Trauma Cover',
    value: 'partner-trauma-cover',
    sublabel: 'Partner',
  },
  {
    label: 'Income Protection',
    value: 'partner-income-protection',
    sublabel: 'Partner',
  },
  {
    label: 'Mortgage Repayment and Income Protection',
    value: 'partner-mortgage-repayment-and-income-protection',
    sublabel: 'Partner',
  },
  {
    label: 'Mortgage Repayment, Income Protection and House Hold Expense Cover',
    value: 'partner-mortgage-repayment-income-protection-and-house-expense-cover',
    sublabel: 'Partner',
  },
  {
    label: 'Health Cover',
    value: 'partner-health-cover',
    sublabel: 'Partner',
  },
  {
    label: 'Tax Calculator',
    value: 'partner-tax-calculator',
    sublabel: 'Partner',
  },
];

export const commonDocumentSections = [
  {
    label: 'ACC Savings',
    value: 'acc-savings',
  },
  {
    label: 'ACC Offsets',
    value: 'acc-offsets',
  },
  {
    label: 'Passive Income',
    value: 'passive-income',
  },
  {
    label: 'Fatal Entitlements',
    value: 'fatal-entitlements',
  },
  {
    label: 'Tax Issues',
    value: 'tax-issues',
  },
];

export const itemDocumentSections = [
  {
    label: 'Item Recommendations',
    value: 'item-recommendations',
  },
  {
    label: 'Item Recommendations - Loyalty Savings',
    value: 'item-recommendations-loyalty-savings',
  },
];

export const statementDocumentSections = [
  {
    label: 'Authority To Proceed',
    value: 'authority-to-proceed',
    disable: false,
  },
];

export const policyDocumentSections = [
  {
    label: 'AIA',
    value: 'aia',
    disable: false,
  },
  {
    label: 'Fidelity',
    value: 'fidelity',
    disable: false,
  },
  {
    label: 'Partners Life',
    value: 'partnerslife',
    disable: false,
  },
  {
    label: 'Sovereign',
    value: 'sovereign',
    disable: false,
  },
];

export const sovereignDocumentSections = [
  {
    label: 'Accidental Death',
    value: 'accidental-death',
    disable: false,
  },
  {
    label: 'Family Protection Cover',
    value: 'family-protection-cover',
    disable: false,
  },
  {
    label: 'Absolute Health',
    value: 'absolute-health',
    disable: false,
  },
  {
    label: 'Business - Rural Continuity Business Income Support Benefit',
    value: 'business-rural',
    disable: false,
  },
  {
    label: 'Business Start-Up Income Protection',
    value: 'business-start-up',
    disable: false,
  },
  {
    label: 'Business Accidental Injury Cover',
    value: 'business-accidental',
    disable: false,
  },
  {
    label: 'Business Comprehensive Living Assurance',
    value: 'business-comprehensive',
    disable: false,
  },
  {
    label: 'Business Continuity Cover',
    value: 'business-continuity',
    disable: false,
  },
  {
    label: 'Business Life Cover',
    value: 'business-life',
    disable: false,
  },
  {
    label: 'Business Private Health & Private Health Plus',
    value: 'business-private',
    disable: false,
  },
  {
    label: 'Business Progressive Care Benefit',
    value: 'business-progressive',
    disable: false,
  },
  {
    label: 'Business Rural Continuity Benefit',
    value: 'business-rural',
    disable: false,
  },
  {
    label: 'Business Specialist and Diagnostic Testing Benefit',
    value: 'business-specialist',
    disable: false,
  },
  {
    label: 'Business Total Permanent Disablement',
    value: 'business-total',
    disable: false,
  },
  {
    label: 'Business Waiver of Premium Benefit',
    value: 'business-waiver',
    disable: false,
  },
  {
    label: 'Essential Disability Income Cover',
    value: 'essential-disability',
    disable: false,
  },
  {
    label: 'Income Protection Agreed Value Contract',
    value: 'income-protection-agreed',
    disable: false,
  },
  {
    label: 'Income Protection Indemnity Value Contract',
    value: 'income-protection-indemnity',
    disable: false,
  },
  {
    label: 'Income Protection Loss of Earnings',
    value: 'income-protection-loss',
    disable: false,
  },
  {
    label: 'MajorCare',
    value: 'majorcare',
    disable: false,
  },
  {
    label: 'Personal Essential Living Assurancet',
    value: 'personal-essential',
    disable: false,
  },
  {
    label: 'Personal Accidential Injury Cover',
    value: 'personal-accident',
    disable: false,
  },
  {
    label: 'Personal Life Cover',
    value: 'personal-life-cover-sovereign',
    disable: false,
  },
  {
    label: 'Personal Living Assurance',
    value: 'personal-living',
    disable: false,
  },
  {
    label: 'Personal Mortgage Income Protection',
    value: 'personal-mortgage',
    disable: false,
  },
  {
    label: 'Personal Progressive Care Benefit',
    value: 'personal-progressive',
    disable: false,
  },
  {
    label: 'Personal Retirement Protection Benefit',
    value: 'personal-retirement',
    disable: false,
  },
  {
    label: 'Personal Total Permanent Disability Cover',
    value: 'personal-total-permanent',
    disable: false,
  },
  {
    label: 'Personal Waiver of Premium',
    value: 'personal-waiver',
    disable: false,
  },
];

export const aiaDocumentSections = [
  {
    label: 'Business Continuation Cover',
    value: 'business-continuation',
    disable: false,
  },
  {
    label: 'Business Farmers Revenue Protection',
    value: 'business-farmers',
    disable: false,
  },
  {
    label: 'Business New to Business Cover',
    value: 'business-new-business',
    disable: false,
  },
  {
    label: 'Real Health Cover',
    value: 'real-health-cover',
    disable: false,
  },
  {
    label: 'Accidental Death Benefit',
    value: 'accidental-death',
    disable: false,
  },
  {
    label: 'Business Total and Permanent Disability',
    value: 'business-total-permanent',
    disable: false,
  },
  {
    label: 'Business Trauma Cover',
    value: 'business-trauma',
    disable: false,
  },
  {
    label: 'Business Waiver of Premium',
    value: 'business-waiver',
    disable: false,
  },
  {
    label: 'Cancer Treatment Benefit',
    value: 'cancer-treatment',
    disable: false,
  },
  {
    label: 'Income Protection Benefit',
    value: 'income-protection-benefit',
    disable: false,
  },
  {
    label: 'Mortgage Income and Rent Cover',
    value: 'mortgage-income',
    disable: false,
  },
  {
    label: 'Personal Life Cover',
    value: 'personal-life-cover-aia',
    disable: false,
  },
  {
    label: 'Personal Total Permanent Disability Cover',
    value: 'personal-total-disability',
    disable: false,
  },
  {
    label: 'Personal Trauma Cover',
    value: 'personal-trauma-cover',
    disable: false,
  },
  {
    label: 'Personal Waiver of Premium',
    value: 'personal-waiver-premium',
    disable: false,
  },
];

export const partnersDocumentSections = [
  {
    label: 'Accidental Death Cover',
    value: 'accidental-death-cover',
    disable: false,
  },
  {
    label: 'Business Premium Cover',
    value: 'business-premium-cover',
    disable: false,
  },
  {
    label: 'Business Protection Plan',
    value: 'business-protection-plan',
    disable: false,
  },
  {
    label: 'Debt Protection Cover',
    value: 'debt-protection',
    disable: false,
  },
  {
    label: 'Household Expenses Cover (1)',
    value: 'household-expenses-cover',
    disable: false,
  },
  {
    label: 'Income Cover Agreed Loss of Earnings',
    value: 'income-cover-agreed',
    disable: false,
  },
  {
    label: 'Income Cover Agreed Value',
    value: 'income-value',
    disable: false,
  },
  {
    label: 'Income Cover Indemnity Loss of Earnings',
    value: 'income-cover-indemnity',
    disable: false,
  },
  {
    label: 'Life Cover',
    value: 'life-cover-partners',
    disable: false,
  },
  {
    label: 'Life Income Cover',
    value: 'life-income-cover',
    disable: false,
  },
  {
    label: 'Loss of Revenue Cover (1)',
    value: 'loss-revenue',
    disable: false,
  },
  {
    label: 'Mortgage Repayment Cover',
    value: 'mortgage-repayment',
    disable: false,
  },
  {
    label: 'Ownership Buyout Cover',
    value: 'ownership-buyout',
    disable: false,
  },
  {
    label: 'Partners Protection Plan',
    value: 'partners-protection',
    disable: false,
  },
  {
    label: 'Permanent Loss of Key Person Cover',
    value: 'permanent-loss-key',
    disable: false,
  },
  {
    label: 'Premium Cover',
    value: 'premium-cover-partners',
    disable: false,
  },
  {
    label: 'Private Medical Cover',
    value: 'private-medical',
    disable: false,
  },
  {
    label: 'Severe Trauma Cover Accelerated',
    value: 'severe-trauma-accelerated',
    disable: false,
  },
  {
    label: 'Severe Trauma Cover Standalone',
    value: 'severe-trauma-standalone',
    disable: false,
  },
  {
    label: 'Terminal Illness Cover',
    value: 'terminal-illness',
    disable: false,
  },
  {
    label: 'Total and Permanent Disability Accelerated',
    value: 'total-permanent-accelerated',
    disable: false,
  },
  {
    label: 'Total and Permanent Disability Standalone',
    value: 'total-permanent-standalone',
    disable: false,
  },
  {
    label: 'Trauma Cover Accelerated',
    value: 'trauma-cover-accelerated',
    disable: false,
  },
  {
    label: 'Trauma Cover Standalone',
    value: 'trauma-cover-standalone',
    disable: false,
  },
];
export const fidelityDocumentSections = [
  {
    label: 'Key-Person-Cover-Stepped',
    value: 'key-person-stepped',
    disable: false,
  },
  {
    label: 'Life Cover - Stepped',
    value: 'life-cover-stepped',
    disable: false,
  },
  {
    label: 'Income-Protection-Indemnity-Value - Stepped',
    value: 'income-protection-stepped',
    disable: false,
  },
  {
    label: 'Terminal-Illness-Booster- Stepped',
    value: 'terminal-illness-stepped',
    disable: false,
  },
  {
    label: 'Trauma-Multi- Stepped',
    value: 'trauma-multi-stepped',
    disable: false,
  },
  {
    label: 'Income-Protection-Agreed-Value- Stepped',
    value: 'income-agreed-stepped',
    disable: false,
  },
  {
    label: 'Rural-Key-Person- Stepped',
    value: 'rural-key-stepped',
    disable: false,
  },
  {
    label: 'Survivors-Income- Stepped',
    value: 'survivors-income-stepped',
    disable: false,
  },
  {
    label: 'Trauma- Stepped',
    value: 'trauma-stepped',
    disable: false,
  },
  {
    label: 'Waiver-of-Premium - Stepped',
    value: 'waiver-premium-stepped',
    disable: false,
  },
  {
    label: 'Fidelity-Total-and-Permanent-Disability- Stepped',
    value: 'fidelity-stepped',
    disable: false,
  },
  {
    label: 'Trauma- Leveled',
    value: 'trauma-leveled',
    disable: false,
  },
  {
    label: 'Waiver-of-Premium- Leveled',
    value: 'waiver-premium-leveled',
    disable: false,
  },
  {
    label: 'Income-Protection-Agreed-Value- Leveled',
    value: 'income-agreed-leveled',
    disable: false,
  },
  {
    label: 'Income-Protection-Indemnity-Value- Leveled',
    value: 'income-indemnity-leveled',
    disable: false,
  },
  {
    label: 'Life-Assurance- Leveled',
    value: 'life-asurance-leveled',
    disable: false,
  },
  {
    label: 'Trauma-Multi- Leveled',
    value: 'trauma-multi-leveled',
    disable: false,
  },
  {
    label: 'Rural-Key-Person Leveled',
    value: 'rural-key-leveled',
    disable: false,
  },
  {
    label: 'Survivors-Income- Leveled',
    value: 'survivors-income-leveled',
    disable: false,
  },
  {
    label: 'Total-and-Permanent-Disability- Leveled',
    value: 'Total-permanent-leveled',
    disable: false,
  },
  {
    label: 'Monthly-Mortgage-Repayment',
    value: 'monthly-mortgage',
    disable: false,
  },
  {
    label: 'Golden-Life',
    value: 'golden-life',
    disable: false,
  },
  {
    label: 'Funeral-Fund',
    value: 'funeral-fund',
    disable: false,
  },
];

export default [
  ...itemDocumentSections,
  ...statementDocumentSections,
  ...policyDocumentSections,
  ...commonDocumentSections,
  ...clientCalculatorOptions,
  ...partnerCalculatorOptions,
  ...sovereignDocumentSections,
  ...aiaDocumentSections,
  ...partnersDocumentSections,
  ...fidelityDocumentSections,
];
