import MasterLayout from 'layouts/Master';
import AuthIndex from 'pages/auth/Index';

import DocumentLayout from 'layouts/Document';

import DocumentPlanIndex from 'pages/document/plan/Index';
import LimitedAdviceIndex from 'pages/document/limited/Index';
import AuthorityToProceedIndex from 'pages/document/atp/Index';
import ScopeOfEngagementIndex from 'pages/document/engagement/Index';
import DisclosureStatementIndex from 'pages/document/disclosure/Index';
import DocumentCalculatorsIndex from 'pages/document/calculators/Index';
import DocumentRecommendationsIndex from 'pages/document/recommendations/Index';

import DashboardLayout from 'layouts/Dashboard';
import DashboardIndex from 'pages/dashboard/Index';
import PlannerIndex from 'pages/dashboard/planner/Index';
import ReferralIndex from 'pages/dashboard/referral/Index';
import InsuranceIndex from 'pages/dashboard/insurance/Index';
import ClassificationIndex from 'pages/dashboard/classification/Index';

import ErrorPage from 'pages/errors/404';

const routes = [
  {
    path: '/',
    component: MasterLayout,
    redirect: { name: 'auth' },
    children: [
      {
        path: 'auth',
        name: 'auth',
        component: AuthIndex,
      },
    ],
  },
  {
    path: '/document',
    component: DocumentLayout,
    meta: { requiresAuth: true },
    children: [
      {
        path: 'scope-of-engagement/preview',
        name: 'scope.of.engagement.preview',
        component: ScopeOfEngagementIndex,
      },
      {
        path: 'disclosure-statement/preview',
        name: 'disclosure.statement.preview',
        component: DisclosureStatementIndex,
      },
      {
        path: 'authority-to-proceed/preview',
        name: 'authority.to.proceed.preview',
        component: AuthorityToProceedIndex,
      },
      {
        path: 'limited-advices/preview',
        name: 'document.limited.advices.preview',
        component: LimitedAdviceIndex,
      },
      {
        path: 'plan/preview/:plannerId?/:reportId?/:type?',
        name: 'document.plan.preview',
        component: DocumentPlanIndex,
      },
      {
        path: 'calculators/preview/:type?',
        name: 'document.calculators.preview',
        component: DocumentCalculatorsIndex,
      },
      {
        path: 'recommendations/:plannerId/report/:reportId/preview/:type?',
        name: 'document.recommendations.preview',
        component: DocumentRecommendationsIndex,
      },
    ],
  },
  {
    path: '/dashboard',
    component: DashboardLayout,
    meta: { requiresAuth: true },
    children: [
      {
        path: 'app',
        name: 'dashboard.app',
        component: DashboardIndex,
      },
      {
        path: 'planner/:id(\\d+)',
        name: 'dashboard.planner',
        component: PlannerIndex,
      },
      {
        path: 'referral/:id(\\d+)?',
        name: 'dashboard.referral',
        component: ReferralIndex,
      },
      {
        path: 'insurance',
        name: 'dashboard.insurance',
        component: InsuranceIndex,
      },
      {
        path: 'classification/units',
        name: 'dashboard.classification.units',
        component: ClassificationIndex,
      },
    ],
  },
  {
    path: '/open/document',
    meta: { requiresAuth: false },
    component: DocumentLayout,
    children: [
      {
        path: 'plan/:plannerId/report/:reportId/preview/:type?',
        name: 'document.open.plan.report.preview',
        component: DocumentPlanIndex,
      },
    ],
  },
];

// Always leave this as last one
if (process.env.MODE !== 'ssr') {
  routes.push({
    path: '*',
    component: ErrorPage,
  });
}

export default routes;
