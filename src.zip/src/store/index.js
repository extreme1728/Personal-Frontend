import Vue from 'vue';
import Vuex from 'vuex';
import user from './modules/user';
import site from './modules/site';
import planner from './modules/planner';
import resources from './modules/resources';
import limitedAdivce from './modules/limitedAdivce';
import liabilityRates from './modules/liabilityRates';
import plannerCollection from './modules/plannerCollection';
import insuranceProvider from './modules/insuranceProvider';
import medicalCategories from './modules/medicalCategories';
import classificationUnit from './modules/classificationUnit';
import clientCalculations from './modules/calculations/client';
import partnerCalculations from './modules/calculations/partner';
import documentRecommendation from './modules/documentRecommendation';
import insuranceProviderReport from './modules/insuranceProviderReport';
import insuranceProviderNoteReport from './modules/insuranceProviderNoteReport';
import hazardousActivitiyCategories from './modules/hazardousActivitiyCategories';
import insuranceProviderCoverTypeComment from './modules/insuranceProviderCoverTypeComment';

import { persist, autosave } from './plugins';

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    user,
    site,
    planner,
    resources,
    limitedAdivce,
    liabilityRates,
    insuranceProvider,
    medicalCategories,
    plannerCollection,
    classificationUnit,
    clientCalculations,
    partnerCalculations,
    documentRecommendation,
    insuranceProviderReport,
    insuranceProviderNoteReport,
    hazardousActivitiyCategories,
    insuranceProviderCoverTypeComment,
  },
  plugins: [persist.plugin, autosave],
});

export default store;
