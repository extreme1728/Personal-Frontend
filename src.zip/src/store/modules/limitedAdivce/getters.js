/*
export const someGetter = (state) => {}
 */
