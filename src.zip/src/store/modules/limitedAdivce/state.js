export default {
  has_limitations: false,
  limitations: {
    instructed: false,
    acknowledge: false,
  },
};
