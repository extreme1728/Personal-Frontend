import _ from 'lodash';

// eslint-disable-next-line
export const UPDATE_LIMITED_ADVICE_FIELD = (state, { field, value }) => _.set(state, field, value);
