const initialState = () => ({
  data: [],
  links: {},
  meta: {},
});

export { initialState };

export default initialState;
