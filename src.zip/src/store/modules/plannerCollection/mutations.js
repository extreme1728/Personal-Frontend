import { reject, eq, toSafeInteger, castArray, set, cloneDeep } from 'lodash';

export const REMOVE_PLANNER_INSTANCE_BY_ID = (state, { data: { id } }) => {
  state.data = reject(state.data, o => eq(o.id, toSafeInteger(id)));
};

export const ADD_PLANNER_COLLECTION = (state, payload) => {
  payload = payload.data || payload;
  const items = state.data;
  /* eslint-disable */
  const result = [...items.concat(castArray(payload))
    .reduce((r, o) => {
      r.has(o.id) || r.set(o.id, {});

      const item = r.get(o.id);

      Object.entries(o).forEach(([k, v]) =>
        // We are removing the reactivity from vue if it is array
        item[k] = Array.isArray(item[k]) ? cloneDeep(v) : v
      );

      return r;
    }, new Map()).values()];
  /* eslint-enable */
  set(state, 'data', result);
};

export const ASSIGN_PLANNER_COLLECTION = (state, payload) =>
  ['data', 'links', 'meta'].forEach((field) => {
    if (payload[field]) {
      if (eq(field, 'data')) {
        ADD_PLANNER_COLLECTION(state, payload[field]);
      }
      else {
        set(state, field, payload[field]);
      }
    }
  });
