import { HTTP_API } from 'src/services/http/http';

export const addPlannerCollection = ({ commit }, payload) =>
  commit('ADD_PLANNER_COLLECTION', payload);

export const requestPlannersFromApi = ({ commit }) => HTTP_API().get('/planners/curate')
  .then(({ data }) => commit('ASSIGN_PLANNER_COLLECTION', data));

export const requestRemovePlanner = ({ commit }, { id, force }) =>
  HTTP_API().post(`/planners/${id}/remove`, { force })
    .then(({ data }) => commit('REMOVE_PLANNER_INSTANCE_BY_ID', data));

export const requestPaginate = ({ commit, state }, link) => {
  if (!link) return;
  // eslint-disable-next-line
  return HTTP_API().get(link).then(({ data: response }) => {
    const { links, meta, data } = response;
    const payload = [...state.data, ...data];
    commit('ASSIGN_PLANNER_COLLECTION', {
      data: payload,
      links,
      meta,
    });
    return data;
  });
};
