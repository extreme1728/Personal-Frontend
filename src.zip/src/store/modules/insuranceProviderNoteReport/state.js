export default {
  reportResults: {
    existing: [],
    proposed: [],
  },
};
