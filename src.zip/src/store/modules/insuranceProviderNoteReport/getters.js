// eslint-disable-next-line
export const reportNoteResults = ({ reportResults }) => reportResults;
