import _ from 'lodash';

const UPDATE_REPORT_NOTE_FORM_DATA = (state, { field, value }) => _.set(state, field, value);

// eslint-disable-next-line
export { UPDATE_REPORT_NOTE_FORM_DATA };
