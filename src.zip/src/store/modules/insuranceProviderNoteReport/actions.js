// eslint-disable-next-line
export const onRequestInsuranceReportNotePersist = (context, payload) =>  {};
