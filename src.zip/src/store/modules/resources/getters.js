import { map, filter, includes, merge, orderBy } from 'lodash';

export const genders = state =>
  state.app.option.values.genders;

export const maritalStatusOptions = state =>
  state.app.option.values.maritalStatus;

export const contractCategoriesOptions = state =>
  state.app.option.values.contractCategories;

export const propertyTypeOptions = state =>
  state.app.option.values.propertyType;

export const alterationAdviceDirectDebitOptions = state =>
  state.app.option.values.alterationAdviceDirectDebit;

export const alterationAdvicePaymentFrequencyOptions = state =>
  state.app.option.values.alterationAdvicePaymentFrequency;

export const alterationAdviceTypesOptions = state =>
  state.app.option.values.alterationAdviceTypes;

export const diabetesTypesOptions = state =>
  state.app.option.values.diabetesTypes;

export const declarationPagesOptions = state =>
  state.app.option.values.declarationPages;

export const houseHoldExpensesOptions = state =>
  map(state.app.option.values.houseHoldExpenses, value => ({
    value,
    label: value,
  }));

export const scopeOfEngagementsOptions = state =>
  state.app.option.values.scopeOfEngagements;

export const adviceTypesOptions = state =>
  state.app.option.values.adviceTypes;

export const letterOfAuthorityOptions = state =>
  state.app.option.values.letterOfAuthority;

export const accCoverPlanTypes = state => state.app.option.values.accCoverPlanTypes;

export const inputDateFormat = state => state.app.config.input.date.format;

export const signatureConfig = state => state.app.config.signature;

export const mortgageRepaymentMethods = state => state.app.option.values.mortgageRepaymentMethods;

export const employmentValues = state => state.app.option.values.employmentValues;

export const employmentScheduleValues = state => state.app.option.values.employmentScheduleValues;

export const taxMethodValues = state => state.app.option.values.taxMethodValues;

export const booleanValues = state => state.app.option.values.booleanValues;

export const clientOrPartner = state => state.app.option.values.clientOrPartner;

export const existingCovers = (state, getters, rootState, rootGetters) => {
  const excepts = ['First Appointment', 'First Meeting Report'];
  const providers = filter(rootGetters['insuranceProvider/providers'], ({ name }) => !includes(excepts, name));
  const sortingCovers = orderBy(providers, 'name', 'asc');
  return map(sortingCovers, ({ name }) => merge({}, { label: name, value: name }));
};

// eslint-disable-next-line
export const incomeIsEmployedMonth = state => state.app.option.values.incomeIsEmployedMonth;

// eslint-disable-next-line
export const incomeIsEmployedYear = state => state.app.option.values.incomeIsEmployedYear;

// eslint-disable-next-line
export const fatalEntitlementCategories = state => state.app.option.values.fatalEntitlementCategories;

// eslint-disable-next-line
export const getFilteredInsuranceProvider = (state, { existingCovers }) => providers => filter(existingCovers, ({ value }) => includes(providers, value));

// eslint-disable-next-line
export const getInsuranceProvidersForTaxIssues = (state, { getFilteredInsuranceProvider }) => getFilteredInsuranceProvider(['Fidelity', 'AIA', 'Partners Life']);

// eslint-disable-next-line
export const getInsuranceProvidersForMortgageRepaymentIncomeProtection = (state, { getFilteredInsuranceProvider }) => getFilteredInsuranceProvider(['Fidelity', 'AIA', 'Partners Life', 'Asteron', 'Sovereign']);

// eslint-disable-next-line
export const getInsuranceProvidersForPolicyWordings = (state, { getFilteredInsuranceProvider }) => getFilteredInsuranceProvider(['Fidelity', 'AIA', 'Partners Life', 'Sovereign']);
