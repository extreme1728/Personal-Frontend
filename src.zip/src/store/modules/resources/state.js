export default () => ({
  app: {
    config: {
      input: {
        date: {
          format: 'DD/MM/YYYY',
        },
      },
      signature: {
        format: 'image/png',
        option: {
          penColor: 'rgb(0, 0, 0)',
        },
      },
    },
    option: {
      values: {
        maritalStatus: [
          { label: 'Single', value: 'single' },
          { label: 'Engaged', value: 'engaged' },
          { label: 'Married', value: 'married' },
          { label: 'Defacto', value: 'defacto' },
          { label: 'Divorced', value: 'divorced' },
        ],
        genders: [
          { label: 'Male', value: 'male' },
          { label: 'Female', value: 'female' },
        ],
        contractCategories: [
          { label: 'Lease of Building', value: 'Lease of Building' },
          { label: 'Equipment', value: 'Equipment' },
          { label: 'Vehicle Rentals', value: 'Vehicle Rentals' },
        ],
        propertyType: [
          { label: 'Mortgage Repayments', value: 'mortgage-repayments' },
          { label: 'Rental Payments', value: 'rental-payments' },
          { label: 'Freehold House', value: 'freehold-house' },
        ],
        alterationAdviceDirectDebit: [
          { label: 'Existing', value: 'existing' },
          { label: 'New', sublabel: 'Provide a new Direct Debit form', value: 'new' },
        ],
        fidelityLifeDirectDebit: [
          { label: 'Existing', value: 'existing' },
          { label: 'New', sublabel: 'Provide a new Direct Debit form', value: 'new' },
        ],
        alterationAdvicePaymentFrequency: [
          { label: 'Monthly', value: 'monthly' },
          { label: 'Half Yearly', value: 'half_yearly' },
          { label: 'Annual', value: 'annual' },
          { label: 'Other', value: 'other' },
        ],
        alterationAdviceTypes: [
          { label: 'Increase/Addition', value: 'increase_or_addition' },
          { label: 'Decrease', value: 'decrease' },
          { label: 'Other', value: 'other' },
        ],
        diabetesTypes: [
          { label: 'Type 1', value: 'Type 1' },
          { label: 'Type 2', value: 'Type 2' },
        ],
        declarationPages: [
          {
            name: 'Aia',
            color: 'pink-5',
          },
          {
            name: 'Asteron',
            color: 'blue-7',
          },
          {
            name: 'Fidelity and Nib',
            value: 'FidAndNib',
            color: 'green-10',
          },
          {
            name: 'Partners Life',
            value: 'PartnersLife',
            color: 'lime-5',
          },
          {
            name: 'Sovereign',
            color: 'cyan-4',
          },
        ],
        houseHoldExpenses: [
          'Body Corporate Fees',
          'Electricity',
          'Gas',
          'Water',
          'Phone',
          'Rent',
          'Rates',
          'Paid Television',
          'Internet',
          'House, Contents and Motor Vehicle Insurance Premiums',
          'Hire Purchase, Bank Loan or other Personal Loan Repayments',
          'Private School Fees',
        ],
        scopeOfEngagements: [
          'Life Cover',
          'Disability Income Protection',
          'Trauma Cover',
          'Key Person Protection',
          'Accidental Injury Cover',
          'Health Cover',
          'Specialists and Diagnostics',
          'Shareholder Protection',
          'Total Permanent Disablement Cover',
          'Waiver of Premium',
        ],
        adviceTypes: [
          { label: 'Full Advice', value: 'full_advice' },
          { label: 'Partial Advice', value: 'partial_advice' },
          { label: 'No Advice', value: 'no_advice' },
        ],
        letterOfAuthority: [
          {
            label: 'Existing Insurance Policy Schedule (including benefit information, loadings & exclusions)',
            value: 'existing_insurance_policy_schedule',
          },
          {
            label: 'ACC 1766 (ACC Giving access to your ACC information)',
            value: 'acc_1766',
          },
          {
            label: 'ACC 5937 (ACC Authority to Act)',
            value: 'acc_5937',
          },
          {
            label: 'Financial Practitioner Engagement',
            value: 'financial_practitioner_engagement',
          },
          {
            label: 'Medical Information Request',
            value: 'medical_information_request',
          },
          {
            label: 'PMAR Request',
            value: 'pmar_request',
          },
          {
            label: 'Combined Insurance Authorisation Letter',
            value: 'combined_insurance',
          },
        ],
        accCoverPlanTypes: [
          {
            label: 'ACC Cover Plus/Work Place Cover',
            value: 'cover_plus',
          },
          {
            label: 'ACC Cover Plus Extra',
            value: 'cover_plus_extra',
          },
        ],
        employmentValues: [
          { label: 'Home-maker', value: 'housemaker' }, // changed LABEL only
          { label: 'Employed', value: 'employed' },
          { label: 'Self Employed', value: 'self-employed' },
          { label: 'Unemployed', value: 'unemployed' },
          { label: 'Retired', value: 'retired' },
          { label: 'On benefit', value: 'on-benefit' },
        ],
        employmentScheduleValues: [
          {
            label: 'Part Time',
            value: 'part-time',
          },
          {
            label: 'Full Time',
            value: 'full-time',
          },
        ],
        taxMethodValues: [
          {
            label: 'Drawings/Shareholder salary (i.e non paye income)',
            value: 'drawings',
          },
          {
            label: 'PAYE',
            value: 'paye',
          },
          {
            label: 'Combination of Drawings/Shareholder salary (i.e none paye income) and PAYE',
            value: 'combination-of-drawings-and-paye',
          },
        ],
        booleanValues: [
          {
            label: 'Yes',
            value: 'yes',
          },
          {
            label: 'No',
            value: 'no',
          },
        ],
        existingCovers: [], // From insurance providers store.
        clientOrPartner: [
          {
            label: 'Client',
            value: 'client',
          },
          {
            label: 'Partner',
            value: 'partner',
          },
        ],
        fatalEntitlementCategories: [
          {
            label: 'With Partner and No Child',
            value: 'no-child',
          },
          {
            label: 'With Partner and ≤ Two children younger than 18 years old',
            value: 'less-than-two-children',
          },
          {
            label: 'With Partner and > Two children younger than 18 years old',
            value: 'greater-than-two-children',
          },
          {
            label: 'With Partner and studying children above than 18 years old',
            value: 'studying-children',
          },
        ],
        mortgageRepaymentMethods: [
          {
            label: 'Weekly',
            value: 'weekly',
          },
          {
            label: 'Fortnightly',
            value: 'fortnightly',
          },
          {
            label: 'Monthly',
            value: 'monthly',
          },
          {
            label: 'Annually',
            value: 'annually',
          },
        ],
        incomeIsEmployedMonth: [
          {
            label: 'January',
            value: 'january',
          },
          {
            label: 'February',
            value: 'february',
          },
          {
            label: 'March',
            value: 'march',
          },
          {
            label: 'April',
            value: 'april',
          },
          {
            label: 'May',
            value: 'may',
          },
          {
            label: 'June',
            value: 'june',
          },
          {
            label: 'July',
            value: 'july',
          },
          {
            label: 'August',
            value: 'august',
          },
          {
            label: 'September',
            value: 'september',
          },
          {
            label: 'October',
            value: 'october',
          },
          {
            label: 'November',
            value: 'november',
          },
          {
            label: 'December',
            value: 'december',
          },
        ],
        incomeIsEmployedYear: [
          {
            label: '2015',
            value: '2015',
          },
          {
            label: '2016',
            value: '2016',
          },
          {
            label: '2017',
            value: '2017',
          },
          {
            label: '2018',
            value: '2018',
          },
          {
            label: '2019',
            value: '2019',
          },
        ],
      },
    },
  },
});
