import { isEmpty, map, filter, some, eq } from 'lodash';
import { floatTotals, numberWithCommas } from 'src/config/utils';

const PLANNER_NAMESPACE = 'planner';

export const reportFormData = state => state.reportFormData;

export const reportResults = state => state.reportResults;

export const currentSelectedReport = state => state.currentSelectedReport;

// For proposed only
export const hasInsurancePolicyOnProviderResult = ({ reportResults: { proposed: proposes } }) => provider => !isEmpty(filter(proposes, ({ policies }) => some(policies, ['provider', provider])));

// eslint-disable-next-line
export const hasFidelityOnPolicyProviderResults = (state, { hasInsurancePolicyOnProviderResult }) => hasInsurancePolicyOnProviderResult('Fidelity');

// eslint-disable-next-line
export const hasPartnersLifeOnPolicyProviderResults = (state, { hasInsurancePolicyOnProviderResult }) => hasInsurancePolicyOnProviderResult('Partners Life');

// eslint-disable-next-line
export const getPropsedTotalMonthlyPremium = ({ reportResults: { proposed, underwriting, category } }, getters, rootState, rootGetters) => {
  const totals = [];
  let values = eq(category, 'Pre and Post Underwriting')
    ? underwriting
    : proposed;
  const plan = rootGetters[`${PLANNER_NAMESPACE}/plan`];
  const shouldFilter = rootGetters[`${PLANNER_NAMESPACE}/showItemRecommendationPartnerValues`];
  values = filter(values, ({ name }) => {
    if (shouldFilter) return true;
    return name !== plan.partner_name;
  });
  values.forEach(({ policies }) => {
    if (!isEmpty(policies) && policies instanceof Array) {
      policies.forEach(({ premium }) => {
        totals.push(numberWithCommas(premium, false));
      });
    }
  });
  return floatTotals(totals);
};

export const getReportCategories = () => map(['Apples for Apples', 'Apples for Apples Improved', 'Full Advice', 'No Existing Insurance', 'Pre and Post Underwriting'], category => ({
  label: category,
  value: category,
}));

export const getReportInsurancePlanTypes = () => map(['Personal', 'Business'], category => ({
  label: category,
  value: category.toLowerCase(),
}));
