import { set, concat } from 'lodash';

export const ASSIGN_REPORT_RESULT = (state, payload) => set(state, 'reportResults', payload);

export const UPDATE_REPORT_FORM_DATA = (state, { field, value }) => set(state, field, value);

export const UPDATE_REPORT_RESULT_DATA = (state, { field, value }) => set(state, ['reportResults', field || null], value);

export const ADD_REPORT_RESULTS_DATA = (state, payload) => {
  // check if it exists via name and offer type
  // update policies array
  state.reportResults = concat(state.reportResults, payload);
};
