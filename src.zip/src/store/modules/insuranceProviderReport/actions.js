import { HTTP_API } from 'src/services/http/http';

export const assignReportResults = ({ commit }, payload) => commit('ASSIGN_REPORT_RESULT', payload);

export const updateReportFormDataFieldAction = ({ commit }, payload) => commit('UPDATE_REPORT_FORM_DATA', payload);

// eslint-disable-next-line
export const onRequestInsuranceReportPersist = (context, { planner_id, ...payload }) =>
  // eslint-disable-next-line
  HTTP_API().post(`/planners/${planner_id}/reports/recommendations/persist`, { ...{ planner_id }, ...payload }).then(({ data }) => data);

// eslint-disable-next-line
export const onRequestInsuranceReportRemove = (ctx, { planner_id, id, ...payload }) =>
  // eslint-disable-next-line
  HTTP_API().post(`/planners/${planner_id}/reports/recommendations/${id}/remove`, { ...{ planner_id, id }, ...payload }).then(({ data }) => data);

// eslint-disable-next-line
export const onRequestInsuranceReportUpdate = (ctx, { planner_id, id, ...payload }) =>
  // eslint-disable-next-line
  HTTP_API().post(`/planners/${planner_id}/reports/recommendations/${id}/update`, { ...{ planner_id, id }, ...payload }).then(({ data }) => data);
