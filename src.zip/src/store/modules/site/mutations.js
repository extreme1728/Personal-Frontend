import { set } from 'lodash';

export const UPDATE_PLANNER_STEP = (state, step) =>
  set(state.dashboard, ['planner', 'step'], step);

export const UPDATE_FAB_SETTINGS_STATE = (state, payload) =>
  set(state.dashboard, ['planner', 'fabs', 'settings'], payload);
