import { eq } from 'lodash';

export const getOfficePhysicalAddress = ({ officePhysicalAddress }) => officePhysicalAddress;

export const getPlannerStep = ({ dashboard: { planner } }) => planner.step;

export const getPlanerFabs = ({ dashboard: { planner } }) => planner.fabs;

export const isBusinessNeedsStep = (state, { getPlannerStep: step }) =>
  eq(step, 'business-needs');
