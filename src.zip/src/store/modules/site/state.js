const initialState = () => ({
  dashboard: {
    planner: {
      step: null,
      fabs: {
        settings: {
          show: true,
        },
        direction: {
          show: true,
        },
      },
      relations: [
        'mortgages',
        'key_persons',
        'buy_and_sells',
        'business_debt',
        'scope_services',
        'referral_banks',
        'alteration_advice',
        'household_expenses',
        'letter_of_authority_scopes',
        'fatal_entitlement_childrens',
      ],
    },
  },
  officePhysicalAddress: '1/367A Withells Road, Avonhead, Christchurch 8042',
});

export { initialState };

export default initialState;
