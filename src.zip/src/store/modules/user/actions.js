import { merge } from 'lodash';
import { HTTP, HTTP_API } from 'src/services/http/http';

export const requestLogin = ({ commit }, payload) => {
  const formData = merge(payload, {
    client_id: process.env.AUTH_CLIENT_ID,
    client_secret: process.env.AUTH_CLIENT_SECRET,
    grant_type: 'password',
  });
  return HTTP().post('/oauth/token', formData)
    .then(({ data }) => {
      commit('SET_CURRENT_USER_TOKEN', data);
      return data;
    });
};

export const requestUserData = ({ commit }) => HTTP_API().get('/user')
  .then(({ data }) => commit('SET_CURRENT_USER_MODEL', data));

export const userClearAll = ({ commit }) => {
  ['REMOVE_CURRENT_USER_TOKEN', 'REMOVE_SET_CURRENT_USER_MODEL']
    .forEach(v => commit(v));
  return Promise.resolve();
};
