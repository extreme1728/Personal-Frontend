export default () => ({
  currentTokenData: {},
  currentModel: {},
  formData: {
    username: null,
    password: null,
  },
});
