export const rateValues = state => state.rateValues;

export const requirements = state => state.requirements;

export const offsets = state => state.offsets;

export const taxRateLevels = state => state.taxes.levels;

export const taxRateIncome = state => state.taxes.income;

export const fatal = state => state.fatal;
