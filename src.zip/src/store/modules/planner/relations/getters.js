import { find, eq, isEmpty, chain, each } from 'lodash';
import CalculatorService from 'src/services/ipp/calculators/Service';
import FatalEntitlement from 'src/services/aos/fatal/FatalEntitlement';
import { floatTotals, switchcase, numberWithCommas } from 'src/config/utils';

/**
 * Constant defining liability rate store namespace.
 *
 * @type {String}
 */
const LIABILITY_RATES_NAMESPACE = 'liabilityRates';

export const clientLetterOfAuthorityScopes = ({ letter_of_authority_scopes: scopes }) =>
  find(scopes, ['type', 'client']);

export const partnerLetterOfAuthorityScopes = ({ letter_of_authority_scopes: scopes }) =>
  find(scopes, ['type', 'partner']);

export const clientScopeServices = ({ scope_services: scopes }) =>
  find(scopes, ['type', 'client']);

export const partnerScopeServices = ({ scope_services: scopes }) =>
  find(scopes, ['type', 'partner']);

export const getClientCalculatorFields = state =>
  (new CalculatorService(state)).getAll();

export const getPartnerCalculatorFields = state =>
  (new CalculatorService(state, 'partner')).getAll();

export const getDeterminedAlterationAdviceSignature = ({ signatures }) => type =>
  find(signatures, { type, stage: 'alteration_advice' }) || null;

export const getDeterminedFirstAppointmentSignature = ({ signatures }) => type =>
  find(signatures, { type, stage: 'first_appointment' }) || null;

export const getDeterminedSecondAppointmentSignature = ({ signatures }) => type =>
  find(signatures, { type, stage: 'second_appointment' }) || null;

export const getAccLevyCalculation = ({ acc_levy_calculations: calculations }) =>
  (type, property) => find(calculations, { type, property }) || null;

// eslint-disable-next-line
export const getFatalEntitlementDetermineActualEstimatedEarningsAmount = ({ client_full_name: name, fatal_entitlement_for_type: category }, getters) => {
  const determinedIncomeByType = eq(category, name)
    ? 'determineIncomeFromBusiness'
    : 'determinePartnerTakingFromTheFirm';
  return getters[determinedIncomeByType];
};

// eslint-disable-next-line
export const calculateFatalEntitlements = ({ fatal_entitlement_category_type: category, fatal_entitlement_annual_pre_aggreed_cover_amount: annualPreAgreedCoverAmount, fatal_entitlement_childrens: childrens }, getters, rootState, rootGetters) => income => {
  if (isEmpty(annualPreAgreedCoverAmount)) return null;
  return (new FatalEntitlement(
    income,
    annualPreAgreedCoverAmount,
    category,
    childrens,
    rootGetters[`${LIABILITY_RATES_NAMESPACE}/fatal`],
    rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`],
  )).handle();
};

// eslint-disable-next-line
export const getFatalEntitlementDetermineCalculationByCategory = (state, { getFatalEntitlementDetermineActualEstimatedEarningsAmount: income, calculateFatalEntitlements }) => calculateFatalEntitlements(income);

// eslint-disable-next-line
export const showFatalEntitlementCalculation = ({ is_partner_shareholder_or_directory }, { getFatalEntitlementDetermineCalculationByCategory, hasClientIncome, hasPartnerIncome }) => {
  if (eq(is_partner_shareholder_or_directory, 'no')) return false;
  return !isEmpty(getFatalEntitlementDetermineCalculationByCategory)
    && (hasClientIncome || hasPartnerIncome);
};

// eslint-disable-next-line
export const mapChildrensName = ({ fatal_entitlement_childrens }) =>
  chain(fatal_entitlement_childrens).map('name').value();

export const getChildYoungestAge = ({ fatal_entitlement_childrens: childrens }) =>
  chain(childrens).map('age').min().value() || 0;


export const householdExpenseTotalAmount = ({ household_expenses: expenses }) => {
  const totals = [];
  each(expenses, ({ frequency, value }) => {
    const frequencyType = switchcase({
      weekly: 52,
      fortnightly: 26,
      monthly: 12,
      annually: 1,
    })(false);
    const amount = frequencyType(frequency);
    totals.push(numberWithCommas(value, false) * amount);
  });
  return floatTotals(totals);
};
