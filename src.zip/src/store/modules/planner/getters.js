import plannerSteps from 'src/config/plannerSteps';
import NoteService from 'src/services/ipp/note/Service';
import { eq, toLower, map, compact, filter, trim, find, isEmpty, includes } from 'lodash';
import { floatTotals, floatFixer, numberWithCommas, switchcase } from 'src/config/utils';

/**
 * Constant defining liability rate store namespace.
 *
 * @type {String}
 */
// const LIABILITY_RATES_NAMESPACE = 'liabilityRates';

export const plan = state => state;

export const preferences = state => state.preferences.values;

export const getEstatePlanningNotes = ({
  client_full_name: clientName,
  client_has_will_in_place: clientHasWillInPlace,
  client_has_attorney: clientHasAttorney,
  partner_name: partnerName,
  partner_has_will_in_place: partnerHasWillInPlace,
  partner_has_attorney: partnerHasAttorney,
}) => [
  (new NoteService(clientName, clientHasWillInPlace, clientHasAttorney)).render(),
  (new NoteService(partnerName, partnerHasWillInPlace, partnerHasAttorney)).render(),
].join('\n\n');

export const getAssetsNote = () => NoteService.getAssetsNote();

// eslint-disable-next-line
export const hasChildren = ({ have_childrens }) => eq(have_childrens, 'yes');

// eslint-disable-next-line
export const determineIncomeFromBusiness = ({ employment_position_type, employed_annual_income, income_from_business }, getters, rootState, rootGetters) => {
  // eslint-disable-next-line
  const income = eq(toLower(employment_position_type), 'employed') ? employed_annual_income : income_from_business;

  // eslint-disable-next-line
  // const { employed_annual_income: incomeRequirement } = rootGetters[`${LIABILITY_RATES_NAMESPACE}/requirements`];
  // const { maximum, minimum } = incomeRequirement;
  // if (income > maximum) return numberWithCommas(maximum);
  // if (income < minimum) return numberWithCommas(minimum);

  return numberWithCommas(income);
};

// eslint-disable-next-line
export const determineNominatedCoverAmount = ({ nominated_cover_amount: income }, getters, rootState, rootGetters) => {
  income = floatFixer(income);

  // eslint-disable-next-line
  // const { nominated_cover_amount: nominatedRequirement } = rootGetters[`${LIABILITY_RATES_NAMESPACE}/requirements`];
  // if (income > nominatedRequirement.maximum)
  // return numberWithCommas(nominatedRequirement.maximum);
  // if (income < nominatedRequirement.minimum)
  // return numberWithCommas(nominatedRequirement.minimum);

  return numberWithCommas(income);
};

/* eslint-disable */
export const determinePartnerTakingFromTheFirm = ({ partner_employment_position_type, partner_taking_from_the_firm, partner_annual_income }, getters, rootState, rootGetters) => {
  const income = floatFixer(eq(toLower(partner_employment_position_type), 'employed') ? partner_annual_income  : partner_taking_from_the_firm);

  return numberWithCommas(income);
};
/* eslint-enable */

// eslint-disable-next-line
export const determinePartnerNominatedCoverAmount = ({ partner_nominated_cover_amount: income }, getters, rootState, rootGetters) => {
  income = floatFixer(income);

  // eslint-disable-next-line
  // const { nominated_cover_amount: nominatedRequirement } = rootGetters[`${LIABILITY_RATES_NAMESPACE}/requirements`];
  // if (income > nominatedRequirement.maximum)
  //   return numberWithCommas(nominatedRequirement.maximum);
  // if (income < nominatedRequirement.minimum)
  //   return numberWithCommas(nominatedRequirement.minimum);

  return numberWithCommas(income);
};

// eslint-disable-next-line
export const hasClientIncome = ({ nominated_cover_amount }, { determineIncomeFromBusiness }) =>
  !!floatTotals([
    floatFixer(determineIncomeFromBusiness),
    floatFixer(nominated_cover_amount),
  ]);

// eslint-disable-next-line
export const hasPartnerIncome = ({ partner_taking_from_the_firm, partner_nominated_cover_amount }) =>
  !!floatTotals([
    floatFixer(partner_taking_from_the_firm),
    floatFixer(partner_nominated_cover_amount),
  ]);

export const isEmployed = (state, { isHouseMaker }) =>
  includes(['employed'], state.employment_position_type) || isHouseMaker;

// these 3 items here basically means that the client does not generate income for the household.
// It will have the same features as if we selected "HOUSEMAKER" that we have on the list before.
export const isHouseMaker = state =>
  includes(['housemaker', 'unemployed', 'retired', 'on-benefit'], state.employment_position_type);

export const isSelfEmployed = state =>
  eq(state.employment_position_type, 'self-employed');

export const isPartnerEmployed = (state, { isPartnerHouseMaker }) =>
  includes(['employed'], state.partner_employment_position_type) || isPartnerHouseMaker;

export const isPartnerHouseMaker = state =>
  includes(['housemaker', 'unemployed', 'retired', 'on-benefit'], state.partner_employment_position_type);

export const isPartnerSelfEmployed = state =>
  eq(state.partner_employment_position_type, 'self-employed');

// eslint-disable-next-line
export const mapClientAndPartnerNameValues = ({ client_full_name: clientName, partner_name: partnerName }, { mapBusinessPartners, mapChildrensName }) =>
  map(compact([
    clientName,
    partnerName,
    ...mapChildrensName,
    ...mapBusinessPartners,
  ]), name => ({
    label: name,
    value: name,
  }));

// eslint-disable-next-line
export const mapDeterminedStepList = (state, { isEmployed, isSelfEmployed }) => {
  const filteredSteps = filter(plannerSteps, ({ employed, selfEmployed }) => {
    // eslint-disable-next-line
    if (!isEmpty(selfEmployed)) return (eq(isEmployed, employed) && eq(isSelfEmployed, selfEmployed));
    if (isEmployed) return eq(isEmployed, employed);
    return plannerSteps;
  });

  return map(filteredSteps, ({ label, value }) => ({
    label,
    value,
    color: 'secondary',
  }));
};

export const mapBusinessPartners = ({ business_partners: businessPartners }) =>
  map(businessPartners, ({ full_name: name }) => name);

// eslint-disable-next-line
export const getClientInsuranceProviders = ({ client_insurance_providers: providers, client_custom_insurance_providers: customProviders }) =>
  [...(providers || []), ...(customProviders || [])];

// eslint-disable-next-line
export const getPartnerInsuranceProviders = ({ partner_insurance_providers: providers, partner_custom_insurance_providers: customProviders }) =>
  [...(providers || []), ...(customProviders || [])];

export const hasPartnerExists = ({ partner_name: name }) =>
  !!trim(name).length;

export const hasClientExists = ({ client_full_name: name }) =>
  !!trim(name).length;

// eslint-disable-next-line
export const getPersonsListInPLanners = ({ client_full_name: clientName, partner_name: partnerName }, { mapBusinessPartners }) =>
  map(compact([clientName, partnerName, ...mapBusinessPartners]), name => ({
    label: name,
    value: name,
  }));

// eslint-disable-next-line
export const getPersonsListDataInPlanners = ({ client_full_name: clientName, partner_name: partnerName, business_partners: businessPartners, ...state }, { determineIncomeFromBusiness, determinePartnerTakingFromTheFirm }) => query => {
  if (eq(clientName, query)) {
    return {
      income: determineIncomeFromBusiness,
      date_of_birth: state.client_date_of_birth,
      smoking_status: state.client_smoking_status,
    };
  }

  if (eq(partnerName, query)) {
    return {
      income: determinePartnerTakingFromTheFirm,
      date_of_birth: state.partner_date_of_birth,
      smoking_status: state.partner_smoking_status,
    };
  }

  return find(businessPartners, ['full_name', query]);
};

// eslint-disable-next-line
export const getCalculatedMortgageRepayment = ({ mortgage_repayments: amount, mortgage_repayments_type: frequency }) => {
  const determinePaymentByFrequency = switchcase({
    weekly: 52,
    fortnightly: 26,
    monthly: 12,
    annually: 1,
  })(false);
  const payment = determinePaymentByFrequency(frequency);
  return (numberWithCommas(amount, false) * payment);
};

// eslint-disable-next-line
export const partnerGrossIncome = ({ partner_income_method: frequency }, { determinePartnerTakingFromTheFirm, isPartnerSelfEmployed }) => {
  const income = numberWithCommas(determinePartnerTakingFromTheFirm, false);
  if (isPartnerSelfEmployed && frequency) {
    const payment = switchcase({
      weekly: 52,
      fortnightly: 26,
      monthly: 12,
      annually: 1,
    })(false);
    const total = payment(frequency);
    return (income * total);
  }
  return income;
};

// eslint-disable-next-line
export const clientGrossIncome = ({ client_income_method: frequency }, { determineIncomeFromBusiness, isSelfEmployed }) => {
  const income = numberWithCommas(determineIncomeFromBusiness, false);
  if (isSelfEmployed && frequency) {
    const payment = switchcase({
      weekly: 52,
      fortnightly: 26,
      monthly: 12,
      annually: 1,
    })(false);
    const total = payment(frequency);
    return (income * total);
  }
  return income;
};

// eslint-disable-next-line
export const showItemRecommendationPartnerValues = ({ is_partner_shareholder_or_directory }, { hasPartnerExists }) =>
  (hasPartnerExists && trim(is_partner_shareholder_or_directory).includes('yes'));

// eslint-disable-next-line
export const getClientHouseholdSavings = ({ household_savings: savings }, { clientGrossIncome, partnerGrossIncome }) => {
  const totalIncome = clientGrossIncome + partnerGrossIncome;
  const livingExpense = totalIncome - numberWithCommas(savings, false);
  return numberWithCommas(floatFixer(livingExpense));
};
