import { assign, set, cloneDeep, isEmpty } from 'lodash';

export const ASSIGN_PLANNER = (state, payload) => {
  const data = payload.data || payload;
  assign(state, data);
};

export const UPDATE_PLAN_FIELD_VALUE = (state, { value, field }) => {
  if ((value instanceof Object && value.constructor === Object) && isEmpty(field)) {
    Object.entries(value).forEach(([k, v]) => {
      const payload = Array.isArray(state[k]) ? cloneDeep(v) : v;
      set(state, k, payload);
    });
  }
  else {
    set(state, field, value);
  }
};
