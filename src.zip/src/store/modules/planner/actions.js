import { has, includes } from 'lodash';
import { HTTP_API } from 'src/services/http/http';
import { initialState as siteInitialState } from 'src/store/modules/site/state';

/**
 * Constant defining store namespace module.
 *
 * @type {String}
 */
const PLANNER_COLLECTION_NAMESPACE = 'plannerCollection';

export const updatePlanFieldAction = ({ commit }, payload) => commit('UPDATE_PLAN_FIELD_VALUE', payload);

export const persistPlanner = (ctx, payload) => {
  const { dashboard: { planner: { relations } } } = siteInitialState();
  const shouldUseRelationRoute = has(payload, 'planner') && has(payload, 'mutationPayload');

  if (shouldUseRelationRoute) {
    const { planner, mutationPayload: { field, value, remove } } = payload;
    if (includes(relations, field)) {
      const route = remove ? 'remove' : 'persist';
      return HTTP_API()
        .post(`/planners/${planner.id}/relations/${field}/${route}`, { payload: value })
        .then(({ data }) => data);
    }
    return HTTP_API().post('/planners/persist', planner).then(({ data }) => data);
  }

  return HTTP_API().post('/planners/persist', payload).then(({ data }) => data);
};

// eslint-disable-next-line
export const persistPlannerCalculator = (ctx, { type, field, payload, id }) =>
  HTTP_API().post(`/planners/${id}/calculators/${type}/${field}/persist`, { payload })
    .then(({ data }) => data);

export const getPlannerReport = (ctx, { plannerId, reportId }) =>
  HTTP_API().get(`/planners/${plannerId}/find/${reportId}`)
    .then(({ data }) => data);

export const persistPlannerSignature = (ctx, { planner_id: id, ...payload }) =>
  HTTP_API().post(`/planners/${id}/signatures/persist`, payload)
    .then(({ data }) => data);

export const findPlanner = (ctx, id) =>
  HTTP_API().get(`/planners/${id}/find`)
    .then(({ data }) => data);

export const persistAccLevyCalculation = ({ state: { id: planner } }, payload) =>
  HTTP_API().post(`acc/calculations/${planner}/persist`, payload)
    .then(({ data }) => data);

export const persistReplicatePlanner = async ({ commit }, { planner, name }) => {
  const { data } = await HTTP_API().post(`/planners/${planner}/replicate`, {
    client_full_name: name,
  });
  commit(`${PLANNER_COLLECTION_NAMESPACE}/ADD_PLANNER_COLLECTION`, data, { root: true });
  return Promise.resolve(data);
};

export const queryPlanner = async ({ commit }, payload) => {
  const { data } = await HTTP_API().post('/planners/query', { query: payload });
  commit(`${PLANNER_COLLECTION_NAMESPACE}/ADD_PLANNER_COLLECTION`, data, { root: true });
  return Promise.resolve(data);
};
