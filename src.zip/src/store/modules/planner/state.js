const initialState = () => ({
  id: 0,
  stage: 'first_appointment',
  selections: [],
  reports: [],
  calculators: [],
  referral_banks: [],
  notes_comparisons: [],
  employment_position_type: null, // 'self-employed'
  company_full_name: null,
  client_name_title: null,
  client_full_name: null,
  client_preferred_name: null,
  business_partners: [], // @TODO: Relational Model
  employed_schedule_type: null, // 'full-time'
  employed_annual_income: null,
  employed_occupation: null,
  employed_how_long: null, // 'no'
  income_tax_method: null,
  on_tools: null,
  classification_unit: null,
  income_from_business: null,
  client_income_method: null,
  acc_cover_plan_type: 'cover_plus',
  acc_levy_calculations: [],
  existing_nominated_cover_amount: '29,453',
  nominated_cover_amount: '29,453',
  business_how_many_years: null,
  when_business_started: null, // 'no'

  how_many_boys: null,
  partner_how_many_boys: null,
  what_you_do_in_business: null,
  has_corporate_partner: null, // 'no'
  partner_has_corporate_partner: null,

  is_partner_shareholder_or_directory: null, // 'yes'
  partner_name_title: null,
  partner_name: null,
  partner_preferred_name: null,
  is_partner_account_tax_splitting: null, // 'yes'
  partner_income_tax_method: null,
  partner_taking_from_the_firm: '0',
  partner_income_method: null,
  partner_acc_cover_plan_type: 'cover_plus',
  partner_existing_nominated_cover_amount: '29,453',
  partner_nominated_cover_amount: '29,453',
  partner_on_tools: null, // 'yes'
  partner_classification_unit: null,
  partner_business_how_many_years: null,
  partner_when_business_started: null,
  partner_annual_income: null,

  partner_is_working_for_business: null, // 'no'
  partner_is_working: null, // 'no'
  partner_employment_position_type: null, // 'employed'
  partner_company_full_name: null,
  partner_employed_schedule_type: null, // 'full-time'
  partner_employed_how_long: null, // 'yes'
  partner_employed_work_exp_month: null,
  partner_employed_work_exp_year: null,
  partner_what_job: null,

  // Business Needs
  key_persons: [],
  buy_and_sells: [],
  business_debt: {},

  // IMPORTANT INFO
  acc_number_personal: null,
  ird_number_personal: null,

  partner_acc_number_personal: null,
  partner_ird_number_personal: null,

  // ACCOUNTANT DETAILS
  acc_number_business: null,
  ird_number_business: null,
  accountants_name: null,
  firm_name: null,
  accountant_email_address: null, // email
  phone_number: null, // telephone

  client_date_of_birth: null,
  client_address: null,
  client_marital_status: null,
  client_mobile_number: null,
  client_email_address: '',
  client_smoking_status: null, // 'no'
  client_insurance_providers: [],
  client_employed_work_exp_month: null,
  client_employed_work_exp_year: null,
  client_custom_insurance_providers: [],
  client_has_will_in_place: null, // 'no'
  client_wills_reflect_situation: null,
  client_has_guardianship_of_children: null,
  client_has_attorney: null, // 'no'
  client_passive_income: null, // 'no'
  client_passive_amount: null,
  client_country_birth: null,
  client_have_trust: null,
  client_medical_usual_general_practitioner: null,
  client_medical_name_general_practitioner_medical_center: null,
  client_medical_general_practitioner_address: null,
  client_have_been_to_doctor: null, // 'no'
  client_have_been_to_doctor_conditions: null,
  client_have_any_hazardous_activity: null, // 'no'
  client_hazardous_activity: null,
  client_on_any_prescription_medicine: {},
  client_on_any_prescription_medicine_conditions: {},
  client_pregnancy_details: {},
  client_family_history: {},
  client_has_increased_height_and_weight: null, // 'no'
  client_body_mass_index: {},
  client_smoked_in_last_twelve_months: null, // 'no'
  client_smoking_when_took_out_previous_risk_insurance: null, // 'no'
  client_citizen_or_pr: null, // 'no'
  client_student_or_work: null, // 'no'
  client_work_visa_greater_two_years: null, // 'no'
  client_three_months_left_visa: null, // 'no'
  client_twelve_months_left_visa: null,
  client_applying_permanent_residency: null, // 'no'
  client_NZ_sole_country_residence: null, // 'no'
  client_plan_leaving_NZ_in_five_years: null, // 'no'
  client_state_vested_interest_in_NZ: '',

  // TAX SPLITTING
  partner_date_of_birth: null,
  partner_address: null,
  partner_marital_status: null,
  partner_mobile_number: null,
  partner_email_address: '',
  partner_smoking_status: null, // 'no'
  partner_insurance_providers: [],
  partner_custom_insurance_providers: [],
  partner_has_will_in_place: null, // 'no'
  partner_wills_reflect_situation: null, // 'no'
  partner_has_guardianship_of_children: null, // 'no'
  partner_has_attorney: null, // 'no'
  partner_passive_income: null, // 'no'
  partner_passive_amount: null,
  partner_country_birth: null,
  partner_have_trust: null,
  partner_medical_usual_general_practitioner: null,
  partner_medical_name_general_practitioner_medical_center: null,
  partner_medical_general_practitioner_address: null,
  partner_have_been_to_doctor: null, // 'no'
  partner_have_been_to_doctor_conditions: null,
  partner_have_any_hazardous_activity: null, // 'no'
  partner_hazardous_activity: null,
  partner_on_any_prescription_medicine: {},
  partner_on_any_prescription_medicine_conditions: {},
  partner_pregnancy_details: {},
  partner_family_history: {},
  partner_has_increased_height_and_weight: null, // 'no'
  partner_body_mass_index: {},
  partner_smoked_in_last_twelve_months: null, // 'no'
  partner_smoking_when_took_out_previous_risk_insurance: null,
  partner_citizen_or_pr: null, // 'no'
  partner_student_or_work: null, // 'no'
  partner_work_visa_greater_two_years: null, // 'no'
  partner_three_months_left_visa: null, // 'no'
  partner_twelve_months_left_visa: null,
  partner_applying_permanent_residency: null, // 'no'
  partner_NZ_sole_country_residence: null, // 'no'
  partner_plan_leaving_NZ_in_five_years: null, // 'no'
  partner_state_vested_interest_in_NZ: '',


  have_childrens: null, // 'no'
  household_savings: null,
  living_expenses: null,
  household_expenses: [],
  household_building_expense: null, // 'rental-payments'
  mortgage_repayments: null,
  mortgage_repayments_type: null, // 'monthly'
  mortgage_bank_or_provider: null,
  mortgage_amount_owing: null,
  has_any_mortgage: null,
  mortgages: [],
  total_debts: null,
  notes: null,
  estate_notes: null,
  assets_notes: null,

  income_protection_covers_with_other_insurance_provider: null,
  passive_income_from_business: null,
  passive_income_from_rentals: null,
  other_passive_income: null,

  client_tax_issues_insurance_provider: null,
  partner_tax_issues_insurance_provider: null,

  fatal_entitlement_for_type: 'client',
  fatal_entitlement_category_type: null,
  fatal_entitlement_annual_pre_aggreed_cover_amount: null,
  fatal_entitlement_childrens: [],

  letter_of_authority_scopes: [],
  scope_services: [],
  signatures: [],
});

export { initialState };

export default initialState;
