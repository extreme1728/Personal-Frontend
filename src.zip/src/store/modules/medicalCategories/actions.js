import { HTTP_API } from 'src/services/http/http';

// eslint-disable-next-line
export const requestMedicalCategories = async ({ commit }) => {
  const { data } = await HTTP_API().get('/medical/categories');
  commit('ASSIGN_MEDICAL_CATEGORIES', data);
  return data;
};
