import { filter } from 'lodash';

export const medicals = ({ data }) => filter(data, ['category', 'medical']);

export const familials = ({ data }) => filter(data, ['category', 'familial']);
