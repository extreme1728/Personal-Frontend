import { set, get } from 'lodash';

// eslint-disable-next-line
export const ASSIGN_MEDICAL_CATEGORIES = (state, payload) => {
  set(state, 'data', get(payload, 'data', payload));
};
