import PaperService from 'src/services/ipp/paper/Service';

export const getDocumentServiceOptions = ({ html2PdfService }) => html2PdfService.opts;

export const getSelectedSections = ({ recommendations: { selectedSections } }) => selectedSections;

export const getDocumentWrapperStyle = ({
  html2PdfService: { opts: { jsPDF } },
}) => PaperService.build(jsPDF);
