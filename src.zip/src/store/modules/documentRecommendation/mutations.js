import { assign, set, merge } from 'lodash';

export const DOCUMENT_RECOMMENDATION_ASSIGN = (state, payload) =>
  assign(state, payload);

export const DOCUMENT_RECOMMENDATION_UPDATE = (state, { field, value }) =>
  set(state, field, value);

export const DOCUMENT_RECOMMENDATION_MERGE = (state, payload) =>
  merge(state.html2PdfService.opts, payload);
