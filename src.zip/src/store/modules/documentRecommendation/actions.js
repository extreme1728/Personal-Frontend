import { clone, eq, isEmpty } from 'lodash';
import * as recommendationSections from 'src/config/recommendationSections';

// eslint-disable-next-line
export const setRecommendationSelection = ({ commit }, payload) => commit('DOCUMENT_RECOMMENDATION_UPDATE', {
  value: clone(payload),
  field: ['recommendations', 'selectedSections'],
});

export const resetRecommendationSelections = ({ dispatch }) => {
  const sections = [
    ...recommendationSections.commonDocumentSections,
    ...recommendationSections.statementDocumentSections,
    ...recommendationSections.policyDocumentSections,
    ...recommendationSections.sovereignDocumentSections,
    ...recommendationSections.aiaDocumentSections,
    ...recommendationSections.partnersDocumentSections,
    ...recommendationSections.fidelityDocumentSections,
  ];
  return dispatch('setRecommendationSelection', sections.map(({ value }) => value));
};

export const setSelectionsForInsurancePlanner = ({ dispatch, rootState }, { type }) => {
  let sections = [
    ...recommendationSections.clientCalculatorOptions,
    ...recommendationSections.partnerCalculatorOptions,
  ];

  const { query } = rootState.route;

  const determinedType = !isEmpty(query) ? query.type : type;

  if (determinedType && eq(determinedType, 'insurance_planner')) {
    const excludedGraphicSection = ['item-recommendations', 'item-recommendations-loyalty-savings'];
    sections = [
      ...sections,
      ...recommendationSections
        .commonDocumentSections
        .filter(({ value }) => !excludedGraphicSection.includes(value)),
    ];
  }
  else {
    sections = [
      ...sections,
      ...[recommendationSections.itemDocumentSections[0]],
      ...recommendationSections.commonDocumentSections,
      ...recommendationSections.statementDocumentSections,
      ...recommendationSections.policyDocumentSections,
      ...recommendationSections.sovereignDocumentSections,
      ...recommendationSections.aiaDocumentSections,
      ...recommendationSections.partnersDocumentSections,
      ...recommendationSections.fidelityDocumentSections,
    ];
  }

  const payload = sections.map(({ value }) => value);

  return dispatch('setRecommendationSelection', payload);
};
