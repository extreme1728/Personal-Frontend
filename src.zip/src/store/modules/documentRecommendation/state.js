// import { dom } from 'quasar';

// const dpi = dom.height(document.getElementById('__dpi')) || 96;

export default {
  recommendations: {
    selectedSections: [],
  },
  html2PdfService: {
    opts: {
      filename: null,
      margin: [0.5, 0.5, 0.5, 0.5],
      jsPDF: {
        unit: 'in',
        format: 'A4',
        orientation: 'portrait',
      },
      html2canvas: {
        scale: window.devicePixelRatio || 1,
        useCORS: true,
        logging: true,
        profile: true,
        allowTaint: true,
        letterRendering: true,
      },
    },
  },
};
