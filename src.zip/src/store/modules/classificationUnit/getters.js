import { map, isEmpty, toString, get } from 'lodash';

export const mapClassificationUnitValues = ({ data }) => {
  const items = map(data, v => { // eslint-disable-line
    let activities = [];
    if (v.activities) {
      activities = map(v.activities, z => ({ label: z.name, value: v.code, bic_code: z.bic_code }));
    }
    // eslint-disable-next-line
    return { label: v.name, value: v.code, bic_code: v.bic_code, activities };
  });

  const flatten = (arr) => { // eslint-disable-line
    return arr ? arr.reduce((result, item) => [
      ...result,
      {
        label: item.label,
        value: item.value,
        bic_code: get(item, 'bic_code', []),
        sublabel: toString(item.value),
      },
      ...flatten(item.activities),
    ], []) : [];
  };

  return flatten(items);
};

export const isClasificationUnitValuesEmpty = ({ data }) => isEmpty(data);
