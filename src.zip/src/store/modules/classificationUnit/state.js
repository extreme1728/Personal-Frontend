const initialState = () => ({
  data: [],
});

export { initialState };

export default initialState;
