import { HTTP_API } from 'src/services/http/http';

// eslint-disable-next-line
export const requestClassificationUnits = ({ commit }) =>
  HTTP_API().get('/classification/unit/curate', {
    params: {
      activities: true,
    },
  })
    .then(({ data }) => {
      commit('SAVE_DATA', data);
      return data;
    });
