const initialState = () => ({
  shouldUseServerCalculation: true,
  calculations: {
    cover_plus: {},
    cover_plus_extra: {},
    cover_plus_extra_on_tools: {},
    cover_plus_extra_existing: {},
  },
});

export default initialState;
