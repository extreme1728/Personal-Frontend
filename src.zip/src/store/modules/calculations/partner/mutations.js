/*
export const someMutation = (state) => {}
 */
