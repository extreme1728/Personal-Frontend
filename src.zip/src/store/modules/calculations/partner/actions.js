import { merge, isEmpty, get, toString } from 'lodash';
import LevyCalculationService from 'src/services/ipp/levy/LevyCalculationService';

/**
 * Constant defining store namespace module.
 *
 * @type {String}
 */
const PLANNER_NAMESPACE = 'planner';
const PLANNER_COLLECTION_NAMESPACE = 'plannerCollection';

export const requestLevyCalculationOnTools = async ({ dispatch, commit, getters }) => {
  const classificationUnit = get(getters, 'getSelectedClassificationunitOnTools');
  if (isEmpty(classificationUnit) || getters.isAlreadyOnAccCoverPlusExtra) return Promise.resolve();
  const options = {
    income: getters.getDeterminedIncomeAmount,
    cover: getters.getDeterminedNominatedAmount,
    cuccode: get(classificationUnit, 'code', null),
  };
  const service = new LevyCalculationService(options);
  const responseValues = await service.requestCalculations();
  let payload = {
    id: 0,
    planner_id: 0,
    type: 'partner',
    property: 'on_tools',
    values: responseValues,
    coverplus_cover: service.hydrateValues('coverplus_cover'),
    coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
  };
  const calculationFromServer = getters.getAccLevyCalculationOnToolsFromServer;
  if (!isEmpty(calculationFromServer)) {
    const { id, planner_id: planner } = calculationFromServer;
    payload = merge(payload, { id, planner_id: planner });
  }
  const reponse = await dispatch(`${PLANNER_NAMESPACE}/persistAccLevyCalculation`, payload, { root: true });
  commit(`${PLANNER_NAMESPACE}/ASSIGN_PLANNER`, reponse, { root: true });
  commit(`${PLANNER_COLLECTION_NAMESPACE}/ADD_PLANNER_COLLECTION`, reponse, { root: true });
  return Promise.resolve(reponse);
};

// eslint-disable-next-line
export const requestLevyCalculationExisting = async ({ commit, dispatch, getters, rootState, rootGetters }) => {
  const cover = get(rootState, [PLANNER_NAMESPACE, 'partner_existing_nominated_cover_amount'], 0);
  // We are getting the current (plan) classification unit from the client
  const isClientEmployed = get(rootGetters, `${PLANNER_NAMESPACE}/isEmployed`, false);
  const classificationUnit = isClientEmployed
    ? get(getters, 'getSelectedClassificationUnit')
    : get(getters, 'getClientSelectedClassificationUnit');
  if (isEmpty(toString(cover))
    || isEmpty(classificationUnit)
    || !getters.isAlreadyOnAccCoverPlusExtra) return Promise.resolve();
  const options = {
    cover,
    income: getters.getDeterminedIncomeAmount,
    cuccode: get(classificationUnit, 'code', 0),
  };
  const service = new LevyCalculationService(options);
  const responseValues = await service.requestCalculations();
  let payload = {
    id: 0,
    planner_id: 0,
    type: 'partner',
    property: 'existing',
    values: responseValues,
    coverplus_cover: service.hydrateValues('coverplus_cover'),
    coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
  };
  const calculationFromServer = getters.getAccLevyCalculationExistingFromServer;
  if (!isEmpty(calculationFromServer)) {
    const { id, planner_id: planner } = calculationFromServer;
    payload = merge(payload, { id, planner_id: planner });
  }
  const reponse = await dispatch(`${PLANNER_NAMESPACE}/persistAccLevyCalculation`, payload, { root: true });
  commit(`${PLANNER_NAMESPACE}/ASSIGN_PLANNER`, reponse, { root: true });
  commit(`${PLANNER_COLLECTION_NAMESPACE}/ADD_PLANNER_COLLECTION`, reponse, { root: true });
  return Promise.resolve(reponse);
};

// eslint-disable-next-line object-curly-newline
export const requestLevyCalculationPlan = async ({ dispatch, commit, getters }) => {
  const classificationUnit = get(getters, 'getSelectedClassificationUnit');
  const cover = getters.getDeterminedNominatedAmount;
  const income = getters.getDeterminedIncomeAmount;
  if (isEmpty(classificationUnit)
    || isEmpty(toString(cover))
    || isEmpty(toString(income))) return Promise.resolve();
  const options = {
    cover,
    income,
    cuccode: get(classificationUnit, 'code', null),
  };
  const service = new LevyCalculationService(options);
  const responseValues = await service.requestCalculations();
  let payload = {
    id: 0,
    planner_id: 0,
    type: 'partner',
    property: 'plan',
    values: responseValues,
    coverplus_cover: service.hydrateValues('coverplus_cover'),
    coverplus_extra_standard: service.hydrateValues('coverplus_extra_standard'),
  };
  const calculationFromServer = getters.getAccLevyCalculationPlanFromServer;
  if (!isEmpty(calculationFromServer)) {
    const { id, planner_id: planner } = calculationFromServer;
    payload = merge(payload, { id, planner_id: planner });
  }
  const reponse = await dispatch(`${PLANNER_NAMESPACE}/persistAccLevyCalculation`, payload, { root: true });
  commit(`${PLANNER_NAMESPACE}/ASSIGN_PLANNER`, reponse, { root: true });
  commit(`${PLANNER_COLLECTION_NAMESPACE}/ADD_PLANNER_COLLECTION`, reponse, { root: true });
  return Promise.resolve(reponse);
};

export const requestAllLevyCalculations = ({ dispatch }) =>
  Promise.all([
    dispatch('requestLevyCalculationPlan'),
    dispatch('requestLevyCalculationOnTools'),
    dispatch('requestLevyCalculationExisting'),
  ]);
