import { get, isEmpty, eq, find } from 'lodash';
import TaxService from 'src/services/aos/tax/TaxService';
import AccOffsetService from 'src/services/aos/offset/AccOffset';
import { floatFixer, floatDiff, getPercentageValue } from 'src/config/utils';
// import CoverPlusService from 'src/services/aos/levy/CoverPlusService';
// import CoverPlusExtraService from 'src/services/aos/levy/CoverPlusExtraService';

/**
 * Constants defining store module namespace.
 *
 * @type {String}
 */
const PLANNER_NAMESPACE = 'planner';
const LIABILITY_RATES_NAMESPACE = 'liabilityRates';
const CLIENT_CALCULATIONS_NAMESPACE = 'clientCalculations';

export const calculationPreferences = (state, getters, rootState, rootGetters) =>
  get(rootGetters[`${PLANNER_NAMESPACE}/preferences`], 'calculations.partner', {});

export const getAccLevyCalculationExistingFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('partner', 'existing');

export const getAccLevyCalculationOnToolsFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('partner', 'on_tools');

export const getAccLevyCalculationPlanFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('partner', 'plan');

export const getDeterminedIncomeAmount = (state, getters, rootState, rootGetters) =>
  floatFixer(rootGetters[`${PLANNER_NAMESPACE}/partnerGrossIncome`]);

export const getDeterminedNominatedAmount = (state, getters, rootState, rootGetters) =>
  floatFixer(rootGetters[`${PLANNER_NAMESPACE}/determinePartnerNominatedCoverAmount`]);

// eslint-disable-next-line
export const getFatalEntitlementCalculations = (state, { getDeterminedIncomeAmount }, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/calculateFatalEntitlements`](getDeterminedIncomeAmount);

// eslint-disable-next-line
export const getAccOffsetCalculation = (state, { getDeterminedIncomeAmount }, rootState, rootGetters) =>
  (new AccOffsetService())
    .setOffsetRates(rootGetters[`${LIABILITY_RATES_NAMESPACE}/offsets`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getNetIncomeTaxCalculation = (state, { getDeterminedIncomeAmount }, { planner: { partner_tax_issues_insurance_provider } }, rootGetters) =>
  (new TaxService())
    .setIsUsingIndemnityAmount()
    .setInsuranceProvider(partner_tax_issues_insurance_provider)
    .setTaxRateLevels(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateLevels`])
    .setTaxRateIncome(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateIncome`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getNetIncomeTaxCalculationForCalculator = (state, { getDeterminedIncomeAmount }, { planner: { partner_tax_issues_insurance_provider } }, rootGetters) =>
  (new TaxService())
    .setInsuranceProvider(partner_tax_issues_insurance_provider)
    .setTaxRateLevels(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateLevels`])
    .setTaxRateIncome(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateIncome`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getPigSavingsPercentage = (state, { getCoverPlusCalculationTotalAmountPayableToAcc, getDeterminedCoverPlusExtraCalculation }) =>
  getPercentageValue(
    getCoverPlusCalculationTotalAmountPayableToAcc,
    get(getDeterminedCoverPlusExtraCalculation, 'totalAmountPayableToAccIncludingGst', 0),
  );

// eslint-disable-next-line
export const getPigSavingsAmount = (state, { getCoverPlusCalculation, getDeterminedCoverPlusExtraCalculation }) =>
  floatDiff(
    get(getCoverPlusCalculation, 'totalAmountPayableToAccIncludingGst', 0),
    get(getDeterminedCoverPlusExtraCalculation, 'totalAmountPayableToAccIncludingGst', 0),
  );

// eslint-disable-next-line max-len
export const getSelectedClassificationunitOnTools = (state, getters, { planner, classificationUnit }, rootGetters) => {
  const isClientEmployed = rootGetters[`${PLANNER_NAMESPACE}/isEmployed`];
  const prop = isClientEmployed ? 'what_you_do_in_business' : 'partner_classification_unit';
  return find(classificationUnit.data, ['code', planner[prop]]) || null;
};

export const getClientSelectedClassificationUnit = (state, getters, rootState, rootGetters) =>
  get(rootGetters, `${CLIENT_CALCULATIONS_NAMESPACE}/getSelectedClassificationUnit`, {});

// eslint-disable-next-line
export const getDeterminedCalculationHeaderLabel = (state, { getSelectedClassificationUnit, isTheSameClassificationUnit, getClientSelectedClassificationUnit, getSelectedClassificationunitOnTools, getCoverPlusExtraCalculationOnTools }, rootState, rootGetters) => {

  if (rootGetters[`${PLANNER_NAMESPACE}/isEmployed`]) {
    if (isTheSameClassificationUnit) {
      return get(getSelectedClassificationUnit, 'name', null);
    }
    if (!isTheSameClassificationUnit && !isEmpty(getCoverPlusExtraCalculationOnTools)) {
      return `From ${get(getSelectedClassificationunitOnTools, 'name', null)} to ${get(getSelectedClassificationUnit, 'name', null)}`;
    }
  }


  if (!isTheSameClassificationUnit
    && !isEmpty(getSelectedClassificationUnit)
    && !isEmpty(getClientSelectedClassificationUnit)) {
    return `From ${get(getClientSelectedClassificationUnit, 'name', null)} to ${get(getSelectedClassificationUnit, 'name', null)}`;
  }

  return isEmpty(getClientSelectedClassificationUnit)
    ? get(getSelectedClassificationUnit, 'name', null)
    : get(getClientSelectedClassificationUnit, 'name', null);
};

// eslint-disable-next-line
export const getCoverPlusCalculationTotalAmountPayableToAcc = (state, { getCoverPlusCalculation }) =>
  get(getCoverPlusCalculation, 'totalAmountPayableToAccIncludingGst', 0);

// eslint-disable-next-line
export const getClientCoverPlusCalculation = (state, { calculationPreferences, getClientSelectedClassificationUnit }, rootState, rootGetters) => {
  // Get the client cover plus calculation regardless
  // If the client calculation is already on cover plus extra
  const calculationFromServer = rootGetters[`${CLIENT_CALCULATIONS_NAMESPACE}/getAccLevyCalculationPlanFromServer`];
  const income = rootGetters[`${CLIENT_CALCULATIONS_NAMESPACE}/getDeterminedIncomeAmount`];
  const cover = rootGetters[`${CLIENT_CALCULATIONS_NAMESPACE}/getDeterminedNominatedAmount`];

  if (calculationPreferences.use_calculation_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getClientSelectedClassificationUnit, 'code');
    const { coverplus_cover: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, income)
      && eq(result.rawNominatedCoverAmount, cover)) ? result : null;
  }

  return null;
};

// eslint-disable-next-line
export const showCalculatedLevy = (state, { getCoverPlusCalculation, getDeterminedCoverPlusExtraCalculation }, rootState, rootGetters) => {
  if (rootGetters[`${PLANNER_NAMESPACE}/isPartnerEmployed`]) return false;
  return (!isEmpty(getCoverPlusCalculation) && !isEmpty(getDeterminedCoverPlusExtraCalculation));
};

export const isTheSameClassificationUnit = (state, getters, { planner }) =>
  eq(planner.partner_on_tools, 'yes');

// eslint-disable-next-line
export const getSelectedClassificationUnit = (state, { isTheSameClassificationUnit }, { planner, classificationUnit }, rootGetters) => {
  const isClientEmployed = rootGetters[`${PLANNER_NAMESPACE}/isEmployed`];
  const prop = isTheSameClassificationUnit && !isClientEmployed
    ? 'classification_unit'
    : 'partner_classification_unit';
  const code = planner[prop];
  return find(classificationUnit.data, ['code', code]) || null;
};

export const isAlreadyOnAccCoverPlusExtra = (state, getters, { planner }) =>
  eq(planner.partner_acc_cover_plan_type, 'cover_plus_extra');

// eslint-disable-next-line
export const getExistingCoverPlusExtraCalculation = (state, { getDeterminedIncomeAmount, getSelectedClassificationUnit, isAlreadyOnAccCoverPlusExtra, calculationPreferences, getAccLevyCalculationExistingFromServer }, { planner }, rootGetters) => {
  const { partner_existing_nominated_cover_amount: existingNominatedCoverAmount } = planner;
  const calculationFromServer = getAccLevyCalculationExistingFromServer;
  if (calculationPreferences.use_calculation_existing_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getSelectedClassificationUnit, 'code');
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, floatFixer(existingNominatedCoverAmount)))
      ? result : null;
  }

  return null;

  // const coverPlusExtraService = new CoverPlusExtraService();
  // if (isEmpty(rootGetters)) return null;
  // coverPlusExtraService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // const { partner_existing_nominated_cover_amount: existingNominatedCoverAmount } = planner;

  // // eslint-disable-next-line
  // if (isEmpty(getDeterminedIncomeAmount)
  //   || isEmpty(existingNominatedCoverAmount)) return null;

  // coverPlusExtraService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(existingNominatedCoverAmount);

  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusExtraService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusExtraService.getAll();
};

// eslint-disable-next-line
export const getDeterminedCoverPlusExtraCalculation = (state, { getCoverPlusExtraCalculationOnTools, getCoverPlusExtraCalculation, isTheSameClassificationUnit }, rootState, rootGetters) =>
  isTheSameClassificationUnit
    ? getCoverPlusExtraCalculation
    : getCoverPlusExtraCalculationOnTools;

// eslint-disable-next-line
export const getCoverPlusExtraCalculationOnTools = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationunitOnTools, calculationPreferences, getAccLevyCalculationOnToolsFromServer }) => {
  const classificationUnit = getSelectedClassificationunitOnTools;
  const calculationFromServer = getAccLevyCalculationOnToolsFromServer;
  if (calculationPreferences.use_calculation_on_tools_from_server
    && !isEmpty(calculationFromServer)
    && !isEmpty(classificationUnit)) {
    const code = get(classificationUnit, 'code');
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;
};

// eslint-disable-next-line
export const getCoverPlusExtraCalculation = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationUnit, calculationPreferences, getAccLevyCalculationPlanFromServer }, rootState, rootGetters) => {
  const calculationFromServer = getAccLevyCalculationPlanFromServer;
  if (calculationPreferences.use_calculation_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getSelectedClassificationUnit, 'code');
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;

  // const coverPlusExtraService = new CoverPlusExtraService();
  // coverPlusExtraService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // if (isEmpty(getDeterminedIncomeAmount)
  //   || isEmpty(getDeterminedNominatedAmount)) return null;

  // coverPlusExtraService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(getDeterminedNominatedAmount);

  // // eslint-disable-next-line
  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusExtraService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusExtraService.getAll();
};

// eslint-disable-next-line
export const getCoverPlusCalculation = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationUnit, isAlreadyOnAccCoverPlusExtra, getExistingCoverPlusExtraCalculation, getAccLevyCalculationPlanFromServer, calculationPreferences, isTheSameClassificationUnit, getClientCoverPlusCalculation }, rootState, rootGetters) => {
  // We are ignoring the cover plus calculations
  // since the partner is already on Cover Plus Extra plan
  if (isAlreadyOnAccCoverPlusExtra) return getExistingCoverPlusExtraCalculation;

  // We are going to check if the partner is on tools
  // This means that the classification unit will be
  // The same as the client either the calculation
  const isClientEmployed = rootGetters[`${PLANNER_NAMESPACE}/isEmployed`];
  if (isTheSameClassificationUnit && !isClientEmployed) return getClientCoverPlusCalculation;

  // Unless if the partner is not on tools
  // Resulting that the partner has been
  // Re-coded to another cu code
  const calculationFromServer = getAccLevyCalculationPlanFromServer;
  if (calculationPreferences.use_calculation_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getSelectedClassificationUnit, 'code');
    const { coverplus_cover: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;

  // const coverPlusService = new CoverPlusService();
  // coverPlusService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // if (isEmpty(getDeterminedIncomeAmount) || isEmpty(getDeterminedNominatedAmount)) return null;
  // coverPlusService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(getDeterminedNominatedAmount);

  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusService.getAll();
};

// eslint-disable-next-line
export const getTotalIncomeProtectionAmount = (state, { getCoverPlusCalculation, getDeterminedNominatedAmount }) =>
  floatDiff(
    get(getCoverPlusCalculation, 'nominatedCoverAmount', 0),
    getDeterminedNominatedAmount,
  );
