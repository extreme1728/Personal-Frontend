import { get, eq, find, isEmpty } from 'lodash';
import TaxService from 'src/services/aos/tax/TaxService';
import AccOffsetService from 'src/services/aos/offset/AccOffset';
import PassiveIncomeService from 'src/services/aos/income/PassiveIncome';
import { floatFixer, floatDiff, getPercentageValue } from 'src/config/utils';
// import CoverPlusService from 'src/services/aos/levy/CoverPlusService';
// import CoverPlusExtraService from 'src/services/aos/levy/CoverPlusExtraService';

/**
 * Constants defining store module namespace.
 *
 * @type {String}
 */
const PLANNER_NAMESPACE = 'planner';
const LIABILITY_RATES_NAMESPACE = 'liabilityRates';

export const calculationPreferences = (state, getters, rootState, rootGetters) =>
  get(rootGetters[`${PLANNER_NAMESPACE}/preferences`], 'calculations.client', {});

export const getAccLevyCalculationExistingFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('client', 'existing');

export const getAccLevyCalculationOnToolsFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('client', 'on_tools');

export const getAccLevyCalculationPlanFromServer = (state, getters, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/getAccLevyCalculation`]('client', 'plan');

export const getDeterminedIncomeAmount = (state, getters, rootState, rootGetters) =>
  floatFixer(rootGetters[`${PLANNER_NAMESPACE}/clientGrossIncome`]);

export const getDeterminedNominatedAmount = (state, getters, rootState, rootGetters) =>
  floatFixer(rootGetters[`${PLANNER_NAMESPACE}/determineNominatedCoverAmount`]);

// eslint-disable-next-line
export const getPassiveIncomeCalculation = (state, { getDeterminedIncomeAmount }, { planner }, rootGetters) =>
  (new PassiveIncomeService())
    .setOffsetRates(rootGetters[`${LIABILITY_RATES_NAMESPACE}/offsets`])
    .setTaxRateIncome(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateIncome`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .setArrayOfPassiveIncomes([
      planner.income_protection_covers_with_other_insurance_provider,
      planner.passive_income_from_business,
      planner.passive_income_from_rentals,
      planner.other_passive_income,
    ])
    .getAll();

// eslint-disable-next-line
export const getFatalEntitlementCalculations = (state, { getDeterminedIncomeAmount }, rootState, rootGetters) =>
  rootGetters[`${PLANNER_NAMESPACE}/calculateFatalEntitlements`](getDeterminedIncomeAmount);

// eslint-disable-next-line
export const getNetIncomeTaxCalculation = (state, { getDeterminedIncomeAmount }, { planner }, rootGetters) =>
  (new TaxService())
    .setIsUsingIndemnityAmount()
    .setInsuranceProvider(planner.client_tax_issues_insurance_provider)
    .setTaxRateLevels(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateLevels`])
    .setTaxRateIncome(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateIncome`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getNetIncomeTaxCalculationForCalculator = (state, { getDeterminedIncomeAmount }, { planner}, rootGetters) =>
  (new TaxService())
    .setInsuranceProvider(planner.client_tax_issues_insurance_provider)
    .setTaxRateLevels(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateLevels`])
    .setTaxRateIncome(rootGetters[`${LIABILITY_RATES_NAMESPACE}/taxRateIncome`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getAccOffsetCalculation = (state, { getDeterminedIncomeAmount }, rootState, rootGetters) =>
  (new AccOffsetService())
    .setOffsetRates(rootGetters[`${LIABILITY_RATES_NAMESPACE}/offsets`])
    .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
    .getAll();

// eslint-disable-next-line
export const getDeterminedCalculationHeaderLabel = (state, { getSelectedClassificationunitOnTools, getSelectedClassificationUnit, isTheSameClassificationUnit }) => {
  if (!isTheSameClassificationUnit
    && !isEmpty(getSelectedClassificationUnit)
    && !isEmpty(getSelectedClassificationunitOnTools)) {
    return `From ${get(getSelectedClassificationUnit, 'name')} to ${get(getSelectedClassificationunitOnTools, 'name')}`;
  }
  return get(getSelectedClassificationUnit, 'name');
};

// eslint-disable-next-line
export const getPigSavingsPercentage = (state, { getCoverPlusCalculation, getDeterminedCoverPlusExtraCalculation }) =>
  getPercentageValue(
    get(getCoverPlusCalculation, 'totalAmountPayableToAccIncludingGst', 0),
    get(getDeterminedCoverPlusExtraCalculation, 'totalAmountPayableToAccIncludingGst', 0),
  );

// eslint-disable-next-line
export const getPigSavingsAmount = (state, { getCoverPlusCalculation, getDeterminedCoverPlusExtraCalculation }) =>
  floatDiff(
    get(getCoverPlusCalculation, 'totalAmountPayableToAccIncludingGst', 0),
    get(getDeterminedCoverPlusExtraCalculation, 'totalAmountPayableToAccIncludingGst', 0),
  );

// eslint-disable-next-line
export const getDeterminedCoverPlusExtraCalculation = (state, { getCoverPlusExtraCalculationOnTools, getCoverPlusExtraCalculation, isTheSameClassificationUnit }) =>
  isTheSameClassificationUnit
    ? getCoverPlusExtraCalculation
    : getCoverPlusExtraCalculationOnTools;

// eslint-disable-next-line
export const showCalculatedLevy = (state, { getCoverPlusCalculation, getDeterminedCoverPlusExtraCalculation }, rootState, rootGetters) => {
  if (rootGetters[`${PLANNER_NAMESPACE}/isEmployed`]) return false;
  return (!isEmpty(getCoverPlusCalculation) && !isEmpty(getDeterminedCoverPlusExtraCalculation));
};

// eslint-disable-next-line
export const getSelectedClassificationunitOnTools = (state, getters, { planner, classificationUnit }) =>
  find(get(classificationUnit, 'data', []), ['code', planner.what_you_do_in_business]) || null;

export const isTheSameClassificationUnit = (state, getters, { planner }) =>
  eq(planner.on_tools, 'yes');

// eslint-disable-next-line
export const getCoverPlusExtraCalculationOnTools = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationunitOnTools, calculationPreferences, getAccLevyCalculationOnToolsFromServer }) => {
  const classificationUnit = getSelectedClassificationunitOnTools;
  const calculationFromServer = getAccLevyCalculationOnToolsFromServer;
  if (calculationPreferences.use_calculation_on_tools_from_server
    && !isEmpty(calculationFromServer)
    && !isEmpty(classificationUnit)) {
    const code = get(classificationUnit, 'code');
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;

  // return (new CoverPlusExtraService())
  //   .setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`])
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(getDeterminedNominatedAmount)
  //   .setClassificationUnit(getSelectedClassificationunitOnTools)
  //   .getAll();
};

export const getSelectedClassificationUnit = (state, getters, { classificationUnit, planner }) =>
  find(get(classificationUnit, 'data', []), ['code', planner.classification_unit]) || null;

export const isAlreadyOnAccCoverPlusExtra = (state, getters, { planner }) =>
  eq(planner.acc_cover_plan_type, 'cover_plus_extra');

// eslint-disable-next-line
export const getExistingCoverPlusExtraCalculation = (state, { getDeterminedIncomeAmount, getSelectedClassificationUnit, isAlreadyOnAccCoverPlusExtra, calculationPreferences, getAccLevyCalculationExistingFromServer }, { planner }, rootGetters) => {
  if (!isAlreadyOnAccCoverPlusExtra) return null;
  const { existing_nominated_cover_amount: existingNominatedCoverAmount } = planner;

  const calculationFromServer = getAccLevyCalculationExistingFromServer;
  if (calculationPreferences.use_calculation_existing_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const { code } = getSelectedClassificationUnit;
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, floatFixer(existingNominatedCoverAmount)))
      ? result : null;
  }

  return null;

  // const coverPlusExtraService = new CoverPlusExtraService();
  // coverPlusExtraService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // // eslint-disable-next-line
  // if (isEmpty(getDeterminedIncomeAmount)
  //   || isEmpty(existingNominatedCoverAmount)) return null;

  // coverPlusExtraService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(existingNominatedCoverAmount);

  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusExtraService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusExtraService.getAll();
};

// eslint-disable-next-line
export const getCoverPlusExtraCalculation = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationUnit, calculationPreferences, getAccLevyCalculationPlanFromServer }, rootState, rootGetters) => {
  const calculationFromServer = getAccLevyCalculationPlanFromServer;
  if (calculationPreferences.use_calculation_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getSelectedClassificationUnit, 'code');
    const { coverplus_extra_standard: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;

  // const coverPlusExtraService = new CoverPlusExtraService();
  // coverPlusExtraService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // // eslint-disable-next-line
  // if (isEmpty(getDeterminedIncomeAmount)
  //   || isEmpty(getDeterminedNominatedAmount)) return null;

  // coverPlusExtraService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(getDeterminedNominatedAmount);

  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusExtraService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusExtraService.getAll();
};

// eslint-disable-next-line
export const getCoverPlusCalculation = (state, { getDeterminedIncomeAmount, getDeterminedNominatedAmount, getSelectedClassificationUnit, getExistingCoverPlusExtraCalculation, isAlreadyOnAccCoverPlusExtra, calculationPreferences, getAccLevyCalculationPlanFromServer }, rootState, rootGetters) => {
  // We are ignoring the cover plus calculations
  // since the client is already on Cover Plus Extra plan
  if (isAlreadyOnAccCoverPlusExtra) return getExistingCoverPlusExtraCalculation;

  const calculationFromServer = getAccLevyCalculationPlanFromServer;
  if (calculationPreferences.use_calculation_plan_from_server
    && !isEmpty(calculationFromServer)) {
    const code = get(getSelectedClassificationUnit, 'code');
    const { coverplus_cover: result } = calculationFromServer;
    return (eq(result.classificationUnitCode, code)
      && eq(result.currentIncomeFromBusiness, getDeterminedIncomeAmount)
      && eq(result.rawNominatedCoverAmount, getDeterminedNominatedAmount)) ? result : null;
  }

  return null;

  // const coverPlusService = new CoverPlusService();
  // coverPlusService.setRateValues(rootGetters[`${LIABILITY_RATES_NAMESPACE}/rateValues`]);

  // // eslint-disable-next-line
  // if (isEmpty(getDeterminedIncomeAmount)
  //   || isEmpty(getDeterminedNominatedAmount)) return null;

  // coverPlusService
  //   .setCurrentIncomeFromBusiness(getDeterminedIncomeAmount)
  //   .setNominatedCoverAmount(getDeterminedNominatedAmount);

  // if (isEmpty(getSelectedClassificationUnit)) return null;
  // coverPlusService.setClassificationUnit(getSelectedClassificationUnit);

  // return coverPlusService.getAll();
};

// eslint-disable-next-line
export const getTotalIncomeProtectionAmount = (state, { getDeterminedNominatedAmount, getCoverPlusCalculation }) =>
  floatDiff(
    get(getCoverPlusCalculation, 'nominatedCoverAmount', 0),
    getDeterminedNominatedAmount,
  );
