import { set } from 'lodash';

// eslint-disable-next-line
export const CLIENT_CALCULATIONS_UPDATE_FIELD = (state, { value, field }) =>
  set(state, field, value);
