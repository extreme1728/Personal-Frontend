import { HTTP_API } from 'src/services/http/http';

// eslint-disable-next-line
export const requestInsuranceProviderCoverTypeComments = ({ commit }) =>
  HTTP_API().get('insurance/cover/types/comments')
    .then(({ data }) => {
      commit('ASSIGN_COVER_TYPE_COMMENTS', data);
      return data;
    });
