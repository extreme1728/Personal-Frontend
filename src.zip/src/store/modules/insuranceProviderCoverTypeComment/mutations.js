import { assign } from 'lodash';

// eslint-disable-next-line
export const ASSIGN_COVER_TYPE_COMMENTS = (state, payload) =>
  assign(state, payload);
