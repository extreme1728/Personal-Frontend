// eslint-disable-next-line
export const comments = ({ data }) => data;
