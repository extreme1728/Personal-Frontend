export default () => ({
  data: [],
});
