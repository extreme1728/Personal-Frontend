// eslint-disable-next-line
export const activities = ({ data }) => data;
