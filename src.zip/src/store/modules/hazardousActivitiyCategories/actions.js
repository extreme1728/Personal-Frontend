import { HTTP_API } from 'src/services/http/http';

// eslint-disable-next-line
export const requestHazardousActivityCategories = async ({ commit }) => {
  const { data } = await HTTP_API().get('/hazardous/activities/categories');
  commit('ASSIGN_HAZARDOUS_ACTIVITY_CATEGORIES', data);
  return data;
};
