import { set, get } from 'lodash';

// eslint-disable-next-line
export const ASSIGN_HAZARDOUS_ACTIVITY_CATEGORIES = (state, payload) => {
  set(state, 'data', get(payload, 'data', payload));
};
