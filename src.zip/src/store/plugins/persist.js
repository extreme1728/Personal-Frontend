import VuexPersistence from 'vuex-persist';

export const KEY = '@ipp';

export default new VuexPersistence({
  key: KEY,
  storage: window.localStorage,
  supportCircular: true,
  modules: [
    'user',
    'site',
    'planner',
    'limitedAdivce',
    'insuranceProvider',
    'medicalCategories',
    'classificationUnit',
    'documentRecommendation',
    'insuranceProviderReport',
    'insuranceProviderNoteReport',
    'hazardousActivitiyCategories',
  ],
});
