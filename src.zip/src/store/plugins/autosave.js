import { Notify, Platform } from 'quasar';
import { noop } from 'lodash';

/** @type {Boolean} determines if the browser is online. */
const isOnline = window.navigator.onLine;

/**
 * Notifier helper.
 *
 * @param  {Object}  opts
 * @param  {Boolean} error
 * @return void
 */
const ShowMessage = (opts = {}, error = false) =>
  Notify.create({
    message: opts.message || 'Saved',
    color: error ? 'negative' : 'amber',
    icon: opts.icon || 'save',
    position: opts.position || Platform.is.mobile ? 'top' : 'top-right',
    timeout: opts.timeout || 1000,
  });

/**
 * Persist to backend and save to collection.
 *
 * @param  {Object} Vuex store instance
 * @param  {Object} planner
 * @param  {Object} payload from mutation object
 * @return {Object} Response Payload
 */
async function persistPlanner(store, planner, { payload: mutationPayload }) {
  const data = await store.dispatch('planner/persistPlanner', { planner, mutationPayload });
  await store.commit('plannerCollection/ADD_PLANNER_COLLECTION', data);
  return data;
}

export default (store) => {
  store.subscribe((mutation, { planner }) => {
    switch (mutation.type) {
      case 'planner/UPDATE_PLAN_FIELD_VALUE':
        if (planner.id && isOnline) {
          try { persistPlanner(store, planner, mutation).then(ShowMessage()); }
          catch (e) {
            ShowMessage({
              message: 'Auto Save Failed',
              icon: 'error',
            }, true);
          }
        }
        break;
      default: noop();
    }
  });
};
