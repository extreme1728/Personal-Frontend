<template lang="pug">
div(class="document-graphics-container")
  div(class="row justify-center q-mt-md" v-if="hasClientIncome")
    div(class="col-md-6")
      with(
        v-if="passiveIncomeCalculation.totalPassiveIncome"
        :amount="passiveIncomeCalculation.totalPassiveIncome"
        :w="400"
        :h="400"
      )
      without(
        v-else
        :w="400"
        :h="400"
      )
    div(class="col-md-6")
      potential-savings(
        :chart-data="getIncomeProtectionPassiveIncomeChartData"
        :options="getChartDataOptions"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import ChartColors from 'src/config/chart-colors';
import { With, Without } from 'src/components/charts/Incomes';
import PotentialSavings from 'src/components/charts/PotentialSavings';
import { FieldableMixin, ChartDataMixin, SvgToCanvasMixin } from 'src/mixins';

export default {
  mixins: [FieldableMixin, ChartDataMixin, SvgToCanvasMixin],
  mounted() {
    this.$nextTick(() => {
      this.svgToCanvas();
    });
  },
  computed: {
    ...mapGetters('clientCalculations', {
      passiveIncomeCalculation: 'getPassiveIncomeCalculation',
    }),
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
    }),
    getIncomeProtectionPassiveIncomeChartData() {
      if (this.hasClientIncome) {
        const {
          totalPassiveIncome,
          incomeProtectionIndemnityAmount,
          incomeProtectionAgreedAmount,
          maximumMonthlyMortgageRepaymentCover,
        } = this.passiveIncomeCalculation;
        if (!totalPassiveIncome) {
          return {
            labels: ['IP Indemnity', 'IP Agreed', 'MMR'],
            datasets: [
              {
                borderWidth: 2,
                backgroundColor: ChartColors.orange,
                borderColor: ChartColors.orange,
                hoverBackgroundColor: ChartColors.orangeLight,
                hoverBorderColor: ChartColors.orange,
                label: 'Income Protection covers without passive income',
                data: [
                  incomeProtectionIndemnityAmount,
                  incomeProtectionAgreedAmount,
                  maximumMonthlyMortgageRepaymentCover,
                ],
              },
            ],
          };
        }
        return {
          labels: ['Passive Income', 'IP Indemnity', 'IP Agreed', 'MMR'],
          datasets: [
            {
              borderWidth: 2,
              backgroundColor: ChartColors.yellow,
              borderColor: ChartColors.yellow,
              hoverBackgroundColor: ChartColors.yellowLight,
              hoverBorderColor: ChartColors.yellow,
              label: 'Income Protection covers with passive income',
              data: [
                -Math.abs(totalPassiveIncome),
                incomeProtectionIndemnityAmount,
                incomeProtectionAgreedAmount,
                maximumMonthlyMortgageRepaymentCover,
              ],
            },
          ],
        };
      }
    },
  },
  components: {
    With,
    Without,
    PotentialSavings,
  },
};
</script>
