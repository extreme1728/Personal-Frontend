<template lang="pug">
div(class="document-preview-wrapper")
  div(class="document-header-container")
    h4(class="document-header-title" :style="documentHeaderTitleStyle") {{ getClientName }}  Calculations for my Recommended Benefits (s)
  div(class="document-fields-container document-font-size")
  tpd(
    v-if="selections.includes('client-tpd')"
    readonly
    color="blue-5"
    :current-name="getClientName"
    :payload="getClientCalculatorFields.getTpd"
    :income="plan[getDeterminedIncomeProperty]"
    :youngest-child-age="getChildYoungestAge"
    :age="plan.client_date_of_birth | getAgeByDate"
    :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
  )
  life-cover(
    v-if="selections.includes('client-life-cover')"
    readonly
    color="blue-5"
    :current-name="getClientName"
    :age="plan.client_date_of_birth | getAgeByDate"
    :class="{ 'document__page-break': selections.length != 1 }"
    :payload="getClientCalculatorFields.getLifeCover"
    :income="plan[getDeterminedIncomeProperty]"
    :youngest-child-age="getChildYoungestAge"
    :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
  )
  trauma-cover(
    v-if="selections.includes('client-trauma-cover')"
    readonly
    color="blue-5"
    :current-name="getClientName"
    :age="plan.client_date_of_birth | getAgeByDate"
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :youngest-child-age="getChildYoungestAge"
    :payload="getClientCalculatorFields.getTraumaCover"
  )
  total-and-permanent-disablement(
    v-if="selections.includes('client-total-and-permanent-disablement')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :youngest-child-age="getChildYoungestAge"
    :payload="getClientCalculatorFields.getTotalAndPermanentDisablement"
  )
  income-protection(
    v-if="selections.includes('client-income-protection')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :category="plan.client_tax_issues_insurance_provider"
    :income-protection-agreed-amount="getNetIncomeTaxCalculation.incomeProtectionAgreedAmount"
    :income-protection-indemnity-amount="getNetIncomeTaxCalculation.incomeProtectionIndemnityAmount"
    @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
    @category:change="value => updatePlanField(value, 'client_tax_issues_insurance_provider')"
  )
  mortgage-repayment-income-protection(
    v-if="selections.includes('client-mortgage-repayment-and-income-protection')"
    readonly
    color="blue-5"
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :payload="getClientCalculatorFields.getMortgageRepaymentAndIncomeProtection"
    :mortgage-repayment-amount="getCalculatedMortgageRepayment"
  )
  mortgage-repayment-income-protection-and-house-expense-cover(
    v-if="selections.includes('client-mortgage-repayment-income-protection-and-house-expense-cover')"
    readonly
    color="blue-5"
    :total-household-expense="householdExpenseTotalAmount"
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="clientGrossIncome"
    :payload="getClientCalculatorFields.getMortgageRepaymentIncomeProtectionAndHec"
  )
  health-cover(
    v-if="selections.includes('client-health-cover')"
    readonly
    type="client"
    :current-name="getClientName"
    :payload="getClientCalculatorFields.getHealthCover"
  )
  tax-calculator(
    v-if="selections.includes('client-tax-calculator')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :payload="getClientCalculatorFields.getTax"
    :tax-calculation-result="getNetIncomeTaxCalculationForCalculator"
    @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
  )
</template>

<script>
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { some, startsWith, get } from 'lodash';
import * as CalculatorComponents from 'src/components/ipp/calculators';

export default {
  mixins: [FieldableMixin],
  props: {
    reports: Object,
    colorStyle: Object,
    isDocumentInsurancePlanner: Boolean,
  },
  computed: {
    shouldShowCalculator() {
      return some(this.selections, value => startsWith(value, 'client-'));
    },
    ...mapGetters('documentRecommendation', {
      getSelectedSections: 'getSelectedSections',
    }),
    ...mapGetters('planner', [
      'isEmployed',
      'clientGrossIncome',
      'getChildYoungestAge',
      'getClientCalculatorFields',
      'householdExpenseTotalAmount',
      'getCalculatedMortgageRepayment',
    ]),
    ...mapGetters('clientCalculations', {
      getNetIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
      getFatalEntitlementCalculations: 'getFatalEntitlementCalculations',
      getNetIncomeTaxCalculationForCalculator: 'getNetIncomeTaxCalculationForCalculator',
    }),
    selections() {
      return this.isDocumentInsurancePlanner
        ? get(this.plan, 'selections', [])
        : get(this.reports, 'selections', []);
    },
    getDeterminedIncomeProperty() {
      return this.isEmployed
        ? 'employed_annual_income'
        : 'income_from_business';
    },
  },
  components: {
    ...CalculatorComponents,
  },
};
</script>
<style lang="stylus" scoped>
h4
  color rgb(66, 165, 245)
  border-bottom 2px solid rgb(66, 165, 245)
  font-size 16px
  letter-spacing 0.2rem
  text-transform uppercase
</style>

