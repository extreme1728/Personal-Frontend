<template lang="pug">
div(v-if="showCalculatedLevy")
  div(class="document-graphics-container")
    h4(
      class="text-center"
      v-text="getDeterminedCalculationHeaderLabel"
    )
    div(
      class="row q-col-gutter-md"
      v-if="coverPlusCalculation && coverPlusExtraCalculation"
    )
      div(:class="getDeterminedPigColumnClass")
        pig-bank(
          :total-savings="getPigSavingsAmount"
          :income-difference-amount="getTotalIncomeProtectionAmount"
          :total-cover-plus-levy="coverPlusCalculation.totalAmountPayableToAccIncludingGst"
          :total-cover-plus-extra-levy="getDeterminedCoverPlusExtraCalculation.totalAmountPayableToAccIncludingGst"
          :w="400"
          :h="351"
        )
      div(
        v-if="getPigSavingsPercentage > 0"
        class="col-md-6"
      )
        pig-savings(
          :percentage="getPigSavingsPercentage"
          :w="400"
          :h="351"
        )
    //- div(class="html2pdf__page-break")
    income-levy-calculation-notes(
      v-if="showCalculatedLevy"
      :client-name="plan.client_full_name"
      :income-tax-method="plan.income_tax_method"
      :cover-plus-calculation="coverPlusCalculation"
      :is-already-on-acc-cover-plus-extra="isAlreadyOnAccCoverPlusExtra"
      :cover-plus-extra-calculation="getDeterminedCoverPlusExtraCalculation"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { IncomeLevyCalculationNotes } from 'src/components/ipp';
import { PigBank, PigSavings } from 'src/components/charts/Pigs';

export default {
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    ...mapGetters('clientCalculations', {
      showCalculatedLevy: 'showCalculatedLevy',
      getPigSavingsAmount: 'getPigSavingsAmount',
      coverPlusCalculation: 'getCoverPlusCalculation',
      getPigSavingsPercentage: 'getPigSavingsPercentage',
      coverPlusExtraCalculation: 'getCoverPlusExtraCalculation',
      isAlreadyOnAccCoverPlusExtra: 'isAlreadyOnAccCoverPlusExtra',
      getTotalIncomeProtectionAmount: 'getTotalIncomeProtectionAmount',
      getDeterminedCalculationHeaderLabel: 'getDeterminedCalculationHeaderLabel',
      getDeterminedCoverPlusExtraCalculation: 'getDeterminedCoverPlusExtraCalculation',
    }),
    getDeterminedPigColumnClass() {
      const hasPercentage = this.getPigSavingsPercentage > 0;
      return !hasPercentage ? {
        'col-md-8': true,
        'offset-md-2': true,
      } : { 'col-md-6': true };
    },
  },
  components: {
    PigBank,
    PigSavings,
    IncomeLevyCalculationNotes,
  },
};
</script>
