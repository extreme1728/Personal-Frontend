<template lang="pug">
div(class="document-graphics-container")
  component(
    :is="getFatalEntitlementCalculations.component"
    :cover-plus-amount="getFatalEntitlementCalculations.coverPlusTotalBenifitAmount"
    :cover-plus-extra-amount="getFatalEntitlementCalculations.coverPlusExtraTotalBenifitAmount"
    :changes-in-cover="getFatalEntitlementCalculations.changesInCoverAmount"
    :w="dimensions.width"
    :h="dimensions.height"
  )
</template>

<script>
import { mapGetters } from 'vuex';
import { SvgToCanvasMixin } from 'src/mixins';
import * as Families from 'src/components/charts/Families';

export default {
  mixins: [SvgToCanvasMixin],
  mounted() {
    this.$nextTick(() => {
      // this.svgToCanvas(() => {
      //   console.log('done [partner] fatal entitlements');
      // });
    });
  },
  computed: {
    ...mapGetters('partnerCalculations', {
      getFatalEntitlementCalculations: 'getFatalEntitlementCalculations',
    }),
    dimensions() {
      return { width: '100%', height: 230 };
    },
  },
  components: {
    ...Families,
  },
};
</script>
