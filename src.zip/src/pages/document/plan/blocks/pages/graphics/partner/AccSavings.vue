<template lang="pug">
div(class="document-graphics-container")
  h4(
    class="text-center"
    v-if="currentClassificationUnit"
    v-text="currentClassificationUnit.name"
  )
  div(class="row q-col-gutter-md" v-if="showCalculatedLevy")
    div(:class="getDeterminedPigColumnClass" key="bank")
      pig-bank(
        :total-savings="getPigSavingsAmount"
        :income-difference-amount="getTotalIncomeProtectionAmount"
        :total-cover-plus-levy="getCoverPlusCalculationTotalAmountPayableToAcc"
        :total-cover-plus-extra-levy="getDeterminedCoverPlusExtraCalculation.totalAmountPayableToAccIncludingGst"
        :w="400"
        :h="351"
      )
    div(
      v-if="getPigSavingsPercentage > 0"
      class="col-md-6"
    )
      pig-savings(
        :percentage="getPigSavingsPercentage"
        :w="400"
        :h="351"
      )
  income-levy-calculation-notes(
    v-if="showCalculatedLevy"
    is-partner
    :client-name="plan.partner_name"
    :cover-plus-calculation="getCoverPlusCalculation"
    :income-tax-method="plan.partner_income_tax_method"
    :cover-plus-extra-calculation="getDeterminedCoverPlusExtraCalculation"
    :is-already-on-acc-cover-plus-extra="isAlreadyOnAccCoverPlusExtra"
  )
</template>

<script>
import { mapGetters } from 'vuex';
import { IncomeLevyCalculationNotes } from 'src/components/ipp';
import { PigBank, PigSavings } from 'src/components/charts/Pigs';

export default {
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    ...mapGetters('partnerCalculations', {
      showCalculatedLevy: 'showCalculatedLevy',
      getPigSavingsAmount: 'getPigSavingsAmount',
      getPigSavingsPercentage: 'getPigSavingsPercentage',
      getCoverPlusCalculation: 'getCoverPlusCalculation',
      coverPlusExtraCalculation: 'getCoverPlusExtraCalculation',
      currentClassificationUnit: 'getSelectedClassificationUnit',
      isAlreadyOnAccCoverPlusExtra: 'isAlreadyOnAccCoverPlusExtra',
      getTotalIncomeProtectionAmount: 'getTotalIncomeProtectionAmount',
      getDeterminedCoverPlusExtraCalculation: 'getDeterminedCoverPlusExtraCalculation',
      getCoverPlusCalculationTotalAmountPayableToAcc: 'getCoverPlusCalculationTotalAmountPayableToAcc',
    }),
    getDeterminedPigColumnClass() {
      const hasPercentage = this.getPigSavingsPercentage > 0;
      return !hasPercentage ? {
        'col-md-8': true,
        'offset-md-2': true,
      } : { 'col-md-6': true };
    },
  },
  components: {
    PigBank,
    PigSavings,
    IncomeLevyCalculationNotes,
  },
};
</script>
