<template lang="pug">
  div(v-if="hasClientIncome")
    div(class="document-graphics-container")
      div
        p(class="text-center no-margin-top") In the event of an Accident your total claim experience with:
        h5(class="text-center no-margin") ACC Cover + Income Protection
      div(class="row md-gutter")
        div(class="col-md-4")
          eighty(
            :amount="clientAccOffsetCalculation.maximumAccCoverPlusCover"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") ACC Cover Plus
        div(class="col-md-4")
          empty(
            :amount="0"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") Income Protection
        div(class="col-md-4")
          eighty(
            :amount="clientAccOffsetCalculation.maximumAccCoverPlusCover"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") Total Claim Amount
    div
      p(class="text-center q-mt-md") In the event of an Accident your total claim experience with:
      h5(class="text-center no-margin") ACC Cover + Monthly Mortgage Repayment Cover
    div(class="row md-gutter")
      div(class="col-md-4")
        eighty(
          :amount="clientAccOffsetCalculation.maximumAccCoverPlusCover"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") ACC Cover Plus
      div(class="col-md-4")
        forty(
          :amount="clientAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") Monthly Mortgage Repayment Cover
      div(class="col-md-4")
        one-hundred(
          :amount="clientAccOffsetCalculation.totalClaimAmount"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") Total Claim Amount
    div(class="html2pdf__page-break")
    acc-offsets-notes(
      :client-name="plan.client_full_name"
      :cover-plus-amount="clientAccOffsetCalculation.maximumAccCoverPlusCover"
      :monthly-mortgage-amount="clientAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
      :cover-plus-amount-without-tax="clientAccOffsetCalculation.maximumAccCoverPlusCoverWithoutTax"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { AccOffsetsNotes } from 'src/components/ipp';
import * as PeopleGraphicsComponents from 'src/components/charts/Peoples';

export default {
  computed: {
    ...mapGetters('clientCalculations', {
      clientAccOffsetCalculation: 'getAccOffsetCalculation',
    }),
    ...mapGetters('planner', {
      plan: 'plan',
      hasClientIncome: 'hasClientIncome',
    }),
    dimensions() {
      return { width: '100%', height: 350 };
    },
  },
  components: {
    AccOffsetsNotes,
    ...PeopleGraphicsComponents,
  },
};
</script>
