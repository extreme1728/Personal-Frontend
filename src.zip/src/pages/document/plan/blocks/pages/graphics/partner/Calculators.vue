<template lang="pug">
div
  div(class="document-fields-container document-font-size")
    h4(class="document-header-title" :style="documentHeaderTitleStyle") {{ getPartnerName }} Calculations for my Recommended Benefits (s)
  div(class="document-fields-container document-font-size")
  tpd(
    v-if="selections.includes('partner-tpd')"
    readonly
    color="blue-5"
    :current-name="getPartnerName"
    :payload="getPartnerCalculatorFields.getTpd"
    :income="plan[getDeterminedIncomeProperty]"
    :youngest-child-age="getChildYoungestAge"
    :age="plan.partner_date_of_birth | getAgeByDate"
    :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
  )

  life-cover(
    v-if="selections.includes('partner-life-cover')"
    readonly
    color="blue-5"
    :current-name="getPartnerName"
    :class="{ 'document__page-break': selections.length != 1 }"
    :payload="getPartnerCalculatorFields.getLifeCover"
    :youngest-child-age="getChildYoungestAge"
    :income="plan[getDeterminedIncomeProperty]"
    :age="plan.partner_date_of_birth | getAgeByDate"
    :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
  )

  trauma-cover(
    v-if="selections.includes('partner-trauma-cover')"
    readonly
    color="blue-5"
    :current-name="getPartnerName"
    :class="{ 'document__page-break': selections.length != 1 }"
    :youngest-child-age="getChildYoungestAge"
    :income="plan[getDeterminedIncomeProperty]"
    :age="plan.partner_date_of_birth | getAgeByDate"
    :payload="getPartnerCalculatorFields.getTraumaCover"
  )

  total-and-permanent-disablement(
    v-if="selections.includes('partner-total-and-permanent-disablement')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :youngest-child-age="getChildYoungestAge"
    :payload="getPartnerCalculatorFields.getTotalAndPermanentDisablement"
    :income="plan[getDeterminedIncomeProperty]"
  )

  income-protection(
    v-if="selections.includes('partner-income-protection')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :category="plan.partner_tax_issues_insurance_provider"
    :income-protection-agreed-amount="getNetIncomeTaxCalculation.incomeProtectionAgreedAmount"
    :income-protection-indemnity-amount="getNetIncomeTaxCalculation.incomeProtectionIndemnityAmount"
    @income:change="value => updatePlanField(value, 'partner_taking_from_the_firm')"
    @category:change="value => updatePlanField(value, 'partner_tax_issues_insurance_provider')"
  )

  mortgage-repayment-income-protection(
    v-if="selections.includes('partner-mortgage-repayment-and-income-protection')"
    readonly
    color="blue-5"
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :payload="getPartnerCalculatorFields.getMortgageRepaymentAndIncomeProtection"
    :mortgage-repayment-amount="getCalculatedMortgageRepayment"
  )

  mortgage-repayment-income-protection-and-house-expense-cover(
    v-if="selections.includes('partner-mortgage-repayment-income-protection-and-house-expense-cover')"
    readonly
    color="blue-5"
    :total-household-expense="householdExpenseTotalAmount"
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="partnerGrossIncome"
    :payload="getPartnerCalculatorFields.getMortgageRepaymentIncomeProtectionAndHec"
  )

  health-cover(
    v-if="selections.includes('partner-health-cover')"
    readonly
    type="partner"
    :current-name="getPartnerName"
    :payload="getPartnerCalculatorFields.getHealthCover"
  )

  tax-calculator(
    v-if="selections.includes('partner-tax-calculator')"
    readonly
    :class="{ 'document__page-break': selections.length != 1 }"
    :income="plan[getDeterminedIncomeProperty]"
    :tax-calculation-result="getNetIncomeTaxCalculationForCalculator"
    :payload="getPartnerCalculatorFields.getTax"
    @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
  )
</template>

<script>
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { some, startsWith, get } from 'lodash';
import * as CalculatorComponents from 'src/components/ipp/calculators';

export default {
  name: 'partner-calculators',
  mixins: [FieldableMixin],
  props: {
    reports: Object,
    colorStyle: Object,
    isDocumentInsurancePlanner: Boolean,
  },
  computed: {
    shouldShowCalculator() {
      return some(this.selections, value => startsWith(value, 'partner-'));
    },
    ...mapGetters('documentRecommendation', {
      getSelectedSections: 'getSelectedSections',
    }),
    ...mapGetters('planner', [
      'isPartnerEmployed',
      'partnerGrossIncome',
      'getChildYoungestAge',
      'getPartnerCalculatorFields',
      'householdExpenseTotalAmount',
      'getCalculatedMortgageRepayment',
    ]),
    ...mapGetters('partnerCalculations', {
      getNetIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
      getFatalEntitlementCalculations: 'getFatalEntitlementCalculations',
      getNetIncomeTaxCalculationForCalculator: 'getNetIncomeTaxCalculationForCalculator',
    }),
    selections() {
      return this.isDocumentInsurancePlanner
        ? get(this.plan, 'selections', [])
        : get(this.reports, 'selections', []);
    },
    getDeterminedIncomeProperty() {
      return this.isPartnerEmployed
        ? 'partner_annual_income'
        : 'partner_taking_from_the_firm';
    },
  },
  components: {
    ...CalculatorComponents,
  },
};
</script>
<style lang="stylus" scoped>
h4
  color rgb(66, 165, 245)
  border-bottom 2px solid rgb(66, 165, 245)
  font-size 16px
  letter-spacing 0.2rem
  text-transform uppercase
</style>
