<template lang="pug">
  div
    div(class="document-graphics-container")
      div
        p(class="text-center no-margin-top") In the event of an Accident your total claim experience with:
        h5(class="text-center no-margin") ACC Cover + Income Protection
      div(class="row md-gutter")
        div(class="col-md-4")
          eighty(
            :amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") ACC Cover Plus
        div(class="col-md-4")
          empty(
            :amount="0"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") Income Protection
        div(class="col-md-4")
          eighty(
            :amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover"
            :w="dimensions.width"
            :h="dimensions.height"
          )
          p(class="text-center no-margin") Total Claim Amount
    div
      p(class="text-center q-mt-md") In the event of an Accident your total claim experience with:
      div(class="html2pdf__page-break")
      h5(class="text-center") ACC Cover + Monthly Mortgage Repayment Cover
    div(class="row md-gutter")
      div(class="col-md-4")
        eighty(
          :amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") ACC Cover Plus
      div(class="col-md-4")
        forty(
          :amount="partnerAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") Monthly Mortgage Repayment Cover
      div(class="col-md-4")
        one-hundred(
          :amount="partnerAccOffsetCalculation.totalClaimAmount"
          :w="dimensions.width"
          :h="dimensions.height"
        )
        p(class="text-center no-margin") Total Claim Amount
    acc-offsets-notes(
      :client-name="plan.partner_name"
      :cover-plus-amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover"
      :monthly-mortgage-amount="partnerAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
      :cover-plus-amount-without-tax="partnerAccOffsetCalculation.maximumAccCoverPlusCoverWithoutTax"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { AccOffsetsNotes } from 'src/components/ipp';
import * as PeopleGraphicsComponents from 'src/components/charts/Peoples';

export default {
  computed: {
    ...mapGetters('partnerCalculations', {
      partnerAccOffsetCalculation: 'getAccOffsetCalculation',
    }),
    ...mapGetters('planner', {
      plan: 'plan',
      hasPartnerIncome: 'hasPartnerIncome',
    }),
    dimensions() {
      return { width: '100%', height: 350 };
    },
  },
  components: {
    AccOffsetsNotes,
    ...PeopleGraphicsComponents,
  },
};
</script>
