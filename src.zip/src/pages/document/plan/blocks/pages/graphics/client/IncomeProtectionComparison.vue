<template lang="pug">
div(v-if="hasClientIncome")
  div(class="document-graphics-container")
    div(class="row justify-center")
      div(class="col-md-6")
        p(class="text-center no-margin") Income Protection Indemnity
        with-tax-chart(
          :tax-amount="netIncomeTaxCalculation.totalTax"
          :total-claim-amount="netIncomeTaxCalculation.totalClaimAmount"
          :w="dimensions.width"
          :h="dimensions.height"
        )
      div(class="col-md-6")
        p(class="text-center no-margin") Income Protection Agreed Value
        without-tax-chart(
          :total-claim-amount="netIncomeTaxCalculation.incomeProtectionAgreedAmount"
          :w="dimensions.width"
          :h="dimensions.height"
        )
    div(class="row")
      div(class="col-md-12")
        common-tax-issues-notes(
          :client-name="plan.client_full_name"
          :tax-amount="netIncomeTaxCalculation.totalTax"
          :total-claim-amount="netIncomeTaxCalculation.totalClaimAmount"
          :agreed-amount="netIncomeTaxCalculation.incomeProtectionAgreedAmount"
          :indemnity-amount="netIncomeTaxCalculation.incomeProtectionIndemnityAmount"
        )
</template>

<script>
import { mapGetters } from 'vuex';
import { CommonTaxIssuesNotes } from 'src/components/ipp';
import { WithTaxChart, WithoutTaxChart } from 'src/components/charts/Taxes';

export default {
  computed: {
    ...mapGetters('clientCalculations', {
      netIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
    }),
    ...mapGetters('planner', {
      plan: 'plan',
      hasClientIncome: 'hasClientIncome',
    }),
    dimensions() {
      return { width: '100%', height: 300 };
    },
  },
  components: {
    WithTaxChart,
    WithoutTaxChart,
    CommonTaxIssuesNotes,
  },
};
</script>
