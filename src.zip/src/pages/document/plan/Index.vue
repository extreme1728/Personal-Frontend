<template lang="pug">
div(class="row justify-center center-block" :style="documentWrapperStyles")
  q-page(id="document-details-1")
    div(class="document-preview-wrapper")
      include blocks/pages/front
      include blocks/pages/client-information
      include blocks/pages/partner-information
      include blocks/pages/children-dependents
      include blocks/pages/business-partners
      include blocks/pages/professional-advisers
      include blocks/pages/mortgage-provider
      include blocks/pages/business-needs
      include blocks/pages/important-information-notes
      include blocks/pages/income-and-expenses
      include blocks/pages/existing-insurances

  q-page(id="document-details-2"  style="min-height:0px !important;")
    div(class="document-preview-wrapper")
      include blocks/pages/client-medical-conditions
      include blocks/pages/client-hazardous-activities
      include blocks/pages/partner-medical-conditions
      include blocks/pages/partner-hazardous-activities

  q-page(
    id="document-calculators-2-1"
    v-if="isClientCalculatorSectionIncluded"
  )
    div(class="document-preview-wrapper")
      div(class="document-header-container")
        h4(class="document-header-title" :style="documentHeaderTitleStyle") My Recommended Benefit (s)
        client-calculators(
          :reports="reports"
          :color-style="colorStyle"
          :is-document-insurance-planner="isDocumentInsurancePlanner"
        )

  q-page(
    class="justify-center"
    id="document-calculators-2-2"
    v-if="isPartnerCalculatorSectionIncluded"
  )
    div(class="document-preview-wrapper")
      div(class="document-header-container")
        partner-calculators(
          :reports="reports"
          :color-style="colorStyle"
          :is-document-insurance-planner="isDocumentInsurancePlanner"
        )

  q-page(
    class="justify-center"
    id="document-item-recommendations-3"
    v-if="selections.includes('item-recommendations')"
  )
    div(class="document-preview-wrapper")
      include blocks/pages/item-recommendations
      include blocks/pages/recommended-benefit-notes

  q-page(
    class="justify-center"
    id="document-info-graphics-4"
    v-if="isGraphicsSectionIncluded"
  )
    div(class="document-preview-wrapper")
      div(
        v-if="clientShowCalculatedLevy && selections.includes('acc-savings')"
        class="document__page-break--after"
      )
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") ACC Savings - {{ getClientName }}
        client-acc-savings

      div(
        v-if="partnerShowCalculatedLevy && selections.includes('acc-savings')"
        class="document__page-break--after"
      )
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") ACC Savings - {{ getPartnerName }}
        partner-acc-savings

      div(
        v-if="showFatalEntitlementCalculation && selections.includes('fatal-entitlements')"
        class="document__page-break--after"
      )
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") Fatal Entitlements - {{ getClientName }}
        client-fatal-entitlements
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") Fatal Entitlements - {{ getPartnerName }}
        partner-fatal-entitlements

      div(
        v-if="hasClientIncome && selections.includes('acc-offsets')"
        class="document__page-break--after"
      )
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") ACC Offsets - {{ getClientName }}
        client-acc-offsets
        template(v-if="hasPartnerIncome")
          div(class="document-header-container")
            h4(class="document-header-title" :style="documentHeaderTitleStyle") ACC Offsets - {{ getPartnerName }}
          partner-acc-offsets

      template(v-if="hasClientIncome && selections.includes('tax-issues')")
        div(class="document__page-break--after")
          div(class="document-header-container")
            h4(class="document-header-title" :style="documentHeaderTitleStyle") Income Protection Comparison - {{ getClientName }}
          client-income-protection-comparison
        div(class="document__page-break--after" v-if="hasPartnerIncome")
          div(class="document-header-container")
            h4(class="document-header-title" :style="documentHeaderTitleStyle") Income Protection Comparison - {{ getPartnerName }}
          partner-income-protection-comparison

      div(class="document__page-break--after" v-if="!hasFidelityOnPolicyProviderResults && selections.includes('tax-issues')")
        div(class="document-header-container")
          h4(class="document-header-title" :style="documentHeaderTitleStyle") Passive Income
        passive-income

  q-page(class="justify-center" id="document-statement-disclosure-5")
    div(class="document-preview-wrapper")
      include blocks/pages/about-us
      include blocks/pages/scope-of-engagement
      include blocks/pages/accuracy-of-information
      include blocks/pages/the-privacy-act-declarations
      include blocks/pages/authority-to-proceed
      include blocks/pages/what-you-need-to-tell-us
      include blocks/pages/what-you-need-to-know-from-us

  q-page(class="justify-center" id="document-acknowledgments-6")
    div(class="document-preview-wrapper")
      include blocks/pages/acknowledgements
      include blocks/pages/signatures

  include blocks/settings/color-picker-dialog
  include blocks/settings/selections-dialog
  include blocks/settings/floating-action-buttons
</template>

<style
  lang="styl"
  src="src/css/document.plan.styl" scoped></style>

<script>
import moment from 'moment';
import { date, QSpinnerGears } from 'quasar';
import { mapGetters, mapActions } from 'vuex';
import { QInput } from 'src/components/quasar';
import * as DocumentGraphics from './blocks/pages/graphics';
import { ScopeOfEngagements } from 'src/pages/dashboard/planner/steps';
import * as RecommendationSections from 'src/config/recommendationSections';
import { ItemRecommendationsTable } from 'src/components/ipp/recommendations';
import { FieldableMixin, ChartDataMixin, DocumentMotifMixin } from 'src/mixins';
import { isEmpty, toString, eq, upperFirst, camelCase, get, some } from 'lodash';
import { switchcase, floatFixer, numberWithCommas, nltobr } from 'src/config/utils';
import DatePicker from 'src/components/datepicker/DatePicker';
import BusinessDebt  from 'pages/dashboard/planner/steps/BusinessNeeds/blocks/BusinessDebt';
import RecommendationCategoryService from 'src/services/ipp/reports/recommendations/Category';
import { ScopeOfServices } from 'src/components/ipp/scopes';
import { BuyAndSells, KeyPersonCovers, BusinessPartnerImportantInfo, BodyMassIndexInput, MedicalConditionInput } from 'src/components/ipp/planner';
import { PrintableDialog, SectionSelections, ItemRecommendationsLoyaltySavings, DisplayInput } from 'src/components/ipp';
import InsurancePlanReportDetail from 'src/pages/dashboard/planner/steps/InsurancePlan/blocks/ReportDetail';

export default {
  name: 'document-plan-preview',
  extends: {
    methods: {
      ...ScopeOfEngagements.methods,
      ...InsurancePlanReportDetail.methods,
    },
    computed: {
      ...ScopeOfEngagements.computed,
    },
  },
  mixins: [FieldableMixin, ChartDataMixin, DocumentMotifMixin],
  data: () => ({
    reports: {},
    reportsLoad: false,
    selectionDialogShow: false,
  }),
  async created() {
    await this.determineSelectionsReset();
  },
  mounted() {
    this.initItemRecommendationsTable();
  },
  methods: {
    ...mapActions('insuranceProviderReport', ['assignReportResults']),
    ...mapActions('planner', ['getPlannerReport']),
    ...mapActions('documentRecommendation', [
      'setSelectionsForInsurancePlanner',
      'resetRecommendationSelections',
      'setRecommendationSelection',
    ]),
    async determineSelectionsReset() {
      const { type } = this.$route.query;
      await this.setSelectionsForInsurancePlanner({ type });
    },
    async initItemRecommendationsTable() {
      try {
        const { params: { reportId, plannerId }, query: { type } } = await this.$route;
        if (this.isDocumentInsurancePlanner) return;
        if (!reportId || !plannerId) return;
        this.reportsLoad = false;
        this.$q.notify({
          timeout: 1000,
          icon: 'sync',
          color: 'primary',
          message: 'Fetching Reports ...',
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
        const { data } = await this.getPlannerReport({ reportId, plannerId });
        this.reports = data;
        this.assignReportResults(data);
        this.reportsLoad = true;
        this.$nextTick(() => {
          this.$refs.$ItemRecommendationsTable.updateTableHeight(true);
        });
      }
      catch (e) { console.error(e); }
    },
    __getAge({ date_of_birth, age }) {
      if (age) return age;
      const viaFilterService = this.$filters.getAgeByDate(date_of_birth);
      if (viaFilterService) return viaFilterService;
      const m = moment(date_of_birth);
      return m.isValid()
        ? m.fromNow(true)
        : null;
    },
    nltobr: nltobr,
  },
  computed: {
    ...mapGetters('medicalCategories', ['medicals', 'familials']),
    ...mapGetters('hazardousActivitiyCategories', ['activities']),
    ...mapGetters('documentRecommendation', {
      getSelectedSections: 'getSelectedSections',
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('partnerCalculations', {
      partnerShowCalculatedLevy: 'showCalculatedLevy',
      isPartnerTheSameClassificationUnit: 'isTheSameClassificationUnit',
      getPartnerSelectedClassificationUnit: 'getSelectedClassificationUnit',
      getPartnerSelectedClassificationunitOnTools: 'getSelectedClassificationunitOnTools',
    }),
    ...mapGetters('clientCalculations', {
      clientShowCalculatedLevy: 'showCalculatedLevy',
      getNetIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
      isClientTheSameClassificationUnit: 'isTheSameClassificationUnit',
      getFatalEntitlementCalculations: 'getFatalEntitlementCalculations',
      getClientSelectedClassificationUnit: 'getSelectedClassificationUnit',
      getNetIncomeTaxCalculationForCalculator: 'getNetIncomeTaxCalculationForCalculator',
      getClientSelectedClassificationunitOnTools: 'getSelectedClassificationunitOnTools',
    }),
    ...mapGetters('insuranceProviderReport', {
      getPropsedTotalMonthlyPremium: 'getPropsedTotalMonthlyPremium',
      hasFidelityOnPolicyProviderResults: 'hasFidelityOnPolicyProviderResults',
      hasPartnersLifeOnPolicyProviderResults: 'hasPartnersLifeOnPolicyProviderResults',
    }),
    ...mapGetters('resources', {
      getIncomeIsEmployedYear: 'incomeIsEmployedYear',
      getIncomeIsEmployedMonth: 'incomeIsEmployedMonth',
    }),
    ...mapGetters('resources', [
      'diabetesTypesOptions',
      'inputDateFormat',
      'booleanValues',
    ]),
    ...mapGetters('planner', [
      'isEmployed',
      'isSelfEmployed',
      'hasClientIncome',
      'hasPartnerIncome',
      'isPartnerEmployed',
      'clientGrossIncome',
      'partnerGrossIncome',
      'getChildYoungestAge',
      'isPartnerSelfEmployed',
      'getEstatePlanningNotes',
      'determineIncomeFromBusiness',
      'getClientInsuranceProviders',
      'getPartnerInsuranceProviders',
      'getCalculatedMortgageRepayment',
      'showFatalEntitlementCalculation',
      'determinePartnerTakingFromTheFirm',
      'showItemRecommendationPartnerValues',
      'getDeterminedFirstAppointmentSignature',
      'getDeterminedSecondAppointmentSignature',
    ]),
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('site', ['getOfficePhysicalAddress']),
    selections() {
      return this.isDocumentInsurancePlanner
        ? get(this.plan, 'selections', [])
        : get(this.reports, 'selections', []);
    },
    shouldShowPartnerItemRecommendationValues() {
      if (!this.isDocumentBusinessPlan) return true;
      return this.showItemRecommendationPartnerValues;
    },
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
    isDocumentBusinessPlan() {
      const { type } = this.$route.query;
      return type && eq(type, 'business');
    },
    isDocumentPersonalPlan() {
      const { type } = this.$route.query;
      return type && eq(type, 'personal');
    },
    isDocumentInsurancePlanner() {
      const { type } = this.$route.query;
      return type && eq(type, 'insurance_planner');
    },
    getFrontTitleText() {
      const { type } = this.$route.query;
      if (this.isDocumentInsurancePlanner) return 'Your Personal Insurance Planner';
      return !isEmpty(toString(type)) ? `Your ${upperFirst(type)} Insurance Plan` : 'Provide Business Name';
    },
    getClientAndPartnerName() {
      const { company_full_name, client_name_title, partner_name_title } = this.plan;
      if (this.isDocumentBusinessPlan) return company_full_name || 'Business Name';
      let names = this.getClientName;
      if (!isEmpty(toString(client_name_title))) {
        names = `${client_name_title} ${names}`;
      }
      if (this.hasPartnerExists) {
        let partnerName = this.getPartnerName;
        if (!isEmpty(toString(partner_name_title))) {
          names = `${names} and ${partner_name_title} ${partnerName}`;
        }
        else {
          names = `${names} and ${partnerName}`;
        }
      }
      return names;
    },
    getClientOccupation() {
      if (this.isSelfEmployed) {
        return this.isClientTheSameClassificationUnit
          ? get(this.getClientSelectedClassificationUnit, 'name')
          : get(this.getClientSelectedClassificationunitOnTools, 'name');
      }
      return this.plan.employed_occupation;
    },
    getPartnerOccupation() {
      if (this.isPartnerSelfEmployed) {
        return this.isPartnerTheSameClassificationUnit
          ? get(this.getPartnerSelectedClassificationUnit, 'name')
          : get(this.getPartnerSelectedClassificationunitOnTools, 'name')
      }
      return this.plan.partner_employed_occupation
    },
    signatures() {
      const { type } = this.$route.query;
      let stage = type.includes('insurance_planner')
                  ? 'first_appointment'
                  : 'second_appointment';
      stage = upperFirst(camelCase(stage));
      const signature = this[`getDetermined${stage}Signature`];
      const client = get(signature('client'), 'value', null);
      const partner = get(signature('partner'), 'value', null);
      return { client, partner };
    },
    solutionDescription() {
      const { category } = this.reports;
      return RecommendationCategoryService.render(category);
    },
    shouldShowPartner() {
      const { type } = this.$route.query;
      if (!isEmpty(type) && this.isDocumentInsurancePlanner) return true;
      if (eq(this.plan.is_partner_shareholder_or_directory, 'yes')) return true;
      return false;
    },
    shouldShowBusinessPartners() {
      const { business_partners } = this.plan;
      return this.isDocumentBusinessPlan && !isEmpty(business_partners);
    },
    isGraphicsSectionIncluded() {
      const sections = RecommendationSections.commonDocumentSections
        .filter(({ value }) => !['item-recommendations', 'item-recommendations-loyalty-savings'].includes(value));
      return some(sections, ({ value }) => {
        return this.selections.includes(value);
      });
    },
    isClientCalculatorSectionIncluded() {
      return some(RecommendationSections.clientCalculatorOptions, ({ value }) => {
        return this.selections.includes(value);
      });
    },
    isPartnerCalculatorSectionIncluded() {
      return some(RecommendationSections.partnerCalculatorOptions, ({ value }) => {
        return this.selections.includes(value);
      });
    },
    getElementIds() {
      let sections = [
        {
          element: 'document-details-1',
          filename: this.isDocumentInsurancePlanner ? 'Insurance Planner' : 'Insurance Plan',
          footer: {
            excludes: [1], // Page# to exclude footer text
            text: 'Information requested in the blank text boxes are not disclosed.',
          },
        },
        {
          element: 'document-details-2',
          filename: 'Existing Medical and Hazardous Activities',
          footer: {
            text: 'Information requested in the blank text boxes are not disclosed.',
          },
        },
        { element: 'document-statement-disclosure-5', filename: 'Scope Of Engagement' },
        { element: 'document-acknowledgments-6', filename: 'Acknowledgments' },
      ];

      if (this.isClientCalculatorSectionIncluded) {
        sections = [
          ...sections,
          ...[{ element: 'document-calculators-2-1', filename: `${this.getClientName} Recommendations` }],
        ];
      }

      if (this.isPartnerCalculatorSectionIncluded) {
        sections = [
          ...sections,
          ...[{ element: 'document-calculators-2-2', filename: `${this.getPartnerName} Recommendations` }],
        ];
      }

      if (!this.isDocumentInsurancePlanner
        && this.selections.includes('item-recommendations')) {
        sections = [
          ...sections,
          ...[{ element: 'document-item-recommendations-3', filename: 'My Recommended Benefits' }],
        ];
      }

      if (this.isGraphicsSectionIncluded) {
        sections = [
          ...sections,
          ...[{ element: 'document-info-graphics-4', filename: 'Acc Savings and Off-sets' }],
        ];
      }

      return sections;
    },
  },
  components: {
    ...DocumentGraphics,
    DisplayInput,
    DatePicker,
    QInput,
    BuyAndSells,
    BusinessDebt,
    KeyPersonCovers,
    PrintableDialog,
    ScopeOfServices,
    SectionSelections,
    BodyMassIndexInput,
    MedicalConditionInput,
    ItemRecommendationsTable,
    BusinessPartnerImportantInfo,
    ItemRecommendationsLoyaltySavings,
  },
};
</script>
