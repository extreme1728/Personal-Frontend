<template lang="pug">
div
  q-page(class="row justify-center" id="document-preview-page")
    section(:style="documentWrapperStyles")
      article
        h4(class="no-margin-top") LIMITED ADVICE TRANSACTION
        p(class="text-tertiary") The purpose of this transaction is to apply for:
        p(class="text-weight-medium") Tick one of the options below:
        q-field(class="q-mt-md")
          q-checkbox(
            readonly
            color="tertiary"
            class="text-tertiary"
            :value="limitations.instructed"
            label="You have instructed me not to determine the suitablity of my financial adviser services to your particular circumstances"
          )
        q-field(class="q-mt-md")
          p(class="text-weight-medium") Or:
          q-checkbox(
            readonly
            color="tertiary"
            class="text-tertiary"
            :value="limitations.acknowledge"
            label="You acknowledge that you have chosen not to disclose all of the information sought by me and that the suitablity of my financial adviser services to your circumstances is based only upon that information which you have provided"
          )
      article(class="text-tertiary")
        ol(class="q-mt-lg")
          li Please note the following:
          ul(class="q-mt-md q-mb-md")
            li The advantages of having a suitability analysis are to:
            ol(type="a" class="q-mt-sm")
              li(class="q-mt-sm") Give me a full understanding of your personal circumstances, including your financial goals and risk tolerances, allowing me to tailor my advice to your specific needs;
              li(class="q-mt-sm") Provide you with an analysis of your current and future financial situation;
              li(class="q-mt-sm") Determine which financial products may be suitable for your current and future needs and goals
              li(class="q-mt-sm") Advise you of any gaps in your risk or investment profile
            li(class="q-mt-md") The risks of not having a suitability analysis are that:
              ol(type="a" start="5" class="q-mt-sm")
                li(class="q-mt-sm") Any advice I give you is based on incomplete information and will therefore be of a more general nature
                li(class="q-mt-sm") A complete financial analysis will not be conducted
                li(class="q-mt-sm") Financial products that I recommend may be unsuitable for your needs and goals either now or in the future
                li(class="q-mt-sm") You may commit to products which bear a greater risk than you would otherwise tolerate
                li(class="q-mt-sm") Possible gaps in your risk or investment profile may not be uncovered
          li This statement acknowledges the following:
            ul(class="q-mt-md")
              li You waive your right to a suitability analysis of my financial adviser services;
            p(class="text-weight-medium") Or:
            ul(class="q-mt-md")
              li(class="q-mt-sm") You have not provided me with all the information I have requested and that the suitability of my financial adviser services to your particular circumstances is based only upon the information that I have received.
              li(class="q-mt-sm") I have not directed or influenced you not to receive a suitability analysis or limit what information you give me;
              li(class="q-mt-sm") You accept that you must still disclose all relevant information on any application submitted on your behalf.
          p(class="q-mt-lg") Please note that at any time during this process, you can elect to have me conduct a financial suitability analysis.
      article(class="row q-gutter-lg")
        div(class="col-md-6")
          q-field(class="q-mt-md" label="Name")
            q-input(:value="plan.client_full_name" readonly)
          q-field(class="q-mt-md" label="Signed")
            img(class="signature" :src="clientSignature" v-if="clientSignature")
            div(class="signature" v-else)
            p(class="no-margin" v-text="plan.client_full_name")
          q-field(class="q-mt-md" label="Date")
            q-input(:value="documentDateNow" readonly)
        div(class="col-md-6")
          q-field(class="q-mt-md" label="Name")
            q-input(:value="plan.partner_name" readonly)
          q-field(class="q-mt-md" label="Signed")
            img(class="signature" :src="partnerSignature" v-if="partnerSignature")
            div(class="signature" v-else)
            p(class="no-margin" v-text="plan.partner_name")
          q-field(class="q-mt-md" label="Date")
            q-input(:value="documentDateNow" readonly)
      article(class="row q-mt-md")
        div(class="col-md-12")
          q-field(:label-width="2" label="Adviser")
            q-input(:value="adviserName" readonly)
          q-field(class="q-mt-md" :label-width="2" label="Signed")
            img(
              v-if="getDeterminedFinancialAdviserSignature"
              :src="getDeterminedFinancialAdviserSignature"
              class="signature adviser"
            )
          q-field(class="q-mt-md" :label-width="2" label="Date")
            q-input(:value="documentDateNow" readonly)
  printable-dialog(:offset="[18, 18]")
</template>

<script>
import { date } from 'quasar';
import { isEmpty } from 'lodash';
import { mapState, mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { PrintableDialog } from 'src/components/ipp';
import { InsurancePlan } from 'src/pages/dashboard/planner/steps'

export default {
  data: () => ({
    adviserName: null,
  }),
  created() {
    const { name } = this.currentUserModel;
    this.adviserName = name;
  },
  extends: {
    computed: {
      ...InsurancePlan.computed,
    },
  },
  computed: {
    ...mapState('limitedAdivce', {
      hasLimitations: state => state.has_limitations,
      limitations: state => state.limitations,
    }),
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    ...mapGetters('documentRecommendation', {
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('user', {
      currentUserModel: 'currentUserModel',
    }),
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
    getDeterminedFinancialAdviserSignature() {
      const { profile } = this.currentUserModel;
      const signature = profile.signature_filename;
      return isEmpty(signature)
        ? null
        : require(`src/assets/signatures/${signature}`);
    },
  },
  components: {
    QInput,
    PrintableDialog,
  },
};
</script>

<style lang="stylus" scoped>
.signature
  max-height 120px
  height 120px
  width 100%
  max-width 100%
  border-bottom 1px dotted #333
img.adviser
  width 50%
</style>
