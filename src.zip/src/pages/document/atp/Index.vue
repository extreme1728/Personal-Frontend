<template lang="pug">
div
  q-page(class="row justify-center" id="document-preview-page")
    div(class="document-preview-wrapper" :style="documentWrapperStyles")
      div(class="row front-section")
        div(class="col-md-6")
          img(class="img-responsive" src="~assets/jdlife-logo.png")
        div(class="col-md-6")
          h1 Authority to Proceed
      include blocks/future-contact
      include blocks/method-to-receive-documentation
      include blocks/registered-financial-adviser-attestation
      include blocks/applicant-insured-authorisation
      include blocks/document-footer
  printable-dialog(:offset="[18, 18]")
</template>

<style
  lang="stylus"
  src="src/css/document.atp.styl" scoped></style>

<script>
import { date } from 'quasar';
import { isEmpty } from 'lodash';
import { mapGetters } from 'vuex';
import { PrintableDialog } from 'src/components/ipp';
import { InsurancePlan } from 'src/pages/dashboard/planner/steps';

export default {
  data: () => ({
    contactedForAnnualReview: ['yes'],
    authoriseForMarketingPurposes: ['yes'],
    permissionChosen: ['email_own'],
    permissionemailown: null,
    permissionEmailThirdParty: null,
    registeredFinancialAdviserName: null,
  }),
  created () {
    const { name } = this.currentUserModel;
    this.registeredFinancialAdviserName = name;
    const { client_email_address, partner_email_address } = this.plan;
    if (!isEmpty(client_email_address)) {
      this.permissionemailown = client_email_address;
    }
    if (!isEmpty(partner_email_address)) {
      this.permissionemailown = partner_email_address;
    }
    if (!isEmpty(client_email_address) && !isEmpty(partner_email_address)) {
      this.permissionemailown = `${client_email_address}, ${partner_email_address}`;
    }
  },
  extends: {
    computed: {
      ...InsurancePlan.computed,
    },
  },
  computed: {
    ...mapGetters('documentRecommendation', {
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('planner', ['plan']),
    ...mapGetters('site', ['getOfficePhysicalAddress']),
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
    getDeterminedFinancialAdviserSignature() {
      const { profile } = this.currentUserModel;
      const signature = profile.signature_filename;
      return isEmpty(signature)
        ? null
        : require(`src/assets/signatures/${signature}`);
    },
    booleanValues: () => ([
      { label: 'YES', value: 'yes' },
      { label: 'NO', value: 'no' },
    ]),
  },
  components: {
    PrintableDialog,
  },
};
</script>
