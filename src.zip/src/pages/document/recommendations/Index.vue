<template lang="pug">
div
  q-page(class="row justify-center" id="document-preview-page" v-show="reportsLoad")
    div(class="document-preview-wrapper" :style="documentWrapperStyle")
      include ../plan/blocks/pages/item-recommendations
  printable-dialog
</template>

<style
  lang="styl"
  src="src/css/document.plan.styl" scoped></style>

<script>
import { QSpinnerGears } from 'quasar';
import { mapActions, mapGetters } from 'vuex';
import { DocumentMotifMixin } from 'src/mixins';
import RecommendationCategoryService from 'src/services/ipp/reports/recommendations/Category';
import {
  PrintableDialog,
  ItemRecommendationsLoyaltySavings,
} from 'src/components/ipp';
import { ItemRecommendationsTable } from 'src/components/ipp/recommendations';

export default {
  name: 'document-recommendation-preview',
  mixins: [DocumentMotifMixin],
  data: () => ({
    reports: {},
    reportsLoad: false,
  }),
  async mounted() {
    try {
      this.reportsLoad = false;
      this.$q.loading.show({
        delay: 500,
        spinnerSize: 250,
        spinner: QSpinnerGears,
        message: 'Generating Document...',
        customClass: 'bg-primary',
      });

      const { params: { reportId, plannerId }, query: { type } } = await this.$route;
      const { data } = await this.getPlannerReport({ reportId, plannerId });
      this.reports = data;
      this.assignReportResults(data);

      this.reportsLoad = true;
      this.$q.loading.hide();

      this.$nextTick(() => {
        this.$refs.$ItemRecommendationsTable.updateTableHeight(true);
      });
    }
    catch (e) { console.error(e); }
  },
  methods:{
    ...mapActions('planner', ['getPlannerReport']),
    ...mapActions('insuranceProviderReport', ['assignReportResults']),
  },
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
      showItemRecommendationPartnerValues: 'showItemRecommendationPartnerValues',
    }),
    ...mapGetters('documentRecommendation', {
      selections: 'getSelectedSections',
      documentWrapperStyle: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('insuranceProviderReport', {
      getPropsedTotalMonthlyPremium: 'getPropsedTotalMonthlyPremium',
      hasFidelityOnPolicyProviderResults: 'hasFidelityOnPolicyProviderResults',
      hasPartnersLifeOnPolicyProviderResults: 'hasPartnersLifeOnPolicyProviderResults',
    }),
    solutionDescription() {
      const { category } = this.reports;
      return RecommendationCategoryService.render(category);
    },
    shouldShowPartnerItemRecommendationValues() {
      return true;
    },
  },
  components: {
    PrintableDialog,
    ItemRecommendationsTable,
    ItemRecommendationsLoyaltySavings,
  },
};
</script>
