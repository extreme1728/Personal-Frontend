<template lang="pug">
div
  q-page(class="row justify-center" id="document-preview-page")
    div(class="document-preview-wrapper" :style="documentWrapperStyles")
      div(class="row logo-section")
        div(class="col-md-12")
          img(class="img-responsive float-right" src="~assets/jdlife-logo.png")
      div(class="row header-section")
        div(class="col-md-12")
          h1(class="header-title") Engagement
          p(class="header-subtitle") Please carefully read the declarations and acknowledgments below and sign to confirm your agreement.
      div(class="content-section-wrapper")
        section(class="row")
          div(class="col-md-12")
            h4(class="no-margin section-heading") Scope of Engagement
            p
              | We have appointed {{ currentUserModel.name }} of JD Life of {{ getOfficePhysicalAddress }} to provide us with a
              |
              span(class="text-red") Financial Risk Review
              | .
              | This is to include a thorough review of our personal &amp;/or financial situation as this relates to Life Risks and related insurance.  This shall include non-obligation indicative quotes/estimates from various insurers.  Any Recommendations will be subject to acceptance of terms offered &amp; completion of application forms.  All details are confidential &amp; shall be kept for seven years unless otherwise stated in order to facilitate on-going services to you.
            p Any financial regulator, external compliance personnel, deemed professionals including medical practitioners, re-insurers &amp; prospective purchasers of JD Life may view your personal/business information.  Our services are free as we are reimbursed by the insurer in the form of commission (initial &amp; ongoing) should you take out insurance through us.  No conflicts of interest exist (unless notified) as we are not tied Agents.
          div(class="row justify-center")
            scope-of-services(
              :display-name="getClientName"
              :payload="clientServices"
              class="col-md-6"
              type="client"
              color="indigo-10"
              @save="onHandleScopeServiceSave"
            )
            scope-of-services(
              :display-name="getPartnerName"
              :payload="partnerServices"
              class="col-md-6"
              type="partner"
              color="indigo-10"
              @save="onHandleScopeServiceSave"
            )
        hr
        section(class="row")
          div(class="col-md-12")
            h4(class="no-margin section-heading") Accuracy of Information
            p The information set out in this form &amp; attached to this declaration including the fact find is true and correct to the best of our knowledge;
            p Accurately and fully represents our Private/Business financial situation, needs and objectives;
            p We understand that the advice will be based primarily on the information supplied in this form;
            p We acknowledge that if any information has been withheld, is inaccurate or misrepresented in any way, any advice provided for our benefit may prove to be inappropriate and unsuitable.
      div(class="html2pdf__page-break")
      div(class="content-section-wrapper q-mt-lg")
        section(class="row")
          div(class="col-md-12")
            h4(class="no-margin section-heading") The Privacy Act Declarations
            p We consent to our Accountant and Estate Solicitor, &amp;/or ACC disclosing to {{ currentUserModel.name }}, all information requested that is reasonably required in the execution of this Scope of Engagement – no liability for fees invoiced/incurred to the client by any such professional shall be JD Life’s Ltd responsibility regardless of how the engagement came about;
            p We hereby authorise {{ currentUserModel.name }} to make our file available to any legal or compliance authority, or such product provider, and/or claims investigators who may need access to such information for the purpose of processing and administering any business we may seek to transact as a result of the specified Scope of Engagement;
            p We understand that the data collected is stored (electronically) at the offices of JD Life Ltd and that a copy and any alterations are available on request;
            p A scan, copy (electronic/paper) or fax of this Agreement is deemed to be as good as the original.
        hr
        section(class="row")
          div(class="col-md-12")
            h4(class="no-margin section-heading") Acknowledgements
          p We acknowledge that we received, read &amp; understood {{ currentUserModel.name }} Disclosure Statement v2.3, {{ documentDateNow }}
          p We acknowledge that we have had the basis of adviser remuneration and brokerage explained to us;
          p We acknowledge that the services being provided are restricted to the scope of engagement and subject to specific limitations indicated as per above;
          p We acknowledge the advantages of undertaking a full suitability (needs) analysis and the need to provide relevant personal and financial information, and by not doing so we risk receiving advice or product recommendations that may not be appropriate to our needs;
          p We can terminate this Agreement at any time by providing thirty (30) days written notice.
        hr
        section(class="row q-col-gutter-md information")
          div(class="col-md-6")
            q-input(label="Name" :value="plan.client_full_name" readonly)
            p(class="text-faded") Signature
            img(class="signature" :src="clientSignature" v-if="clientSignature")
            div(class="signature" v-else)
            p(class="no-margin" v-text="plan.client_full_name")
            q-input(label="Date" :value="documentDateNow" readonly)
          div(class="col-md-6")
            q-input(label="Name" :value="plan.partner_name" readonly)
            p(class="text-faded") Signature
            img(class="signature" :src="partnerSignature" v-if="partnerSignature")
            div(class="signature" v-else)
            p(class="no-margin" v-text="plan.partner_name")
            q-input(label="Date" :value="documentDateNow" readonly)
  printable-dialog(:offset="[18, 18]")
</template>

<style
  lang="stylus"
  src="src/css/document.enagement.styl"
  scoped></style>

<script>
import { date } from 'quasar';
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { PrintableDialog } from 'src/components/ipp';
import { ScopeOfServices } from 'src/components/ipp/scopes';
import { InsurancePlanner, ScopeOfEngagements } from 'src/pages/dashboard/planner/steps';

export default {
  name: 'engagement-preview',
  extends: {
    methods: {
      ...ScopeOfEngagements.methods,
    },
    computed: {
      ...FieldableMixin.computed,
      ...InsurancePlanner.computed,
      ...ScopeOfEngagements.computed,
    },
  },
  computed: {
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('documentRecommendation', {
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('site', ['getOfficePhysicalAddress']),
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
  },
  components: {
    QInput,
    PrintableDialog,
    ScopeOfServices,
  },
};
</script>
