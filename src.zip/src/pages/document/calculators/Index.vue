<template lang="pug">
div
  q-page(
    class="row justify-center"
    id="calculators-client"
    v-if="isClientCalculatorSectionIncluded"
  )
    div(class="document-preview-wrapper" :style="documentWrapperStyles")
      client-calculators
  q-page(
    class="row justify-center"
    id="calculators-partner"
    v-if="isPartnerCalculatorSectionIncluded"
  )
    div(class="document-preview-wrapper" :style="documentWrapperStyles")
      partner-calculators
  printable-dialog(
    compressed
    :offset="[18, 90]"
    :element-id="getElementIds"
  )
  q-page-sticky(position="bottom-right" :offset="[18, 18]")
    q-btn(
      fab
      no-ripple
      icon="reorder"
      color="teal"
      @click="selectionDialogShow = true"
    )
  q-dialog(
    v-model="selectionDialogShow"
    @cancel="selectionDialogShow = false"
    @hide="selectionDialogShow = false"
    prevent-close
  )
    h6(slot="title" class="text-faded no-margin") Select Document Sections
    span(slot="message") Choose document sections to be shown
    div(slot="body")
      section-selections(:disables="['graphics', 'statement', 'policy', 'sovereign', 'aia', 'partners', 'fidelity']")
    template(slot="buttons" slot-scope="{ cancel }")
      q-btn(flat color="primary" label="Close" @click="cancel")
</template>

<style
  lang="styl"
  src="src/css/document.plan.styl" scoped></style>

<script>
import { some } from 'lodash';
import { mapGetters, mapActions } from 'vuex';
import { PrintableDialog, SectionSelections } from 'src/components/ipp';
import * as RecommendationSections from 'src/config/recommendationSections';
import ClientCalculators from '../plan/blocks/pages/graphics/client/Calculators';
import PartnerCalculators from '../plan/blocks/pages/graphics/partner/Calculators';

export default {
  data: () => ({
    selectionDialogShow: false,
  }),
  created() {
    // Clear all
    const sections = [
      ...RecommendationSections.clientCalculatorOptions,
      ...RecommendationSections.partnerCalculatorOptions,
    ];
    this.setRecommendationSelection(sections.map(({ value }) => value));
  },
  methods: mapActions('documentRecommendation', ['setRecommendationSelection']),
  computed: {
    ...mapGetters('documentRecommendation', {
      selections: 'getSelectedSections',
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    isClientCalculatorSectionIncluded() {
      return some(RecommendationSections.clientCalculatorOptions, ({ value }) => {
        return this.selections.includes(value);
      });
    },
    isPartnerCalculatorSectionIncluded() {
      return some(RecommendationSections.partnerCalculatorOptions, ({ value }) => {
        return this.selections.includes(value);
      });
    },
    getElementIds() {
      let sections = [];

      if (this.isClientCalculatorSectionIncluded) {
        sections = [
          ...sections,
          ...['calculators-client'],
        ];
      }

      if (this.isPartnerCalculatorSectionIncluded) {
        sections = [
          ...sections,
          ...['calculators-partner'],
        ];
      }

      return sections;
    },
  },
  components: {
    ClientCalculators,
    PartnerCalculators,
    PrintableDialog,
    SectionSelections,
  },
};
</script>
