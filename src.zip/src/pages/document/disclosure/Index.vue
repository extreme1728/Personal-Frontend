<template lang="pug">
div
  q-page(class="row justify-center" id="document-preview-page")
    div(class="document-preview-wrapper" :style="documentWrapperStyles")
      div(class="row logo-section")
        div(class="col-md-12")
          img(class="img-responsive float-right" src="~assets/jdlife-logo.png")
      div(class="row header-section")
        div(class="col-md-12")
          h1(class="title") Disclosure Statement – (Financial Adviser)
      div(class="row details-section")
        div(class="col-md-12")
          table(border="0" cellspacing="0" cellpadding="0" class="details-table")
            tr
              th Name of financial adviser:
              td {{ currentUserModel.name }}
            tr
              th FSPR Number:
              td {{ currentUserModel.profile.fsp_number }}
            tr
              th Physical address:
              td {{ getOfficePhysicalAddress }}
            tr
              th Trading name:
              td JD Life Ltd
            tr
              th Email address:
              td {{ currentUserModel.email }}
            tr
              th Telephone number:
              td {{ currentUserModel.profile.telephone_number }}
      div(class="row details-section q-mt-md")
        div(class="col-md-12")
          p
            b This disclosure statement was prepared on:&nbsp;
            | {{ documentDateNow }}
      div(class="row details-section q-mt-md")
        div(class="col-md-12")
          p(class="no-margin")
            b It is important that you read this document
          p(class="no-margin-top") This information will help you to choose a financial adviser that best suits your needs. It will also provide some useful information about the financial adviser that you choose.
      div(class="row details-section q-mt-md")
        div(class="col-md-12")
          p(class="no-margin")
            b What sort of adviser am I?
          p(class="no-margin-top") I am a registered, but not authorised, financial adviser.
          p I can give you advice about:
      div(class="row details-section q-mt-md")
        div(class="col-md-4")
          p(class="text-center text-bold no-margin") Risk products
      div(class="row details-section q-mt-sm")
        div(class="col-md-4")
          ul(class="no-margin")
            li Life insurance
            li Trauma insurance
            li Disability Income Protection insurance
            li Total Permanent Disablement insurance
            li Accidental Death insurance
        div(class="col-md-8")
          ul(class="no-margin")
            li Business Continuity insurance
            li Mortgage Protection insurance
            li Key Person Protection insurance
            li Medical insurance
      div(class="row details-section q-mt-lg")
        div(class="col-md-12")
          p(class="no-margin")
            b What should you do if something goes wrong?
          p(class="no-margin-top") If you have a concern or complaint about the services provided, please let me know so that I can try to fix the problem.
          p Upon letting me know of a complaint, JD Life internal complaints scheme will be activated.
          p If no agreement can be reached on how to fix the issue, or if you decide not to use the internal complaints scheme, you can contact the Financial Services Complaints Ltd. This service is free to you and will help us resolve any disagreements.
      div(class="html2pdf__page-break")
      div(class="row details-section")
        p(class="col-md-12 no-margin") You can contact the Financial Services Complaints Ltd at:
      div(class="row details-section")
        div(class="col-md-2")
          p(class="no-margin") Address:
          p(class="no-margin") Telephone number:
          p(class="no-margin") Email address:
        div(class="col-md-10")
          p(class="no-margin") PO Box 5967, Wellington 6145
          p(class="no-margin") 0800 347 257
          p(class="no-margin") info@fscl.org.nz
      div(class="row details-section q-mt-md")
        div(class="col-md-12")
          p(class="text-bold no-margin") Government Regulation
          p You can check that I am a registered financial adviser at &nbsp;
            a(href="//fspr.govt.nz" target="_blank") www.fspr.govt.nz
          p The Financial Markets Authority regulates financial advisers. Contact the Financial Markets Authority for more information, including financial tips and warnings.
          p You can report information or complain about my conduct to the Financial Markets Authority, but in the event of a disagreement, the JD Life internal complaints scheme and or Financial Services Complaints Ltd procedure should have first been followed.
      div(class="row details-section q-mt-md")
        div(class="col-md-12")
          p(class="text-bold no-margin") Declaration
          p I, {{ currentUserModel.name }}, declare that, to the best of my knowledge and belief, the information contained in this disclosure statement is true and complete and complies with the disclosure requirements in the Financial Adviser Act 2008 and the Financial Advisers (Disclosure) Regulations 2010.
      div(class="row q-col-gutter-md q-mt-sm")
        div(class="col-md-6")
          span(class="text-bold" v-text="currentUserModel.name")
          img(class="signature" :src="getDeterminedFinancialAdviserSignature" v-if="getDeterminedFinancialAdviserSignature")
          div(class="signature" v-else)
      div(class="row details-section q-mt-lg")
        div(class="col-md-12")
          p(class="no-margin") I have viewed the contents of the disclosure statement and understand its content.
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          span(class="text-bold") Client Receipt Acknowledgment
          img(class="signature" :src="clientSignature" v-if="clientSignature")
          div(class="signature" v-else)
          p(class="no-margin" v-text="plan.client_full_name")
        div(class="col-md-6")
          span(class="text-bold") Partner Receipt Acknowledgment
          img(class="signature" :src="partnerSignature" v-if="partnerSignature")
          div(class="signature" v-else)
          p(class="no-margin" v-text="plan.partner_name")
      footer
        p Disclosure Statement - Version 2.3, {{ documentDateNow }}
  printable-dialog(:offset="[18, 18]")
</template>

<style
  lang="stylus"
  src="src/css/document.disclosure.statement.styl"
  scoped></style>

<script>
import { date } from 'quasar';
import { isEmpty } from 'lodash';
import { mapGetters } from 'vuex';
import { PrintableDialog } from 'src/components/ipp';
import { InsurancePlanner } from 'src/pages/dashboard/planner/steps';

export default {
  name: 'disclosure-preview',
  extends: {
    computed: {
      ...InsurancePlanner.computed,
    },
  },
  computed: {
    ...mapGetters('documentRecommendation', {
      documentWrapperStyles: 'getDocumentWrapperStyle',
    }),
    ...mapGetters('user', ['currentUserModel']),
    ...mapGetters('planner', ['plan']),
    ...mapGetters('site', ['getOfficePhysicalAddress']),
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
    getDeterminedFinancialAdviserSignature() {
      const { profile } = this.currentUserModel;
      const signature = profile.signature_filename;
      return isEmpty(signature)
        ? null
        : require(`src/assets/signatures/${signature}`);
    },
  },
  components: {
    PrintableDialog,
  },
};
</script>
