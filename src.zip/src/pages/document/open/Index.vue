<template lang="pug">
q-layout
  q-page-container
    q-page(padding class="document-preview-wrapper")
      div(class="document-table-container q-mt-lg")
        div(class="row q-col-gutter-md comparison-table-wrapper")
          div(class="col-md-12")
            item-recommendations-table(
              v-if="reportsLoad"
              :values="reports"
              read-only
            )
</template>

<script>
import { mapActions } from 'vuex';
import { ItemRecommendationsTable } from 'src/components/ipp';

export default {
  name: 'open-document-preview',
  data: () => ({
    reports: {},
    reportsLoad: false,
  }),
  mounted() {
    this.$nextTick(() => {
      $('.document-preview-wrapper').css({
        width: '1280px',
        'max-width': '1280px',
      });
    });
  },
  async created() {
    this.reportsLoad = false;
    const { reportId, plannerId } = this.$route.params;
    const { data } = await this.getPlannerReport({ reportId, plannerId });
    this.reports = data;
    this.reportsLoad = true;
  },
  methods: mapActions('planner', ['getPlannerReport']),
  components: {
    ItemRecommendationsTable,
  },
};
</script>
