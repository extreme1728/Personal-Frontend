<template lang="pug">
q-page(padding class="classification-units-page")
  q-jumbotron(class="text-faded")
    div(class="text-h2") Classification Units
    div(class="text-subtitle1") Items defined directly to applications database.
    q-field(:helper="getSearchFieldHelper")
      q-input(
        autofocus
        clearable
        hide-underline
        v-model="query"
        placeholder="Search"
        class="q-my-md search--input"
      )
  div(
    class="row q-col-gutter-sm q-mt-md justify-around"
    v-for="(units, index) in visibleOptions"
    :key="index"
  )
    div(class="col-md-3 flex" v-for="unit in units")
      q-card(
        square
        :key="unit.id"
        class="full-width"
      )
        q-card-title {{ unit.name }}
        q-card-main(class="card-item-main")
          p Code: {{ unit.code }}
          p Created at: {{ unit.created_at }}
          p Last Modified At: {{ unit.updated_at }}
  q-page-scroller(position="bottom-right" :offset="[18, 18]")
    q-btn(fab color="primary" icon="keyboard_arrow_up")
</template>

<script>
import Fuse from 'fuse.js';
import { mapState } from 'vuex';
import { isEmpty, chunk } from 'lodash';
import { QInput } from 'src/components/quasar';

export default {
  name: 'classification-index',
  data: () => ({
    query: null,
  }),
  computed: {
    ...mapState('classificationUnit', {
      units: state => state.data,
    }),
    visibleOptions() {
      const CHUNK_SIZE = 4;
      const { units, query } = this;
      if (isEmpty(query)) return chunk(units, CHUNK_SIZE);
      const keys = ['code', 'name', 'id'];
      const fuse = new Fuse(units, { keys });
      const results = fuse.search(query);
      return chunk(results, CHUNK_SIZE);
    },
    getSearchFieldHelper() {
      const { units } = this;
      return `Search over ${units.length} items`;
    },
  },
  components: {
    QInput,
  },
};
</script>

<style lang="stylus">
.classification-units-page
  .search--input
    &.q-input
      font-size 3em !important
    .q-input-target
      height 2em !important
      color $tertiary
  .card-item-main p
      color $faded
      border-bottom 1px dotted $faded
</style>
