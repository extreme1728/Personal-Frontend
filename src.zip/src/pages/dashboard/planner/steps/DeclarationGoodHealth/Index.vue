<template lang="pug">
div
  q-tabs(
    align="center"
    class="text-secondary"
    v-model="currentTab"
  )
    include blocks/tab-navigation

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="sovereign-declaration")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/sovereign-details
        div(class="col-md-6")
          include blocks/partner/sovereign-details
    q-tab-panel(name="aia-declaration")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/aia-details
        div(class="col-md-6")
          include blocks/partner/aia-details
    q-tab-panel(name="fidelity-declaration")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/fidelity-details
        div(class="col-md-6")
          include blocks/partner/fidelity-details
    q-tab-panel(name="partners-life-declaration")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/partnerslife-details
        div(class="col-md-6")
          include blocks/partner/partnerslife-details
</template>

<script>
import { date } from 'quasar';
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { get, cloneDeep, eq, isEmpty } from 'lodash';
import DatePicker from 'src/components/datepicker/DatePicker';


export default {
  name: 'declaration-good-health',
  mixins: [FieldableMixin],
  data() {
    const currentTab = this.isEmployed
      ? 'sovereign-declarations'
      : 'aia-declarations';
    return {
      currentTab,
    };
  },
  props: {
    clientSignature: String,
    partnerSignature: String,
    guardianSignature: String,
    witnessSignature: String,
  },
  mounted() {
    const { clientSignature, partnerSignature, guardianSignature } = this;
    this.$nextTick().then(() => {
      if (!isEmpty(clientSignature))
        this.$refs['clientSignature'].fromDataURL(clientSignature);
      if (!isEmpty(partnerSignature))
        this.$refs['partnerSignature'].fromDataURL(partnerSignature);
      if (!isEmpty(guardianSignature))
        this.$refs['guardianSignature'].fromDataURL(guardianSignature);
      if (!isEmpty(witnessSignature))
        this.$refs['witnessSignature'].fromDataURL(witnessSignature);
    });
  },
  methods: {
    onSignatureClear(type) {
      this.$refs[`${type}Signature`].clear();
      // this.$emit('clear', type);
      this.$emit('save', { data: null, type });
    },
    onSignatureUndo(type) {
      this.$refs[`${type}Signature`].undo();
      this.$emit('undo', type);
    },
    onSignatureSave(type) {
      const { format } = this.signatureConfig;
      const data = this.$refs[`${type}Signature`].save(format);
      this.$emit('save', { data, type });
    },
  },
  computed: {
    ...mapGetters('planner', { hasClientIncome: 'hasClientIncome', }, [
      'isEmployed',
    ]),
    ...mapGetters('resources', [
      'signatureConfig',
      'booleanValues',
    ]),
    documentDateNow() {
      return date.formatDate(Date.now(), 'D MMM YYYY');
    },
  },
  components: {
    QInput,
    DatePicker,
  },
};
</script>

<style lang="stylus" scoped>
.remove__gap--margin-bottom
  margin-bottom -18px
.signature-container
  border 1px dotted $tertiary
  margin-top .5em
  margin-bottom .5em
  &.partner
    margin-top 1em
</style>
