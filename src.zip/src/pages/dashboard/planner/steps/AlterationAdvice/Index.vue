<template lang="pug">
div
  q-tabs(
    align="center"
    position="top"
    class="text-secondary"
    v-model="currentTab"
  )
    q-tab(
      name="alteration-advice"
      icon="verified_user"
      label="Fidelity Alteration Form"
    )
    q-tab(
      name="asteron-alteration"
      icon="security"
      label="Asteron Alteration Form"
    )
    q-tab(
      icon="chrome_reader_mode"
      name="general-alteration"
      label="General Alteration Form"
    )

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="alteration-advice")
      div(class="alteration-advice")
        div(class="row")
          div(class="col-md-12")
            h5(class="text-faded") I/We request that the policy be altered as follows:
        alteration-advice-policies(
          v-if="plan.alteration_advice.policies.length"
          :values="plan.alteration_advice.policies"
          @change="modifyArrayOfPolicies"
          @remove="onRemoveArrayOfPolicies"
        )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-2")
            q-input(label="Benefit..." v-model="policyModel.benefit")
          div(class="col-md-3")
            q-input(v-model="policyModel.from" label="Change from...")
          div(class="col-md-3")
            q-input(v-model="policyModel.to" label="To...")
          div(class="col-md-2")
            q-select(
              emit-value
              map-options
              label="Category"
              v-model="policyModel.category"
              :options="alterationAdviceTypesOptions"
            )
          div(class="col-md-2 q-mt-md")
            q-btn(
              :loading="addingArrayOfPolicy"
              @click="addArrayOfPolicy"
              class="full-width"
              color="primary"
              icon="add"
            )
        div(class="row q-col-gutter-md")
          div(class="col-md-12")
            date-picker(
              class="q-my-md"
              :value="plan.alteration_advice.effective_at"
              label="This alteration request will be effective on"
              @change="value => onModifyAlterationField(value, 'effective_at')"
            )
            q-input(
              prefix="$"
              type="tel"
              v-money="{}"
              align="right"
              class="q-my-md"
              debounce="500"
              label="The new annual premium will be"
              :value="plan.alteration_advice.new_annual_premium_amount"
              @input="value => onModifyAlterationField(value, 'new_annual_premium_amount')"
            )
        div(class="row q-col-gutter-md")
          div(class="col-md-12")
            p(class="text-faded") Payment frequency
            q-option-group(
              inline
              type="checkbox"
              class="q-my-md"
              :options="alterationAdvicePaymentFrequencyOptions"
              :value="plan.alteration_advice.payment_frequency"
              @input="value => onModifyAlterationField(value, 'payment_frequency')"
            )
            q-input(
              v-if="plan.alteration_advice.payment_frequency.includes('other')"
              class="q-my-md"
              label="Specify"
              debounce="500"
              :value="plan.alteration_advice.payment_frequentcy_other_description"
              @input="value => onModifyAlterationField(value, 'payment_frequentcy_other_description')"
            )
            q-select(
              emit-value
              map-options
              class="q-my-xs"
              label="Paying by Direct Debit"
              :options="alterationAdviceDirectDebitOptions"
              :value="plan.alteration_advice.paying_by_direct_debit_type"
              @input="value => onModifyAlterationField(value, 'paying_by_direct_debit_type')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            q-input(
              label="I understand and agree that this application, together with the Proposal shall be the basis of contract for the altered insurance. any endorsement, and/or terms and conditions on the current policy benefits will also apply to any change in those benefits unless otherwise by"
              debounce="500"
              :value="plan.alteration_advice.company_full_name"
              @input="value => onModifyAlterationField(value, 'company_full_name')"
            )
        transition-group(
          tag="div"
          class="row q-col-gutter-md"
          enter-active-class="animated fadeIn"
          leave-active-class="animated fadeOut"
          :appear="!!plan.alteration_advice.id"
        )
          div(class="col-md-6" key="generate")
            q-btn(
              class="full-width"
              color="primary"
              icon="picture_as_pdf"
              label="Generate"
              :loading="isFieldUpdating"
              @click="openURL(plan.preview_alteration_advices_url)"
            )
          div(class="col-md-6" key="download")
            q-btn(
              class="full-width"
              color="secondary"
              icon="cloud_download"
              label="Download"
              :loading="isFieldUpdating"
              @click="openURL(`${plan.preview_alteration_advices_url}/download`)"
            )
        div(class="row")
          div(class="col-md-12")
            generate-signature(
              :client-signature="clientSignature"
              :partner-signature="partnerSignature"
              @save="onHandleSignatureSave"
            )
    q-tab-panel(name="asteron-alteration")
      div(class="alteration-advice")
        div(class="row")
          div(class="col-md-12")
          h5(class="text-faded") Alteration Details:
        asteron-alteration-policies(
          v-if="plan.alteration_advice.policies.length"
          :values="plan.alteration_advice.policies"
          @change="modifyArrayOfPolicies"
          @remove="onRemoveArrayOfPolicies"
        )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            q-input(debounce="500" label="Policy Number" v-model="policyModel.number")
          div(class="col-md-6")
            q-input(debounce="500" label="Family Name" v-model="policyModel.family")
          div(class="col-md-6")
            q-input(debounce="500" label="Given Name" v-model="policyModel.given")
          div(class="col-md-3")
            q-input(debounce="500" label="Cover Name" v-model="policyModel.cover")
          div(class="col-md-3")
            q-input(prefix="$" type="tel" align="right" debounce="500" v-model="policyModel.fromMoney" label="Change from...")
          div(class="col-md-3")
            q-input(prefix="$" type="tel" align="right" debounce="500" v-model="policyModel.toMoney" label="To...")
          div(class="col-md-12 q-mt-md")
            q-btn(
              :loading="addingArrayOfPolicy"
              @click="addArrayOfPolicy"
              class="full-width"
              color="primary"
              icon="add"
            )
          div(class="col-md-6")
            date-picker(
              class="q-my-md"
              label="Alteration Date:"
              :value="plan.alteration_advice.date_asteron"
              @change="value => onModifyAlterationField(value, 'date_asteron')"
            )
          div(class="col-md-6")
            q-input(
              prefix="$"
              type="tel"
              v-money="{}"
              align="right"
              class="q-my-md"
              debounce="500"
              label="New Premium"
              :value="plan.alteration_advice.new_premium_amount"
              @input="value => onModifyAlterationField(value, 'new_premium_amount')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-6")
            q-input(
              class="q-my-md"
              label="Servicing Adviser's Name"
              debounce="500"
              :value="plan.alteration_advice.Servicing_Adviser_Name"
              @input="value => onModifyAlterationField(value, 'Servicing_Adviser_Name')"
            )
          div(class="col-md-6")
            q-input(
              class="q-my-md"
              label="Adviser's Name"
              debounce="500"
              :value="plan.alteration_advice.Adviser_Name"
              @input="value => onModifyAlterationField(value, 'Adviser_Name')"
            )
        transition-group(
          tag="div"
          class="row q-col-gutter-md"
          enter-active-class="animated fadeIn"
          leave-active-class="animated fadeOut"
          :appear="!!plan.alteration_advice.id"
        )
          div(class="col-md-6" key="generate")
            q-btn(
              class="full-width"
              color="primary"
              icon="picture_as_pdf"
              label="Generate"
              :loading="isFieldUpdating"
              @click="openURL(plan.preview_asteron_alteration_url)"
            )
          div(class="col-md-6" key="download")
            q-btn(
              class="full-width"
              color="secondary"
              icon="cloud_download"
              label="Download"
              :loading="isFieldUpdating"
              @click="openURL(`${plan.preview_asteron_alteration_url}/download`)"
            )
        div(class="row")
          div(class="col-md-12")
            generate-signature(
              :client-signature="clientSignature"
              :partner-signature="partnerSignature"
              @save="onHandleSignatureSave"
            )
    q-tab-panel(name="general-alteration")
      div(class="alteration-advice")
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Address:
            q-input(
              class="q-my-md"
              label="Client's Address"
              debounce="500"
              :value="plan.alteration_Address"
              @input="value => onModifyAlterationField(value, 'alteration_Address')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Date:
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Attn:
        div(class="row")
          div(class="col-md-12")
            h5(class="text-faded" align="center") Policy Alteration
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Policy: Risk Policy
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Life Assured:
            q-input(
              class="q-my-md"
              label="Client or Partner's Name"
              debounce="500"
              :value="plan.alteration_full_name"
              @input="value => onModifyAlterationField(value, 'alteration_full_name')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Date of Birth:
            date-picker(
              class="q-my-md"
              :value="plan.date_of_birth"
              @change="value => onModifyAlterationField(value, 'date_of_birth')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            h5(class="text-faded") Declaration and Signature
        div(class="row")
          div(class="col-md-12")
            h5(class="text-faded") I/we the owner/s of this policy wish to alter covers for [client name], effective immediately. Alterations to the cover is as follows:
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            date-picker(
              class="q-my-md"
              :value="plan.alteration_advice.effective_at"
              label="This alteration request will be effective on"
              @change="value => onModifyAlterationField(value, 'effective_at')"
            )
            q-input(
              prefix="$"
              type="tel"
              v-money="{}"
              align="right"
              class="q-my-md"
              debounce="500"
              label="The new annual premium will be"
              :value="plan.alteration_advice.new_annual_premium_amount"
              @input="value => onModifyAlterationField(value, 'new_annual_premium_amount')"
            )
        div(class="row q-my-md q-col-gutter-md")
          div(class="col-md-12")
            q-input(
              label="Please respect that I do not want to be contacted by [existing insurance provider] and/or our previous advisor in regards with this decision."
              debounce="500"
              :value="plan.alteration_advice.company_full_name"
              @input="value => onModifyAlterationField(value, 'company_full_name')"
            )
        transition-group(
          tag="div"
          class="row q-col-gutter-md"
          enter-active-class="animated fadeIn"
          leave-active-class="animated fadeOut"
          :appear="!!plan.alteration_advice.id"
        )
          div(class="col-md-6" key="generate")
            q-btn(
              class="full-width"
              color="primary"
              icon="picture_as_pdf"
              label="Generate"
              :loading="isFieldUpdating"
              @click="openURL(plan.preview_alteration_advices_url)"
            )
          div(class="col-md-6" key="download")
            q-btn(
              class="full-width"
              color="secondary"
              icon="cloud_download"
              label="Download"
              :loading="isFieldUpdating"
              @click="openURL(`${plan.preview_alteration_advices_url}/download`)"
            )
        div(class="row")
          div(class="col-md-12")
            generate-signature(
              :client-signature="clientSignature"
              :partner-signature="partnerSignature"
              @save="onHandleSignatureSave"
            )
</template>

<script>
import { uid, openURL } from 'quasar';
import { get, cloneDeep } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { mapGetters, mapActions } from 'vuex';
import { QInput } from 'src/components/quasar';
import { GenerateSignature } from 'src/components/ipp';
import DatePicker from 'src/components/datepicker/DatePicker';
import AlterationAdvicePolicies from './blocks/AlterationAdvicePolicies';
import AsteronAlterationPolicies from './blocks/AsteronAlterationPolicies';
import VueFriendlyIframe from 'vue-friendly-iframe';

const policySchema = {
  benefit: null,
  from: null,
  to: null,
  category: 'increase_or_addition',
};

export default {
  name: 'alteration-advice',
  mixins: [FieldableMixin],
  data: () => ({
    currentTab: 'alteration-advice',
    policyModel: cloneDeep(policySchema),
    addingArrayOfPolicy: false,
    isFieldUpdating: false,
  }),
  methods: {
    ...mapActions('planner', ['persistPlannerSignature']),
    openURL,
    async onModifyAlterationField(value, field) {
      try {
        this.isFieldUpdating = true;
        const payload = {
          ...this.plan.alteration_advice,
          ...{ [field]: value },
        };
        await this.updatePlanRelationField(payload, 'alteration_advice');
        this.$q.notify({
          message: 'Saved',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
      }
      catch (e) {}
      finally {
        this.isFieldUpdating = false;
      }
    },
    async onRemoveArrayOfPolicies(policy) {
      const policies = this
        .plan
        .alteration_advice
        .policies
        .filter(values => !([values].indexOf(policy) !== -1));
      const payload = {
        ...this.plan.alteration_advice,
        ...{ policies },
      };
      await this.updatePlanRelationField(payload, 'alteration_advice');
    },
    async modifyArrayOfPolicies(policies) {
      const payload = {
        ...this.plan.alteration_advice,
        ...{ policies },
      };
      await this.updatePlanRelationField(payload, 'alteration_advice');
    },
    async addArrayOfPolicy() {
      try {
        this.addingArrayOfPolicy = true;
        let { policyModel } = this;
        policyModel = { ...policyModel, ...{ uid: uid() } };
        const payload = {
          ...this.plan.alteration_advice,
          ...{ policies: this.plan.alteration_advice.policies.concat([policyModel]) },
        };
        await this.updatePlanRelationField(payload, 'alteration_advice');
        this.policyModel = cloneDeep(policySchema);
      }
      catch (e) {}
      finally {
        this.addingArrayOfPolicy = false;
      }
    },
    async onHandleSignatureSave({ data, type }) {
      this.$q.notify({
        message: 'Saving',
        color: 'primary',
        icon: 'save',
        timeout: 1000,
        position: 'top-right',
      });
      const payload = { planner_id: this.plan.id, stage: 'alteration_advice', type, value: data };
      const { data: response } = await this.persistPlannerSignature(payload);
      this.ASSIGN_PLANNER(response);
      this.ADD_PLANNER_COLLECTION(response);
      this.$q.notify({
        message: 'Saved',
        color: 'secondary',
        icon: 'check',
        timeout: 1000,
        position: 'top-right',
      });
    },
  },
  computed: {
    ...mapGetters('resources', [
      'alterationAdviceTypesOptions',
      'alterationAdviceDirectDebitOptions',
      'alterationAdvicePaymentFrequencyOptions',
    ]),
    ...mapGetters('planner', ['getDeterminedAlterationAdviceSignature']),
    clientSignature() {
      return get(this.getDeterminedAlterationAdviceSignature('client'), 'value', null);
    },
    partnerSignature() {
      return get(this.getDeterminedAlterationAdviceSignature('partner'), 'value', null);
    },
  },
  components: {
    QInput,
    DatePicker,
    GenerateSignature,
    AlterationAdvicePolicies,
    AsteronAlterationPolicies,
  },
};
</script>

<style lang="stylus" scoped>
.alteration-advice
  min-height 100vh
  max-width 90%
  width 90%
  margin-left auto
  margin-right auto
  display block
</style>
