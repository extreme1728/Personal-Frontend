<template lang="pug">
div
  transition-group(
    tag="div"
    class="row q-my-md q-col-gutter-md"
    :appear="!!values.length"
    enter-active-class="animated fadeIn"
    leave-active-class="animated fadeOut"
    v-for="(policy, index) in values"
    :key="index"
  )
    div(:key="`${index}-benefit`" class="q-mt-md col-md-2")
      q-input(
        float-label="Benefit..."
        :value="policy.benefit"
        @input="value => onModifyPolicy(value, policy, 'benefit')"
      )
    div(:key="`${index}-from`" class="q-mt-md col-md-3")
      q-input(
        float-label="Change from..."
        :value="policy.from"
        @input="value => onModifyPolicy(value, policy, 'from')"
      )
    div(:key="`${index}-to`" class="q-mt-md col-md-3")
      q-input(
        float-label="To..."
        :value="policy.to"
        @input="value => onModifyPolicy(value, policy, 'to')"
      )
    div(:key="`${index}-category`" class="q-mt-md col-md-2")
      q-select(
        float-label="Category"
        :value="policy.category"
        :options="alterationAdviceTypesOptions"
        @input="value => onModifyPolicy(value, policy, 'category')"
      )
    div(:key="`${index}-remove`" class="q-mt-md col-md-2")
      q-btn(
        icon="remove"
        color="red-5"
        class="full-width"
        @click="onRemovePolicy(policy)"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { set, cloneDeep, debounce } from 'lodash';

export default {
  name: 'alteration-advice-policies',
  props: {
    values: Array,
  },
  methods: {
    onRemovePolicy(policy) {
      this.$q.dialog({
        color: 'red-5',
        title: 'Remove policy',
        message: 'This action cannot be undone. Would you like to continue?',
        cancel: true,
      }).onOk(() => {
        this.$emit('remove', policy);
      });
    },
    onModifyPolicy: debounce(function (value, policy, field) {
      set(policy, field, value);
      this.$emit('change', this.values);
    }, 500),
  },
  computed: {
    ...mapGetters('resources', [
      'alterationAdviceTypesOptions',
      'alterationAdviceDirectDebitOptions',
      'alterationAdvicePaymentFrequencyOptions',
    ]),
  },
  components: {
    QInput,
  },
};
</script>
