<template lang="pug">
div
  transition-group(
    tag="div"
    class="row q-my-md q-col-gutter-md"
    :appear="!!values.length"
    enter-active-class="animated fadeIn"
    leave-active-class="animated fadeOut"
    v-for="(policy, index) in values"
    :key="index"
  )
    div(:key="`${index}-number`" class="q-mt-md col-md-12")
      q-input(
        float-label="Policy Number"
        :value="policy.number"
        @input="value => onModifyPolicy(value, policy, 'number')"
      )
    div(:key="`${index}-family`" class="q-mt-md col-md-6")
      q-input(
        float-label="Family Name"
        :value="policy.family"
        @input="value => onModifyPolicy(value, policy, 'family')"
      )
    div(:key="`${index}-given`" class="q-mt-md col-md-6")
      q-input(
        float-label="Given Name"
        :value="policy.given"
        @input="value => onModifyPolicy(value, policy, 'given')"
      )
    div(:key="`${index}-number`" class="q-mt-md col-md-3")
      q-input(
        float-label="Cover Name"
        :value="policy.cover"
        @input="value => onModifyPolicy(value, policy, 'cover')"
      )
    div(:key="`${index}-fromMoney`" class="q-mt-md col-md-3")
      q-input(
        float-label="Change from..."
        prefix="$"
        type="tel"
        align="right"
        debounce="500"
        :value="policy.fromMoney"
        @input="value => onModifyPolicy(value, policy, 'fromMoney')"
      )
    div(:key="`${index}-toMoney`" class="q-mt-md col-md-3")
      q-input(
        float-label="To..."
        prefix="$"
        type="tel"
        align="right"
        debounce="500"
        :value="policy.toMoney"
        @input="value => onModifyPolicy(value, policy, 'toMoney')"
      )
    q-field(:key="`${index}-remove`" class="q-mt-md col-md-12")
      q-btn(
        icon="remove"
        color="red-5"
        class="full-width"
        @click="onRemovePolicy(policy)"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { set, cloneDeep, debounce } from 'lodash';

export default {
  name: 'asteron-alteration-policies',
  props: {
    values: Array,
  },
  methods: {
    onRemovePolicy(policy) {
      this.$q.dialog({
        color: 'red-5',
        title: 'Remove policy',
        message: 'This action cannot be undone. Would you like to continue?',
        cancel: true,
      }).onOk(() => {
        this.$emit('remove', policy);
      });
    },
    onModifyPolicy: debounce(function (value, policy, field) {
      set(policy, field, value);
      this.$emit('change', this.values);
    }, 500),
  },
  computed: {
    ...mapGetters('resources', [
      'alterationAdviceTypesOptions',
      'alterationAdviceDirectDebitOptions',
      'alterationAdvicePaymentFrequencyOptions',
    ]),
  },
  components: {
    QInput,
  },
};
</script>
