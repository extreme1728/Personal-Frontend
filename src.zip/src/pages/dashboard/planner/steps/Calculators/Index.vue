<template lang="pug">
div
  q-tabs(
    align="center"
    v-model="currentTab"
    class="text-secondary"
  )
    q-tab(name="client" icon="star") {{ getClientName }}
    q-tab(name="partner" icon="favorite" v-show="hasPartnerExists") {{ getPartnerName }}

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="client")
      client-calculators(type="client")
    q-tab-panel(name="partner" v-if="hasPartnerExists")
      partner-calculators(type="partner")
</template>

<script>
import { FieldableMixin } from 'src/mixins';
import ClientCalculators from './blocks/ClientCalculators';
import PartnerCalculators from './blocks/PartnerCalculators';

export default {
  name: 'calculator-index',
  data: () => ({
    currentTab: 'client',
  }),
  extends: {
    computed: {
      ...FieldableMixin.computed,
    },
  },
  components: {
    ClientCalculators,
    PartnerCalculators,
  },
};
</script>
