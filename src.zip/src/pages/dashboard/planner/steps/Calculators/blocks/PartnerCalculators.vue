<template lang="pug">
div
  q-tab-panels(v-model="field" animated)
    q-tab-panel(:keep-alive="keepAlive" name="tpd")
      tpd(
        :current-name="getPartnerName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getClientCalculatorFields.getTpd"
        :payload="getPartnerCalculatorFields.getTpd"
        :youngest-child-age="getChildYoungestAge"
        :age="plan.partner_date_of_birth | getAgeByDate"
        :income="plan[getDeterminedIncomeProperty]"
        :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="life-cover")
      life-cover(
        :current-name="getPartnerName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getClientCalculatorFields.getLifeCover"
        :payload="getPartnerCalculatorFields.getLifeCover"
        :youngest-child-age="getChildYoungestAge"
        :income="plan[getDeterminedIncomeProperty]"
        :age="plan.partner_date_of_birth | getAgeByDate"
        :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="trauma-cover")
      trauma-cover(
        :current-name="getPartnerName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getClientCalculatorFields.getTraumaCover"
        :payload="getPartnerCalculatorFields.getTraumaCover"
        :age="plan.partner_date_of_birth | getAgeByDate"
        :income="plan[getDeterminedIncomeProperty]"
        :youngest-child-age="getChildYoungestAge"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="income-protection")
      income-protection(
        :income="plan[getDeterminedIncomeProperty]"
        :category="plan.partner_tax_issues_insurance_provider"
        :income-protection-agreed-amount="getNetIncomeTaxCalculation.incomeProtectionAgreedAmount"
        :income-protection-indemnity-amount="getNetIncomeTaxCalculation.incomeProtectionIndemnityAmount"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
        @category:change="value => updatePlanField(value, 'partner_tax_issues_insurance_provider')"
      )
    q-tab-panel(:keep-alive="keepAlive" name="mortgage-repayment-and-income-protection")
      mortgage-repayment-income-protection(
        :income="plan[getDeterminedIncomeProperty]"
        :payload="getPartnerCalculatorFields.getMortgageRepaymentAndIncomeProtection"
        :mortgage-repayment-amount="getCalculatedMortgageRepayment"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="mortgage-repayment-income-protection-and-hec")
      mortgage-repayment-income-protection-and-house-expense-cover(
        :income="partnerGrossIncome"
        :total-household-expense="householdExpenseTotalAmount"
        :mortgage-repayment-amount="getCalculatedMortgageRepayment"
        :payload="getPartnerCalculatorFields.getMortgageRepaymentIncomeProtectionAndHec"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="health-cover")
      health-cover(
        :type="type"
        :current-name="getPartnerName"
        :payload="getPartnerCalculatorFields.getHealthCover"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="tax")
      tax-calculator(
        @save="onHandleCalculatorPersist"
        :income="plan[getDeterminedIncomeProperty]"
        :payload="getPartnerCalculatorFields.getTax"
        :tax-calculation-result="getNetIncomeTaxCalculationForCalculator"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
      )

  q-separator

  q-tabs(
    v-model="field"
    align="justify"
    class="text-primary"
  )
    q-tab(name="tpd" icon="assessment")
      q-tooltip TPD
    q-tab(name="life-cover" icon="favorite_border")
      q-tooltip Life Cover
    q-tab(name="trauma-cover" icon="face")
      q-tooltip Trauma Cover
    q-tab(name="income-protection" icon="verified_user")
      q-tooltip Income Protection
    q-tab(name="mortgage-repayment-and-income-protection" icon="star_border")
      q-tooltip Mortgage Repayment and Income Protection
    q-tab(name="mortgage-repayment-income-protection-and-hec" icon="location_city")
      q-tooltip Mortgage Repayment Income Protection and House Expense Cover
    q-tab(name="health-cover" icon="local_hospital")
      q-tooltip Health Cover
    q-tab(name="tax" icon="attach_money")
      q-tooltip Tax Calculator
</template>

<script>
import { mapGetters } from 'vuex';
import BaseCalculator from './BaseCalculator';
import { upperFirst, camelCase } from 'lodash';

export default {
  name: 'partner-calculators',
  extends: BaseCalculator,
  computed: {
    ...mapGetters('planner', [
      'isPartnerEmployed',
      'partnerGrossIncome',
      'getClientCalculatorFields',
      'getPartnerCalculatorFields',
      'householdExpenseTotalAmount',
    ]),
    ...mapGetters('partnerCalculations', [
      'getNetIncomeTaxCalculation',
      'getFatalEntitlementCalculations',
      'getNetIncomeTaxCalculationForCalculator',
    ]),
    getRecentValuesPayload() {
      const alias = upperFirst(camelCase(this.oldField));
      const payload = this.getPartnerCalculatorFields[`get${alias}`];
      return { alias, payload };
    },
    getDeterminedIncomeProperty() {
      return this.isPartnerEmployed
        ? 'partner_annual_income'
        : 'partner_taking_from_the_firm';
    },
  },
};
</script>
