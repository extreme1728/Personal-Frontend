import { eq, snakeCase } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { mapGetters, mapActions } from 'vuex';
import * as CalculatorComponents from 'src/components/ipp/calculators';

export default {
  data: () => ({
    field: 'tpd',
    oldField: null,
  }),
  mixins: [FieldableMixin],
  props: {
    keepAlive: {
      type: Boolean,
      default: false,
    },
    type: String,
  },
  watch: {
    field: {
      handler(newVal, oldVal) {
        this.oldField = oldVal || newVal;
      },
      immediate: true,
    },
  },
  methods: {
    ...mapActions('planner', ['persistPlannerCalculator']),
    onHandleCalculatorPersist(
      payload,
      field,
      type = this.type,
      id = this.plan.id,
    ) {
      if (!id) this.onHandlePersist();
      this.$q.notify({
        message: 'Saving Calculations',
        color: 'amber',
        icon: 'save',
        timeout: 1000,
        position: 'top-right',
      });
      this.persistPlannerCalculator({
        id,
        type,
        payload,
        field: snakeCase(field),
      }).then(({ data }) => {
        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);
        this.$q.notify({
          message: 'Calculations Saved',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      }).catch((e) => {
        this.$q.notify({
          message: e,
          color: 'negative',
          icon: 'error',
          timeout: 1000,
          position: 'top-right',
        });
      });
      if (eq(field, 'mortgage-repayment-income-protection-and-hec')) {
        this.$q.notify({
          message: 'Please note the build-in TPD Benefits is tiered down <br> for payment terms of less than 2 years',
          color: 'amber',
          icon: 'save',
          timeout: 7000,
          position: 'top-right',
          html: true,
        });
      }
    },
  },
  computed: mapGetters('planner', {
    getChildYoungestAge: 'getChildYoungestAge',
    getCalculatedMortgageRepayment: 'getCalculatedMortgageRepayment',
  }),
  components: CalculatorComponents,
};
