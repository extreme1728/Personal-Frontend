<template lang="pug">
div
  q-tab-panels(v-model="field" animated)
    q-tab-panel(:keep-alive="keepAlive" name="tpd")
      tpd(
        :current-name="getClientName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getPartnerCalculatorFields.getTpd"
        :payload="getClientCalculatorFields.getTpd"
        :income="plan[getDeterminedIncomeProperty]"
        :youngest-child-age="getChildYoungestAge"
        :age="plan.client_date_of_birth | getAgeByDate"
        :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="life-cover")
      life-cover(
        :current-name="getClientName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getPartnerCalculatorFields.getLifeCover"
        :payload="getClientCalculatorFields.getLifeCover"
        :income="plan[getDeterminedIncomeProperty]"
        :youngest-child-age="getChildYoungestAge"
        :age="plan.client_date_of_birth | getAgeByDate"
        :changes-in-cover="(getFatalEntitlementCalculations && getFatalEntitlementCalculations.changesInCoverAmount) || 0"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="trauma-cover")
      trauma-cover(
        :current-name="getClientName"
        :recent-values-payload="getRecentValuesPayload"
        :sync-from-payload="getPartnerCalculatorFields.getTraumaCover"
        :payload="getClientCalculatorFields.getTraumaCover"
        :youngest-child-age="getChildYoungestAge"
        :age="plan.client_date_of_birth | getAgeByDate"
        :income="plan[getDeterminedIncomeProperty]"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="income-protection")
      income-protection(
        :income="plan[getDeterminedIncomeProperty]"
        :category="plan.client_tax_issues_insurance_provider"
        :income-protection-agreed-amount="getNetIncomeTaxCalculation.incomeProtectionAgreedAmount"
        :income-protection-indemnity-amount="getNetIncomeTaxCalculation.incomeProtectionIndemnityAmount"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
        @category:change="value => updatePlanField(value, 'client_tax_issues_insurance_provider')"
      )
    q-tab-panel(:keep-alive="keepAlive" name="mortgage-repayment-and-income-protection")
      mortgage-repayment-income-protection(
        :income="plan[getDeterminedIncomeProperty]"
        :payload="getClientCalculatorFields.getMortgageRepaymentAndIncomeProtection"
        :mortgage-repayment-amount="getCalculatedMortgageRepayment"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="mortgage-repayment-income-protection-and-hec")
      mortgage-repayment-income-protection-and-house-expense-cover(
        :income="clientGrossIncome"
        :total-household-expense="householdExpenseTotalAmount"
        :mortgage-repayment-amount="getCalculatedMortgageRepayment"
        :payload="getClientCalculatorFields.getMortgageRepaymentIncomeProtectionAndHec"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="health-cover")
      health-cover(
        :type="type"
        :current-name="getClientName"
        :payload="getClientCalculatorFields.getHealthCover"
        @save="onHandleCalculatorPersist"
      )
    q-tab-panel(:keep-alive="keepAlive" name="tax")
      tax-calculator(
        @save="onHandleCalculatorPersist"
        :income="plan[getDeterminedIncomeProperty]"
        :payload="getClientCalculatorFields.getTax"
        :tax-calculation-result="getNetIncomeTaxCalculationForCalculator"
        @income:change="value => updatePlanField(value, getDeterminedIncomeProperty)"
      )

  q-separator

  q-tabs(
    v-model="field"
    align="justify"
    class="text-primary"
  )
    q-tab(name="tpd" icon="assessment")
      q-tooltip TPD
    q-tab(name="life-cover" icon="favorite_border")
      q-tooltip Life Cover
    q-tab(name="trauma-cover" icon="face")
      q-tooltip Trauma Cover
    q-tab(name="income-protection" icon="verified_user")
      q-tooltip Income Protection
    q-tab(name="mortgage-repayment-and-income-protection" icon="star_border")
      q-tooltip Mortgage Repayment and Income Protection
    q-tab(name="mortgage-repayment-income-protection-and-hec" icon="location_city")
      q-tooltip Mortgage Repayment Income Protection and House Expense Cover
    q-tab(name="health-cover" icon="local_hospital")
      q-tooltip Health Cover
    q-tab(name="tax" icon="attach_money")
      q-tooltip Tax Calculator
</template>

<script>
import { mapGetters } from 'vuex';
import BaseCalculator from './BaseCalculator';
import { upperFirst, camelCase } from 'lodash';

export default {
  name: 'client-calculators',
  extends: BaseCalculator,
  computed: {
    ...mapGetters('planner', [
      'isEmployed',
      'clientGrossIncome',
      'getClientCalculatorFields',
      'getPartnerCalculatorFields',
      'householdExpenseTotalAmount',
    ]),
    ...mapGetters('clientCalculations', [
      'getNetIncomeTaxCalculation',
      'getFatalEntitlementCalculations',
      'getNetIncomeTaxCalculationForCalculator',
    ]),
    getRecentValuesPayload() {
      const alias = upperFirst(camelCase(this.oldField));
      const payload = this.getClientCalculatorFields[`get${alias}`];
      return { alias, payload };
    },
    getDeterminedIncomeProperty() {
      return this.isEmployed
        ? 'employed_annual_income'
        : 'income_from_business';
    },
  },
};
</script>
