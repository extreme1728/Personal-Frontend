<template lang="pug">
div
  div
    key-person-covers(
      v-if="plan.key_persons && plan.key_persons.length"
      :values="plan.key_persons"
      @remove="onHandleRemovePerson"
      @change="onHandleChangeKeyPersons"
    )
    div(class="q-pt-lg text-center" v-else)
      p
        img(
          src="~assets/sad.svg"
          style="width:30vw; max-width:150px;"
        )
      p(class="text-faded") No key person found yet...
      q-btn(
        color="cyan"
        label="Add"
        style="width: 200px"
        @click="keyPersonCoverModalShow = true"
      )
  include modals/key-person
  q-page-sticky(position="bottom-left" :offset="[18, 90]")
    q-btn(
      round
      size="lg"
      icon="add"
      color="cyan"
      v-show="showCreateKeyPerson"
      @click="keyPersonCoverModalShow = true"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { validationMixin } from 'vuelidate';
import { QInput } from 'src/components/quasar';
import { floatTotals } from 'src/config/utils';
import { required } from 'vuelidate/lib/validators';
import { KeyPersonCovers } from 'src/components/ipp/planner';
import DatePicker from 'src/components/datepicker/DatePicker';
import { cloneDeep, eq, isArray, last, merge, uniqBy } from 'lodash';
import { FieldableMixin, KeyPersonCoverMixin, ModalToggleMixin } from 'src/mixins';

const keyPersonCoverSchema = {
  id: 0,
  name: null,
  role_in_business: null,
  date_of_birth: (new Date),
  smoking_status: null,
  income: null,
  payment_frequency: null,
  gross_income: null,
  income_percentage: 1,
  insurance_calculations: [],
  income_needing_to_be_protected: null,
  notes: null,
};

export default {
  name: 'key-person-cover-tab',
  mixins: [
    FieldableMixin,
    validationMixin,
    ModalToggleMixin,
    KeyPersonCoverMixin,
  ],
  inject: {
    tabProvider: {
      from: 'data',
      default() {
        return { tabName: 'key-person-cover' };
      },
    },
  },
  data: () => ({
    loading: false,
    othersSelected: false,
    keyPersonCoverModalShow: false,
    keyPersonCoverModel: cloneDeep(keyPersonCoverSchema),
  }),
  mounted() {
    this.$v.keyPersonCoverModel.$touch();
  },
  methods: {
    handleModalOnShow() {
      const models = this.plan.key_persons;
      if (models && models.length) {
        const { gross_income, payment_frequency } = last(models);
        this.keyPersonCoverModel = merge(this.keyPersonCoverModel, { gross_income, payment_frequency });
      }
      this.__modalOnShow();
    },
    handleKeyPersonListOnChange(value) {
      if (!this.othersSelected) {
        try {
          const payload = this.getPersonsListDataInPlanners(value);
          if (payload) {
            const { income, smoking_status, date_of_birth } = payload;
            this.keyPersonCoverModel = merge(this.keyPersonCoverModel, { income, smoking_status, date_of_birth });
          }
        }
        catch (e) {}
      }
      this.keyPersonCoverModel.name = value;
    },
    async handleUpdateKeyPersons(people = this.plan.key_persons) {
      /**
       * Regardless any action/modification did by the user
       * We will loop through the values and update the details
       * If there are matching (name) mapped in the application
       */
      let values = [];

      people.forEach(({ name, income, date_of_birth, smoking_status }) => {
        if (eq(name, this.plan.client_full_name)) {
          values.push({
            client_full_name: name,
            client_smoking_status: smoking_status,
            client_date_of_birth: date_of_birth,
            income_from_business: income,
          });
        }
        if (eq(name, this.plan.partner_name)) {
          values.push({
            partner_name: name,
            partner_smoking_status: smoking_status,
            partner_date_of_birth: date_of_birth,
            partner_taking_from_the_firm: income,
          });
        }
      });

      // Avoiding to override client details based on n+1 key person instance
      values = uniqBy(values, 'client_full_name');

      await values.reduce(async (promise, payload) => {
        await promise;
        await this.updatePlanField(payload);
      }, Promise.resolve());
    },
    async addArrayOfKeyPersons() {
      try {
        this.loading = true;
        await this.updatePlanRelationField(
          [...this.plan.key_persons, ...[this.keyPersonCoverModel]],
          'key_persons'
        );
        this.keyPersonCoverModel = cloneDeep(keyPersonCoverSchema);
        this.keyPersonCoverModalShow = false;
        await this.handleUpdateKeyPersons();
      }
      catch (e) {}
      finally {
        this.loading = false;
      }
    },
    async onHandleChangeKeyPersons(people) {
      await this.updatePlanRelationField(people, 'key_persons');
      await this.handleUpdateKeyPersons();
    },
    async onHandleRemovePerson(person) {
      await this.removePlanRelationInstanceField(person, 'key_persons');
    },
    incomeNeedingToBeProtectedHandler() {
      const { income, payment_frequency } = this.keyPersonCoverModel;
      const value =this.getIncomeNeedingToBeProtected(income, payment_frequency);
      this.keyPersonCoverModel.income_needing_to_be_protected = value;
    },
  },
  computed: {
    ...mapGetters('planner', [
      'getPersonsListInPLanners',
      'getPersonsListDataInPlanners',
    ]),
    isKeyPersonCoverTab() {
      return eq(this.tabProvider.tabName, 'key-person-cover');
    },
    getMaxiumGrossIncomePercentage() {
      const totals = [];
      this.plan.key_persons.forEach(({ income_percentage }) => {
        totals.push(income_percentage);
      });
      const value = (100 - floatTotals(totals));
      return (value === 1) ? 0 : value;
    },
    showCreateKeyPerson() {
      return this.isKeyPersonCoverTab
        && window.Boolean(this.getMaxiumGrossIncomePercentage);
    }
  },
  validations() {
    return {
      keyPersonCoverModel: {
        name: {
          required,
        },
        income: {
          required,
        },
        gross_income: {
          required,
        },
      },
    };
  },
  components: {
    QInput,
    DatePicker,
    KeyPersonCovers,
  },
};
</script>
