<template lang="pug">
  div
    buy-and-sells(
      class="q-mt-sm"
      v-if="plan.buy_and_sells && plan.buy_and_sells.length"
      :values="plan.buy_and_sells"
      :key-persons="plan.key_persons"
      @change="onHandleChangeBuyAndSells"
      @remove="onHandleRemoveBuyAndSell"
    )
    div(class="q-pt-lg text-center" v-else)
      p
        img(
          src="~assets/sad.svg"
          style="width:30vw; max-width:150px;"
        )
      p(class="text-faded") No buy and sell person found yet...
      q-btn(
        label="Add"
        color="amber"
        style="width: 200px"
        @click="buyAndSellModalShow = true"
      )
    include modals/buy-and-sell
    q-page-sticky(position="bottom-left" :offset="[18, 90]")
      q-btn(
        round
        size="lg"
        icon="add"
        color="amber"
        v-show="isBuyAndSellTab"
        @click="buyAndSellModalShow = true"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { validationMixin } from 'vuelidate';
import { QInput } from 'src/components/quasar';
import { cloneDeep, last, merge } from 'lodash';
import { required } from 'vuelidate/lib/validators';
import DatePicker from 'src/components/datepicker/DatePicker';
import { ShareHoldersList, BuyAndSells } from 'src/components/ipp/planner';
import { FieldableMixin, BuyAndSellMixin, ModalToggleMixin } from 'src/mixins';

const buyAndSellSchema = {
  id: 0,
  business_valuation: null,
  life_assured: null,
  date_of_birth: (new Date()),
  smoking_status: null,
  income: null,
  owner_of_shares: [],
  percentage_needed: 1,
  person_purchasing_share: [],
  sum_assured: null,
  notes: null,
  any_other_siblings: null,
  required_for_other_siblings: null,
  name_of_siblings: [],
};

export default {
  name: 'buy-and-sell-tab',
  mixins: [
    FieldableMixin,
    BuyAndSellMixin,
    validationMixin,
    ModalToggleMixin,
  ],
  inject: {
    tabProvider: {
      from: 'data',
      default() {
        return { tabName: 'buy-and-sell' };
      },
    },
  },
  data: () => ({
    loading: false,
    buyAndSellModalShow: false,
    buyAndSellModel: cloneDeep(buyAndSellSchema),
    others: {
      life_assured: false,
      owner_of_shares: false,
      person_purchasing_share: false,
    },
  }),
  mounted() {
    this.$v.buyAndSellModel.$touch();
  },
  methods: {
    handleModalOnShow() {
      const models = this.plan.buy_and_sells;
      if (models && models.length) {
        const { business_valuation } = last(models);
        this.buyAndSellModel = merge(this.buyAndSellModel, { business_valuation });
      }
      this.__modalOnShow();
    },
    handleBuyAndSellPersonListOnChange(value) {
      const { life_assured: isLifeAssuredOthers } = this.others;
      if (!isLifeAssuredOthers) {
        try {
          const payload = this.getPersonsListDataInPlanners(value);
          if (payload) {
            const { income, smoking_status, date_of_birth } = payload;
            this.buyAndSellModel = merge(this.buyAndSellModel, { income, smoking_status, date_of_birth });
          }
        }
        catch (e) {}
      }
      this.buyAndSellModel.life_assured = value;
    },
    async addArrayOfBuyAndSells() {
      try {
        this.loading = true;
        await this.updatePlanRelationField(
          [...this.plan.buy_and_sells, ...[this.buyAndSellModel]],
          'buy_and_sells'
        );
        this.buyAndSellModel = cloneDeep(buyAndSellSchema);
        this.buyAndSellModalShow = false;
      }
      catch (e) {}
      finally {
        this.loading = false;
      }
    },
    async onHandleChangeBuyAndSells(models) {
      await this.updatePlanRelationField(models, 'buy_and_sells');
    },
    async onHandleRemoveBuyAndSell(model) {
      await this.removePlanRelationInstanceField(model, 'buy_and_sells');
    },
    sumASsuredHandler() {
      const { business_valuation, percentage_needed } = this.buyAndSellModel;
      this.buyAndSellModel.sum_assured = this.getCalculatedSumAssured(business_valuation, percentage_needed);
    },
  },
  computed: {
    ...mapGetters('planner', [
      'getPersonsListInPLanners',
      'getPersonsListDataInPlanners',
    ]),
    isBuyAndSellTab() {
      return this.tabProvider.tabName.includes('buy-and-sell');
    },
  },
  validations() {
    return {
      buyAndSellModel: {
        life_assured: {
          required,
        },
        business_valuation: {
          required,
        },
      },
    };
  },
  components: {
    QInput,
    DatePicker,
    BuyAndSells,
    ShareHoldersList,
  },
};
</script>
