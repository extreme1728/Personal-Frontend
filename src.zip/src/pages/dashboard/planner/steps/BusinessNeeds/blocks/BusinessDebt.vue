<template lang="pug">
q-card(flat)
  q-card-section
    q-input(
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      debounce="500"
      class="q-my-md"
      :readonly="readonly"
      label="Business Debt"
      :value="plan.business_debt.debt"
      @input="_ => updatePlanBusinessDebtField(_, 'debt')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :readonly="readonly"
      :options="booleanValues"
      label="Are there any Personal Guarantees in place?"
      :value="plan.business_debt.personal_guarantees_in_place"
      @input="_ => updatePlanBusinessDebtField(_, 'personal_guarantees_in_place')"
    )
    q-input(
      v-if="plan.business_debt.personal_guarantees_in_place === 'yes'"
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      class="q-my-md"
      :readonly="readonly"
      label="Personal Guarantee Value"
      :value="plan.business_debt.personal_guarantee_value"
      @input="_ => updatePlanBusinessDebtField(_, 'personal_guarantee_value')"
    )
    q-select(
      emit-value
      map-options
      :color="color"
      class="q-my-md"
      :readonly="readonly"
      :options="booleanValues"
      hint="eg's Lease of building"
      label="Any long term contracts?"
      :value="plan.business_debt.any_long_term_contracts"
      @input="_ => updatePlanBusinessDebtField(_, 'any_long_term_contracts')"
    )
    div(v-if="plan.business_debt.any_long_term_contracts === 'yes'")
      div(
        class="row q-col-gutter-md q-my-md"
        v-for="(contract, index) in plan.business_debt.contract_categories"
        :class="{ 'q-my-md' : index !== 0 }"
        :key="contract.id"
      )
        div(:class="getDeterminedCategoryColumnClass")
          q-select(
            use-input
            emit-value
            map-options
            label="Category"
            hide-dropdown-icon
            input-debounce="0"
            :readonly="readonly"
            new-value-mode="add-unique"
            :value="contract.category_name"
            :options="contractCategoriesOptions"
            @input="value => modifyBusinessDebtContract(value, contract, 'category_name')"
          )
        div(:class="getDeterminedCategoryColumnClass")
          q-input(
            type="number"
            debounce="500"
            :readonly="readonly"
            label="How many years"
            :value="contract.how_many_years"
            @input="value => modifyBusinessDebtContract(value, contract, 'how_many_years')"
          )
        div(:class="getDeterminedCategoryColumnClass")
          q-input(
            prefix="$"
            type="tel"
            align="right"
            v-money="{}"
            debounce="500"
            :readonly="readonly"
            label="Contract value per year"
            :value="contract.contract_value_per_year"
            @input="value => modifyBusinessDebtContract(value, contract, 'contract_value_per_year')"
          )
        div(class="col-md-3 q-my-md" v-if="!readonly")
          q-btn(
            icon="remove"
            class="full-width"
            color="secondary"
            @click="removeBusinessDebtContract(contract)"
          )
      div(class="row q-col-gutter-md" v-if="!readonly")
        div(class="col-md-3")
          q-select(
            use-input
            emit-value
            map-options
            label="Category"
            input-debounce="0"
            hide-dropdown-icon
            new-value-mode="add-unique"
            hint="Press Enter to create new value"
            :options="contractCategoriesOptions"
            v-model="contractCategoryModel.category_name"
          )
        div(class="col-md-3")
          q-input(
            type="number"
            label="How many years"
            v-model="contractCategoryModel.how_many_years"
          )
        div(class="col-md-3")
          q-input(
            prefix="$"
            type="tel"
            align="right"
            v-money="{}"
            label="Contract value per year"
            v-model="contractCategoryModel.contract_value_per_year"
          )
        div(class="col-md-3 q-my-md")
          q-btn(
            icon="add"
            color="primary"
            class="full-width"
            @click="addArrayOfBusinessDebtCategories"
          )
    q-input(
      readonly
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      label="Total"
      class="q-my-md"
      :value="getBusinessDebCalculation | numberComma"
    )
    q-input(
      :rows="4"
      label="Notes"
      type="textarea"
      class="q-my-md"
      debounce="500"
      :max-height="100"
      :readonly="readonly"
      :value="plan.business_debt.notes"
      @input="_ => updatePlanBusinessDebtField(_, 'notes')"
    )
</template>

<script>
import { uid } from 'quasar';
import { mapGetters } from 'vuex';
import { validationMixin } from 'vuelidate';
import { QInput } from 'src/components/quasar';
import { required } from 'vuelidate/lib/validators';
import { FieldableMixin, FilterableMixin } from 'src/mixins';
import { numberWithCommas, floatTotals } from 'src/config/utils';
import { map, eq, cloneDeep, merge, set, isArray } from 'lodash';

const businessDebtContractCategorySchema = {
  id: 0,
  category_name: null,
  how_many_years: 1,
  contract_value_per_year: null,
};

export default {
  name: 'business-debt',
  mixins: [FieldableMixin, FilterableMixin, validationMixin],
  data: () => ({
    businessDebtModel: {},
    contractCategoryModel: cloneDeep(businessDebtContractCategorySchema),
  }),
  created() {
    this.businessDebtModel = this.plan.business_debt;
  },
  mounted() {
    this.$v.contractCategoryModel.$touch();
  },
  props: {
    readonly: {
      type: Boolean,
      default: false,
    },
    color: {
      type: String,
      default: 'primary',
    },
  },
  methods: {
    async persistBusinessDebtModel(values = this.businessDebtModel) {
      const { business_debt } = await this.updatePlanRelationField(
        cloneDeep(values),
        'business_debt'
      );
      this.businessDebtModel = business_debt;
    },
    async updatePlanBusinessDebtField(value, field) {
      set(this, ['businessDebtModel', field], value);
      await this.persistBusinessDebtModel();
    },
    async modifyBusinessDebtContract(value, contract, field) {
      set(contract, field, value);
      await this.persistBusinessDebtModel();
    },
    async removeBusinessDebtContract(contract) {
      try {
        await this.$q.dialog({
          title: 'Prompt',
          message: 'This action cannot be undone and will result of losing data.',
          cancel: true,
        });
        this.businessDebtModel.contract_categories.splice(this.businessDebtModel.contract_categories.indexOf(contract), 1);
        await this.persistBusinessDebtModel();
      }
      catch (e) {}
    },
    async addArrayOfBusinessDebtCategories() {
      this.businessDebtModel.contract_categories.push(merge(
        cloneDeep(this.contractCategoryModel),
        { id: uid() },
      ));
      this.contractCategoryModel = cloneDeep(businessDebtContractCategorySchema);
      await this.persistBusinessDebtModel();
    },
  },
  computed: {
    ...mapGetters('resources', ['contractCategoriesOptions', 'booleanValues']),
    getBusinessDebCalculation() {
      const {
        debt,
        personal_guarantee_value,
        personal_guarantees_in_place,
        any_long_term_contracts,
        contract_categories,
      } = this.plan.business_debt;

      let termContractsTotal = 0;

      if (eq(any_long_term_contracts, 'yes') && (isArray(contract_categories) && contract_categories.length)) {
        map(contract_categories, ({ contract_value_per_year, how_many_years }) => {
          termContractsTotal += (numberWithCommas(contract_value_per_year, false) * how_many_years);
        });
      }

      const guaranteeTotal = eq(personal_guarantees_in_place, 'yes') ? numberWithCommas(personal_guarantee_value, false) : 0;

      const values = map([
        debt,
        guaranteeTotal,
        termContractsTotal ], amount => numberWithCommas(amount, false));

      return floatTotals(values);
    },
    getDeterminedCategoryColumnClass() {
      return this.readonly ? 'col-md-4' : 'col-md-3';
    },
  },
  validations() {
    return {
      contractCategoryModel: {
        category_name: {
          required,
        },
        contract_value_per_year: {
          required,
        },
      },
    };
  },
  components: {
    QInput,
  },
};
</script>
