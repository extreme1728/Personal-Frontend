<template lang="pug">
div
  q-tabs(
    align="center"
    class="text-secondary"
    v-model="currentTab"
  )
    q-tab(name="key-person-cover" icon="person_outline") Key Person Cover
    q-tab(name="buy-and-sell" icon="money") Buy and Sell
    q-tab(name="business-debt" icon="payment") Business Debt

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="key-person-cover")
      key-person-cover-tab
    q-tab-panel(name="buy-and-sell")
      buy-and-sell-tab
    q-tab-panel(name="business-debt")
      div(class="q-mt-sm")
        business-debt
</template>

<script>
import BuyAndSellTab from './blocks/BuyAndSellTab';
import BusinessDebt from './blocks/BusinessDebt';
import KeyPersonCoverTab from './blocks/KeyPersonCoverTab';

export default {
  name: 'business-needs',
  data: () => ({
    currentTab: 'key-person-cover',
  }),
  components: {
    BusinessDebt,
    BuyAndSellTab,
    KeyPersonCoverTab,
  },
};
</script>
