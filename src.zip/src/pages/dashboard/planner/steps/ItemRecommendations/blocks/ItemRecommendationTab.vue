<template lang="pug">
div
  div(class="row q-my-md justify-center")
    div(class="offset-md-1 col-md-10")
      q-option-group(
        inline
        type="radio"
        label="Category"
        :options="getReportCategories"
        v-model="itemRecommendationModel.category"
        :error="$v.itemRecommendationModel.category.$error"
      )
  div(class="row q-col-gutter-xs" v-show="!$v.itemRecommendationModel.category.$error")
    div(class="col-md-6" v-show="!isPreAndPostUnderwriting")
      item-recommendations-inputs(
        type="existing"
        :force="force.existing"
        @change:force="_ => force.existing = _"
        @change:item="handleOnAddItemRecommendation"
      )
    div(class="col-md-6")
      item-recommendations-inputs(
        :title="isPreAndPostUnderwriting ? 'Pre-Underwriting' : 'proposed'"
        type="proposed"
        :force="force.proposed"
        @change:force="_ => force.proposed = _"
        @change:item="_ => handleOnAddItemRecommendation(_, 'proposed')"
      )
    div(class="col-md-6" v-show="isPreAndPostUnderwriting")
      item-recommendations-inputs(
        title="Post Underwriting"
        type="underwriting"
        :force="force.underwriting"
        @change:force="_ => force.underwriting = _"
        @change:item="_ => handleOnAddItemRecommendation(_, 'underwriting')"
      )
  div(class="row q-my-md" v-show="showUpdate")
    q-uploader(
      multiple
      send-raw
      class="col-md-12"
      label="Attach Images"
      :filter="__uploadFilter"
      extensions=".jpg,.jpeg,.png"
      @added="files => images = files"
      @removed="__uploadRemoveCancel"
      @uploading="(files, xhr) => __uploadImage(__uploadImageitemRecommendationModel)"
    )
    //- div(class="col-md-4 q-mt-md")
    //-   q-btn(
    //-     label="Upload"
    //-     color="primary"
    //-     class="full-width"
    //-     icon="cloud_upload"
    //-     :loading="imageUploadLoading"
    //-     @click="__uploadImage(itemRecommendationModel)"
    //-   )
  div(class="row" v-show="showSaveAs")
    item-recommendations-comment-input(
      class="offset-md-1 col-md-10"
      :value="itemRecommendationModel.comments"
      @change="_ => itemRecommendationModel.comments = _"
    )
  div(class="row q-my-md" v-show="shouldShowReasons")
    div(class="offset-md-1 col-md-10")
      q-input(
        icon="edit"
        type="textarea"
        :max-height="170"
        v-model="itemRecommendationModel.reasons"
        label="Reason/s for replacement of existing cover"
      )
  div(class="row q-my-md comparison-table-wrapper")
    div(class="col-md-12")
      item-recommendations-table(
        v-show="loadTable"
        show-partner-values
        :is-pre-and-post-underwriting="isPreAndPostUnderwriting"
        ref="$ItemRecommendationsTable"
        :values="itemRecommendationModel"
        :partner-name="plan.partner_name"
        @change="_ => itemRecommendationModel = _"
      )
  item-recommendations-images-view(
    :report="itemRecommendationModel"
    :show="showImageViewDialog"
    @change="__updateImage"
    @remove="__removeImage"
    @cancel="showImageViewDialog = false"
  )
  item-recommendations-save-dialog(
    v-if="showSaveDialog"
    :show="showSaveDialog"
    :disable="reportSaving"
    @save="handleReportSaveAs"
    :value="itemRecommendationModel"
    @cancel="showSaveDialog = false"
  )
  item-recommendations-reports-view(
    :reports="plan.reports"
    :show="showReportViewDialog"
    @remove="handleReportRemove"
    @select="handleReportSelect"
    @change="handleReportUpdate"
    @cancel="showReportViewDialog = false"
  )
  //- q-page-sticky(position="bottom-right" :offset="[18, 90]")
  //-   q-btn(
  //-     fab
  //-     color="primary"
  //-     class="animate-pop"
  //-     icon="keyboard_arrow_up"
  //-     v-back-to-top.animate="{ offset: 500, duration: 200 }"
  //-   )
  q-page-sticky(
    v-if="showUpdate && itemRecommendationModel.images && itemRecommendationModel.images.length"
    position="bottom-left"
    :offset="[18, 90]"
  )
    q-btn(
      fab
      color="cyan"
      icon="photo_library"
      @click="showImageViewDialog = true"
    )
  q-page-sticky(position="bottom-left" :offset="[18, 18]")
    q-fab(
      color="red-5"
      icon="create_new_folder"
      direction="right"
      size="lg"
    )
      q-tooltip(
        slot="tooltip"
        anchor="center left"
        self="center right"
        :offset="[20, 0]"
      ) Report Settings
      q-fab-action(
        icon="update"
        color="blue-5"
        v-show="showUpdate"
        @click="e => handleReportUpdate(itemRecommendationModel)"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Update
      q-fab-action(
        icon="save"
        color="green-5"
        v-show="showSaveAs"
        @click="showSaveDialog = true"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Save As
      q-fab-action(
        color="indigo"
        icon="bubble_chart"
        v-show="showViewReports"
        @click="showReportViewDialog = true"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Reports
</template>

<script>
import {
  ItemRecommendationsTable,
  ItemRecommendationsInputs,
  ItemRecommendationsSaveDialog,
  ItemRecommendationsImagesView,
  ItemRecommendationsReportsView,
  ItemRecommendationsCommentInput
} from 'src/components/ipp/recommendations';
import { validationMixin } from 'vuelidate';
import { HTTP_API } from 'src/services/http/http';
import { required } from 'vuelidate/lib/validators';
import { mapMutations, mapActions, mapGetters } from 'vuex';
import { FieldableMixin, PlannerSettingsMixin } from 'src/mixins';
import RecommendationService, { recommendationSchema, recommendationItemSchema } from 'src/services/ipp/reports/recommendations/Service';
import {
  eq,
  set,
  each,
  trim,
  merge,
  find,
  filter,
  isEmpty,
  cloneDeep,
  findIndex,
  castArray
} from 'lodash';

const forceSchema = { existing: false, proposed: false, underwriting: false };

export default {
  name: 'item-recommendation-tab',
  extends: {
    methods: {
      ...PlannerSettingsMixin.methods,
      ...FieldableMixin.methods,
    },
    computed: {
      ...PlannerSettingsMixin.computed,
    },
  },
  mixins: [validationMixin],
  data: () => ({
    images: [],
    imageUploadLoading: false,
    loadTable: false,
    reportSaving: false,
    showSaveDialog: false,
    showReportViewDialog: false,
    showImageViewDialog: false,
    force: cloneDeep(forceSchema),
    itemRecommendationModel: cloneDeep(recommendationSchema),
  }),
  created() {
    window.onbeforeunload = function (e) {
      e.preventDefault();
      return '';
    };
  },
  mounted() {
    this.$v.$touch();
    this.UPDATE_FAB_SETTINGS_STATE({ show: false });
  },
  beforeDestroy() {
    window.onbeforeunload = null;
    this.UPDATE_FAB_SETTINGS_STATE({ show: true });
  },
  inject: {
    tabProvider: {
      from: 'data',
      default() {
        return { tabName: 'item-recommendation' };
      },
    },
  },
  watch: {
    force: {
      handler: 'forceHandler',
      deep: true,
    },
    itemRecommendationModel: {
      handler: 'itemRecommendationModelHandler',
      deep: true,
    },
  },
  methods: {
    ...mapMutations('insuranceProviderReport', ['ASSIGN_REPORT_RESULT']),
    ...mapMutations('site', ['UPDATE_FAB_SETTINGS_STATE']),
    ...mapActions('insuranceProviderReport', [
      'onRequestInsuranceReportPersist',
      'onRequestInsuranceReportRemove',
      'onRequestInsuranceReportUpdate',
    ]),
    itemRecommendationModelHandler({ existing, proposed, underwriting }) {
      // Watch both existing and proposed models
      // If there are no policies exists therefore
      // This will remove the whole model object
      try {
        each(existing, ({ name, policies }) => {
          if (isEmpty(policies)) {
            this.itemRecommendationModel['existing'].splice(
              findIndex(this.itemRecommendationModel['existing'], ['name', name]),
              1
            );
          }
        });
        each(proposed, ({ name, policies }) => {
          if (isEmpty(policies)) {
            this.itemRecommendationModel['proposed'].splice(
              findIndex(this.itemRecommendationModel['proposed'], ['name', name]),
              1
            );
          }
        });
        each(underwriting, ({ name, policies }) => {
          if (isEmpty(policies)) {
            this.itemRecommendationModel['underwriting'].splice(
              findIndex(this.itemRecommendationModel['underwriting'], ['name', name]),
              1
            );
          }
        });
      }
      catch (e) {} // This will execute if the model are being mutated to object.
    },
    forceHandler({ existing, proposed, underwriting }) {
      if (!underwriting) {
        if (!existing && !proposed) return;
        if (existing && proposed) { set(this, 'force', cloneDeep(forceSchema)); }
      }
      else {
        if (!proposed && !underwriting) return;
        if (proposed && underwriting) { set(this, 'force', cloneDeep(forceSchema)); }
      }
    },
    handleReportSelect(model) {
      this.loadTable = false;
      this.itemRecommendationModel = model;
      this.ASSIGN_REPORT_RESULT(model);
      this.showReportViewDialog = false;
      this.loadTable = true;
      this.$nextTick(() => {
        this.$refs.$ItemRecommendationsTable.updateTableHeight(true);
      });
    },
    async handleOnAddItemRecommendation(item, type = 'existing') {
      this.loadTable = false;
      const { [type]: models } = this.itemRecommendationModel;
      const Service = (new RecommendationService(models, item)).build();

      if (Service.shouldPush)
        this.itemRecommendationModel[type].push(Service.create());
      else
        set(this.itemRecommendationModel, type, castArray(Service.create()));

      // Handle Force Adding of opposite model items.
      const { existing, proposed } = this.force;
      if (existing && type === 'existing')
        await this.handleOnForceAddRecommendationItem(item, 'proposed');
      if (proposed && type === 'proposed')
        await this.handleOnForceAddRecommendationItem(item, 'existing');
      if (proposed && type === 'underwriting')
        await this.handleOnForceAddRecommendationItem(item, 'underwriting');

      // Render Same table height.
      this.loadTable = true;
      this.$nextTick(() => this.$refs.$ItemRecommendationsTable.updateTableHeight(true));
    },
    async handleOnForceAddRecommendationItem(item, type) {
      const { [type]: models } = this.itemRecommendationModel;
      const payload = merge(recommendationItemSchema, { name: item.name, offer_type: type });
      const Service = (new RecommendationService(models, cloneDeep(payload))).build();
      if (Service.shouldPush)
        this.itemRecommendationModel[type].push(Service.create());
      else
        set(this.itemRecommendationModel, type, castArray(Service.create()));
    },
    async handleReportSaveAs(payload) {
      try {
        this.reportSaving = true;
        if (!trim(payload.name).length) return;
        let planner = this.plan;
        // Check if planner exists
        if (!planner.id) {
          this.$q.notify({
            message: 'Planner Not Found... Generating a new one.',
            color: 'red-5',
            icon: 'save',
            timeout: 1000,
            position: 'top-right',
          });
          // Generate a new one.
          const { data: response } = await this.persistPlanner(this.plan);
          planner = response;
          this.ASSIGN_PLANNER(planner);
          this.ADD_PLANNER_COLLECTION(planner);
        }

        this.$q.notify({
          message: 'Creating Report...',
          color: 'primary',
          icon: 'save',
          timeout: 1000,
          position: 'top-right',
        });

        // Merge Planner ID to payload from response
        payload = merge(payload, { planner_id: planner.id, id: 0 });
        const { data: newPlannerResponse } = await this.onRequestInsuranceReportPersist(payload);

        // Assign the new planner from response
        planner = newPlannerResponse;

        this.$q.notify({
          message: 'Report has been Saved...',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });

        // Assign from both planner and planer collection
        this.ASSIGN_PLANNER(planner);
        this.ADD_PLANNER_COLLECTION(planner);

        // Get the latest reports instance from planner
        const { reports, stage } = planner;
        set(this, 'itemRecommendationModel', reports[0]);
        this.ASSIGN_REPORT_RESULT(reports[0]);

        await this.$router.replace({
          name: 'dashboard.planner',
          params: {
            id: planner.id,
          },
          query: {
            stage,
            step: this.currentStep,
          },
        });

        // Close the Dialog.
        this.showSaveDialog = false;
      } catch (e) {
        this.$q.notify({
          message: 'Something went wrong',
          color: 'negative',
          icon: 'warning',
          timeout: 1000,
          position: 'top-right',
        });
      } finally {
        this.reportSaving = false;
      }
    },
    async handleReportRemove(payload) {
      try {
        this.$q.notify({
          message: 'Removing Report',
          color: 'red-5',
          icon: 'sync',
          timeout: 1000,
          position: 'top-right',
        });
        const { data: planner } = await this.onRequestInsuranceReportRemove(payload);
        this.ASSIGN_PLANNER(planner);
        this.ADD_PLANNER_COLLECTION(planner);
        this.$q.notify({
          message: 'Removed',
          color: 'red-5',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      }
      catch (e) {
        this.$q.notify({
          message: 'Something went wrong',
          color: 'negative',
          icon: 'warning',
          timeout: 1000,
          position: 'top-right',
        });
      }
    },
    async handleReportUpdate(payload) {
      try {
        this.$q.notify({
          message: 'Updating Report',
          color: 'red-5',
          icon: 'sync',
          timeout: 1000,
          position: 'top-right',
        });
        const { data: planner } = await this.onRequestInsuranceReportUpdate(payload);
        this.ASSIGN_PLANNER(planner);
        this.ADD_PLANNER_COLLECTION(planner);
        this.$q.notify({
          message: 'Updated',
          color: 'red-5',
          icon: 'done',
          timeout: 1000,
          position: 'top-right',
        });
      } catch (e) {
        this.$q.notify({
          message: 'Something went wrong',
          color: 'negative',
          icon: 'warning',
          timeout: 1000,
          position: 'top-right',
        });
      }
    },
    async __removeImage(payload) {
      try {
        const { id: planner } = this.plan;
        const { id: image, planner_item_recommendation_id: report } = payload;
        this.$q.notify({
          message: 'Removing Report Image',
          color: 'red-5',
          icon: 'sync',
          timeout: 1000,
          position: 'top-right',
        });
        const { data } = await HTTP_API().post(`/planners/${planner}/reports/recommendations/${report}/${image}/image/remove`, payload);
        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);
        const { reports } = this.plan;
        set(this, 'itemRecommendationModel', find(reports, ['id', report]));
        this.$q.notify({
          message: 'Removed',
          color: 'red-5',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      } catch (e) {
        console.error(e);
      }
    },
    async __updateImage(payload) {
      try {
        const { id: planner } = this.plan;
        const { id: image, planner_item_recommendation_id: report } = payload;
        const { data } = await HTTP_API().post(`/planners/${planner}/reports/recommendations/${report}/${image}/image/modify`, payload);
        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);
        const { reports } = this.plan;
        set(this, 'itemRecommendationModel', find(reports, ['id', report]));
      } catch (e) {
        console.error(e);
      }
    },
    async __uploadImage({ id: report, planner_id: planner }) {
      try {
        this.imageUploadLoading = true;

        const images = this.images;
        if (isEmpty(images)) return;

        this.$q.notify({
          message: 'Uploading',
          color: 'secondary',
          timeout: 1000,
          icon: 'send',
          position: 'top-right',
        });

        const bodyFormData = new FormData;
        each(images, file => {
          bodyFormData.append('images[]', file);
        });

        const url = `/planners/${planner}/reports/recommendations/${report}/upload`;

        const { data } = await HTTP_API().post(
          url,
          bodyFormData,
          {
            headers: {
               Accept: 'application/json',
              'Content-Type': 'multipart/form-data',
            },
          }
        );

        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);

        const { reports } = this.plan;
        set(this, 'itemRecommendationModel', find(reports, ['id', report]));

        this.$q.notify({
          message: 'Success',
          color: 'primary',
          icon: 'done',
          timeout: 1000,
          position: 'top-right',
        });
      } catch (e) {
        console.error(e);
      } finally {
        this.imageUploadLoading = false;
      }
    },
    __uploadRemoveCancel(files) {
      const images = filter(this.images, (image) => {
        return files.findIndex((f) => {
          return eq(f.name, image.name);
        }) == -1;
      });
      this.images = images;
      // this.images = filter(
      //   this.images,
      //   ({ name: fileName }) => !eq(name, fileName)
      // );
    },
    __uploadFilter(files) {
      const MAX_FILE_SIZE = 3 * 1024 * 1024 /* =3M */
      // returns an Array containing allowed files
      return files.filter((file) => {
        return file.size <= MAX_FILE_SIZE
      });
    },
  },
  computed: {
    ...mapGetters('planner', ['plan']),
    ...mapGetters('site', { currentStep: 'getPlannerStep' }),
    ...mapGetters('insuranceProviderReport', ['getReportCategories']),
    shouldShowReasons() {
      return this.showSaveAs
        && this.itemRecommendationModel.proposed
        && this.itemRecommendationModel.proposed.length
        && !this.isPreAndPostUnderwriting;
    },
    showViewReports() {
      return this.plan.reports && this.plan.reports.length;
    },
    showSaveAs() {
      const { existing, proposed } = this.itemRecommendationModel;
      return !isEmpty(existing) || !isEmpty(proposed);
    },
    showUpdate() {
      const { id } = this.itemRecommendationModel;
      return window.Boolean(id);
    },
    isPreAndPostUnderwriting() {
      const { category } = this.itemRecommendationModel;
      return eq(category, 'Pre and Post Underwriting');
    },
  },
  validations() {
    return {
      itemRecommendationModel: {
        category: {
          required,
        },
      },
    };
  },
  components: {
    ItemRecommendationsTable,
    ItemRecommendationsInputs,
    ItemRecommendationsImagesView,
    ItemRecommendationsSaveDialog,
    ItemRecommendationsReportsView,
    ItemRecommendationsCommentInput,
  },
};
</script>
