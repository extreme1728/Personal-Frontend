<template lang="pug">
  q-tabs(
    inverted
    no-pane-border
    align="center"
    position="top"
    color="secondary"
    :two-lines="false"
    v-model="currentTab"
  )
    q-tab(
      slot="title"
      name="recommendation-table"
      icon="insert chart"
      label="Table"
    )
    q-tab(
      slot="title"
      name="recommendation-notes"
      icon="note"
      label="Notes"
      v-if="isAdministrator"
    )

    q-tab-pane(name="recommendation-table")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/comparison/existing/input-details
        div(class="col-md-6")
          include blocks/comparison/proposed/input-details

      //- Results Table
      include blocks/comparison/results-table
      include blocks/comparison/results-table-action

    q-tab-pane(name="recommendation-notes" v-if="isAdministrator")
      include blocks/note/notes-content

    //- Save Item Recommendation Report Dialog
    item-recommendation-report-dialog(
      :show="dialogSchema.customDialogModel"
      :name="dialogSchema.name"
      :category="dialogSchema.category"
      :description="dialogSchema.description"
      :insurance-plan-type="dialogSchema.insurance_plan_type"
      @save="payload => onReportSave(payload, currentTab)"
      @close="dialogSchema.customDialogModel = false"
    )

    item-recommendations-reports-view(
      v-if="plan.reports && plan.reports.length"
      :show="reportDialogSchema.show"
      :reports="plan.reports"
      @cancel="reportDialogSchema.show = false"
      @change="values => updatePlanField(values, 'reports')"
      @select="payload => { currentSelectedReportHandler(payload); reportDialogSchema.show = false; }"
    )

    q-page-sticky(position="bottom-left" :offset="[18, 90]")
      q-btn(
        round
        size="lg"
        icon="show_chart"
        color="cyan"
        @click="reportDialogSchema.show = true"
        v-show="plan.reports && plan.reports.length"
      )
</template>

<script>
import {
  InsuranceProviderNoteEditor,
  InsuranceProviderSelection,
  ItemRecommendationsReportsView,
  ItemRecommendationReportDialog,
  ItemRecommendationsGraphicsTable,
} from 'src/components/ipp';
import {
  FieldableMixin,
  ItemRecommendationTableMixin,
  ItemRecommendationReportMixin,
} from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { HTTP_API } from 'src/services/http/http';
import { trim, eq, find, merge } from 'lodash';
import { mapGetters, mapState, mapMutations, mapActions } from 'vuex';

export default {
  name: 'item-recommendations',
  mixins: [
    FieldableMixin,
    ItemRecommendationTableMixin,
    ItemRecommendationReportMixin,
  ],
  data: () => ({
    insuranceProviderSchema: {
      providerId: 0,
      coverTypeId: 0,
    },
    coverTypeNotes: [],
    arrayOfExistingCoverTypeNotes: [],
    arrayOfProposedCoverTypeNotes: [],
    currentTab: 'recommendation-table',
    dialogSchema: {
      name: null,
      category: null,
      description: null,
      insurance_plan_type: null,
      customDialogModel: false,
    },
    reportDialogSchema: {
      show: false,
    },
  }),
  watch: {
    arrayOfExistingCoverTypeNotes: {
      handler: 'arrayOfExistingCoverTypeNotesHandler',
      deep: true,
    },
    arrayOfProposedCoverTypeNotes: {
      handler: 'arrayOfProposedCoverTypeNotesHandler',
      deep: true,
    },
  },
  methods: {
    ...mapMutations('insuranceProviderNoteReport', ['UPDATE_REPORT_NOTE_FORM_DATA']),
    ...mapActions('insuranceProviderReport', ['onRequestInsuranceReportPersist']),
    arrayOfExistingCoverTypeNotesHandler(value) {
      this.UPDATE_REPORT_NOTE_FORM_DATA({
        value,
        field: ['reportResults', 'existing'],
      });
    },
    arrayOfProposedCoverTypeNotesHandler(value) {
      this.UPDATE_REPORT_NOTE_FORM_DATA({
        value,
        field: ['reportResults', 'proposed'],
      });
    },
    onPreviewReportSelect({ existing, proposed }) {
      this.arrayOfExistingCoverTypeNotes = existing;
      this.arrayOfProposedCoverTypeNotes = proposed;
    },
    addArrayCoverTypeNote(note, type='arrayOfExistingCoverTypeNotes') {
      this[type].push(this.convertToNonReactive(note));
    },
    removeArrayCoverTypeNote(noteIndex, type='arrayOfExistingCoverTypeNotes') {
      this[type].splice(noteIndex, 1);
    },
    async onReportSave(payload, currentTab = this.currentTab) {
      if (!trim(payload.name).length) return;
      try {
        const { data: response } = await this.persistPlanner(this.plan);
        this.$q.notify({
          message: 'Saving',
          color: 'primary',
          icon: 'save',
          timeout: 1000,
          position: 'top-right',
        });

        const method = eq(currentTab, 'note') ? 'onHandlePersistPlannerNotesComparison' : 'onHandlePersistPlannerItemRecommendations';

        payload = merge(payload, { id: response.id });
        const data = await this[method](payload)
        this.ASSIGN_PLANNER(data);
        this.ADD_PLANNER_COLLECTION(data);
        this.$q.notify({
          message: 'Saved',
          color: 'info',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
        await this.$router.replace({
          name: 'dashboard.planner',
          params: {
            id: data.id,
          },
        });
        this.updateInsuranceProviderField(find(data.reports, ['name', payload.name]).id, 'currentSelectedReport');
      }
      catch (e) {}
    },
    async onHandlePersistPlannerItemRecommendations(payload) {
      try {
        const { data } = await this.onRequestInsuranceReportPersist(merge(payload, {
          existing: this.arrayOfExistingPolicyProviders,
          proposed: this.arrayOfProposedPolicyProviders,
        }));

        this.dialogSchema.customDialogModel = false;
        this.dialogSchema.name = null;
        this.dialogSchema.description = null;
        this.dialogSchema.insurance_plan_type = null;

        return data;
      }
      catch (e) {}
    },
    async onHandlePersistPlannerNotesComparison({ id, name, description }) {
      try {
        const { data } = await HTTP_API().post(`/planners/${id}/reports/notes/persist`, {
          name,
          description,
          existing: this.arrayOfExistingCoverTypeNotes,
          proposed: this.arrayOfProposedCoverTypeNotes,
        });
        this.$q.notify({
          message: 'Saved',
          color: 'secondary',
          icon: 'save',
        });

        this.dialogSchema.customDialogModel = false;
        this.dialogSchema.name = null;
        this.dialogSchema.description = null;

        return data;
      }
      catch (e) {}
    },
  },
  computed: {
    ...mapGetters('planner', {
      mapClientAndPartnerNameValues: 'mapClientAndPartnerNameValues',
    }),
    ...mapGetters('user', {
      isAdministrator: 'isAdministrator',
    })
  },
  components: {
    QInput,
    InsuranceProviderSelection,
    InsuranceProviderNoteEditor,
    ItemRecommendationsReportsView,
    ItemRecommendationReportDialog,
    ItemRecommendationsGraphicsTable,
  },
};
</script>
