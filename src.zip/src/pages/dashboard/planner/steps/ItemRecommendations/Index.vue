<template lang="pug">
div
  q-tabs(
    align="center"
    position="top"
    v-model="currentTab"
    class="text-secondary"
  )
    q-tab(
      label="Table"
      icon="insert_chart"
      name="item-recommendation"
    )
  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="item-recommendation")
      item-recommendation-tab
</template>

<script>
import ItemRecommendationTab from './blocks/ItemRecommendationTab';

export default {
  name: 'report-index',
  data: () => ({
    currentTab: 'item-recommendation',
  }),
  components: {
    ItemRecommendationTab,
  },
};
</script>
