<template lang="pug">
div
  q-tabs(
    position="top"
    align="center"
    class="text-secondary"
    v-model="currentTab"
  )
    include blocks/tab-navigation

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="disclosure-statement")
      div(class="row justify-center q-pa-md")
        div(class="generate-wrapper")
          q-btn(
            outline
            class="full-width"
            label="Generate"
            color="primary"
            icon="picture_as_pdf"
            @click="onHandleDisclosureStatementRedirect"
          )
    q-tab-panel(name="scope-of-engagement")
      div(class="row justify-center q-pa-md")
        div(class="generate-wrapper")
          q-btn(
            outline
            class="full-width"
            label="Generate"
            color="primary"
            icon="picture_as_pdf"
            @click="onHandleScopeOfEngagementRedirect"
          )
    q-tab-panel(name="letter-of-authority")
      div(class="row q-col-gutter-md q-mt-md")
        letter-of-authority-scopes(
          :display-name="getClientName"
          class="offset-md-1 col-md-5"
          type="client"
          :signature="clientSignature"
          :payload="clientLetterOfAuthorityScopes"
          @save="onHandleLetterOfAuthorityScopeSave"
        )
        letter-of-authority-scopes(
          :display-name="getPartnerName"
          class="col-md-5"
          type="partner"
          :signature="partnerSignature"
          :payload="partnerLetterOfAuthorityScopes"
          @save="onHandleLetterOfAuthorityScopeSave"
        )
    q-tab-panel(name="declarations")
      div(
        v-if="plan.id && isOnline"
        v-for="services in declarationPageServices"
        class="row justify-center q-col-gutter-md q-mt-md"
      )
        div(class="col-md-4" v-for="(service, index) in services")
          q-card(:key="index" square)
            q-card-section(style="height: 100px" :class="`bg-${service.color}`")
            q-card-section(class="relative-position")
              p(class="text-h6 text-faded") {{ service.name }}
              q-btn(
                fab
                color="blue-grey"
                icon="open_in_new"
                class="absolute service-card--button"
                @click="onHandleDeclarationRedirect(service)"
              )
            q-card-actions
              q-btn(
                flat
                label="Download"
                icon="cloud_download"
                :color="service.color"
                @click="onHandleDeclarationRedirect(service, true)"
              )
    q-tab-panel(name="amp-letter-of-authority" v-if="clientHasAMPInsurance")
      q-card(v-if="plan.id && isOnline")
        q-card-section(class="text-faded") Preview
        q-card-section
          vue-friendly-iframe(:src="getAMPLoaDocumentUrl")
      q-card(v-if="isOnline" class="q-mt-md")
        q-card-section
          div(class="row justify-center")
            div(class="offset-2 col-md-4")
              q-btn(
                flat
                color="secondary"
                icon="remove red eye"
                label="Generate Preview"
                @click="onHandlePersist(plan)"
              )
            div(class="col-md-4")
              q-btn(
                flat
                v-show="plan.id"
                color="primary"
                label="Download"
                icon="cloud_download"
                @click="e => openURL(`${getAMPLoaDocumentUrl}/download`)"
              )
    q-tab-panel(name="southern-cross-letter-of-authority" v-if="clientHasSouthernCrossInsurance")
      q-card(v-if="plan.id && isOnline")
        q-card-section(class="text-faded") Preview
        q-card-section
          vue-friendly-iframe(:src="getSouthernCrossLoaDocumentUrl")
      q-card(v-if="isOnline" class="q-mt-md")
        q-card-section
          div(class="row justify-center")
            div(class="offset-2 col-md-4")
              q-btn(
                flat
                color="secondary"
                icon="remove red eye"
                label="Generate Preview"
                @click="onHandlePersist(plan)"
              )
            div(class="col-md-4")
              q-btn(
                flat
                v-show="plan.id"
                color="primary"
                label="Download"
                icon="cloud_download"
                @click="e => openURL(`${getSouthernCrossLoaDocumentUrl}/download`)"
              )
    q-tab-panel(name="insurance-planner")
      q-card(square)
        q-card-section
          section-selections(
            from-server
            :payload="plan.selections"
            @change="_ => updatePlanField(_, 'selections')"
          )
        q-card-actions(align="around")
          q-btn(
            color="primary"
            icon="picture_as_pdf"
            label="Generate Insurance Planner"
            @click="onHandleInsurancePlannerRedirect"
          )
          q-btn(
            color="cyan"
            icon="vertical_split"
            label="Generate Calculators"
            @click="onHandleCalculatorsRedirect"
          )
    q-tab-panel(name="signature")
      generate-signature(
        :disclosure="disclosure"
        :client-signature="clientSignature"
        :partner-signature="partnerSignature"
        @save="onHandleSignatureSave"
      )
    q-tab-panel(name="mail")
      generate-email
</template>

<script>
import URL from 'url';
import { openURL } from 'quasar';
import { FieldableMixin } from 'src/mixins';
import { mapActions, mapGetters } from 'vuex';
import VueFriendlyIframe from 'vue-friendly-iframe';
import { get, chunk, merge, castArray } from 'lodash';
import { GenerateEmail, GenerateSignature } from 'src/components/ipp';
import { SectionSelections } from 'src/components/ipp';
import { LetterOfAuthorityScopes } from 'src/components/ipp/scopes';

export default {
  name: 'insurance-planner',
  mixins: [FieldableMixin],
  data: () => ({
    currentTab: 'letter-of-authority',
    selectedLoaOptions: [],
  }),
  methods: {
    ...mapActions('planner', ['persistPlannerSignature']),
    async onHandleLetterOfAuthorityScopeSave(payload) {
      this.$q.notify({
        message: 'Saving',
        color: 'primary',
        icon: 'save',
        timeout: 1000,
        position: this.$q.platform.is.mobile ? 'top' : 'top-right',
      });
      await this.updatePlanRelationField(
        castArray(payload),
        'letter_of_authority_scopes',
      );
      this.$q.notify({
        message: 'Saved',
        color: 'secondary',
        icon: 'check',
        timeout: 1000,
        position: this.$q.platform.is.mobile ? 'top' : 'top-right',
      });
    },
    onHandleDeclarationRedirect({ value }, download = false) {
      const { preview_declaration_documents_url } = this.plan;
      if (!preview_declaration_documents_url) return;
      let href = `${preview_declaration_documents_url}/${value}`;
      if (download) {
        href = `${href}/download`;
      }
      this.openURL(href);
    },
    onHandleDownloadLoa(url) {
      const urlInstance = URL.parse(url);
      if (!urlInstance.search) {
        this.openURL(`${url}?download`);
      }
      else {
        this.openURL(`${url}&download`);
      }
    },
    async onHandleCalculatorsRedirect() {
      const query = { type: 'insurance_planner' };
      const name = 'document.calculators.preview';
      const { href } = await this.$router.resolve({ name, query });
      this.openURL(href);
    },
    onHandleInsurancePlannerRedirect() {
      const name = 'document.plan.preview';
      const { href } = this.$router.resolve({ name, query: { type: 'insurance_planner' } });
      this.openURL(href);
    },
    onHandleDisclosureStatementRedirect() {
      const name = 'disclosure.statement.preview';
      const { href } = this.$router.resolve({ name });
      this.openURL(href);
    },
    onHandleScopeOfEngagementRedirect() {
      const name = 'scope.of.engagement.preview';
      const { href } = this.$router.resolve({ name });
      this.openURL(href);
    },
    async onHandleSignatureSave({ data, type }) {
      try {
        const { id: planner_id } = this.plan;
        if (!planner_id) {
          this.$q.notify({
            message: 'Planner must be saved first',
            color: 'red-5',
            icon: 'warning',
            timeout: 1000,
            position: 'top-right',
          });
          return;
        }
        this.$q.notify({
          message: 'Saving',
          color: 'primary',
          icon: 'save',
          timeout: 1000,
          position: 'top-right',
        });
        const payload = { planner_id, stage: 'first_appointment', type, value: data };
        const { data: response } = await this.persistPlannerSignature(payload);
        this.ASSIGN_PLANNER(response);
        this.ADD_PLANNER_COLLECTION(response);
        this.$q.notify({
          message: 'Saved',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      }
      catch (e) { console.error(e); }
    },
    openURL,
  },
  computed: {
    ...mapGetters('planner', {
      getClientInsuranceProviders: 'getClientInsuranceProviders',
      clientLetterOfAuthorityScopes: 'clientLetterOfAuthorityScopes',
      partnerLetterOfAuthorityScopes: 'partnerLetterOfAuthorityScopes',
      getDeterminedFirstAppointmentSignature: 'getDeterminedFirstAppointmentSignature',
    }),
    ...mapGetters('resources', ['declarationPagesOptions']),
    ...mapGetters('user', ['isMarketingSpecialist']),
    clientSignature() {
      return get(this.getDeterminedFirstAppointmentSignature('client'), 'value', null);
    },
    partnerSignature() {
      return get(this.getDeterminedFirstAppointmentSignature('partner'), 'value', null);
    },
    disclosure() {
      return 'Please confirm that you have read the Disclosure Statement, Scope of Engagement, Letter of Authority and Insurance Planner.';
    },
    clientHasAMPInsurance() {
      const providers = this.getClientInsuranceProviders;
      return providers.includes('AMP') || providers.includes('amp');
    },
    clientHasSouthernCrossInsurance() {
      const providers = this.getClientInsuranceProviders;
      return providers.includes('Southern Cross') || providers.includes('southern cross');
    },
    getAMPLoaDocumentUrl() {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { id: user } = this.$store.getters['user/currentUserModel'];
      if (!planner && !user) return null;
      return `${WEB_ENDPOINT}/document/amp/${user}/loa/${planner}/preview`;
    },
    getSouthernCrossLoaDocumentUrl() {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      if (!planner) return null;
      return `${WEB_ENDPOINT}/document/southern-cross/loa/${planner}/preview`;
    },
    declarationPageServices() {
      const services = this.declarationPagesOptions.map(values => {
        return merge(values, {
          value: values.value || values.name,
        });
      });
      return chunk(services, 3);
    },
  },
  components: {
    GenerateEmail,
    VueFriendlyIframe,
    GenerateSignature,
    SectionSelections,
    LetterOfAuthorityScopes,
  },
};
</script>

<style lang="stylus" scoped>
.generate-wrapper
  width 800px
  max-width 800px
.service-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
