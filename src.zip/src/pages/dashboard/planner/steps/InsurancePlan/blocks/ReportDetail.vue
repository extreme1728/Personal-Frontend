<template lang="pug">
div
  q-card(flat class="full-width")
    q-card-section
      div(class="row items-center")
        div(class="col")
          div(class="text-h6 text-faded") {{ report.name | limit }}
        div(class="col-auto")
          q-btn(flat round dense icon="filter_list" color="faded" @click="selectionDialogShow = true")
            q-tooltip Filter Sections
          q-btn(flat round dense icon="more_vert" color="faded")
            q-menu(cover auto-close)
              q-list
                q-item(clickable @click="onHandleGenerateInsurancePlan(report)")
                  q-item-section(avatar)
                    q-icon(name="picture_as_pdf" color="primary")
                  q-item-section Insurance Plan
                q-item(clickable @click="onHandleGenerateCalculators(report)")
                  q-item-section(avatar)
                    q-icon(name="vertical_split" color="cyan")
                  q-item-section Calculators
                q-item(clickable @click="onHandleGenerateItemRecommendations(report)")
                  q-item-section(avatar)
                    q-icon(name="view_column" color="orange-5")
                  q-item-section
                    q-item-label Item
                    q-item-label(caption) Recommendations
                q-separator
                q-item(clickable @click="onHandleReportRemove(report)")
                  q-item-section(avatar)
                    q-icon(name="remove" color="red-5")
                  q-item-section
                    q-item-label Delete
                    q-item-label(caption) Report
    q-card-section(class="text-faded")
      p(class="report-detail") Last modified at: {{ report.updated_at | formatDate }}
      p(class="report-detail") Attached Images: {{ report.images.length || 0 }}
      p(class="report-detail") {{ report.category || 'No Category' }}
      p(class="report-detail") {{ report.insurance_plan_type | inputFormatter }}
      p(class="report-detail") {{ report.description || 'No Description' }}
  selection-detail(
    :report="report"
    :show="selectionDialogShow"
    @change="__onReportSelectionChange"
    @cancel="selectionDialogShow = false"
  )
</template>

<script>
import { openURL } from 'quasar';
import { set, truncate } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { mapGetters, mapActions } from 'vuex';
import SelectionDetail from './SelectionDetail';

export default {
  name: 'report-detail',
  mixins: [FieldableMixin],
  filters: {
    limit(value) {
      if (!value) return null;
      return truncate(value, { length: 15 });
    },
  },
  data: () => ({
    selectionDialogShow: false,
  }),
  props: {
    report: {
      type: Object,
      required: true,
    },
  },
  methods: {
    ...mapActions('insuranceProviderReport', [
      'onRequestInsuranceReportRemove',
      'onRequestInsuranceReportUpdate'
    ]),
    async __onReportSelectionChange(report, value) {
      this.$q.notify({
        message: 'Updating Report',
        color: 'red-5',
        icon: 'sync',
        timeout: 1000,
        position: 'top-right',
      });
      const payload = set(report, 'selections', value);
      const { data: planner } = await this.onRequestInsuranceReportUpdate(payload);
      this.ASSIGN_PLANNER(planner);
      this.ADD_PLANNER_COLLECTION(planner);
      this.$q.notify({
        message: 'Updated',
        color: 'red-5',
        icon: 'done',
        timeout: 1000,
        position: 'top-right',
      });
    },
    async onHandleReportRemove(report) {
      try {
        await this.$q.dialog({
            title: 'Confirm',
            message: 'This action cannot be undone and will result of losing data. Would you like to continue?',
            color: 'red-5',
            cancel: true,
            preventClose: true,
        });
        this.$q.notify({
          message: 'Removing Report',
          color: 'red-5',
          icon: 'sync',
          timeout: 1000,
          position: 'top-right',
        });
        const { data: planner } = await this.onRequestInsuranceReportRemove(report);
        this.ASSIGN_PLANNER(planner);
        this.ADD_PLANNER_COLLECTION(planner);
        this.$q.notify({
          message: 'Removed',
          color: 'red-5',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      }
      catch (e) { console.log(e); }
    },
    async onHandleGenerateCalculators({ insurance_plan_type: type }) {
      const query = { type };
      const name = 'document.calculators.preview';
      const { href } = await this.$router.resolve({ name, query });
      openURL(href);
    },
    async onHandleGenerateItemRecommendations({ id: reportId, planner_id: plannerId, insurance_plan_type: type }) {
      const query = { type };
      const params = { plannerId, reportId };
      const name = 'document.recommendations.preview';
      const { href } = await this.$router.resolve({ name, params, query });
      openURL(href);
    },
    async onHandleGenerateInsurancePlan({ id: reportId, planner_id: plannerId, insurance_plan_type: type }) {
      const query = { type };
      const params = { plannerId, reportId };
      const name = 'document.plan.preview';
      const { href } = await this.$router.resolve({ name, params, query });
      openURL(href);
    },
  },
  components: {
    SelectionDetail,
  },
};
</script>

<style lang="styl" scoped>
.report-detail
  border-bottom 1px dotted #333
</style>
