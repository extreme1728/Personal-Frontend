<template lang="pug">
q-dialog(full-width :value="show" @hide="$emit('cancel')" @cancel="$emit('cancel')")
  q-card
    q-card-section
      h6(class="text-faded no-margin") Select Document Sections
      p(class="text-caption") Choose document sections to be shown
    q-card-section
      section-selections(
        from-server
        :report="report"
        :payload="report.selections"
        @change="_ => $emit('change', report, _)"
      )
    q-card-actions(align="right")
      q-btn(flat color="primary" label="Set" @click="$emit('cancel')")
</template>

<script>
import { SectionSelections } from 'src/components/ipp';

export default {
  name: 'selection-detail',
  props: {
    show: Boolean,
    report: {
      type: Object,
      required: true,
    },
  },
  components: {
    SectionSelections,
  }
}
</script>
