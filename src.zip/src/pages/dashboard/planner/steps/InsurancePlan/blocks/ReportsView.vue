<template lang="pug">
div
  div(
    v-if="chunkedReports && chunkedReports.length"
    v-for="reports in chunkedReports"
    class="row q-col-gutter-md justify-center"
  )
    div(class="col-md-4" v-for="report in reports" :key="report.id")
      report-detail(:report="report")
  div(class="text-center" v-else)
    p
      img(
        src="~assets/sad.svg"
        style="width:30vw; max-width:150px;"
      )
    p(class="text-faded") No Reports Found Yet...
</template>

<script>
import { chunk } from 'lodash';
import { mapGetters } from 'vuex';
import ReportDetail from './ReportDetail';

export default {
  name: 'reports-view',
  computed: {
    ...mapGetters('planner', {
      plan: 'plan',
    }),
    chunkedReports() {
      const { reports } = this.plan;
      return chunk(reports, 3);
    },
  },
  components: {
    ReportDetail,
  },
};
</script>
