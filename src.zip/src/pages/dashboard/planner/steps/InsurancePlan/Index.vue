<template lang="pug">
div
  q-tabs(
    align="center"
    position="top"
    class="text-secondary"
    v-model="currentTab"
  )
    q-tab(
      name="limited-advice"
      icon="verified_user"
      label="Limited Advice"
    )
    q-tab(
      name="authority-to-proceed"
      icon="security"
      label="Authority To Proceed"
    )
    q-tab(
      icon="chrome_reader_mode"
      name="insurance-plan"
      label="Insurance Plan"
    )
    q-tab(
      icon="beach_access"
      name="acc-cover-plus-extra-forms"
      label="ACC Cover Plus Extra Forms"
    )
    q-tab(
      v-if="clientHasFidelityInsurance || partnerHasFidelityInsurance"
      icon="filter_b_and_w"
      name="fidelity-life-extra-forms"
      label="Fidelity Life Forms"
    )
    q-tab(
      v-if="clientHasNibInsurance || partnerHasNibInsurance"
      icon="brightness_auto"
      name="nib-direct-debit-forms"
      label="NIB Direct Debit Forms"
    )
    q-tab(
      icon="description"
      name="advice-on-business-replacement"
      label="Advice on Business Replacement"
    )
    q-tab(
      v-if="clientHasSovereignInsurance || partnerHasSovereignInsurance"
      icon="cancel_presentation"
      name="sovereign-cancellation-forms"
      label="Cancellation Forms"
    )
    q-tab(
      icon="edit"
      label="Signature"
      name="signature"
    )
    q-tab(
      name="mail"
      icon="mail"
      label="Mail"
    )

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="limited-advice")
      generate-limited-advice
    q-tab-panel(name="authority-to-proceed")
      div(class="row justify-center q-pa-md")
        div(style="width: 800px; max-width: 800px;")
          h6(class="text-subtitle1 text-faded") Generate Authority To Proceed
          q-btn(
            outline
            color="primary"
            class="full-width"
            icon="picture_as_pdf"
            label="Generate Document"
            @click="onHandleATPRedirect"
          )
    q-tab-panel(name="insurance-plan")
      q-list(separator)
        q-expansion-item(icon="file_copy" label="Reports" default-opened)
          reports-view
    q-tab-panel(name="acc-cover-plus-extra-forms")
      div(
        v-if="plan.id && isOnline"
        v-for="services in accCoverPlusExtraFormServices"
        class="row justify-center q-col-gutter-md q-mt-md"
      )
        div(class="col-md-6" v-for="(service, index) in services")
          q-card(:key="index" square)
            q-card-section(style="height: 100px" :class="`bg-${service.color}`")
            q-card-section(class="relative-position")
              p(class="text-h6 text-faded") {{ service.name }}
              q-btn(
                v-if="service.name !== 'Direct Debit'"
                fab
                color="blue-grey"
                icon="open_in_new"
                class="absolute service-card--button"
                @click="openURL(`${service.url}?type=client`)"
              )
              q-btn(
                v-else
                fab
                color="blue-grey"
                icon="open_in_new"
                class="absolute service-card--button"
              )
                q-menu(anchor="center middle" self="center middle")
                  q-list(style="min-width: 100px")
                    q-item(
                      clickable
                      v-close-popup
                      @click="openURL(`${service.url}?type=client`)"
                    )
                      q-item-section(v-text="getClientName")
                    q-item(
                      v-if="hasPartnerExists"
                      clickable
                      v-close-popup
                      @click="openURL(`${service.url}?type=partner`)"
                    )
                      q-item-section(v-text="getPartnerName")
            q-card-actions
              q-btn(
                v-if="service.name !== 'Direct Debit'"
                flat
                label="Download"
                icon="cloud_download"
                :color="service.color"
                @click="openURL(`${service.url}?type=client&download=true`)"
              )
              q-btn(
                v-else
                flat
                label="Download"
                icon="cloud_download"
                :color="service.color"
              )
    q-tab-panel(name="nib-direct-debit-forms")
      div(
        v-if="plan.id && isOnline"
        v-for="services in nibDirectDebitFormServices"
        class="row justify-center q-col-gutter-md q-mt-md"
      )
        div(class="col-md-6" v-for="(service, index) in services")
          q-card(:key="index" square)
            q-card-section(style="height: 100px" :class="`bg-${service.color}`")
            q-card-section(class="relative-position")
              p(class="text-h6 text-faded") {{ service.name }}
              q-btn(
                fab
                color="blue-grey"
                icon="open_in_new"
                class="absolute service-card--button"
                @click="openURL(service.url)"
              )
            q-card-actions
              q-btn(
                flat
                label="Download"
                icon="cloud_download"
                :color="service.color"
                @click="onHandleDownload(service.url)"
              )
    q-tab-panel(name="fidelity-life-extra-forms")
      q-card(v-if="isOnline" class="q-my-md")
        q-card-section(style="height: 100px" class="bg-teal")
        q-card-section(class="relative-position")
          p(class="text-h6 text-faded") Direct Debit
            q-btn(
              fab
              color="blue-grey"
              icon="open_in_new"
              class="absolute service-card--button"
            )
              q-menu(anchor="center middle" self="center middle")
                q-list(style="min-width: 100px")
                  q-item(
                    clickable
                    v-close-popup
                    @click="openURL(`${plan.preview_fidelity_life_direct_debit_form_document_url}?type=client`)"
                  )
                    q-item-section(v-text="getClientName")
                  q-item(
                    v-if="hasPartnerExists"
                    clickable
                    v-close-popup
                    @click="openURL(`${plan.preview_fidelity_life_direct_debit_form_document_url}?type=partner`)"
                  )
                    q-item-section(v-text="getPartnerName")
          q-card-actions
            q-btn(
              flat
              color="teal"
              label="Download"
              icon="cloud_download"
            )
              q-menu(anchor="center middle" self="center middle")
                q-list(style="min-width: 100px")
                  q-item(
                    clickable
                    v-close-popup
                    @click="openURL(`${plan.preview_fidelity_life_direct_debit_form_document_url}?type=client&download=true`)"
                  )
                    q-item-section(v-text="getClientName")
                  q-item(
                    v-if="hasPartnerExists"
                    clickable
                    v-close-popup
                    @click="openURL(`${plan.preview_fidelity_life_direct_debit_form_document_url}?type=partner&download=true`)"
                  )
                    q-item-section(v-text="getPartnerName")
    q-tab-panel(name="advice-on-business-replacement" class="advice-on-business-replacement-max-height")
      div(
        v-if="plan.id && isOnline"
        v-for="services in adviceOnBusinessReplacementServices"
        class="row justify-center q-col-gutter-md q-mt-md"
      )
        div(class="col-sm-12 col-md-6 flex" v-for="(service, index) in services")
          q-card(:key="index + 1" square inline class="full-width relative-position")
            q-card-section(style="height: 100px" :class="`bg-${service.color}`")
            q-card-section(class="relative-position")
              p(class="text-h6 text-faded") {{ service.name }}
              transition(
                enter-active-class="animated fadeIn"
                leave-active-class="animated fadeOut"
              )
                q-btn(
                  fab
                  color="blue-grey"
                  icon="open_in_new"
                  v-show="service.show"
                  @click="openURL(service.url)"
                  class="absolute service-card--button"
                )
            q-card-section(v-if="service.form" class="q-mb-xl")
              q-option-group(
                type="checkbox"
                class="q-my-xs"
                :color="service.color"
                :options="service.form.options"
                v-model="selectedGeneralAdviceOptions"
              )
            q-card-actions(class="absolute-bottom")
              q-btn(
                flat
                label="Download"
                v-show="service.show"
                icon="cloud_download"
                :color="service.color"
                @click="openURL(service.downloadUrl)"
              )
    q-tab-panel(name="sovereign-cancellation-forms")
      div(
        v-if="plan.id && isOnline"
        v-for="services in sovereignCancellationFormServices"
        class="row justify-center q-col-gutter-md q-mt-md"
      )
        div(class="col-md-6" v-for="(service, index) in services")
          q-card(:key="index" square)
            q-card-section(style="height: 100px" :class="`bg-${service.color}`")
            q-card-section(class="relative-position")
              p(class="text-h6 text-faded") {{ service.name }}
              q-btn(
                fab
                color="blue-grey"
                icon="open_in_new"
                class="absolute service-card--button"
                @click="openURL(service.url)"
              )
            q-card-actions
              q-btn(
                flat
                label="Download"
                icon="cloud_download"
                :color="service.color"
                @click="onHandleDownload(service.url)"
              )
    q-tab-panel(name="signature")
      generate-signature(
        :disclosure="disclosure"
        :client-signature="clientSignature"
        :partner-signature="partnerSignature"
        @save="onHandleSignatureSave"
      )
    q-tab-panel(name="mail")
      generate-email
</template>

<script>
import {
  GenerateEmail,
  GenerateSignature,
  GenerateLimitedAdvice,
} from 'src/components/ipp';
import qs from 'qs';
import { openURL } from 'quasar';
import { get, chunk, merge } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { mapActions, mapGetters } from 'vuex';
import ReportsView from './blocks/ReportsView';
import VueFriendlyIframe from 'vue-friendly-iframe';

export default {
  name: 'insurance-plan',
  mixins: [FieldableMixin],
  data: () => ({
    currentTab: 'limited-advice',
    selectedGeneralAdviceOptions: [],
  }),
  created() {
    const defaults = this
      .generalAdviceOnBusinessReplacementOptions
      .filter(({ value }) => value !== 'option_3')
      .map(({ value }) => value);
    this.selectedGeneralAdviceOptions = defaults;
  },
  methods: {
    ...mapActions('planner', ['persistPlannerSignature']),
    openURL: openURL,
    onHandleDownload(url) {
      this.openURL(`${url}/download`);
    },
    onHandleATPRedirect() {
      const name = 'authority.to.proceed.preview';
      const { href } = this.$router.resolve({ name });
      this.openURL(href);
    },
    async onHandleSignatureSave({ data, type }) {
      try {
        const { id: planner_id } = this.plan;
        if (!planner_id) {
          this.$q.notify({
            message: 'Planner must be saved first',
            color: 'red-5',
            icon: 'warning',
            timeout: 1000,
            position: 'top-right',
          });
          return;
        }
        this.$q.notify({
          message: 'Saving',
          color: 'primary',
          icon: 'save',
          timeout: 1000,
          position: 'top-right',
        });
        const payload = { planner_id, stage: 'second_appointment', type, value: data };
        const { data: response } = await this.persistPlannerSignature(payload);
        this.ASSIGN_PLANNER(response);
        this.ADD_PLANNER_COLLECTION(response);
        this.$q.notify({
          message: 'Saved',
          color: 'secondary',
          icon: 'check',
          timeout: 1000,
          position: 'top-right',
        });
      }
      catch (e) { console.error(e); }
    },
  },
  computed: {
    ...mapGetters('planner', ['getDeterminedSecondAppointmentSignature', 'getClientInsuranceProviders', 'getPartnerInsuranceProviders']),
    clientSignature() {
      return get(this.getDeterminedSecondAppointmentSignature('client'), 'value', null);
    },
    partnerSignature() {
      return get(this.getDeterminedSecondAppointmentSignature('partner'), 'value', null);
    },
    clientHasFidelityInsurance() {
      const providers = this.getClientInsuranceProviders;
      return providers.includes('Fidelity') || providers.includes('fidelity');
    },
    partnerHasFidelityInsurance() {
      const providers = this.getPartnerInsuranceProviders;
      return providers.includes('Fidelity') || providers.includes('fidelity');
    },
    clientHasNibInsurance() {
      const providers = this.getClientInsuranceProviders;
      return providers.includes('NIB') || providers.includes('nib');
    },
    partnerHasNibInsurance() {
      const providers = this.getPartnerInsuranceProviders;
      return providers.includes('NIB') || providers.includes('nib');
    },
    clientHasSovereignInsurance() {
      const providers = this.getClientInsuranceProviders;
      return providers.includes('Sovereign') || providers.includes('sovereign');
    },
    partnerHasSovereignInsurance() {
      const providers = this.getPartnerInsuranceProviders;
      return providers.includes('Sovereign') || providers.includes('sovereign');
    },
    disclosure: () => ('Please confirm that you have read the Limited Advice, Authority to Proceed and Insurance Plan.'),
    adviceOnBusinessReplacementServices() {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { id: user } = this.$store.getters['user/currentUserModel'];
      if (!planner || !user) return [];
      const DOCUMENT_ENDPOINT = `${WEB_ENDPOINT}/document/advice-on-business-replacement/pages/${user}/${planner}/type/:service/preview`;
      let services = [
        {
          name: 'General',
          color: 'blue-10',
          form: {
            type: 'checkbox',
            options: this.generalAdviceOnBusinessReplacementOptions,
          },
        },
        { name: 'Sovereign', color: 'cyan-4' },
      ].map((service, index) => {
        let url = DOCUMENT_ENDPOINT.replace(':service', service.name);
        let values = {
          ...service,
          url,
          downloadUrl: [url, qs.stringify({ download: true })].join('?'),
          value: service.value || service.name,
          show: true,
        };
        if (index === 0) {
          const model = this.selectedGeneralAdviceOptions;
          url = [url, qs.stringify({ values: model })].join('?');
          values = {
            ...values,
            ...{
              url,
              show: !!model.length,
              downloadUrl: [url, qs.stringify({ download: true })].join('&')
            },
          };
        }
        return values;
      });
      return chunk(services, 2);
    },
    sovereignCancellationFormServices() {
      const { WEB_ENDPOINT } = process.env;
      const { id: planner } = this.plan;
      const { id: user } = this.$store.getters['user/currentUserModel'];
      if (!planner || !user) return [];
      const DOCUMENT_ENDPOINT = `${WEB_ENDPOINT}/document/sovereign-cancellation/pages/${user}/${planner}/type/:service/preview`;
      let services = [
        { name: 'Sovereign', color: 'cyan-4' },
      ].map((service, index) => {
        let url = DOCUMENT_ENDPOINT.replace(':service', service.name);
        let values = {
          ...service,
          url,
          downloadUrl: [url, qs.stringify({ download: true })].join('?'),
          value: service.value || service.name,
          show: true,
        };
        return values;
      });
      return chunk(services, 2);
    },
    accCoverPlusExtraFormServices() {
      const {
        id,
        preview_acc_cover_plus_extra_application_form_document_url: applicationForm,
        preview_acc_cover_plus_extra_direct_debit_form_document_url: directDebitForm,
      } = this.plan;
      if (!id) return [];
      const services = [
        {
          name: 'Application',
          url: applicationForm,
          color: 'teal',
        },
        {
          name: 'Direct Debit',
          url: directDebitForm,
          color: 'blue-5'
        }
      ];
      return chunk(services, 2);
    },
    nibDirectDebitFormServices() {
      const {
        id,
        preview_nib_direct_debit_form_document_url: directDebitForm,
      } = this.plan;
      if (!id) return [];
      const services = [
        {
          name: 'Direct Debit',
          url: directDebitForm,
          color: 'blue-5'
        }
      ];
      return chunk(services, 2);
    },
    generalAdviceOnBusinessReplacementOptions() {
      return [
        {
          label: 'I/We acknowledge that my/our adviser has provided me/us with a detailed comparison between my/our existing and proposed policies/benefits that covers the key aspects outlined above, and that I/we understand the consequences of my/our adviser’s recommendation.',
          value: 'option_1',
        },
        {
          label: ' I/We acknowledge that my/our adviser has not provided us with advice in respect of this replacement but I/we have been advised of the types of adverse circumstances which might occur as a result of changing products.',
          value: 'option_2',
        },
        {
          label: 'I/We acknowledge that a copy of the brochure ‘Get the most out of life’ has been given to me/us and I/we have read it and understand what it means to me/us',
          value: 'option_3'
        },
        {
          label: 'I/We acknowledge that this information was provided and explained to me/us before I/we signed the application for the new policy/benefit.',
          value: 'option_4',
        },
      ];
    },
  },
  components: {
    ReportsView,
    GenerateEmail,
    VueFriendlyIframe,
    GenerateSignature,
    GenerateLimitedAdvice,
  },
};
</script>

<style lang="stylus" scoped>
.advice-on-business-replacement-max-height
  min-height 100vh
.service-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
