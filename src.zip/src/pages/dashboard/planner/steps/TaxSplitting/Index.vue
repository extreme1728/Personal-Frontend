<template lang="pug">
  div
    div(v-show="!isClientEmployed && shouldShowRemainingQuestions")
      include ../IncomeDetails/blocks/acc-title
    div(v-if="!isClientEmployed")
      include blocks/income
    include blocks/income-result
    income-levy-calculation-notes(
      v-if="showCalculatedLevy"
      is-partner
      :client-name="plan.partner_name"
      :cover-plus-calculation="getCoverPlusCalculation"
      :income-tax-method="plan.partner_income_tax_method"
      :is-already-on-acc-cover-plus-extra="isAlreadyOnAccCoverPlusExtra"
      :cover-plus-extra-calculation="getDeterminedCoverPlusExtraCalculation"
      :cover-plus-total-amount-payable="getCoverPlusCalculationTotalAmountPayableToAcc"
    )
</template>

<script>
import { QSpinnerGears } from 'quasar';
import { validationMixin } from 'vuelidate';
import { mapActions, mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { eq, lowerCase, toString } from 'lodash';
import { required } from 'vuelidate/lib/validators';
import { FieldableMixin, FilterableMixin } from 'src/mixins';
import { maxValue, minValue } from 'src/services/validation';
import DatePicker from 'src/components/datepicker/DatePicker';
import { IncomeLevyCalculationNotes } from 'src/components/ipp';
import { PigBank, PigSavings } from 'src/components/charts/Pigs';

export default {
  name: 'tax-splitting',
  mixins: [validationMixin, FieldableMixin, FilterableMixin],
  data: () => ({
    calculating: false,
    classificationUnitOptions: [],
  }),
  created() {
    this.classificationUnitOptions = this.mapClassificationUnitValues;
  },
  props: {
    isClientEmployed: Boolean,
  },
  methods: {
    ...mapActions('partnerCalculations', ['requestAllLevyCalculations']),
    __filterFn(val, update) {
      if (val === '') {
        update(() => {
          this.classificationUnitOptions = this.mapClassificationUnitValues;
        });
        return;
      }
      update(() => {
        const needle = lowerCase(val);
        this.classificationUnitOptions = this.mapClassificationUnitValues.filter(({ value, label }) => {
          return lowerCase(toString(value)).indexOf(toString(needle)) > -1
            || lowerCase(toString(label)).indexOf(lowerCase(needle)) > -1;
        });
      });
    },
    async calculateLevy() {
      try {
        this.calculating = true;
        this.$q.loading.show({
          message: 'Calculating.... Please wait.',
          spinner: QSpinnerGears,
        });
        await this.requestAllLevyCalculations();
      }
      catch (e) {}
      finally {
        this.$q.loading.hide();
        this.calculating = false;
      }
    },
    handlePartnerEmployedScheduleTypeOnChange(value, field) {
      if (eq(value, 'part-time')) {
        this.showPartnerEmployedScheduleTypePrompt();
      }
      this.updatePlanField(value, field);
    },
    async showPartnerEmployedScheduleTypePrompt() {
      try {
        await this.$q.dialog({
          title: 'Warning:',
          color: 'amber',
          message: this.plan.partner_name + ` is not eligible for Cover Plus Extra (CPX) as CPX is only available when client is working full time`,
        });
      } catch (e) {}
    },
  },
  computed: {
    ...mapGetters('planner', [
      'partnerGrossIncome',
      'isPartnerEmployed',
      'isPartnerHouseMaker',
      'isPartnerSelfEmployed',
    ]),
    ...mapGetters('resources', {
      employmentScheduleValues: 'employmentScheduleValues',
      booleanValues: 'booleanValues',
      taxMethodValues: 'taxMethodValues',
      employmentValues: 'employmentValues',
      accCoverPlanTypes: 'accCoverPlanTypes',
      paymentMethods: 'mortgageRepaymentMethods',
    }),
    ...mapGetters('partnerCalculations', {
        showCalculatedLevy: 'showCalculatedLevy',
        getPigSavingsAmount: 'getPigSavingsAmount',
        getPigSavingsPercentage: 'getPigSavingsPercentage',
        getCoverPlusCalculation: 'getCoverPlusCalculation',
        coverPlusExtraCalculation: 'getCoverPlusExtraCalculation',
        currentClassificationUnit: 'getSelectedClassificationUnit',
        isTheSameClassificationUnit: 'isTheSameClassificationUnit',
        isAlreadyOnAccCoverPlusExtra: 'isAlreadyOnAccCoverPlusExtra',
        getTotalIncomeProtectionAmount: 'getTotalIncomeProtectionAmount',
        getDeterminedCalculationHeaderLabel: 'getDeterminedCalculationHeaderLabel',
        getDeterminedCoverPlusExtraCalculation: 'getDeterminedCoverPlusExtraCalculation',
        getCoverPlusCalculationTotalAmountPayableToAcc: 'getCoverPlusCalculationTotalAmountPayableToAcc',
    }),
    ...mapGetters('classificationUnit', [
      'mapClassificationUnitValues',
      'isClasificationUnitValuesEmpty',
    ]),
    getPartnerWhatJobLabel() {
      const { partner_name: name } = this.plan;
      return `What job does ${name || 'Husband/Wife'} do?`;
    },
    getEmploymentPositionTypeLabel() {
      const { partner_name: name } = this.plan;
      return `What is ${name || 'Husband/Wife'} employment status?`;
    },
    getPartnerIsWorkingForBusinessLabel() {
      const { partner_name: name } = this.plan;
      return `Is ${name || 'Husband/Wife'} working for business?`;
    },
    getPartnerDesignationLabel() {
      const { partner_name: name } = this.plan;
      return `Is ${name || 'Husband/Wife'} a...Shareholder or Director?`;
    },
    getPartnerAccountTaxSpliitingLabel() {
      const { partner_name: name } = this.plan;
      return `Is your Accountant Tax splitting with ${name || 'Husband/Wife'}?`
    },
    getPartnerTaxMethodLabel() {
      const { partner_name: name } = this.plan;
      return `Is ${name || 'Husband/Wife'} on Drawings or PAYE?`;
    },
    getPartnerTakingFirm() {
      const { partner_name: name } = this.plan;
      return `How much is ${name || 'Husband/Wife'} taking from the firm?`;
    },
    getPartnerNominatedCoverAmount(){
      const { partner_name:name } = this.plan;
      return `How much is ${name || 'Husband/Wife'}'s nominated Cover Plus Extra cover amount?`;
    },
    getPartnerOnToolsLabel() {
      const { partner_name: name } = this.plan;
      return `Is ${name || 'Husband/Wife'} on tools?`;
    },
    getPartnerBusinessOnToolsLabel() {
      const { partner_name: name } = this.plan;
      return `What is it that ${name || 'Husband/Wife'} does?`;
    },
    getPartnerBusinessLabel() {
      const { partner_name: name } = this.plan;
      return `How long has ${name || 'Husband/Wife'} been doing this (in years)?`;
    },
    isPartnerTakingPartOfTheBusiness() {
      return eq(this.plan.is_partner_shareholder_or_directory, 'yes');
    },
    shouldShowRemainingQuestions() {
      return this.isPartnerTakingPartOfTheBusiness
        && eq(this.plan.is_partner_account_tax_splitting, 'yes')
        ? true
        : false;
    },
    getDeterminedPigColumnClass() {
      const hasPercentage = this.getPigSavingsPercentage > 0;
      return !hasPercentage ? {
        'col-md-8': true,
        'offset-md-2': true,
      } : { 'col-md-6': true };
    },
    cpxPartnerWarningMessage() {
      if (eq(this.plan.partner_employed_schedule_type, 'part-time')){
        return this.plan.partner_name + ` is not eligible for Cover Plus Extra (CPX) as CPX is only available when client is working full time`;
      }
    },
  },
  components: {
    QInput,
    PigBank,
    PigSavings,
    DatePicker,
    IncomeLevyCalculationNotes,
  },
};
</script>
