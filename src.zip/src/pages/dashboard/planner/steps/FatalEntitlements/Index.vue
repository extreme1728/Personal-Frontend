<template lang="pug">
div
  q-card(flat)
    q-card-section ACC Fatal Entitlements Calculator
    q-card-section
      include blocks/inputs
      transition-group(enter="fadeIn" leave="fadeOut" appear)
        include blocks/has-child
        include blocks/has-child-studying
  div(class="chart-block--space" v-if="showFatalEntitlementCalculation")
    component(
      :is="getFatalEntitlementCalculations.component"
      :cover-plus-amount="getFatalEntitlementCalculations.coverPlusTotalBenifitAmount"
      :cover-plus-extra-amount="getFatalEntitlementCalculations.coverPlusExtraTotalBenifitAmount"
      :changes-in-cover="getFatalEntitlementCalculations.changesInCoverAmount"
    )
  div(class="chart-block--space" v-else)
    h4(class="text-center text-faded") INCOME AMOUNT REQUIRED
</template>

<script>
import {
  NoChild,
  LessThanTwoChildren,
  GreaterThanTwoChildren,
  StudyingChildren,
} from 'src/components/charts/Families';
import moment from 'moment';
import { date } from 'quasar';
import { mapGetters } from 'vuex';
import { validationMixin } from 'vuelidate';
import { FieldableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { numberWithCommas } from 'src/config/utils';
import { required } from 'vuelidate/lib/validators';
import { maxValue, minValue } from 'src/services/validation';
import DatePicker from 'src/components/datepicker/DatePicker';
import { cloneDeep, merge, filter, concat, set, eq, includes } from 'lodash';

const yearNow = date.formatDate(Date.now(), 'YYYY');
const yearAfter = date.formatDate(date.addToDate(Date.now(), { year: 1 }), 'YYYY');
const childModelSchema = {
  id: 0,
  name: null,
  age: null,
  gender: null,
  date_of_birth: null,
  studying: false,
};

export default {
  name: 'fatal-entitlements',
  mixins: [validationMixin, FieldableMixin],
  data: () => ({
    childModel: cloneDeep(childModelSchema),
    childModelWhoStudy: cloneDeep(merge(childModelSchema, { studying: true })),
    arrayOfChildrens: [],
    arrayOfChildrensWhoStudy: [],
  }),
  mounted() {
    this.$v.plan.$touch();
  },
  async created() {
    const { fatal_entitlement_childrens, nominated_cover_amount } = this.plan;
    this.arrayOfChildrens = filter(cloneDeep(fatal_entitlement_childrens), ['studying', false]);
    this.arrayOfChildrensWhoStudy = filter(cloneDeep(fatal_entitlement_childrens), ['studying', true]);
    await this.updatePlanField(nominated_cover_amount, 'fatal_entitlement_annual_pre_aggreed_cover_amount');
  },
  watch: {
    childModelWhoStudy: {
      handler({ date_of_birth }) {
        if (date_of_birth) this.childModelWhoStudy.age = this.$filters.getAgeByDate(date_of_birth);
      },
      deep: true,
    },
    childModel: {
      handler({ date_of_birth }) {
        if (date_of_birth) this.childModel.age = this.$filters.getAgeByDate(date_of_birth);
      },
      deep: true,
    },
    arrayOfChildrens: {
      handler(values) {
        // Concat reverse
        // this.updatePlanField(concat(values, this.arrayOfChildrensWhoStudy), 'fatal_entitlement_childrens');
      },
      deep: true,
    },
    arrayOfChildrensWhoStudy: {
      handler(values) {
        // Concat reverse
        // this.updatePlanField(concat(values, this.arrayOfChildrens), 'fatal_entitlement_childrens');
      },
      deep: true,
    },
  },
  methods: {
    async addChildrenWhoStudy() {
      const { name } = this.childModelWhoStudy;
      if (!name) {
        this.$q.notify({
          message: 'Name cannot be empty',
          color: 'negative',
          icon: 'error',
        });
        return;
      }

      this.arrayOfChildrensWhoStudy.push({
        ...this.childModelWhoStudy,
        studying: true,
      });

      this.childModelWhoStudy = cloneDeep(merge(childModelSchema, { studying: true }));

      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(
        concat(this.arrayOfChildrensWhoStudy, this.arrayOfChildrens),
        'fatal_entitlement_childrens'
      );

      this.arrayOfChildrensWhoStudy = filter(fatal_entitlement_childrens, ['studying', true]);
    },
    async modifyChildrenWhoStudy(value, children, field) {
      if (children.date_of_birth) children.age = this.$filters.getAgeByDate(children.date_of_birth);
      set(children, field, value);

      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(
        concat(this.arrayOfChildrensWhoStudy, this.arrayOfChildrens),
        'fatal_entitlement_childrens'
      );

      this.arrayOfChildrensWhoStudy = filter(fatal_entitlement_childrens, ['studying', true]);
    },
    async removeChildrenWhoStudy(childModel) {
      const { fatal_entitlement_childrens } = await this.removePlanRelationInstanceField(
        childModel,
        'fatal_entitlement_childrens',
      );
      this.arrayOfChildrensWhoStudy = filter(fatal_entitlement_childrens, ['studying', true]);
    },
    async addChildren() {
      const { name } = this.childModel;
      if (!name) {
        this.$q.notify({
          message: 'Name cannot be empty',
          color: 'negative',
          icon: 'error',
        });
        return;
      }

      // validation for age and limit requirement
      if (eq(this.plan.fatal_entitlement_category_type, 'less-than-two-children')) {
        if (this.arrayOfChildrens.length >= 2) {
          this.$q.notify({
            message: 'Children must be less than equal to two.',
            color: 'secondary',
            icon: 'warning',
          });
          return;
        }
        if (age >= this.fatalRequirement.age_income_requirement) {
          this.$q.notify({
            message: `Children age must not be greater than equal ${this.fatalRequirement.age_income_requirement}`,
            color: 'secondary',
            icon: 'warning',
          });
          return;
        }
      }

      this.arrayOfChildrens.push({
        ...this.childModel,
        studying: false,
      });

      this.childModel = cloneDeep(childModelSchema);

      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(
        concat(this.arrayOfChildrensWhoStudy, this.arrayOfChildrens),
        'fatal_entitlement_childrens'
      );

      this.arrayOfChildrens = filter(fatal_entitlement_childrens, ['studying', false]);
    },
    async modifyChildren(value, children, field) {
      if (children.date_of_birth) children.age = this.$filters.getAgeByDate(children.date_of_birth);
      set(children, field, value);

      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(
        concat(this.arrayOfChildrensWhoStudy, this.arrayOfChildrens),
        'fatal_entitlement_childrens'
      );

      this.arrayOfChildrens = filter(fatal_entitlement_childrens, ['studying', false]);
    },
    async removeChildren(childModel) {
      const { fatal_entitlement_childrens } = await this.removePlanRelationInstanceField(
        childModel,
        'fatal_entitlement_childrens'
      );
      this.arrayOfChildrens = filter(fatal_entitlement_childrens, ['studying', false]);
    },
    onBlurAnnualPreAgreedCoverAmount() {
      const { minimum, maximum } = this.liabilityRequirement.nominated_cover_amount;
      // eslint-disable-next-line
      const { minValue, maxValue } = this.$v.plan.fatal_entitlement_annual_pre_aggreed_cover_amount;

      if (!minValue) {
        this.updatePlanField(numberWithCommas(minimum), 'nominated_cover_amount');
      }

      if (!maxValue) {
        this.updatePlanField(numberWithCommas(maximum), 'nominated_cover_amount');
      }
    },
    __getAge({ date_of_birth, age }) {
      if (age) return age;
      const viaFilterService = this.$filters.getAgeByDate(date_of_birth);
      if (viaFilterService) return viaFilterService;
      const m = moment(date_of_birth);
      return m.isValid()
        ? m.fromNow(true)
        : null;
    },
  },
  computed: {
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
      mapClientAndPartnerNameValues: 'mapClientAndPartnerNameValues',
      showFatalEntitlementCalculation: 'showFatalEntitlementCalculation',
      getFatalEntitlementCalculations: 'getFatalEntitlementDetermineCalculationByCategory',
      getDetermineActualEstimatedEarningsAmount: 'getFatalEntitlementDetermineActualEstimatedEarningsAmount',
    }),
    ...mapGetters('resources', {
      genders: 'genders',
      inputDateFormat: 'inputDateFormat',
      getFatalEntitlementCategories: 'fatalEntitlementCategories',
    }),
    ...mapGetters('liabilityRates', {
      fatalRequirement: 'fatal',
      liabilityRequirement: 'requirements',
    }),
    getDetermineCategoryFieldMessage() {
      return `${this.plan.fatal_entitlement_for_type} Category`;
    },
    getAnnualPreAgreedCoverAmountFieldMessage() {
      return `Annual Pre-Agreed Cover Amount for ${yearNow}/${yearAfter}`;
    },
    getActualEstimatedEarningsFieldMessage() {
      return `Actual/Estimated Earnings for ${yearNow}/${yearAfter}`;
    },
    determineHasChildrenFromCategory() {
      if (this.determineHasChildrenAndStudyingFromCategory) return true;
      return includes(['less-than-two-children', 'greater-than-two-children'], this.plan.fatal_entitlement_category_type);
    },
    determineHasChildrenAndStudyingFromCategory() {
      return includes(['studying-children'], this.plan.fatal_entitlement_category_type);
    },
    getAnnualPreAgreedCoverAmountErrorMessage() {
      const { minimum, maximum } = this.liabilityRequirement.nominated_cover_amount;
      // eslint-disable-next-line
      const { minValue, maxValue } = this.$v.plan.fatal_entitlement_annual_pre_aggreed_cover_amount;

      if (!minValue) {
        return `The amount you have entered is less than the minimum cover of $${numberWithCommas(minimum)} this amount will be used in your calculations.`;
      }

      if (!maxValue) {
        return `The amount you have entered is more than the maximum cover of $${numberWithCommas(maximum)} this amount will be used in your calculations.`;
      }
      return null;
    },
    shouldShowChildrensOption() {
      return !((this.arrayOfChildrens.length >= 2) && eq(this.plan.fatal_entitlement_category_type, 'less-than-two-children'));
    },
  },
  validations() {
    return {
      plan: {
        fatal_entitlement_annual_pre_aggreed_cover_amount: {
          required,
          minValue: minValue(this.liabilityRequirement.nominated_cover_amount.minimum),
          maxValue: maxValue(this.liabilityRequirement.nominated_cover_amount.maximum),
        },
      },
    };
  },
  components: {
    QInput,
    NoChild,
    DatePicker,
    StudyingChildren,
    LessThanTwoChildren,
    GreaterThanTwoChildren,
  },
};
</script>

<style lang="stylus" scoped>
  .chart-block--space
    margin-top 5vh
    margin-bottom 5vh
</style>
