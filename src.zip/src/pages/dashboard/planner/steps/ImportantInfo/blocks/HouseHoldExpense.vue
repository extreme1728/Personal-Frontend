<template lang="pug">
div
  p(class="text-faded no-margin-bottom") Household Expenses
  div(class="row q-mb-md q-col-gutter-md")
    div(class="col-md-3")
      q-select(
        emit-value
        map-options
        options-cover
        stack-label
        label="Payment Frequency"
        :options="mortgageRepaymentMethods"
        v-model="model.frequency"
      )
    div(class="col-md-5")
      q-select(
        emit-value
        map-options
        options-cover
        stack-label
        label="Expense"
        :options="houseHoldExpensesOptions"
        v-model="model.name"
      )
    div(class="col-md-3")
      q-input(
        stack-label
        label="Amount"
        type="tel"
        prefix="$"
        v-money="{}"
        align="right"
        v-model="model.value"
      )
    div(class="col-md-1 q-mt-md")
      q-btn(
        :disable="$v.$error"
        flat
        icon="add"
        class="full-width"
        color="primary"
        @click="__add"
      )
  div(
    v-for="(model, index) in expenses"
    class="row q-col-gutter-md"
    :class="{ 'q-my-md': index != 0 }"
    :key="index + 1"
  )
    div(class="col-md-3")
      q-select(
        emit-value
        map-options
        options-cover
        label="Payment Frequency"
        :options="mortgageRepaymentMethods"
        :value="model.frequency"
        @input="_ => __modify(model, _, 'frequency')"
      )
    div(class="col-md-5")
      q-select(
        emit-value
        map-options
        options-cover
        label="Expense"
        :options="houseHoldExpensesOptions"
        :value="model.name"
        @input="_ => __modify(model, _, 'name')"
      )
    div(class="col-md-3")
      q-input(
        label="Amount"
        type="tel"
        prefix="$"
        v-money="{}"
        align="right"
        debounce="500"
        :value="model.value"
        @input="_ => __modify(model, _, 'value')"
      )
    div(class="col-md-1 q-mt-md")
      q-btn(
        flat
        icon="remove"
        class="full-width"
        color="red-5"
        @click="__remove(model)"
      )
</template>

<script>
import { mapGetters } from 'vuex';
import { set, cloneDeep } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { validationMixin } from 'vuelidate';
import { QInput } from 'src/components/quasar';
import { required } from 'vuelidate/lib/validators';

const expenseschema = {
  id: 0,
  frequency: null,
  name: null,
  value: null,
};

export default {
  name: 'house-hold-expense',
  mixins: [validationMixin, FieldableMixin],
  data: () => ({
    model: cloneDeep(expenseschema),
    expenses: [],
  }),
  mounted() {
    this.$v.$touch();
  },
  created() {
    const { household_expenses: expenses } = this.plan;
    this.expenses = expenses;
  },
  methods: {
    async __add() {
      this.expenses.push(cloneDeep(this.model));
      set(this, 'model', cloneDeep(expenseschema));
      const { household_expenses } = await this.updatePlanRelationField(this.expenses, 'household_expenses');
      this.expenses = household_expenses;
    },
    async __modify(model, value, field) {
      set(model, field, value);
      const { household_expenses } = await this.updatePlanRelationField(this.expenses, 'household_expenses');
      this.expenses = household_expenses;
    },
    async __remove(model) {
      const { household_expenses } = await this.removePlanRelationInstanceField(model, 'household_expenses');
      this.expenses = household_expenses;
    },
  },
  computed: {
    ...mapGetters('resources', [
      'houseHoldExpensesOptions',
      'mortgageRepaymentMethods',
    ]),
  },
  validations() {
    return {
      model: {
        name: {
          required,
        },
        frequency: {
          required,
        },
        value: {
          required,
        },
      },
    };
  },
  components: {
    QInput,
  },
};
</script>
