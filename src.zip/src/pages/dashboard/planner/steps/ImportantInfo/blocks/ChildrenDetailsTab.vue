<template lang="pug">
div
  q-select(
    emit-value
    map-options
    class="q-my-md"
    :options="booleanValues"
    label="Do you have kids?"
    :value="plan.have_childrens"
    @input="value => updatePlanField(value, 'have_childrens')"
  )
  div(v-if="plan.have_childrens === 'yes'")
    div(class="row")
      h6(class="text-h5 text-faded no-margin-bottom") What are the kids names and ages?
    children-details-important-info(
      v-if="plan.fatal_entitlement_childrens && plan.fatal_entitlement_childrens.length"
      :values="plan.fatal_entitlement_childrens"
      @change="onHandleChangeChildrens"
      @remove="onHandleRemoveChildren"
    )
    div(class="row q-col-gutter-md")
      div(class="col-md-3")
        q-input(
          :error="$v.child.name.$error"
          placeholder="Name"
          v-model="child.name"
          @keyup.enter="addChildren"
          bottom-slots
          error-message="Please enter child name"
        )
      div(class="col-md-2")
        q-select(
          emit-value
          map-options
          placeholder="Gender"
          :options="genders"
          v-model="child.gender"
          :disable="!child.name"
        )
      div(class="col-md-2")
        date-picker(
          clearable
          :inline="false"
          v-model="child.date_of_birth"
          :disable="!child.name"
        )
      div(class="col-md-2")
        q-input(
          type="tel"
          placeholder="Age"
          :value="__getAge(child)"
          @input="_ => child.age = _"
          :disable="!!child.date_of_birth || !child.name"
          bottom-slots
          v-if="!childAge"
            :hint="lessThanAYear"
        )
      div(class="col-2 q-my-md text-center")
        q-toggle(
          label="Studying"
          v-model="child.studying"
        )
      div(class="col-md-1 q-my-md")
        q-btn(
          icon="add"
          color="primary"
          class="full-width"
          @click="addChildren"
          :disable="$v.$error"
        )
</template>

<script>
import moment from 'moment';
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { validationMixin } from 'vuelidate';
import { QInput } from 'src/components/quasar';
import { cloneDeep, set, filter } from 'lodash';
import { required, between } from 'vuelidate/lib/validators';
import DatePicker from 'src/components/datepicker/DatePicker';
import { ChildrenDetailsImportantInfo } from 'src/components/ipp/planner';

const childSchema = {
  id: 0,
  age: null,
  name: null,
  gender: null,
  studying: false,
  date_of_birth: null,
};

export default {
  name: 'children-details-tab',
  mixins: [FieldableMixin, validationMixin],
  data: () => ({
    childAge: false,
    arrayOfChildrens: [],
    child: cloneDeep(childSchema)
  }),
  created() {
    const { fatal_entitlement_childrens: childrens } = this.plan;
    this.arrayOfChildrens = childrens;
  },
  mounted() {
    this.$v.child.$touch();
  },
  watch: {
    child: {
      handler: 'childHandler',
      immediate: true,
      deep: true,
    },
    arrayOfChildrens: {
      handler: 'arrayOfChildrensHandler',
      deep: true,
    },
  },
  methods: {
    async arrayOfChildrensHandler(childrens) {
      // Determine category for fatal entitlement children
      let category = 'no-child';

      if (this.plan.have_childrens === 'yes') {
        if (childrens.length <= 2 ) {
          category = 'less-than-two-children';
        }

        if (childrens.length > 2) {
          category = 'greater-than-two-children';
        }

        if (filter(childrens, 'studying').length) {
          category = 'studying-children';
        }
      }

      await this.updatePlanField({
        fatal_entitlement_category_type: category,
      });
    },
    childHandler({ date_of_birth }) {
      if (date_of_birth)
        set(this.child, 'age', this.$filters.getAgeByDate(date_of_birth));
    },
    async addChildren() {
      this.arrayOfChildrens.push(cloneDeep(this.child));
      set(this, 'child', cloneDeep(childSchema));
      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(this.arrayOfChildrens, 'fatal_entitlement_childrens');
      this.arrayOfChildrens = fatal_entitlement_childrens;
    },
    async onHandleChangeChildrens(childrens) {
      const { fatal_entitlement_childrens } = await this.updatePlanRelationField(childrens, 'fatal_entitlement_childrens');
      this.arrayOfChildrens = fatal_entitlement_childrens;
    },
    async onHandleRemoveChildren(child) {
      const { fatal_entitlement_childrens } = await this.removePlanRelationInstanceField(child, 'fatal_entitlement_childrens');
      this.arrayOfChildrens = fatal_entitlement_childrens;
    },
    __getAge({ date_of_birth, age }) {
      if (age) return age;
      const viaFilterService = this.$filters.getAgeByDate(date_of_birth);
      if (viaFilterService) return viaFilterService;
      const m = moment(date_of_birth);
      return m.isValid()
        ? m.fromNow(true)
        : null;
    },
  },
  computed: {
    ...mapGetters('resources', ['booleanValues', 'genders']),
    // ...mapGetters('planners', )
    lessThanAYear() {
      const viaFilterService = this.$filters.getAgeByDate(this.child.date_of_birth);
      if (viaFilterService) {
        return viaFilterService >= 2
          ? "Years old"
          : "Year old";
      } 
    },
  },
  validations() {
    return {
      child: {
        name: {
          required,
        },
      },
    };
  },
  components: {
    QInput,
    DatePicker,
    ChildrenDetailsImportantInfo,
  },
};
</script>
