<template lang="pug">
div
  p(class="text-faded no-margin-bottom") Investment/Rental Property
  div(class="row")
    div(class="col-md-12")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          q-input(
            type="tel"
            prefix="$"
            v-money="{}"
            class="q-my-md"
            label="Mortgage Amount"
            v-model="model.mortgage_amount"
          )
        div(class="col-md-6")
          q-select(
            emit-value
            map-options
            class="q-my-md"
            :options="booleanValues"
            label="Does rental income cover mortgage repayments?"
            v-model="model.does_rental_income_cover_mortgage_repayments"
          )
      div(
        v-if="model.does_rental_income_cover_mortgage_repayments === 'no'"
        class="row q-col-gutter-md"
      )
        div(class="col-md-6")
          q-input(
            prefix="$"
            v-money="{}"
            class="q-my-md"
            label="How much is the shortfall"
            v-model="model.shortfall_amount"
          )
        div(class="col-md-6")
          q-input(
            type="text"
            class="q-my-md"
            placeholder="ie Term of mortgage"
            label="How long will shortfall last?"
            v-model="model.how_long_will_shortfall_last"
          )
      div(claas="row q-my-md")
        q-btn(
          flat
          icon="add"
          color="primary"
          @click="__add"
          class="full-width"
        )
  //- records
  div(
    class="row"
    v-for="(model, index) in mortgages"
    :class="{ 'q-my-md': index != 0 }"
    :key="index + 1"
  )
    div(class="col-md-12")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          q-input(
            type="tel"
            prefix="$"
            v-money="{}"
            debounce="500"
            class="q-my-md"
            label="Mortgage Amount"
            :value="model.mortgage_amount"
            @input="_ => __modify(model, _, 'mortgage_amount')"
          )
        div(class="col-md-6")
          q-select(
            emit-value
            map-options
            class="q-my-md"
            :options="booleanValues"
            label="Does rental income cover mortgage repayments?"
            :value="model.does_rental_income_cover_mortgage_repayments"
            @input="_ => __modify(model, _, 'does_rental_income_cover_mortgage_repayments')"
          )
      div(
        class="row q-col-gutter-md"
        v-if="model.does_rental_income_cover_mortgage_repayments === 'no'"
      )
        div(class="col-md-6")
          q-input(
            prefix="$"
            v-money="{}"
            debounce="500"
            class="q-my-md"
            :value="model.shortfall_amount"
            label="How much is the shortfall"
            @input="_ => __modify(model, _, 'shortfall_amount')"
          )
        div(class="col-md-6")
          q-input(
            type="text"
            debounce="500"
            class="q-my-md"
            placeholder="ie Term of mortgage"
            label="How long will shortfall last?"
            :value="model.how_long_will_shortfall_last"
            @input="_ => __modify(model, _, 'how_long_will_shortfall_last')"
          )
      div(class="row q-my-md")
        q-btn(
          flat
          icon="remove"
          class="full-width"
          color="red-5"
          @click="__remove(model)"
        )
</template>

<script>
import { mapGetters } from 'vuex';
import { set, cloneDeep } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';

const mortgageSchema = {
  id: 0,
  mortgage_amount: null,
  does_rental_income_cover_mortgage_repayments: null,
  shortfall_amount: null,
  how_long_will_shortfall_last: null,
};

export default {
  name: 'investment-and-rental-property',
  data: () => ({
    model: cloneDeep(mortgageSchema),
    mortgages: [],
  }),
  mixins: [FieldableMixin],
  created() {
    const { mortgages } = this.plan;
    this.mortgages = mortgages;
  },
  methods: {
    async __add() {
      this.mortgages.push(cloneDeep(this.model));
      set(this, 'model', cloneDeep(mortgageSchema));
      const { mortgages } = await this.updatePlanRelationField(this.mortgages, 'mortgages');
      this.mortgages = mortgages;
    },
    async __modify(model, value, field) {
      set(model, field, value);
      const { mortgages } = await this.updatePlanRelationField(this.mortgages, 'mortgages');
      this.mortgages = mortgages;
    },
    async __remove(model) {
      const { mortgages } = await this.removePlanRelationInstanceField(model, 'mortgages');
      this.mortgages = mortgages;
    },
  },
  computed: {
    ...mapGetters('resources', [
      'booleanValues',
    ]),
  },
  components: {
    QInput,
  },
};
</script>
