<template lang="pug">
div
  q-tabs(
    align="center"
    class="text-secondary"
    v-model="currentTab"
  )
    include blocks/tab-navigation

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="accountant-details")
      include blocks/accountant-details
    q-tab-panel(name="personal-details")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/personal-details
        div(class="col-md-6")
          include blocks/partner/personal-details
    q-tab-panel(name="medical")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/medical-details
        div(class="col-md-6")
          include blocks/partner/medical-details
    q-tab-panel(name="hazardous-activities" class="important__info--max-height")
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          include blocks/client/hazardous-activities
        div(class="col-md-6")
          include blocks/partner/hazardous-activities
    q-tab-panel(
      name="business-partners-information"
      v-if="showBusinessPartners"
    )
      business-partner-important-info(
        class="q-pb-xl"
        :values="plan.business_partners"
        @change="values => updatePlanField(values, 'business_partners')"
      )
    q-tab-panel(name="children-details" class="important__info--max-height")
      children-details-tab
    q-tab-panel(name="expenses-details" class="important__info--max-height")
      include blocks/expenses-details
    q-tab-panel(name="notes")
      include blocks/notes
</template>

<script>
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { QInput } from 'src/components/quasar';
import { cloneDeep, eq, isEmpty } from 'lodash';
import ChildrenDetailsTab from './blocks/ChildrenDetailsTab';
import DatePicker from 'src/components/datepicker/DatePicker';
import { BusinessPartnerImportantInfo, BodyMassIndexInput, MedicalConditionInput } from 'src/components/ipp/planner';
import HouseHoldExpense from './blocks/HouseHoldExpense';
import InvestmentAndRentalProperty from './blocks/InvestmentAndRentalProperty';

const customProviderSchema = {
  show: false,
  values: [],
};

export default {
  name: 'important-info',
  mixins: [FieldableMixin],
  data() {
    const currentTab = this.isSelfEmployed
      ? 'accountant-details'
      : 'personal-details';
    return {
      currentTab,
      clientCustomExistingProvider: cloneDeep(customProviderSchema),
      partnerCustomExistingProvider: cloneDeep(customProviderSchema),
    };
  },
  watch: {
    plan: {
      handler({ client_country_birth, partner_country_birth }) {
        if (eq(client_country_birth, 'New Zealand')) {
          this.updatePlanField('yes', 'client_citizen_or_pr');
        }
        if (eq(partner_country_birth, 'New Zealand')) {
          this.updatePlanField('yes', 'partner_citizen_or_pr');
        }
      },
      deep: true,
    }
  },
  methods: {
    handleFamilyHistoryOnChange(value, field) {
      if (eq(value, 'yes')) {
        this.showFamilyHistoryPropmt();
      }
      this.updatePlanField(value, field);
    },
    handleSmokingWhenTookOutPreviousRiskOnChange(value, field) {
      if (value && eq(value, 'no')) {
        this.showSmokerCoverRatePrompt();
      }
      this.updatePlanField(value, field);
    },
    showSmokerCoverRatePrompt() {
      this.$q.dialog({
        title: 'Warning',
        color: 'amber',
        message: 'Any new cover will have smoker rates applied',
      });
    },
    showFamilyHistoryPropmt() {
      this.$q.dialog({
        title: 'Multiple Sclerosis Family History Warning',
        color: 'amber',
        message: `If an immediate family member (father, mother, brother, sister) has multiple sclerosis, an exclusion may apply with all providers except AIA and Asteron* (AIA and Asteron may not exclude if you are older than 40 years old)
          \n\n
          * as Asteron and AIA use Re-Insurer RGA`,
      });
    },
  },
  computed: {
    getCountryBirthOptions: () => ([
      { label: 'New Zealand', value: 'New Zealand' },
    ]),
    getDeterminedMortgageAndRentalTypeLabel() {
      return eq(this.plan.household_building_expense, 'mortgage-repayments')
        ? 'Mortgage Repayments Frequency'
        : 'Rental Payments Frequency';
    },
    getDeterminedMortgageAndRentalLabel() {
      return eq(this.plan.household_building_expense, 'mortgage-repayments')
        ? 'Mortgage Repayments (inc Rental property mortgage repayments)'
        : 'Rental Payments';
    },
    ...mapGetters('planner', [
      'isEmployed',
      'hasChildren',
      'getAssetsNote',
      'isSelfEmployed',
      'getEstatePlanningNotes',
      'getClientHouseholdSavings',
    ]),
    ...mapGetters('resources', [
      'booleanValues',
      'existingCovers',
      'propertyTypeOptions',
      'maritalStatusOptions',
      'diabetesTypesOptions',
      'mortgageRepaymentMethods',
      'houseHoldExpensesOptions',
    ]),
    ...mapGetters('user', ['isMarketingSpecialist']),
    ...mapGetters('medicalCategories', ['medicals', 'familials']),
    ...mapGetters('hazardousActivitiyCategories', ['activities']),
    showBusinessPartners() {
      const { business_partners } = this.plan;
      return business_partners && business_partners.length;
    },
  },
  components: {
    QInput,
    DatePicker,
    ChildrenDetailsTab,
    BusinessPartnerImportantInfo,
    BodyMassIndexInput,
    MedicalConditionInput,
    HouseHoldExpense,
    InvestmentAndRentalProperty,
  },
};
</script>

<style lang="stylus" scoped>
.important__info--max-height
  min-height 100vh
.remove__gap--margin-bottom
  margin-bottom -18px
</style>
