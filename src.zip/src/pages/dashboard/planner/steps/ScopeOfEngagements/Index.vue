<template lang="pug">
div
  div(class="row justify-center")
    h6(class="text-faded") Scope of Services
  div(class="row q-col-gutter-md")
    scope-of-services(
      :display-name="getClientName"
      :payload="clientServices"
      class="offset-md-2 col-md-4"
      type="client"
      @save="onHandleScopeServiceSave"
    )
    scope-of-services(
      :display-name="getPartnerName"
      :payload="partnerServices"
      class="col-md-4"
      type="partner"
      @save="onHandleScopeServiceSave"
    )
</template>

<script>
import { mapGetters } from 'vuex';
import { castArray } from 'lodash';
import { FieldableMixin } from 'src/mixins';
import { ScopeOfServices } from 'src/components/ipp/scopes';

export default {
  name: 'scope-of-engagements',
  mixins: [FieldableMixin],
  methods: {
    onHandleScopeServiceSave(payload) {
      this.$q.notify({
        message: 'Saving',
        color: 'primary',
        icon: 'save',
        timeout: 1000,
        position: this.$q.platform.is.mobile ? 'top' : 'top-right',
      });
      this.updatePlanRelationField(
        castArray(payload),
        'scope_services',
      );
      this.$q.notify({
        message: 'Saved',
        color: 'secondary',
        icon: 'check',
        timeout: 1000,
        position: this.$q.platform.is.mobile ? 'top' : 'top-right',
      });
    },
  },
  computed: mapGetters('planner', {
    clientServices: 'clientScopeServices',
    partnerServices: 'partnerScopeServices',
  }),
  components: {
    ScopeOfServices,
  },
};
</script>
