<template lang="pug">
div(class="q-mt-md")
  template(v-if="isPartnerEmployed")
    template(v-if="!isPartnerHouseMaker")
      h6(
        v-show="!isPartnerHouseMaker || !['unemployed', 'retired', 'on-benefit'].includes(plan.partner_employment_position_type)"
        class="text-faded"
        v-text="getPartnerName"
      )
      q-select(
        emit-value
        map-options
        class="q-my-md"
        label="What is your employment status?"
        :options="employmentScheduleValues"
        :value="plan.partner_employed_schedule_type"
        @input="value => updatePlanField(value, 'partner_employed_schedule_type')"
      )
      q-input(
        prefix="$"
        type="tel"
        v-money="{}"
        align="right"
        debounce="500"
        class="q-my-md"
        label="What is your annual income?"
        :value="plan.partner_annual_income"
        @input="value => updatePlanField(value, 'partner_annual_income')"
      )
        template(v-slot:append v-if="plan.partner_taking_from_the_firm")
          q-icon(
            name="sync"
            class="cursor-pointer"
            @click="updatePlanField(plan.partner_taking_from_the_firm, 'partner_annual_income')"
          )
      q-input(
        debounce="500"
        class="q-my-md"
        label="What is your occupation?"
        :value="plan.partner_employed_occupation"
        @input="value => updatePlanField(value, 'partner_employed_occupation')"
      )
    q-select(
      v-if="!['unemployed', 'retired', 'on-benefit'].includes(plan.partner_employment_position_type)"
      emit-value
      map-options
      class="q-my-md"
      :options="booleanValues"
      :value="plan.partner_employed_how_long"
      label="Work for company or simular job greater than 3 years?"
      @input="value => updatePlanField(value, 'partner_employed_how_long')"
    )
    template(v-if="plan.partner_employed_how_long === 'no'")
      p(class="text-faded") When Month Year did you start?
      div(class="row q-col-gutter-md")
        div(class="col-md-6")
          q-select(
            label="Month"
            emit-value
            map-options
            :options="getIncomeIsEmployedMonth"
            :value="plan.partner_employed_work_exp_month"
            @input="value => updatePlanField(value, 'partner_employed_work_exp_month')"
          )
        div(class="col-md-6")
          q-select(
            label="Year"
            emit-value
            map-options
            :options="getIncomeIsEmployedYear"
            :value="plan.partner_employed_work_exp_year"
            @input="value => updatePlanField(value, 'partner_employed_work_exp_year')"
          )
  template(v-else)
    h6(class="text-faded" v-text="getPartnerName")
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="taxMethodValues"
      :value="plan.partner_income_tax_method"
      label="Are you taking Drawings or Paye?"
      @input="value => updatePlanField(value, 'partner_income_tax_method')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="booleanValues"
      label="Are you Shareholder or Director?"
      :value="plan.is_partner_shareholder_or_directory"
      @input="value => updatePlanField(value, 'is_partner_shareholder_or_directory')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="employmentScheduleValues"
      label="What is your employment status?"
      :value="plan.partner_employed_schedule_type"
      @input="value => updatePlanField(value, 'partner_employed_schedule_type')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="booleanValues"
      label="Been in business in more than 3 years?"
      :value="plan.partner_is_working_for_business"
      @input="value => updatePlanField(value, 'partner_is_working_for_business')"
    )
    q-input(
      v-show="plan.partner_is_working_for_business === 'yes'"
      type="tel"
      maxlength="3"
      class="q-my-md"
      debounce="500"
      label="How many years?"
      :value="plan.partner_business_how_many_years"
      @input="value => updatePlanField(value, 'partner_business_how_many_years')"
    )
    q-input(
      type="tel"
      maxlength="3"
      class="q-my-md"
      debounce="500"
      :value="plan.partner_how_many_boys"
      label="How many staff do you have working for you?"
      @input="value => updatePlanField(value, 'partner_how_many_boys')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="booleanValues"
      label="Now, Are you on tools?"
      :value="plan.partner_on_tools"
      @input="value => updatePlanField(value, 'partner_on_tools')"
    )
    q-select(
      v-if="plan.partner_on_tools === 'no'"
      use-input
      emit-value
      class="q-my-md"
      input-debounce="0"
      @filter="__filterFn"
      hint="Search Classification Code"
      :options="classificationUnitOptions"
      :value="plan.what_you_do_in_business"
      label="What is it that you do? (Project Management or Office)"
      @input="value => updatePlanField(value, 'what_you_do_in_business')"
    )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="booleanValues"
      :value="plan.partner_has_corporate_partner"
      label="Is there any other shareholders/director that are not on the tools?"
      @input="value => updatePlanField(value, 'partner_has_corporate_partner')"
    )
    q-input(
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      class="q-my-md"
      debounce="500"
      :value="plan.partner_taking_from_the_firm"
      label="How much income did you take out last year from the business?"
      @input="value => updatePlanField(value, 'partner_taking_from_the_firm')"
    )
      template(v-slot:append v-if="plan.partner_annual_income")
        q-icon(
          name="sync"
          class="cursor-pointer"
          @click="updatePlanField(plan.partner_annual_income, 'partner_taking_from_the_firm')"
        )
    q-select(
      emit-value
      map-options
      class="q-my-md"
      :options="accCoverPlanTypes"
      label="What ACC cover plan do you have?"
      :value="plan.partner_acc_cover_plan_type"
      @input="value => updatePlanField(value, 'partner_acc_cover_plan_type')"
    )
    q-input(
      v-if="isAlreadyOnAccCoverPlusExtra"
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      class="q-my-md"
      debounce="500"
      label="How much is your current ACC Cover Plus Extra nominated amount?"
      :value="plan.partner_existing_nominated_cover_amount"
      @input="value => updatePlanField(value, 'partner_existing_nominated_cover_amount')"
    )
    q-input(
      prefix="$"
      type="tel"
      v-money="{}"
      align="right"
      class="q-my-md"
      debounce="500"
      :value="plan.partner_nominated_cover_amount"
      label="Your nominated Cover Plus Extra cover amount"
      @input="value => updatePlanField(value, 'partner_nominated_cover_amount')"
    )
    q-select(
      use-input
      emit-value
      class="q-my-md"
      input-debounce="0"
      @filter="__filterFn"
      :value="plan.partner_classification_unit"
      hint="Search Classification Code"
      :options="classificationUnitOptions"
      label="Just to ensure you are on the right classification code with ACC, what does your business do?"
      @input="value => updatePlanField(value, 'partner_classification_unit')"
    )
    q-btn(
      class="q-mt-md full-width"
      color="primary"
      icon="settings"
      :loading="calculating"
      label="Calculate Levy"
      @click="calculateLevy"
    )
    tax-splitting(is-client-employed)
</template>

<script>
import { mapGetters } from 'vuex';
import { lowerCase, toString } from 'lodash';
import { QInput } from 'src/components/quasar';
import { TaxSplitting } from 'pages/dashboard/planner/steps';
import { FieldableMixin, FilterableMixin } from 'src/mixins';

export default {
  name: 'partner-income',
  mixins: [FieldableMixin, FilterableMixin],
  extends: {
    methods: {
      ...TaxSplitting.methods,
    },
  },
  data: () => ({
    calculating: false,
    classificationUnitOptions: [],
  }),
  created() {
    this.classificationUnitOptions = this.mapClassificationUnitValues;
  },
  methods: {
    __filterFn(val, update) {
      if (val === '') {
        update(() => {
          this.classificationUnitOptions = this.mapClassificationUnitValues;
        });
        return;
      }
      update(() => {
        const needle = lowerCase(val);
        this.classificationUnitOptions = this.mapClassificationUnitValues.filter(({ value, label }) => {
          return lowerCase(toString(value)).indexOf(toString(needle)) > -1
            || lowerCase(toString(label)).indexOf(lowerCase(needle)) > -1;
        });
      });
    },
  },
  computed: {
    ...mapGetters('planner', [
      'isEmployed',
      'hasPartnerExists',
      'isPartnerEmployed',
      'isPartnerHouseMaker',
    ]),
    ...mapGetters('resources', {
      booleanValues: 'booleanValues',
      taxMethodValues: 'taxMethodValues',
      employmentValues: 'employmentValues',
      accCoverPlanTypes: 'accCoverPlanTypes',
      getIncomeIsEmployedYear: 'incomeIsEmployedYear',
      getIncomeIsEmployedMonth: 'incomeIsEmployedMonth',
      employmentScheduleValues: 'employmentScheduleValues',
    }),
    ...mapGetters('partnerCalculations', {
      isAlreadyOnAccCoverPlusExtra: 'isAlreadyOnAccCoverPlusExtra',
      currentClassificationUnit: 'getSelectedClassificationUnit',
      getSelectedClassificationunitOnTools: 'getSelectedClassificationunitOnTools',
    }),
    ...mapGetters('classificationUnit', [
      'mapClassificationUnitValues',
      'isClasificationUnitValuesEmpty',
    ]),
  },
  components: {
    QInput,
    TaxSplitting,
  },
};
</script>
