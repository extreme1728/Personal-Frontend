<template lang="pug">
div
  q-tabs(
    align="center"
    class="text-secondary"
    v-model="currentTab"
  )
    //- Titles
    q-tab(name="occupation-status" icon="work") Occupation
    q-tab(name="income" icon="attach_money") Income
    q-tab(name="acc-levy-guidebook" icon="book" v-if="!isMarketingSpecialist") ACC Levy Guidebook

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="occupation-status" style="min-height: 100vh")
      include blocks/occupation-status
      include blocks/partner-occupation-status

    q-tab-panel(name="income" style="min-height: 100vh")
      div(v-show="isSelfEmployed")
        include blocks/acc-title
      include blocks/income
      include blocks/income-result
      partner-income(v-if="isEmployed && hasPartnerExists")
      income-levy-calculation-notes(
        v-if="showCalculatedLevy"
        :client-name="plan.client_full_name"
        :income-tax-method="plan.income_tax_method"
        :cover-plus-calculation="coverPlusCalculation"
        :is-already-on-acc-cover-plus-extra="isAlreadyOnAccCoverPlusExtra"
        :cover-plus-extra-calculation="getDeterminedCoverPlusExtraCalculation"
      )

    q-tab-panel(name="acc-levy-guidebook" v-if="!isMarketingSpecialist")
      div(class="acc-levy-guidebook--container")
        div(class="vue-friendly-iframe relative-position")
          embed(class="acc-levy-guidebook--element" :src="accLevyGuidebookPdf")
        q-field(class="col-md-12")
          q-btn(
            class="full-width"
            color="primary"
            icon="open_in_new"
            label="Open as External Link"
            @click="openURL(accLevyGuidebookPdf)"
          )
</template>

<script>
import { validationMixin } from 'vuelidate';
import { mapActions, mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import { required } from 'vuelidate/lib/validators';
import { uid, QSpinnerGears, openURL } from 'quasar';
import { FieldableMixin, FilterableMixin } from 'src/mixins';
import { maxValue, minValue } from 'src/services/validation';
import DatePicker from 'src/components/datepicker/DatePicker';
import { numberWithCommas, floatDiff } from 'src/config/utils';
import { PigBank, PigSavings } from 'src/components/charts/Pigs';
import { IncomeLevyCalculationNotes } from 'src/components/ipp';
import { trim, eq, map, merge, lowerCase, every, isEmpty, toString } from 'lodash';
import accLevyGuidebookPdf from 'assets/documents/acc/ACC_Levy_Guidebook_2017-2018.pdf';
import PartnerIncome from './blocks/PartnerIncome';

const businessPartnerSchema = {
  id: null,
  full_name: null,
  when_business_started: null,
  business_how_many_years: null,
  employed_schedule_type: null,
  how_many_boys: null,
  on_tools: null,
  what_you_do_in_business: null,
  has_corporate_partner: null,
  acc_cover_plan_type: 'cover_plus',
  existing_nominated_cover_amount: null,
  nominated_cover_amount: null,
  income_tax_method: 'drawings',
  acc_number_personal: null,
  classification_unit: null,
  ird_number_personal: null,
  date_of_birth: null,
  mobile_number: null,
  email_address: null,
  address: null,
  smoking_status: null,
  income: null,
  nominated_cover_amount: null,
  insurance_providers: [],
  custom_insurance_providers: [],
  has_will_in_place: null,
  has_attorney: null,
};

export default {
  name: 'income-details',
  mixins: [validationMixin, FieldableMixin, FilterableMixin],
  data: () => ({
    calculating: false,
    accLevyGuidebookPdf,
    currentTab: 'income',
    classificationUnitOptions: [],
  }),
  created() {
    this.classificationUnitOptions = this.mapClassificationUnitValues;
  },
  mounted() {
    this.$v.plan.$touch();
  },
  methods: {
    openURL,
    ...mapActions('clientCalculations', ['requestAllLevyCalculations']),
    __filterFn(val, update) {
      if (val === '') {
        update(() => {
          this.classificationUnitOptions = this.mapClassificationUnitValues;
        });
        return;
      }
      update(() => {
        const needle = lowerCase(val);
        this.classificationUnitOptions = this.mapClassificationUnitValues.filter(({ value, label }) => {
          return lowerCase(toString(value)).indexOf(toString(needle)) > -1
            || lowerCase(toString(label)).indexOf(lowerCase(needle)) > -1;
        });
      });
    },
    async calculateLevy() {
      try {
        this.calculating = true;
        this.$q.loading.show({
          message: 'Calculating.... Please wait.',
          spinner: QSpinnerGears,
        });
        await this.requestAllLevyCalculations();
      }
      catch (e) {}
      finally {
        this.$q.loading.hide();
        this.calculating = false;
      }
    },
    __handleBusinessPartnerOnBlur(e) {
      const { value } = e.target;
      if (trim(value)) {
        this.$refs.$ArrayOfBusinessPartners.add(value);
      }
    },
    handleEmployedScheduleTypeOnChange(value, field) {
      if (eq(value, 'part-time')) {
        this.showEmployedScheduleTypePrompt();
      }
      this.updatePlanField(value, field);
    },
      async showEmployedScheduleTypePrompt() {
      try {
        await this.$q.dialog({
          title: 'Warning:',
          color: 'amber',
          message: this.plan.client_full_name + ` is not eligible for Cover Plus Extra (CPX) as CPX is only available when client is working full time`,
        });
      } catch (e) {}
    },
  },
  watch: {
    plan: {
      async handler({ on_tools, employment_position_type }) {
        let payload = {};

        if (eq(employment_position_type, 'self-employed')) {
          payload = merge(payload, {
            // employed_how_long: 'yes',
            partner_employment_position_type: 'self-employed',
          });
        }

        if (!isEmpty(payload)) {
          await this.updatePlanField(payload);
        }
      },
      deep: true,
    },
  },
  computed: {
    arrayOfBusinessPartners: {
      set(values) {
        const partners = map(values, name => {
          return merge(this.convertToNonReactive(businessPartnerSchema), { full_name: name, id: uid() });
        });
        this.updatePlanField(partners, 'business_partners');
      },
      get() {
        return this.mapBusinessPartners;
      },
    },
    ...mapGetters('liabilityRates', ['requirements']),
    ...mapGetters('user', ['isMarketingSpecialist']),
    ...mapGetters('clientCalculations', {
      showCalculatedLevy: 'showCalculatedLevy',
      getPigSavingsAmount: 'getPigSavingsAmount',
      coverPlusCalculation: 'getCoverPlusCalculation',
      getPigSavingsPercentage: 'getPigSavingsPercentage',
      coverPlusExtraCalculation: 'getCoverPlusExtraCalculation',
      currentClassificationUnit: 'getSelectedClassificationUnit',
      isAlreadyOnAccCoverPlusExtra: 'isAlreadyOnAccCoverPlusExtra',
      getTotalIncomeProtectionAmount: 'getTotalIncomeProtectionAmount',
      getDeterminedCalculationHeaderLabel: 'getDeterminedCalculationHeaderLabel',
      getCoverPlusExtraCalculationOnTools: 'getCoverPlusExtraCalculationOnTools',
      getSelectedClassificationunitOnTools: 'getSelectedClassificationunitOnTools',
      getExistingCoverPlusExtraCalculation: 'getExistingCoverPlusExtraCalculation',
      getDeterminedCoverPlusExtraCalculation: 'getDeterminedCoverPlusExtraCalculation',
    }),
    ...mapGetters('resources', {
      booleanValues: 'booleanValues',
      taxMethodValues: 'taxMethodValues',
      employmentValues: 'employmentValues',
      accCoverPlanTypes: 'accCoverPlanTypes',
      paymentMethods: 'mortgageRepaymentMethods',
      getIncomeIsEmployedYear: 'incomeIsEmployedYear',
      getIncomeIsEmployedMonth: 'incomeIsEmployedMonth',
      employmentScheduleValues: 'employmentScheduleValues',
    }),
    ...mapGetters('planner', [
      'isEmployed',
      'isHouseMaker',
      'isSelfEmployed',
      'hasPartnerExists',
      'isPartnerEmployed',
      'clientGrossIncome',
      'isPartnerHouseMaker',
      'mapBusinessPartners',
      'isPartnerSelfEmployed',
      'determineIncomeFromBusiness',
      'determineNominatedCoverAmount',
    ]),
    ...mapGetters('classificationUnit', [
      'mapClassificationUnitValues',
      'isClasificationUnitValuesEmpty',
    ]),
    getDeterminedPigColumnClass() {
      const hasPercentage = this.getPigSavingsPercentage > 0;
      return !hasPercentage ? {
        'col-md-8': true,
        'offset-md-2': true,
      } : { 'col-md-6': true };
    },
    cpxErrorMessage() {
      return `WARNING: Minimum CPX is $${numberWithCommas(this.requirements.nominated_cover_amount.minimum)}`;
    },
    cpxWarningMessage() {
      return eq(this.plan.employed_schedule_type, 'part-time')
        ? `${this.plan.client_full_name} is not eligible for Cover Plus Extra (CPX) as CPX is only available when client is working full time`
        : null;
    },
  },
  validations() {
    return {
      plan: {
        classification_unit: {
          required,
        },
        nominated_cover_amount: {
          required,
          minValue: minValue(this.requirements.nominated_cover_amount.minimum),
        },
      },
    };
  },
  components: {
    QInput,
    PigBank,
    PigSavings,
    DatePicker,
    PartnerIncome,
    IncomeLevyCalculationNotes,
  },
};
</script>

<style lang="stylus" scoped>
.acc-levy-guidebook--container
  min-height 90vh
  .acc-levy-guidebook--element
    width 100%
    height 100%
    display block
</style>
