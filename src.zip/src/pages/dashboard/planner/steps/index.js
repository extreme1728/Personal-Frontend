import Referrals from './Referrals/Index';
import AccOffsets from './AccOffsets/Index';
import Calculators from './Calculators/Index';
import TaxSplitting from './TaxSplitting/Index';
import IncomeDetails from './IncomeDetails/Index';
import BusinessNeeds from './BusinessNeeds/Index';
import ImportantInfo from './ImportantInfo/Index';
import InsurancePlan from './InsurancePlan/Index';
import CommonTaxIssues from './CommonTaxIssues/Index';
import InsurancePlanner from './InsurancePlanner/Index';
import FatalEntitlements from './FatalEntitlements/Index';
import ScopeOfEngagements from './ScopeOfEngagements/Index';
import PassiveIncomeIssues from './PassiveIncomeIssues/Index';
import ItemRecommendations from './ItemRecommendations/Index';
import AlterationAdvice from './AlterationAdvice/Index';
import DeclarationGoodHealth from './DeclarationGoodHealth/Index';

export {
  Referrals,
  AccOffsets,
  Calculators,
  TaxSplitting,
  ImportantInfo,
  BusinessNeeds,
  IncomeDetails,
  CommonTaxIssues,
  InsurancePlan,
  AlterationAdvice,
  InsurancePlanner,
  FatalEntitlements,
  PassiveIncomeIssues,
  ScopeOfEngagements,
  ItemRecommendations,
  DeclarationGoodHealth,
};
