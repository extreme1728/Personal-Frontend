<template lang="pug">
div
  q-tabs(
    align="center"
    position="top"
    class="text-secondary"
    v-model="currentTab"
  )
    q-tab(name="client-tax" icon="star") {{ getClientName }}
    q-tab(name="partner-tax" icon="favorite" v-show="hasPartnerIncome") {{ getPartnerName }}

  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="client-tax")
      div(v-if="hasClientIncome")
        div(class="row q-mt-md")
          div(class="col-md-4 offset-md-4")
            q-select(
              emit-value
              map-options
              label="Insurance Provider"
              :value="plan.client_tax_issues_insurance_provider"
              :options="getInsuranceProvidersForTaxIssues"
              @input="value => updatePlanField(value, 'client_tax_issues_insurance_provider')"
            )
        div(class="row q-mt-lg")
          div(class="col-md-6")
            p(class="text-center text-faded") Income Protection Indemnity
            with-tax-chart(
              :tax-amount="netClientIncomeTaxCalculation.totalTax"
              :total-claim-amount="netClientIncomeTaxCalculation.totalClaimAmount"
            )
          div(class="col-md-6")
              p(class="text-center text-faded") Income Protection Agreed Value
              without-tax-chart(:total-claim-amount="netClientIncomeTaxCalculation.incomeProtectionAgreedAmount")
        div(class="row")
          div(class="col-md-12")
            common-tax-issues-notes(
              :client-name="plan.client_full_name"
              :date-of-birth="plan.client_date_of_birth"
              :tax-amount="netClientIncomeTaxCalculation.totalTax"
              :total-claim-amount="netClientIncomeTaxCalculation.totalClaimAmount"
              :agreed-amount="netClientIncomeTaxCalculation.incomeProtectionAgreedAmount"
              :indemnity-amount="netClientIncomeTaxCalculation.incomeProtectionIndemnityAmount"
            )
      h6(v-else class="text-center text-faded") INCOME AMOUNT REQUIRED
    q-tab-panel(name="partner-tax" v-if="hasPartnerIncome")
      div(class="row q-mt-md")
        div(class="col-md-4 offset-md-4")
          q-select(
            emit-value
            map-options
            label="Insurance Provider"
            :options="getInsuranceProvidersForTaxIssues"
            :value="plan.partner_tax_issues_insurance_provider"
            @input="value => updatePlanField(value, 'partner_tax_issues_insurance_provider')"
          )
      div(class="row q-mt-lg")
        div(class="col-md-6")
          p(class="text-center text-faded") Income Protection Indemnity
          with-tax-chart(
            :tax-amount="netPartnerIncomeTaxCalculation.totalTax"
            :total-claim-amount="netPartnerIncomeTaxCalculation.totalClaimAmount"
          )
        div(class="col-md-6")
            p(class="text-center text-faded") Income Protection Agreed Value
            without-tax-chart(:total-claim-amount="netPartnerIncomeTaxCalculation.incomeProtectionAgreedAmount")
      div(class="row")
        div(class="col-md-12")
          common-tax-issues-notes(
            :client-name="plan.partner_name"
            :tax-amount="netPartnerIncomeTaxCalculation.totalTax"
            :total-claim-amount="netPartnerIncomeTaxCalculation.totalClaimAmount"
            :agreed-amount="netPartnerIncomeTaxCalculation.incomeProtectionAgreedAmount"
            :indemnity-amount="netPartnerIncomeTaxCalculation.incomeProtectionIndemnityAmount"
          )
</template>

<script>
import { mapGetters } from 'vuex';
import { CommonTaxIssuesNotes } from 'src/components/ipp';
import { WithTaxChart, WithoutTaxChart } from 'src/components/charts/Taxes';
import { FieldableMixin } from 'src/mixins';

export default {
  name: 'common-tax-issues',
  data: () => ({
    currentTab: 'client-tax',
  }),
  mixins: [FieldableMixin],
  computed: {
    ...mapGetters('clientCalculations', {
      netClientIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
    }),
    ...mapGetters('partnerCalculations', {
      netPartnerIncomeTaxCalculation: 'getNetIncomeTaxCalculation',
    }),
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
      hasPartnerIncome: 'hasPartnerIncome',
    }),
    ...mapGetters('resources', {
      getInsuranceProvidersForTaxIssues: 'getInsuranceProvidersForTaxIssues',
    }),
  },
  components: {
    WithTaxChart,
    WithoutTaxChart,
    CommonTaxIssuesNotes,
  },
};
</script>
