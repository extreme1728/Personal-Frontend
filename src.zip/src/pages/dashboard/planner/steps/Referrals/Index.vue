<template lang="pug">
div
  div(class="row")
    div(class="col-md-10 offset-md-1")
      h5(class="text-italic text-faded") The greatest compliment is a referral...
      blockquote(class="note-border-primary text-weight-regular") Do you appreciate our work? If so, the biggest compliment is a referral, would you be able to share 7 to 9 friends, family and co-workers who we could have a non obligation chat with to help them as we have helped you?
  div(class="row q-my-md")
    div(class="col-md-10 offset-md-1")
      referral-items(
        v-if="plan.referral_banks && plan.referral_banks.length"
        :values="plan.referral_banks"
        @change="_ => updatePlanRelationField(_, 'referral_banks')"
        @remove="_ => removePlanRelationInstanceField(_, 'referral_banks')"
      )
      div(class="text-center" v-else)
        h4(class="text-faded") There are no referrals found yet...
        p
          img(
            src="~assets/sad.svg"
            style="width:30vw; max-width:150px;"
          )
        p
          q-btn(
            color="blue-5"
            style="width: 200px"
            label="Add Referrals"
            @click="showReferralModal = true"
          )
  include blocks/referral-create-modal
  q-page-sticky(position="bottom-left" :offset="[18, 90]")
    q-btn(
      fab
      icon="add"
      color="blue-5"
      @click="showReferralModal = true"
    )
      q-tooltip(
        anchor="center left"
        self="center right"
        :offset="[20, 0]"
      ) Add Referrals
</template>

<script>
import { validationMixin } from 'vuelidate';
import { cloneDeep, castArray } from 'lodash';
import { QInput } from 'src/components/quasar';
import ReferralItems from './blocks/ReferralItems';
import { required, email } from 'vuelidate/lib/validators';
import { FieldableMixin, ModalToggleMixin } from 'src/mixins';

const REFERRAL_SCHEMA = {
  full_name: null,
  email: null,
  notes: null,
  address: null,
  occupation: null,
  company_name: null,
  mobile_phone: null,
};

export default {
  name: 'referrals',
  mixins: [FieldableMixin, ModalToggleMixin, validationMixin],
  data: () => ({
    model: cloneDeep(REFERRAL_SCHEMA),
    loading: false,
    showReferralModal: false,
  }),
  mounted() {
    this.$v.model.$touch();
  },
  methods: {
    async addReferral() {
      try {
        this.loading = true;
        await this.updatePlanRelationField(
          [...castArray(this.plan.referral_banks), ...castArray(this.model)],
          'referral_banks'
        );
        this.model = cloneDeep(REFERRAL_SCHEMA);
      }
      catch (e) { console.error(e); }
      finally {
        this.loading = false;
        this.showReferralModal = false;
      }
    },
  },
  computed: {
    orientation() {
      return 'vertical';
    },
  },
  validations() {
    return {
      model: {
        full_name: {
          required,
        },
        email: {
          email: email,
        },
      },
    };
  },
  components: {
    QInput,
    ReferralItems,
  },
};
</script>
