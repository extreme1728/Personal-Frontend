<template lang="pug">
q-card(flat inline class="full-width")
  q-card-section(style="height: 100px" class="bg-blue-5")
  q-card-section(class="relative-position")
    p(class="text-faded text-h6") Referral List
    q-btn(
      fab
      icon="send"
      @click="email"
      color="blue-grey"
      class="absolute referral-item-card--button"
    )
      q-tooltip Email to administrator
  q-list(separator)
    q-expansion-item(
      default-opened
      v-for="(item, index) in values"
      icon="person"
      :label="item.full_name"
      :class="{ 'q-my-sm': index !== 0 }"
      :key="index"
    )
      div(class="row q-col-gutter-md")
        div(class="col-md-4")
          q-input(
            maxlength="80"
            label="Full Name"
            :value="item.full_name"
            @input="_ => modify(_, item, 'full_name')"
          )
        div(class="col-md-4")
          q-input(
            type="email"
            maxlength="100"
            :value="item.email"
            label="Email Address"
            @input="_ => modify(_, item, 'email')"
          )
        div(class="col-md-4")
          q-input(
            type="tel"
            maxlength="25"
            label="Mobile Phone"
            :value="item.mobile_phone"
            @input="_ => modify(_, item, 'mobile_phone')"
          )
      div(class="row q-col-gutter-md q-my-md")
        div(class="col-md-4")
          q-input(
            maxlength="150"
            :value="item.address"
            label="Physical Address"
            @input="_ => modify(_, item, 'address')"
          )
        div(class="col-md-4")
          q-input(
            maxlength="100"
            label="Occupation"
            :value="item.occupation"
            @input="_ => modify(_, item, 'occupation')"
          )
        div(class="col-md-4")
          q-input(
            maxlength="150"
            label="Company Name"
            :value="item.company_name"
            @input="_ => modify(_, item, 'company_name')"
          )
      div(class="row q-mt-md")
        div(class="col-md-12")
          q-input(
            label="Notes"
            type="textarea"
            :max-height="150"
            :value="item.notes"
            @input="_ => modify(_, item, 'notes')"
          )
      div(class="row q-col-gutter-md q-mt-sm")
        div(class="col-md-12")
          q-btn(
            flat
            color="red-5"
            icon="remove"
            class="full-width"
            @click="expunge(item)"
            label="Remove Referral"
          )
</template>

<script>
import { mapGetters } from 'vuex';
import { set, debounce } from 'lodash';
import { QInput } from 'src/components/quasar';
import { HTTP_API } from 'src/services/http/http';

export default {
  name: 'referral-items',
  props: {
    values: {
      type: Array,
      required: true,
    },
  },
  methods: {
    modify: debounce(function (value, item, field) {
      set(item, field, value);
      this.$emit('change', this.values);
    }, 500),
    expunge(referral) {
      this.$q.dialog({
        title: `Remove ${referral.full_name}`,
        message: 'This action cannot be undone. Would you like to continue?',
        color: 'negative',
        cancel: true,
      }).onOk(() => {
        this.$emit('remove', referral);
      });
    },
    email() {
      this.$q.dialog({
        title: 'Send referrals via email',
        message: 'Subject',
        cancel: true,
        prompt: {
          model: this.defaultEmailSubject,
          type: 'text',
        },
      }).onOk(subject => {
        this.$q.notify({
          icon: 'send',
          timeout: 1000,
          color: 'primary',
          message: 'Sending...',
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
        HTTP_API()
          .post(`planners/${this.plan.id}/mailer/referral/send`, {
            subject,
            payload: this.values,
          })
          .then(() => {
            this.$q.notify({
              icon: 'check',
              timeout: 1000,
              message: 'Sent',
              color: 'secondary',
              position: this.$q.platform.is.mobile ? 'top' : 'top-right',
            });
          });
      });
    },
  },
  computed: {
    defaultEmailSubject() {
      const { client_full_name } = this.plan;
      return `${client_full_name} - Referrals`
    },
    ...mapGetters('planner', {
      plan: 'plan',
    }),
  },
  components: {
    QInput,
  },
};
</script>

<style lang="stylus" scoped>
.referral-item-card--button
  top 0
  right 8px
  transform translateY(-50%)
</style>
