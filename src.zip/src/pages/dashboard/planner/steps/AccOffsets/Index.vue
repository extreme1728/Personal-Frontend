<template lang="pug">
div
  q-tabs(
    align="center"
    position="top"
    v-model="currentTab"
    class="text-secondary"
  )
    q-tab(name="client-acc-offsets" icon="star") {{ getClientName }}
    q-tab(name="partner-acc-offsets" icon="favorite" v-if="hasPartnerIncome") {{ getPartnerName }}
  q-tab-panels(v-model="currentTab" animated)
    q-tab-panel(name="client-acc-offsets")
      div(v-if="hasClientIncome")
        div
          p(class="text-faded text-center") In the event of an Accident:
          h5(class="text-faded text-center no-margin-top") ACC Cover + Income Protection
        div(class="row md-gutter")
          div(class="col-md-4")
            eighty(:amount="clientAccOffsetCalculation.maximumAccCoverPlusCover")
            p(class="text-faded text-center") ACC Cover Plus
          div(class="col-md-4")
            empty(:amount="0")
            p(class="text-faded text-center") Income Protection
          div(class="col-md-4")
            eighty(:amount="clientAccOffsetCalculation.maximumAccCoverPlusCover")
            p(class="text-faded text-center") Total Claim Amount
        div
          h5(class="text-faded text-center") ACC Cover + Monthly Mortgage Repayment Cover
        div(class="row md-gutter")
          div(class="col-md-4")
            eighty(:amount="clientAccOffsetCalculation.maximumAccCoverPlusCover")
            p(class="text-faded text-center") ACC Cover Plus
          div(class="col-md-4")
            forty(:amount="clientAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover")
            p(class="text-faded text-center") Monthly Mortgage Repayment Cover
          div(class="col-md-4")
            one-hundred(:amount="clientAccOffsetCalculation.totalClaimAmount")
            p(class="text-faded text-center") Total Claim Amount
        div
          acc-offsets-notes(
            :client-name="plan.client_full_name"
            :cover-plus-amount="clientAccOffsetCalculation.maximumAccCoverPlusCover"
            :monthly-mortgage-amount="clientAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
            :cover-plus-amount-without-tax="clientAccOffsetCalculation.maximumAccCoverPlusCoverWithoutTax"
          )
      h6(v-else class="text-center text-faded") INCOME AMOUNT REQUIRED

    q-tab-panel(name="partner-acc-offsets" v-if="hasPartnerIncome")
      div
        p(class="text-faded text-center") In the event of an Accident:
        h5(class="text-faded text-center no-margin-top") ACC Cover + Income Protection
      div(class="row md-gutter")
        div(class="col-md-4")
          eighty(:amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover")
          p(class="text-faded text-center") ACC Cover Plus
        div(class="col-md-4")
          empty(:amount="0")
          p(class="text-faded text-center") Income Protection
        div(class="col-md-4")
          eighty(:amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover")
          p(class="text-faded text-center") Total Claim Amount
      div
        h5(class="text-faded text-center") ACC Cover + Monthly Mortgage Repayment Cover
      div(class="row md-gutter")
        div(class="col-md-4")
          eighty(:amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover")
          p(class="text-faded text-center") ACC Cover Plus
        div(class="col-md-4")
          forty(:amount="partnerAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover")
          p(class="text-faded text-center") Monthly Mortgage Repayment Cover
        div(class="col-md-4")
          one-hundred(:amount="partnerAccOffsetCalculation.totalClaimAmount")
          p(class="text-faded text-center") Total Claim Amount
      div
        acc-offsets-notes(
          :client-name="plan.partner_name"
          :cover-plus-amount="partnerAccOffsetCalculation.maximumAccCoverPlusCover"
          :monthly-mortgage-amount="partnerAccOffsetCalculation.maximumMonthlyMortgageRepaymentCover"
          :cover-plus-amount-without-tax="partnerAccOffsetCalculation.maximumAccCoverPlusCoverWithoutTax"
        )
</template>

<script>
import { mapGetters } from 'vuex';
import { FieldableMixin } from 'src/mixins';
import { AccOffsetsNotes } from 'src/components/ipp';
import * as PeopleGraphicsComponents from 'src/components/charts/Peoples';

export default {
  name: 'acc-offsets',
  mixins: [FieldableMixin],
  data: () => ({
    currentTab: 'client-acc-offsets'
  }),
  computed: {
    ...mapGetters('clientCalculations', {
      clientAccOffsetCalculation: 'getAccOffsetCalculation',
    }),
    ...mapGetters('partnerCalculations', {
      partnerAccOffsetCalculation: 'getAccOffsetCalculation',
    }),
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
      hasPartnerIncome: 'hasPartnerIncome',
    }),
  },
  components: {
    ...PeopleGraphicsComponents,
    AccOffsetsNotes,
  },
};
</script>
