<template lang="pug">
  div
    q-card
      q-card-section(class="text-h6 text-faded") Passive Income Details
      q-card-section
        q-input(
          type="tel"
          prefix="$"
          v-money="{}"
          align="right"
          debounce="500"
          class="q-my-md"
          label="Income Protection Covers with Other Insurance Providers"
          :value="plan.income_protection_covers_with_other_insurance_provider"
          @input="value => updatePlanField(value, 'income_protection_covers_with_other_insurance_provider')"
        )
        q-input(
          type="tel"
          prefix="$"
          v-money="{}"
          align="right"
          debounce="500"
          class="q-my-md"
          label="Passive Income From Business (e.g dividends)"
          :value="plan.passive_income_from_business"
          @input="value => updatePlanField(value, 'passive_income_from_business')"
        )
        q-input(
          type="tel"
          prefix="$"
          v-money="{}"
          align="right"
          debounce="500"
          class="q-my-md"
          label="Passive Income From Rentals"
          :value="plan.passive_income_from_rentals"
          @input="value => updatePlanField(value, 'passive_income_from_rentals')"
        )
        q-input(
          prefix="$"
          v-money="{}"
          align="right"
          debounce="500"
          class="q-my-md"
          label="Other Passive Income"
          :value="plan.other_passive_income"
          @input="value => updatePlanField(value, 'other_passive_income')"
        )
    div(
      v-if="hasClientIncome"
      class="row q-col-gutter-md q-my-md"
    )
      div(class="col-md-6")
        with(
          v-if="passiveIncomeCalculation.totalPassiveIncome"
          :amount="passiveIncomeCalculation.totalPassiveIncome"
        )
        without(v-else)
      div(class="col-md-6")
        potential-savings(
          :chart-data="getIncomeProtectionPassiveIncomeChartData"
          :options="getChartDataOptions"
        )
</template>

<script>
import { mapGetters } from 'vuex';
import { QInput } from 'src/components/quasar';
import ChartColors from 'src/config/chart-colors';
import { FieldableMixin, ChartDataMixin } from 'src/mixins';
import { With, Without } from 'src/components/charts/Incomes';
import PotentialSavings from 'src/components/charts/PotentialSavings';

export default {
  name: 'passive-income-issues',
  mixins: [FieldableMixin, ChartDataMixin],
  computed: {
    ...mapGetters('clientCalculations', {
      passiveIncomeCalculation: 'getPassiveIncomeCalculation',
    }),
    ...mapGetters('planner', {
      hasClientIncome: 'hasClientIncome',
    }),
    getIncomeProtectionPassiveIncomeChartData() {
      if (this.hasClientIncome) {
        const {
          totalPassiveIncome,
          incomeProtectionIndemnityAmount,
          incomeProtectionAgreedAmount,
          maximumMonthlyMortgageRepaymentCover,
        } = this.passiveIncomeCalculation;
        if (!totalPassiveIncome) {
          return {
            labels: ['IP Indemnity', 'IP Agreed', 'MMR'],
            datasets: [
              {
                borderWidth: 2,
                backgroundColor: ChartColors.orange,
                borderColor: ChartColors.orange,
                hoverBackgroundColor: ChartColors.orangeLight,
                hoverBorderColor: ChartColors.orange,
                label: 'Income Protection covers without passive income',
                data: [
                  incomeProtectionIndemnityAmount,
                  incomeProtectionAgreedAmount,
                  maximumMonthlyMortgageRepaymentCover,
                ],
              },
            ],
          };
        }

        return {
          labels: ['Passive Income', 'IP Indemnity', 'IP Agreed', 'MMR'],
          datasets: [
            {
              borderWidth: 2,
              backgroundColor: ChartColors.yellow,
              borderColor: ChartColors.yellow,
              hoverBackgroundColor: ChartColors.yellowLight,
              hoverBorderColor: ChartColors.yellow,
              label: 'Income Protection covers with passive income',
              data: [
                -Math.abs(totalPassiveIncome),
                incomeProtectionIndemnityAmount,
                incomeProtectionAgreedAmount,
                maximumMonthlyMortgageRepaymentCover,
              ],
            },
          ],
        };
      }
    },
  },
  components: {
    QInput,
    With,
    Without,
    PotentialSavings,
  },
};
</script>
