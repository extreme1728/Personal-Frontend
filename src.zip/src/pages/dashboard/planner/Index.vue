<template lang="pug">
q-page
  q-stepper(
    animated
    header-nav
    ref="stepper"
    color="primary"
    :value="currentStep"
    @input="onHandleStepperChange"
    :vertical="$q.platform.is.mobile"
  )
    template(v-for="(step, index) in plannerStepComponents")
      q-step(
        :order="step.order"
        :name="step.name"
        :icon="step.icon"
        :title="step.title"
        :caption="step.caption"
      )
        component(:is="step.name")
  q-page-sticky(
    position="bottom-left"
    :offset="getFabOffset"
    v-show="getPlanerFabsState.settings.show && !$q.platform.is.mobile"
  )
    q-fab(
      color="secondary"
      icon="settings"
      direction="right"
    )
      q-tooltip(
        slot="tooltip"
        anchor="center left"
        self="center right"
        :offset="[20, 0]"
      ) Settings
      q-fab-action(
        v-if="isOnline"
        icon="save"
        color="primary"
        @click="onHandlePersist"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Save
      q-fab-action(
        v-if="isOnline && plan.id"
        color="blue-5"
        icon="file_copy"
        @click="onHandleReplicateInstance(plan)"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Replicate
      q-fab-action(
        v-if="plan.id"
        icon="bookmark"
        color="teal"
        @click="onHandleModifyPlannerStage"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Stage
      q-fab-action(
        v-if="plan.id"
        icon="add"
        color="cyan"
        @click="onHandleNewInstance"
      )
        q-tooltip(
          anchor="center right"
          self="center left"
          :offset="[20, 0]"
        ) Create
</template>

<script>
import { mapGetters, mapMutations } from 'vuex';
import { isEmpty, isObject, find } from 'lodash';
import { FieldableMixin, PlannerSettingsMixin, PlannerStepComponentsMixin } from 'src/mixins';

export default {
  name: 'planner-index',
  mixins: [FieldableMixin, PlannerSettingsMixin, PlannerStepComponentsMixin],
  async preFetch({ store, currentRoute, redirect }) {
    try {
      const id = window.Number(currentRoute.params.id);
      const { data: planner } = await store.dispatch('planner/findPlanner', id);
      store.commit('planner/ASSIGN_PLANNER', planner);
      store.commit('plannerCollection/ADD_PLANNER_COLLECTION', planner);
    } catch (e) {
      return redirect('/dashboard/app');
    }
    return Promise.resolve();
  },
  created() {
    this.UPDATE_FAB_SETTINGS_STATE({ show: true });
  },
  mounted() {
    const { currentStep } = this;
    this.initialized(this.plan);
    // this.$nextTick(() => {
    //   if (!isEmpty(currentStep)) {
    //     this.$refs.stepper.goToStep(currentStep);
    //   }
    // });
  },
  async beforeRouteLeave(to, from, next) {
    const { referral_banks } = this.plan;
    if (process.env.PROD && isEmpty(referral_banks)) {
      this.$q.dialog({
        preventClose: true,
        title: 'Referral Program',
        message: 'There are no referrals found yet. Would you want to add it now?',
        ok: {
          push: true,
          label: 'Yes',
        },
        cancel: {
          flat: true,
          label: 'No',
        },
      }).onOk(() => {
        this.UPDATE_PLANNER_STEP('referrals');
        return next(false);
      }).onCancel(() => {
        return next();
      });
    }
    else {
      return next();
    }
  },
  methods: {
    ...mapMutations('site', ['UPDATE_FAB_SETTINGS_STATE']),
    initialized(values) {
      const state = isObject(values) && values.id;
      if (state && this.isOnline) {
        this.$q.notify({
          message: 'Auto Save Enabled',
          icon: 'verified_user',
          timeout: 1000,
          color: 'amber',
          position: this.$q.platform.is.mobile ? 'top' : 'top-right',
        });
      }
    },
    async onHandleStepperChange(plannerStep = null, plannerId = null) {
      const { params: { id }, query: { step, stage } } = await this.$route;
      this.UPDATE_PLANNER_STEP(plannerStep || step);
      await this.$router.replace({
        name: 'dashboard.planner',
        params: { id: plannerId || id },
        query: {
          step: plannerStep || step,
          stage: stage,
        },
      });
    },
  },
  computed: {
    ...mapGetters('site', {
      getPlanerFabsState: 'getPlanerFabs',
    }),
    getFabOffset() {
      return [18, 18];
    },
    getDirectionStyles() {
      const { mobile } = this.$q.platform.is;
      return mobile ? {'flex-direction': 'column', 'align-items': 'start'} : {};
    },
    getDirectionButtonPreviousStyles() {
      const { mobile } = this.$q.platform.is;
      return mobile ? { 'margin-bottom': '15px' } : { 'margin-right': '15px' };
    },
    getDirectionPosition() {
      const { mobile } = this.$q.platform.is;
      return mobile ? 'right' : 'bottom-right';
    },
  },
};
</script>
