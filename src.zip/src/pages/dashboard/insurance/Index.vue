<template lang="pug">
  q-page(padding)
    h4(class="text-faded no-margin") Insurance Providers
    div(class="q-mt-lg")
      insurance-provider-selection(
        :chunk-number="3"
        :provider-id="insuranceProviderSchema.providerId"
        :cover-type-id="insuranceProviderSchema.coverTypeId"
        @change-provider-id="v => insuranceProviderSchema.providerId = v"
        @change-cover-type-id="v => insuranceProviderSchema.coverTypeId = v"
        @change-cover-type-notes="v => coverTypeNotes = v"
      )
    div(class="insurance-provider-editor overflow-hidden")
      div(class="row note-container q-mt-md" v-for="notes in coverTypeNotes")
        insurance-provider-note-editor(
          inline
          v-for="note in notes"
          :key="note.id"
          :image-url="note.image"
          :note="note.note"
          :provider-id="insuranceProviderSchema.providerId"
          :cover-id="insuranceProviderSchema.coverTypeId"
          :note-id="note.id"
          @update="handleOnProviderNoteUpdate"
          class="col-md-4"
        )
</template>

<script>
  import _ from 'lodash';
  import { QInput } from 'src/components/quasar';
  import { mapActions, mapGetters } from 'vuex';
  import { HTTP_API } from 'src/services/http/http';
  import { InsuranceProviderNoteEditor, InsuranceProviderSelection } from 'src/components/ipp';

  export default {
    name: 'insurance-index',
    data: () => ({
      insuranceProviderSchema: {
        providerId: 0,
        coverTypeId: 63,
      },
      coverTypeNotes: [],
    }),
    methods: {
      ...mapActions('insuranceProvider', ['requestProviderNoteUpdate']),
      async handleOnProviderNoteUpdate(payload) {
        await this.$q.notify({
          message: 'Updating',
          color: 'primary',
          icon: 'save'
        });

        await this.requestProviderNoteUpdate(payload);

        await this.$q.notify({
          message: 'Updated',
          color: 'secondary',
          icon: 'check'
        });
      },
    },
    components: {
      QInput,
      InsuranceProviderSelection,
      InsuranceProviderNoteEditor,
    },
  };
</script>

<style lang="stylus" scoped>
  .insurance-provider-editor
    margin-top 1em
    .note-container
      justify-content center
</style>
