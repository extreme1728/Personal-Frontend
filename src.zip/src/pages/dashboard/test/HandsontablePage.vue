<template lang="pug">
  q-page(padding class="row justify-center")
    div(style="width: 1200px; max-width: 1200px;")
      div(class="board")
        div(class="panel")
          div(class="styling-panel")
            p Styling
            div(class="normal" title="Erase Styling")
            div(class="bold" title="Make Cells Bold")
            div(class="italic" title="Make Cells Italic")
            div(class="underline" title="Make Cells Underline")
          div(class="cancel-panel")
            p Changes
            div(class="cancel" title="Cancel All Changes")
            div(class="undo" title="Undo a Single Change")
            div(class="redo" title="Redo a Single Change")
          div(class="row-col-operations")
            p Add / Delete
            div(class="newrow" title="Add a single row at the end of the table")
            div(class="newcol" title="Add a single column at the end of the table")
            div(class="delrow" title="Delete last row")
            div(class="delcol" title="Delete last column")
          div(class="show-hide")
            p Show / Hide
            div(class="hideCols" title="Hide Selected Columns")
            div(class="hideRows" title="Hide Selected Rows")
            div(class="showCols" title="Show Selected Columns")
            div(class="showRows" title="Show Selected Rows")
          div(class="export")
            p Export
            div(class="export-file" title="Export table as a .csv file")
            div(class="export-console" title="Send all data to console")
          div(class="search")
            p Search
            div(class="search-box")
              input(id="search_field" type="search" placeholder="...")
      hot-table(ref="$HOT" :settings="settings" :onInit="onInit")
      div(class="left") &larr;
      div(class="right") &rarr;
</template>

<script>
import Handsontable from 'handsontable';
import HotTable from '@handsontable-pro/vue';
import 'node_modules/handsontable-pro/dist/handsontable.full.css';

const negativeValueRenderer = function(instance, td, row, col, prop, value, cellProperties) {
  Handsontable.renderers.NumericRenderer.apply(this, arguments);
  td.className = 'make-me-grey';

  if (value > 0.003) {
      td.className = 'make-me-pink';
  }
  if (value < 0) {
      td.className = 'make-me-blue';
  }
};

const tableItems = [
    {id: 1, flag: 'EUR', currencyCode: 'EUR', currency: 'Euro', level: 0.9033, units: 'EUR / USD', asOf: '08/19/2015', onedChng: 0.0026},
    {id: 2, flag: 'JPY', currencyCode: 'JPY', currency: 'Japanese Yen', level: 124.3870, units: 'JPY / USD', asOf: '08/19/2015', onedChng: 0.0001},
    {id: 3, flag: 'GBP', currencyCode: 'GBP', currency: 'Pound Sterling', level: 0.6396, units: 'GBP / USD', asOf: '08/19/2015', onedChng: 0.00},
    {id: 4, flag: 'CHF', currencyCode: 'CHF', currency: 'Swiss Franc',  level: 0.9775, units: 'CHF / USD', asOf: '08/19/2015', onedChng: 0.0008},
    {id: 5, flag: 'CAD', currencyCode: 'CAD', currency: 'Canadian Dollar',  level: 1.3097, units: 'CAD / USD', asOf: '08/19/2015', onedChng: -0.0005},
    {id: 6, flag: 'AUD', currencyCode: 'AUD', currency: 'Australian Dollar',  level: 1.3589, units: 'AUD / USD', asOf: '08/19/2015', onedChng: 0.0020},
    {id: 7, flag: 'NZD', currencyCode: 'NZD', currency: 'New Zealand Dollar', level: 1.5218, units: 'NZD / USD', asOf: '08/19/2015', onedChng: -0.0036},
    {id: 8, flag: 'SEK', currencyCode: 'SEK', currency: 'Swedish Krona',  level: 8.5280, units: 'SEK / USD', asOf: '08/19/2015', onedChng: 0.0016},
    {id: 9, flag: 'NOK', currencyCode: 'NOK', currency: 'Norwegian Krone',  level: 8.2433, units: 'NOK / USD', asOf: '08/19/2015', onedChng: 0.0008},
    {id: 10, flag: 'BRL', currencyCode: 'BRL', currency: 'Brazilian Real',  level: 3.4806, units: 'BRL / USD', asOf: '08/19/2015', onedChng: -0.0009},
    {id: 11, flag: 'CNY', currencyCode: 'CNY', currency: 'Chinese Yuan',  level: 6.3961, units: 'CNY / USD', asOf: '08/19/2015', onedChng: 0.0004},
    {id: 12, flag: 'RUB', currencyCode: 'RUB', currency: 'Russian Rouble',  level: 65.5980, units: 'RUB / USD', asOf: '08/19/2015', onedChng: 0.0059},
    {id: 13, flag: 'INR', currencyCode: 'INR', currency: 'Indian Rupee',  level: 65.3724, units: 'INR / USD', asOf: '08/19/2015', onedChng: 0.0026},
    {id: 14, flag: 'TRY', currencyCode: 'TRY', currency: 'New Turkish Lira',  level: 2.8689, units: 'TRY / USD', asOf: '08/19/2015', onedChng: 0.0092},
    {id: 15, flag: 'THB', currencyCode: 'THB', currency: 'Thai Baht', level: 35.5029, units: 'THB / USD', asOf: '08/19/2015', onedChng: 0.0044},
    {id: 16, flag: 'IDR', currencyCode: 'IDR', currency: 'Indonesian Rupiah', level: 13.83, units: 'IDR / USD', asOf: '08/19/2015', onedChng: -0.0009},
    {id: 17, flag: 'MYR', currencyCode: 'MYR', currency: 'Malaysian Ringgit', level: 4.0949, units: 'MYR / USD', asOf: '08/19/2015', onedChng: 0.0010},
    {id: 18, flag: 'MXN', currencyCode: 'MXN', currency: 'Mexican New Peso',  level: 16.4309, units: 'MXN / USD', asOf: '08/19/2015', onedChng: 0.0017},
    {id: 19, flag: 'ARS', currencyCode: 'ARS', currency: 'Argentinian Peso',  level: 9.2534, units: 'ARS / USD', asOf: '08/19/2015', onedChng: 0.0011},
    {id: 20, flag: 'DKK', currencyCode: 'DKK', currency: 'Danish Krone',  level: 6.7417, units: 'DKK / USD', asOf: '08/19/2015', onedChng: 0.0025},
    {id: 21, flag: 'ILS', currencyCode: 'ILS', currency: 'Israeli New Sheqel',  level: 3.8262, units: 'ILS / USD', asOf: '08/19/2015', onedChng: 0.0084},
    {id: 22, flag: 'PHP', currencyCode: 'PHP', currency: 'Philippine Peso', level: 46.3108, units: 'PHP / USD', asOf: '08/19/2015', onedChng: 0.0012}
];

const cols = [
  {
      data: 'id',
      type: 'numeric',
      className: 'htCenter'
  },
  {
      data: 'currencyCode',
      type: 'text',
      className: 'htCenter'
  },
  {
      data: 'currency',
      type: 'text'
  },
  {
      data: 'level',
      type: 'numeric',
      numericFormat: {
        pattern: '0.0000',
      },
  },
  {
      data: 'units',
      type: 'text'
  },
  {
      data: 'asOf',
      type: 'date',
      dateFormat: 'MM/DD/YYYY',
      className: 'htCenter'
  },
  {
      data: 'onedChng',
      type: 'numeric',
      numericFormat: {
        pattern: '0.00%',
      },
      renderer: negativeValueRenderer
  }
];

const colsHeaders = ['ID', 'Symbol', 'Currency', ' Level', 'Units', 'Date', 'Change'];

export default {
  name: 'handsontable-test',
  data: () => ({
    table: null,
    settings: {
      data: tableItems,
      columns: cols,
      colWidths: [100, 120, 250, 150, 150, 150, 150],
      autoWrapRow: true,
      contextMenu: true,
      rowHeights: 25,
      height: 500,
      width: 1120,
      dropdownMenu: true,
      filters: true,
      currentRowClassName: 'myRow',
      columnSorting: true,
      customBorders: true,
      outsideClickDeselects: false,
      rowHeaders: true,
      search: true,
      manualColumnResize: true,
      manualRowResize: true,
      comments: true,
      colHeaders: colsHeaders,
      afterViewportColumnCalculatorOverride: function(calc) {
        const totalEnd = calc.endColumn;
      },
      hiddenColumns: {
       columns: [],
       indicators: true
     },
      hiddenRows: {
        rows: [],
        indicators: true
      },
      cells: function(row, col){
        var cellProp = {};
        if(col === 7){
            cellProp.className = 'delete';
        }
        return cellProp;
      }
    },
  }),
  methods: {
    onInit() {
      const { table } = this.$refs.$HOT;
      console.log(table);
      this.table = table;
    }
  },
  components: {
    HotTable,
  },
};
</script>

<style scoped>
  th, td {
      font: 12px sans-serif;
  }
  #hot .handsontable th {
      background: #ededed;
      font: 0.85em sans-serif;
  }
  .negative {
      background: RGBA(45, 12, 99, 0.5);
  }
  /* classes for the negativeValueRenderer */
  .make-me-blue,
  .make-me-grey,
  .make-me-pink {
    text-align: center;
  }

  .make-me-blue {
    color: RGBA(49, 141, 253, 0.9);
  }

  .make-me-grey {
    color: RGBA(0, 0, 0, 0.5);
  }

  .make-me-pink {
    color: RGBA(234, 53, 144, 0.9);
  }
  /* buttons */
  .board {
    height: 6.2em;
  }

  .panel{
    float: left;
  }

  .panel {
    width: 100%;
  }

  .cancel,
  .newrow,
  .newcol,
  .delrow,
  .delcol,
  .hideCols,
  .hideRows,
  .showCols,
  .showRows,
  .showSelRows,
  .showSelCols,
  .export-file, .export-console, .undo, .redo, .normal, .bold, .italic, .underline {
    background: #ededed;
    border: 2px solid #ededed;
    color: #222;
    padding: 0.5em;
    width: 3em;
    text-align: center;
    font: 0.88em sans-serif;
    float: left;
    height: 3em;
    box-sizing: border-box;
    margin-left: 0.1em;
  }
  .newrow {
    background-image: url('~assets/handsontable/addrow.png');
  }
  .delrow {
    background-image: url('~assets/handsontable/delrow.png');
  }
  .newcol {
    background-image: url('~assets/handsontable/addcol.png');
  }
  .delcol {
    background-image: url('~assets/handsontable/delcol.png');
  }
  .export-file {
    background-image: url('~assets/handsontable/export-file.png');
  }
  .export-console {
    background-image: url('~assets/handsontable/export-console.png');
  }
  .cancel {
    background-image: url('~assets/handsontable/cancel.png');
  }
  .undo {
    background-image: url('~assets/handsontable/undo.png');
  }
  .redo {
    background-image: url('~assets/handsontable/redo.png');
  }
  .hideCols {
    background-image: url('~assets/handsontable/hidecol.png');
  }
  .hideRows {
    background-image: url('~assets/handsontable/hiderow.png');
  }
  .showCols {
    background-image: url('~assets/handsontable/showcol.png');
  }
  .showRows {
    background-image: url('~assets/handsontable/showrow.png');
  }
  .normal {
    background-image: url('~assets/handsontable/normal.png');
  }
  .bold {
    background-image: url('~assets/handsontable/bold.png');
  }
  .italic {
    background-image: url('~assets/handsontable/italic.png');
  }
  .underline {
    background-image: url('~assets/handsontable/underscore.png');
  }

  .cancel-panel, .row-col-operations, .show-hide, .export, .search, .styling-panel {
    background: #ededed;
    padding: 0.5em;
    text-align: center;
    margin-left: 1px;
    height: 6em;
    float: left;
    font: 14px sans-serif;
    font-weight: bold;
    color: #555;
  }

  .left,
  .right {
    position: absolute;
    top: 2.05em;
    z-index: 110;
    height: 500px;
    width: 50px;
    padding: 19% 1em;
    box-sizing: border-box;
    font: 3em sans-serif;
    background: RGBA(20, 20, 20, 0.2);
    visibility: hidden;
    color: white;
  }

  .right {
    left: 1023px;
  }

  #search_field {
    width: 28.6em;
    padding: 0.45em;
    margin-top: 0.4em;
    border: 0;
  }

  .make-bold {
    font-weight: bold;
  }

  .make-italic {
    font-style: italic;
  }

  .make-italic {
    font-style: none;
    font-weight: normal;
  }

  .make-underline {
    text-decoration: underline;
  }

  .rename {
    background: #0f9d58;
    padding: 3px;
    float: right;
    border: 1px solid #18804e;
    color: #fff;
    width: 56px;
    height: 25px;
    border-radius: 2px;
    font-family: Helvetica,sans-serif;
    font-size: 11px;
  }

  .nameInp {
    border-radius: 2px;
    padding: 4px;
    box-shadow: none;
    width: 90px;
    border: 1px solid rgb(210, 209, 209);
  }
</style>
