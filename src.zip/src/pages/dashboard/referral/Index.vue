<template lang="pug">
q-page(padding class="referral-index")
  template(v-if="chunkedPlanners.length")
    q-infinite-scroll(@load="fetchPlanners")
      div(
        class="row q-col-gutter-md justify-around q-my-sm"
        v-for="(planners, index) in chunkedPlanners"
        :class="{ 'q-mt-sm': index !== 0 }"
        :key="index"
      )
        div(class="col-md-3 flex" v-for="plan in planners")
          q-card(:key="plan.id" class="full-width relative-position" inline)
            q-card-section
              div(class="row items-center no-wrap")
                div(class="col")
                  div(class="text-h6 text-weight-regular") {{ plan.client_full_name }} - \#{{ plan.id }}
                  div(class="text-subtitle1 text-light") {{ plan.company_full_name | limit }}
                q-icon(
                  class="col-auto"
                  :name="plan | determinePlannerIconName"
                  :color="plan | determinePlannerIconColor"
                )
            q-card-section(class="text-faded card-main")
              p(class="no-margin") Total Number of Referrals {{ plan.referral_banks.length }}
              p(class="no-margin-bottom q-mt-sm") Created By {{ plan.created_by_user }}
              p(class="no-margin-bottom q-mt-sm") Created at {{ plan.created_at_formatted }}
              p(class="no-margin") Last modified at {{ plan.updated_at_formatted }}
            q-card-actions(align="around" class="absolute-bottom")
              q-btn(
                flat
                color="blue-5"
                class="full-width"
                icon="import_contacts"
                @click="handleOnPlannerImport(plan)"
              )
                q-tooltip Import Referrals
  template(v-else)
    include ../blocks/planner-not-found
  include ../blocks/planner-query-fab
  //- q-page-sticky(position="bottom-right" :offset="[18, 18]")
  //-   q-btn(
  //-     fab
  //-     color="primary"
  //-     class="animate-pop"
  //-     icon="keyboard_arrow_up"
  //-     v-back-to-top.animate="{ offset: 500, duration: 200 }"
  //-   )
</template>

<script>
import { last } from 'lodash';
import plannerSteps from 'src/config/plannerSteps';
import DashboardIndex from 'pages/dashboard/Index';

export default {
  name: 'referral-index',
  extends: DashboardIndex,
  methods: {
    handleOnPlannerImport({ id, stage }) {
      const { value: step } = last(plannerSteps);
      this.UPDATE_PLANNER_STEP(step);
      this.$router.push({
        name: 'dashboard.planner',
        params: { id },
        query: { stage },
      });
    },
  },
};
</script>

<style lang="stylus">
.referral-index
  .card-main
    padding-bottom 4em
</style>
