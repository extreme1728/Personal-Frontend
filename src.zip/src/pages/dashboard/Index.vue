<template lang="pug">
q-page(padding class="dashboard-index")
  template(v-if="chunkedPlanners.length")
    q-infinite-scroll(@load="fetchPlanners")
      div(
        class="row q-col-gutter-md justify-around q-my-sm"
        v-for="(planners, index) in chunkedPlanners"
        :class="{ 'q-mt-sm': index !== 0 }"
        :key="index"
      )
        div(class="col-md-3 flex" v-for="plan in planners")
          q-card(:key="plan.id" class="full-width relative-position" inline)
            q-card-section
              div(class="row items-center no-wrap")
                div(class="col")
                  div(class="text-h6 text-weight-regular") {{ plan.client_full_name | limit }} - \#{{ plan.id }}
                  div(class="text-subtitle1 text-light") {{ plan.company_full_name | limit }}
                q-icon(
                  class="col-auto"
                  :name="plan | determinePlannerIconName"
                  :color="plan | determinePlannerIconColor"
                )
                | &nbsp;{{ plan.reports.length }}
                q-tooltip Number of reports
            q-card-section(class="text-faded card-main")
              p(class="no-margin-bottom q-mt-sm") Created By {{ plan.created_by_user }}
              p(class="no-margin-bottom q-mt-sm") Created at {{ plan.created_at_formatted }}
              p(class="no-margin") Last modified at {{ plan.updated_at_formatted }}
            q-card-actions(align="around" class="absolute-bottom")
              q-btn(
                flat
                round
                icon="edit"
                color="primary"
                @click="onHandleEdit(plan)"
              )
                q-tooltip Edit
              q-btn(
                flat
                round
                color="blue-5"
                icon="file_copy"
                @click="onHandleReplicateInstance(plan)"
              )
                q-tooltip Duplicate
              q-btn(
                flat
                round
                icon="remove"
                color="negative"
                @click="handleOnPlannerRemove(plan)"
              )
                q-tooltip Remove
  template(v-else)
    include blocks/planner-not-found
  include blocks/planner-query-fab
  q-page-scroller(position="bottom-right" :offset="[18, 90]" :scroll-offset="150")
    q-btn(fab color="primary" icon="keyboard_arrow_up")
  q-page-sticky(position="bottom-right" :offset="[18, 18]")
    q-btn(fab icon="add" color="primary" @click="onHandleNewInstance")
      q-tooltip(
        anchor="center left"
        self="center right"
        :offset="[10, 0]"
      ) Create Planner
</template>

<script>
import Fuse from 'fuse.js';
import { PlannerSettingsMixin } from 'src/mixins';
import plannerSteps from 'src/config/plannerSteps';
import { mapGetters, mapActions, mapMutations, mapState } from 'vuex';
import { chunk, truncate, isEmpty, filter, lowerCase, toString, orderBy } from 'lodash';

export default {
  name: 'dashboard-index',
  mixins: [PlannerSettingsMixin],
  data: () => ({
    plannerQuery: null,
    showQueryInput: false,
    searching: false,
    CHUNK_SIZE: 4,
    FUSE_OPTIONS: {
      location: 0,
      threshold: 0.3,
      maxPatternLength: 32,
      minMatchCharLength: 2,
      keys: [
        'partner_email_address',
        'client_email_address',
        'company_full_name',
        'client_full_name',
        'created_by_user',
        'stage',
        'id',
      ],
    },
  }),
  methods: {
    ...mapActions('planner', ['queryPlanner']),
    ...mapMutations('site', ['UPDATE_PLANNER_STEP']),
    ...mapActions('plannerCollection', ['requestPaginate']),
    handleQueryInputOnShow() {
      const input = this.$refs.$QueryInput;
      if (input) {
        this.$refs.$QueryInput.focus();
      }

      const popover = this.$refs.popover;
      if (popover && popover.showing) {
        this.$nextTick(() => popover && popover.reposition())
      }
    },
    async onHandleQueryPlanner() {
      try {
        this.searching = true;
        await this.queryPlanner(this.plannerQuery);
      }
      catch (e) { console.log(e); }
      finally {
        this.searching = false;
      }
    },
    async fetchPlanners(index, done) {
      const { next } = this.links;
      if (isEmpty(next)) return;
      await this.requestPaginate(next);
      done();
    },
    onHandleEdit({ id, stage }) {
      const { value: step } = plannerSteps[0];
      this.UPDATE_PLANNER_STEP(step);
      this.$router.push({
        name: 'dashboard.planner',
        params: { id },
        query: { stage },
      });
    },
  },
  filters: {
    limit(value) {
      if (!value) return 'No Company Name';
      return truncate(value, { length: 20 });
    },
    determinePlannerIconName({ stage }) {
      return toString(stage).indexOf('first') > -1 ? 'favorite' : 'star';
    },
    determinePlannerIconColor({ stage }) {
      return toString(stage).indexOf('first') > -1 ? 'red-5' : 'amber';
    },
  },
  computed: {
    getQueryInputStyles() {
      return {
        'padding': '10px',
        'width': '400px',
      };
    },
    getDeterminedNotFoundLabel() {
      const { plannerQuery } = this;
      return isEmpty(plannerQuery)
        ? 'No Documents Found'
        : `Search [${plannerQuery}] to Database`;
    },
    chunkedPlanners() {
      let planners = this.planners;
      planners = orderBy(planners, ['id'], ['desc']);
      const query = lowerCase(this.plannerQuery);
      if (isEmpty(query)) return chunk(planners, this.CHUNK_SIZE);
      const fuse = new Fuse(planners, this.FUSE_OPTIONS);
      const result = fuse.search(query);
      return chunk(result, this.CHUNK_SIZE);
    },
    ...mapGetters('plannerCollection', {
      planners: 'planners',
    }),
    ...mapState('plannerCollection', {
      links: state => state.links,
      meta: state => state.meta
    }),
  },
};
</script>

<style lang="stylus">
.dashboard-index
  .card-main
    padding-bottom 4em
</style>
