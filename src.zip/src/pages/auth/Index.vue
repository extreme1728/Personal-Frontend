<template lang="pug">
  q-page
    div(
      :class="heightSize"
      class="window-height row justify-center"
    )
      q-card(
        inline
        id="login"
        :class="cardWidthSize"
      )
        q-card-section(class="bg-primary")
          svg(
            id="svg-logo"
            viewBox="0 0 483 483"
            style="enable-background:new 0 0 460 460;"
            xml:space="preserve" width="128px" height="128px"
            v-html="logoMethod"
          )
          h4(class="text-white text-center") IPP - Insurance Planner and Plan
        q-card-section(class="q-mt-md justify-center")
          q-input(
            autofocus
            type="email"
            label="Email"
            @keyup.enter="login"
            :value="formData.username"
            :disable="buttonState.loaded"
            :error="$v.formData.username.$error"
            @input="_ => updateAuthField(_, 'username')"
          )
          q-input(
            label="Password"
            @keyup.enter="login"
            :value="formData.password"
            :disable="buttonState.loaded"
            :type="isPwd ? 'password' : 'text'"
            :error="$v.formData.password.$error"
            @input="_ => updateAuthField(_, 'password')"
          )
            template(v-slot:append)
              q-icon(
                :name="isPwd ? 'visibility_off' : 'visibility'"
                class="cursor-pointer"
                @click="isPwd = !isPwd"
              )
        q-card-actions(vertical align="center")
          q-btn(
            :loading="buttonState.loaded"
            :color="buttonState.color"
            :label="buttonState.text"
            :disable="$v.$error"
            @click="login"
            class="fit"
          )
            q-spinner-gears(slot="loading")
</template>

<script>
import Vivus from 'vivus';
import LogoData from 'src/services/utils';
import { validationMixin } from 'vuelidate';
import { required } from 'vuelidate/lib/validators';
import { mapActions, mapGetters, mapMutations } from 'vuex';

export default {
  name: 'auth-index',
  mixins: [validationMixin],
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      vm.startLogoAnimation();
    });
  },
  data: () => ({
    isPwd: true,
    buttonState: {
      loaded: false,
      text: 'Login',
      color: 'primary',
    },
  }),
  mounted() {
    this.$v.formData.$touch();
  },
  methods: {
    ...mapMutations('user', ['SET_AUTH_FORM_DATA']),
    ...mapActions('user', ['requestLogin', 'requestUserData']),
    login() {
      if (this.$v.$error) return;
      this.$q.notify({
        message: 'Logging in...',
        color: 'positive',
        icon: 'verified_user',
      });
      this.buttonState.loaded = true;
      this.requestLogin(this.formData)
        .then(data => {
          this.buttonState.color = 'primary';
          this.requestUserData()
            .then(() => {
              const { redirect } = this.$route.query;
              if (redirect) {
                this.$router.replace(redirect);
              }
              else {
                this.$router.replace({ name: 'dashboard.app' });
              }
            });
        })
        .catch(() => {
          this.buttonState.color = 'negative';
          this.$router.replace({ name: 'auth' });
        })
        .finally(() => {
          this.buttonState.loaded = false;
        });
    },
    startLogoAnimation() {
      /* eslint-disable */
      const svgLogo = new Vivus('svg-logo', {
        duration: 400,
        forceRender: true,
      }, ((element) => {
          for (const item of element.el.children[0].children) {
            item.setAttribute('style', 'fill:white');
          }
        }));
      /* eslint-enable */
      svgLogo.reset().play();
    },
    updateAuthField(value, field) {
      this.SET_AUTH_FORM_DATA({ value, field });
    },
  },
  computed: {
    ...mapGetters('user', {
      formData: 'authFormData',
    }),
    heightSize() {
      const { desktop } = this.$q.platform.is;
      return desktop ? 'items-center' : '';
    },
    cardWidthSize() {
      const { desktop } = this.$q.platform.is;
      return desktop ? 'width-50' : 'full-width';
    },
    logoMethod() {
      return LogoData.Keytronic;
    },
  },
  validations() {
    return {
      formData: {
        username: {
          required,
        },
        password: {
          required,
        },
      },
    };
  },
};
</script>

<style lang="stylus" scoped>
.width-50
  width 50% !important

.card
  margin-bottom 0px

.card-content
  min-height 160px

button
  margin-bottom 4%

#svg-logo
  margin 1em auto
  display block
</style>
