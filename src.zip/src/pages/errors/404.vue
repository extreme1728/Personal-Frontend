<template lang="pug">
  div(class="fixed-center text-center")
    p
      img(
        src="~assets/sad.svg"
        style="width:30vw; max-width:150px;"
      )
    p(class="text-faded")
      | Sorry, nothing here...
      strong (404)
    q-btn(
      color="secondary"
      style="width: 200px"
      @click="determineRedirect"
    ) Go Back
</template>

<script>
import _ from 'lodash';
import { mapGetters } from 'vuex';

export default {
  methods: {
    determineRedirect() {
      if (_.isEmpty(this.currentUserModel)) return this.$router.push({name: 'auth'});
      return this.$router.push({name: 'dashboard.app'});
    },
  },
  computed: mapGetters('user', {
    currentUserModel: 'currentUserModel',
  }),
};
</script>
