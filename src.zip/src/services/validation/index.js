/* eslint-disable */
import maxValue from './maxValue'
import minValue from './minValue'

export {
  maxValue,
  minValue
}
