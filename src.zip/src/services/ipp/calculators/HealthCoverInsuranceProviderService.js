import { numberWithCommas } from 'src/config/utils';
import { eq, uniq, isEmpty, filter, sortBy } from 'lodash';

export default class HealthCoverInsuranceProviderService {
  constructor(model, citizen = false) {
    this.model = model;
    this.citizen = citizen;
  }

  providers() {
    // Not Citizen
    if (!this.citizen) return [this.accuro];

    let __providers = []; // eslint-disable-line no-underscore-dangle

    if (this.item.has_pre_existing_conditions_covered) {
      // TOGGLE YES AND EXCESS IS ZERO = Southern Cross Ultracare
      __providers = [...__providers, ...[this.southernCrossUltraCare]];

      if (isEmpty(this.item.excess_base_plan)
        || [0, 250, 500, 1000, 2000, 4000, 6000].includes(this.excessBasePlanAmount)) {
        // TOGGLE YES AND EXCESS BASE PLAN IS $0, 250, 500, 1000, 2K, 4k, 6k = NIB Easy Health
        __providers = [...__providers, ...[this.nibEasyHealth]];
      }
      // Southern Cross UltraCare shall be included in S&D filter
      // will not be available if $250 excess is chosen on S&D excess
      if (this.includeSpecialistAndDiagnostics
        && !this.isExcessOnSpecialistAndDiagnosticsIsZero) {
        __providers = filter(__providers, n => !eq(this.southernCrossUltraCare, n));
      }

      return sortBy(__providers);
    }

    // Check if excess base plan is $10k
    if (this.isExcessBasePlanTenGrand) {
      // AIA and ACCURO is included for both $0 and $250 S&D Excess
      __providers = [this.accuro, this.aia]; // eslint-disable-line no-underscore-dangle

      // Partners Life only offers $250 S&D Excess
      // UNLESS S&D IS NOT INCLUDED should be still available
      if (isEmpty(this.item.specialist_and_diagnostics_excess)
        || !this.isExcessOnSpecialistAndDiagnosticsIsZero) {
        __providers = [
          ...__providers,
          ...[this.partnersLife],
        ];
      }

      return sortBy(__providers);
    }

    if ([0, 250, 500, 750, 1000, 2000, 4000].includes(this.excessBasePlanAmount)) {
      __providers = [...__providers, ...[this.aia, this.sovereign]];
    }

    if ([0, 250, 500, 1000, 2000, 4000, 6000, 8000].includes(this.excessBasePlanAmount)) {
      __providers = [...__providers, ...[this.accuro]];
    }

    if ([0, 250, 500, 1000, 2000, 4000, 6000].includes(this.excessBasePlanAmount)) {
      __providers = [...__providers, ...[this.nib]];
    }

    if ([0, 250, 500, 1000, 2000, 5000].includes(this.excessBasePlanAmount)) {
      __providers = [...__providers, ...[this.partnersLife]];
    }

    if ([500, 1000, 2000, 4000].includes(this.excessBasePlanAmount)) {
      __providers = [...__providers, ...[this.southernCross]];
    }

    // If S&D is included apply second filter
    if (this.includeSpecialistAndDiagnostics) {
      if (!this.isExcessOnSpecialistAndDiagnosticsIsZero) {
        __providers = filter(__providers, n => ![this.southernCross, this.nib].includes(n));
      }
      if (this.isExcessOnSpecialistAndDiagnosticsIsZero) {
        __providers = filter(__providers, n => !eq(this.partnersLife, n));
      }
    }

    return sortBy(uniq(__providers));
  }

  // eslint-disable-next-line class-methods-use-this
  get nibEasyHealth() {
    return 'NIB Easy Health';
  }

  // eslint-disable-next-line class-methods-use-this
  get southernCrossUltraCare() {
    return 'Southern Cross Ultracare';
  }

  // eslint-disable-next-line class-methods-use-this
  get aia() {
    return 'AIA Real Health';
  }

  get nib() {
    return this.includeNonPharmac
      ? 'NIB Ultimate Health Max'
      : 'NIB Ultimate Health';
  }

  // eslint-disable-next-line class-methods-use-this
  get partnersLife() {
    return 'Partners Life Medical';
  }

  // eslint-disable-next-line class-methods-use-this
  get southernCross() {
    return 'Southern Cross';
  }

  get accuro() {
    if (!this.citizen) return 'Accuro Day to Day';
    return this.includeNonPharmac
      ? 'Accuro Smart Care Plus'
      : 'Accuro Smart Care';
  }

  get sovereign() {
    return this.includeSpecialistAndDiagnostics
      ? 'Sovereign Private Health Plus'
      : 'Sovereign Private Health';
  }

  get isExcessOnSpecialistAndDiagnosticsIsZero() {
    return eq(this.item.specialist_and_diagnostics_excess, '0');
  }

  get isExcessBasePlanTenGrand() {
    return eq(this.excessBasePlanAmount, 10000);
  }

  get includeSpecialistAndDiagnostics() {
    return eq(this.item.does_include_specialist_and_diagnostics, 'Include');
  }

  get includeNonPharmac() {
    return eq(this.item.does_include_pharmac, 'Include Non Pharmac');
  }

  get excessBasePlanAmount() {
    return numberWithCommas(this.item.excess_base_plan, false);
  }

  get item() {
    return this.model;
  }
}
