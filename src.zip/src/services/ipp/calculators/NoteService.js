import { toNumberFixed } from 'src/services/filters/formatter';
import { floatFixer, numberWithCommas } from 'src/config/utils';
import { startCase, camelCase, eq, toNumber, toString, get, join } from 'lodash';

export default class CalculatorNotService {
  constructor(type, attr, currentName, age, currentTab = null) {
    this.age = age;
    this.attr = attr;
    this.currentTab = currentTab;
    type = camelCase(type);
    this.currentName = startCase(currentName);
    if (typeof this[type] === 'function') return this[type]();
    return [];
  }

  /* eslint-disable */
  others() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(
        'Reason for my recommendation:'
      );
    }
    if (levelToNum && [80, 100].includes(levelToNum)) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as this allows more premium certainly for the longer term allowing better budgeting for premium affordability.`
      );
    }
    else if (levelToNum && [65].includes(levelToNum)) {
      str.push(
        `${this.currentName}, you have levelled your premium structure till age ${levelToNum} as this is the age that you would expect to retire and therefore would otherwise have less income coming into the household reducing the need for a higher sum assured life cover beyond this point.`
      );

      str.push(
        `${this.currentName}, you have recognise that there is a strong chance that you will live beyond age, ${levelToNum}, however due to premium affordability and belief that you can self-ensure after this point you decided to level till ${levelToNum}.`
      );

      str.push(
        `${this.currentName}, should you decide to continue your cover at age ${levelToNum} you recognise that it will be at rate for age/yearly premium/stepped rates which may mean that you might not be able to afford to keep some or all of your sum assured.`
      );
    }

    if (levelToNum && ![65, 80, 100].includes(levelToNum)) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure for ${levelToNum} years as this allows more certainly ${wordings}.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }
    return str;
  }

  disabilityIncomeProtection() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(
        `Reason for my recommendation: In the event that you experience a significant trauma event, you would like a lump sum payment of $${value} income to look after the everyday expenses. You have expressed that you would like to use this as a form of income protection at a discounted premium rate but also do recognise the fact that this is a lump sum payment and not a monthly repayment cover. Furthermore, I have explained to you that trauma cover covers only a certain amount of defined conditions as described and defined in the policy wordings and therefore may not cover all conditions that you would be off work for.`
      );
    }
    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you note that a mortgage is a long term commitment and would like long term certainly over premium affordability.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }
    return str;
  }

  limitedIncomeProtection() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(
        `Reason for my recommendation: In the event that you experience a significant trauma event, you would like a lump sum payment of $${value} income to look after the everyday expenses. You have expressed that you would like to use this as a form of income protection at a discounted premium rate but also do recognise the fact that this is a lump sum payment and not a monthly repayment cover. Furthermore, I have explained to you that trauma cover covers only a certain amount of defined conditions as described and defined in the policy wordings and therefore may not cover all conditions that you would be off work for.`
      );
    }
    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you note that a mortgage is a long term commitment and would like long term certainly over premium affordability.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }
    return str;
  }

  /* eslint-disable */
  investment() {
    const str = [];
    const { value, index, time_period, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value && time_period) {
      str.push(
        `Life cover is needed to attain $${value} annuity payment for the next ${time_period} Years`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  nonPharmacDrugCost() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push('Reason for my recommendation: You have nominated this amount to cover you in the event that you suffer from a critical medical condition where the medication is not covered by Pharmac.');
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  caregiverCostAnnually() {
    const str = [];
    const { value, index, level, years_needed } = this.payload;
    const levelToNum = this.__extractNumToString(level);
    const total = toNumberFixed(this.__calculateCaregiverCost(this.payload));

    if (value && years_needed) {
      const yearWordings = years_needed === 65
          ? `till age ${years_needed}`
          : (years_needed > 1 && years_needed !== 65)
          ? `for ${years_needed} years` : `for ${years_needed} year`;
      if (eq(this.currentTab, 'tpd')) {
        str.push(
          `${this.currentName}, you have stated that in the event of never being able to work again that you need financial assistance with either a family member or professional caregiver to look after you and this would cost $${value} per annum with it needed ${yearWordings} thus totalling $${numberWithCommas(total)}.`
        );
      }
      else if (eq(this.currentTab, 'trauma-cover')) {
        str.push(
          `${this.currentName}, you have stated that in the event of experiencing a major trauma event, you may need the assistance of a caregiver for some time to help you and the household to function optimally and hence have recognised that $${value} per annum for ${yearWordings} would be needed totalling $${numberWithCommas(total)}.`
        );
      }
      else {
        str.push('Children are the lifeline of a parent\'s life and vice versa. Should one of the parents however pass away unexpectedly, this can make life difficult for those loved ones left behind. Who will now look after the children whilst the other parent goes to work to provide now solely for the family? Having life cover to assist with providing funding for a nanny can be a relief allowing the children to develop into adulthood with proper supervision and care. It has been discussed that you would like the following monetary value provided in the event that you pass away thus being unable to supervise the children.');
      }
    }

    if (levelToNum && [65, 80, 100].includes(levelToNum)) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have levelled your premium structure ${wordings} as this is the age that would have expected otherwise to have retired and will be happy to rely on pension after this age.`
      );
    }
    else if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you would like more certainly over your premium for the long term allowing you to budget more accurately for premiums.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed') && [65, 80, 100].includes(levelToNum)) {
      const age = levelToNum === 65
        ? 80
        : levelToNum === 100 ? 80 : 65;
      str.push(
        `${this.currentName}, you have further stated that you would like the premium to stay the same beyond the age of ${levelToNum === 100 ? levelToNum : 65} so should you still need financial assistance beyond this age, you have certainly over premium till age ${age}.`
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  nannyCost() {
    const str = [];
    const { years_needed, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);
    const nannyCostTotal = this.__calculateNannyCost(this.payload);
    const total = toNumberFixed(this.__calculateCaregiverCost({ value: nannyCostTotal, years_needed }));

    if (total && years_needed) {
      const yearWordings = years_needed === 65
          ? `till age ${years_needed}`
          : (years_needed > 1 && years_needed !== 65)
          ? `for ${years_needed} years` : `for ${years_needed} year`;
      str.push(
        `${this.currentName}, you have stated that in the event of experiencing a major trauma event, you may need the assistance of a caregiver for some time to help you and the household to function optimally and hence have recognised that $${numberWithCommas(nannyCostTotal)} per annum is needed for ${yearWordings} totalling $${numberWithCommas(total)}.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  nannyCostAnnually() {
    const str = [];
    const { value, years_needed, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);
    const total = toNumberFixed(this.__calculateCaregiverCost(this.payload));

    if (total && years_needed) {
      const yearWordings = years_needed === 65
          ? `till age ${years_needed}`
          : (years_needed > 1 && years_needed !== 65)
          ? `for ${years_needed} years` : `for ${years_needed} year`;
      str.push(
        `${this.currentName}, you have stated that in the event of experiencing a major trauma event, you may need the assistance of a caregiver for some time to help you and the household to function optimally and hence have recognised that $${value} per annum will be needed ${yearWordings} totalling $${numberWithCommas(total)}.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  charity() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(`Reason for my recommendation: Charity - in the event that you pass away you want to fulfill your social responsibility to help those in need and so you have nominated $${value} to donate to a charity.`);
    }


    if (levelToNum && ![80, 100].includes(levelToNum)) {
      str.push(
        `${this.currentName}, you have selected to level your premium structure till the age of ${levelToNum} as you would want certainly that your premium stays the same till this age which would help budgeting and affordability for the long term.`
      );
    }

    if (levelToNum && [80, 100].includes(levelToNum)) {
      str.push(
        `${this.currentName}, you have expected to live longer and you are comfortable in leveling your cover at age ${levelToNum} even though you are expecting to be dying at age 65 because you have assets behind you at that time and they will be liquid and turned into cash that beyond the age of ${levelToNum} you will not need any funeral cover.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  inheritance() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push('Reason for my recommendation: Inheritance - in the event that you pass away you want to make sure that your family will have enough funds to inherit giving you peace of mind that they will still be financially stable even in your absence.');
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }
    
    return str;
  }

  repatriationBenefit() {
    const str = [];
    const { value, country, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(`${this.currentName}, you have stated that you would like your body transported back to your home country, ${country}, so that your friends and family may lay your body to rest and say their personal farewell and celebrate your life. ${this.currentName}, you agree this would cost $${value}`);
    }


    if (levelToNum && ![80, 100].includes(levelToNum)) {
      str.push(
        `This will cover you in the event of death to look after your funeral and you are thinking that $${value} is enough and that you are expecting to pass away in ${levelToNum} years time and would like certainty in terms of premium for this period of time.`
      );
    }

    if (levelToNum && [65, 80, 100].includes(levelToNum)) {
      str.push(
        `${this.currentName}, you have expected to live longer and you are comfortable in leveling your cover at age ${levelToNum} even though you are expecting to be dying at age 65 because you have assets behind you at that time and they will be liquid and turned into cash that beyond the age of ${levelToNum} you will not need any funeral cover.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  funeralCover() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push('Reason for my recommendation: In the event that you pass away you want to make sure that your family will have enough fund to cover the funeral costs.');
    }


    if (levelToNum && ![80, 100].includes(levelToNum)) {
      str.push(
        `This will cover you in the event of death to look after your funeral and you are thinking that $${value} is enough and that you are expecting to pass away in ${levelToNum} years time and would like certainty in terms of premium for this period of time.`
      );
    }

    if (levelToNum && [65, 80, 100].includes(levelToNum)) {
      str.push(
        `${this.currentName}, you have expected to live longer and you are comfortable in leveling your cover at age ${levelToNum} even though you are expecting to be dying at age 65 because you have assets behind you at that time and they will be liquid and turned into cash that beyond the age of ${levelToNum} you will not need any funeral cover.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  familyFund() {
    const str = [];
    const { value, index, level } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(
        'Reason for my recommendation: In the event you pass away you want to make sure that your family is well taken care of.'
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  businessDebt() {
    const str = [];
    const { value, index, level, percentage } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      const total = toNumberFixed(this.__calculateByPercentage(value, percentage));
      if (eq(this.currentTab, 'tpd')) {
        str.push(
          `A total business debt of $${value} is owing currently, in the event of that you were never able to work again, you would like a proportion of this debt covered, and this would be ${percentage}% covering, a total of $${numberWithCommas(total)}.`
        );
      }
      else if (eq(this.currentTab, 'trauma-cover')) {
        str.push(
          `A business debt of $${value} is owing currently, in the event of that you experienced a significant health issue as defined by the trauma definition wordings, you would like a proportion of this debt covered, and this would be ${percentage}% covering, a total of $${numberWithCommas(total)}.`
        );
      }
      else {
        str.push(`A business debt of $${value} is owing currently, in the event of that you passed away, you would like a proportion of this covered, and this would be ${percentage}% covering, a total of $${numberWithCommas(total)}.`);
      }
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  personalLoan() {
    const str = [];
    const { value, index, level, percentage } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      const total = toNumberFixed(this.__calculateByPercentage(value, percentage));
      str.push(
        `A personal loan of $${value} is owing currently, in the event of that you passed away you would like a proportion of this covered, and this would be ${percentage}% covering, a total of $${numberWithCommas(total)}`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  mortgageAmount() {
    const str = [];
    const { value, index, level, percentage } = this.payload;
    const levelToNum = this.__extractNumToString(level);
    const total = toNumberFixed(this.__calculateByPercentage(value, percentage));

    if (value) {
      const __message = eq(this.currentTab, 'trauma-cover') ? `experience a significant trauma event, you would like a payment of $${numberWithCommas(total)}` : 'pass away you want to make sure that your family is well taken care of';
      str.push(
        `Reason for my recommendation: In the event you ${__message}.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you note that a mortgage is a long term commitment and would like long term certainly over premium affordability.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  incomeNeeded() {
    const str = [];
    const { value, index, level, years_income } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (years_income && value) {
      const total = toNumberFixed(this.__calculateByYears(value, years_income));
      str.push(
        `Reason for my recommendation: In the event of a trauma, you feel that you would like your partner to take time off work and that will be equivalent of ${years_income} years off work and $${value} is the income per annum earned, therefore $${numberWithCommas(total)} will be needed.`
      );
    }

    if (levelToNum && [65, 80, 100].includes(levelToNum)) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `You wanted it to be leveled ${wordings} because that is the time that you think you will stop working or that you are happy with premium increasing yearly and will look into leveling the cover later on.`
      );
    }
    else if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  bucketList() {
    const str = [];
    const { wishes, value, level, index } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if ((wishes && wishes.length) || value) {
      const wishesList = (wishes && wishes.length && Array.isArray(wishes)) ? wishes.join(', ') : '';
      str.push(
        `Reason for my recommendation - ${this.currentName}, you have stated that in the event of a major trauma occurance you would like a lump sum funding mechanism that allows you to purchase and do things in your bucket list.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  fatalEntitlements() {
    const str = [];
    const { value, level, index } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      str.push(
        `Reason for my recommendation:  You have chosen to go with ACC Cover Plus Extra and therefore you are exposed to fatal entitlements and you have decided to choose $${value} amount of life cover with fatal entitlements.`
      );
    }

    if (levelToNum && eq(65, levelToNum)) {
      str.push(
        `You have leveled it to ${levelToNum} as this is ACC is paying up to the age of 67 and so you are aware that you could be potentially exposed for 2 years of claim.`
      );
    }

    if (levelToNum && !eq(65, levelToNum)) {
      str.push(
        `You've levelled to age ${levelToNum} because this is the age of retirement that you will need.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  educationalFund() {
    const str = [];
    const { child_name, value, level, index } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (Array.isArray(child_name) && child_name.length) {
      const childrens = join(child_name, ', ');
      str.push(
        `You have indicated that you want ${childrens} to go to private school and or university, $${value} is the total amount you would like to have covered as a provision for this purpose.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} which will allow more certainly over long term affordability of premiums as well as better budgeting experience.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  remainingMortgageRepayments() {
    const str = [];
    const { level, index } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    str.push(
      'Reason for my recommendation: In the event that you passed away you would like part of your mortgage to be paid up. You have an option to have the principal or the interest amount to be paid off to be able to be up to date with your family\'s  daily living expense.'
    );

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you note that a mortgage is a long term commitment and would like long term certainly over premium affordability.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }

  homeModifications() {
    const str = [];
    const { percentage, value, level, index } = this.payload;
    const levelToNum = this.__extractNumToString(level);

    if (value) {
      const total = toNumberFixed(this.__calculateByPercentage(value, percentage));
      str.push(
        `Reason for my recommendation: Having a look at the general market you feel that it will take $${numberWithCommas(total)} as a minimum to modify your house for wheel chair access and other certain modifications in the event that something happened that you will need to modify your house.`
      );
    }

    if (levelToNum) {
      const wordings = this.__getPremiumStructureWordings(levelToNum);
      str.push(
        `${this.currentName}, you have decided to level your premium structure ${wordings} as you note that a mortgage is a long term commitment and would like long term certainly over premium affordability.`
      );
    }

    if (eq(level, 'Stepped')) {
      str.push(
        'You decided to have a yearly increasing premium as it will be more affordable at the moment and you prefer to pay for the slight premium increase every year.'
      );
    }

    if (eq(index, 'Indexed')) {
      str.push(
        `You have indexed it for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 2%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 2% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Indexed 5%')) {
      str.push(
        `You have indexed the sum assured with it increasing by a minimum 5% annually for it to keep up to date with inflation as inflation degrades the value of your sum assured.`
      );
    }

    if (eq(index, 'Not Indexed')) {
      str.push(
        `You have decided not to index it which means that your cover will not keep up with inflation.`
      );
    }

    return str;
  }
  /* eslint-enable */

  // eslint-disable-next-line class-methods-use-this
  __calculateByYears(value, years) {
    return floatFixer(numberWithCommas(value, false) * (years || 0));
  }

  // eslint-disable-next-line class-methods-use-this
  __calculateByPercentage(value, percentage) {
    return floatFixer(numberWithCommas(value, false) * (percentage / 100));
  }

  // eslint-disable-next-line class-methods-use-this
  __extractNumToString(str) {
    if (!str) return null;
    const numbers = toString(str).match(/\d+/g);
    if (!numbers) return null;
    return toNumber(numbers.map(Number).join(''));
  }

  // eslint-disable-next-line class-methods-use-this
  __calculateNannyCost({ rate_per_hour: hour, hours_per_week: week }) {
    const weeksPerYear = 52;
    hour = numberWithCommas(hour, false);
    const total = ((hour * week) * weeksPerYear);
    return floatFixer(total);
  }

  __calculateCaregiverCost({ value, years_needed: years }) {
    if (!value) return 0;
    if (!years) return value;
    const val = numberWithCommas(value, false);
    let total = val * years;
    const age = get(this, 'age', false);
    if (years === 65 && age) {
      total = val * (65 - age);
    }
    return floatFixer(total);
  }

  // eslint-disable-next-line class-methods-use-this
  __getPremiumStructureWordings(value) {
    let wordings = null;
    if (value && [65, 80, 100].includes(value)) {
      wordings = `to the age of ${value}`;
    }
    else {
      wordings = `for the next ${value} years`;
    }
    return wordings;
  }

  get payload() {
    return this.attr;
  }
}
