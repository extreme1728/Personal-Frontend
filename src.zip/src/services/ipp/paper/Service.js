import jsPDF from 'jspdf';

export default class PaperService {
  static build(o, u, f) {
    const { width: pageWidth, unit } = jsPDF.getPageSize(o, u, f);
    return { width: `${pageWidth + unit}` };
    // const method = upperFirst(camelCase(`${format} ${orientation}`));
    // if (typeof this[method] === 'function') return this[method](format, orientation);
    // return null;
  }

  static A3Portrait() {
    return { width: '297mm' };
  }

  static A3Landscape() {
    return { width: '420mm' };
  }

  static A4Portrait() {
    return { width: '210mm' };
  }

  static A4Landscape() {
    return { width: '297mm' };
  }

  static A5Portrait() {
    return { width: '148mm' };
  }

  static A5Landscape() {
    return { width: '210mm' };
  }

  static LetterPortrait() {
    return { width: '216mm' };
  }

  static LetterLandscape() {
    return { width: '280mm' };
  }

  static LegalPortrait() {
    return { width: '216mm' };
  }

  static LegalLandscape() {
    return { width: '357mm' };
  }
}
