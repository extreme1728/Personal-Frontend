import { merge, inRange, gte } from 'lodash';

export default class InsuranceDecisionGuideService {
  constructor(bmi) {
    this.bmi = bmi;
    this.defaults = {
      max: 0,
      min: 0,
      value: 0,
      show: true,
      label: null,
    };
  }

  get all() {
    // eslint-disable-next-line
    const { bmi, tpd, disabilityBenefits, livingAssurance, life } = this;
    // eslint-disable-next-line
    return { bmi, tpd, disabilityBenefits, livingAssurance, life };
  }

  get tpd() {
    const { bmi, defaults } = this;

    if (inRange(bmi, 35, 37)) {
      return merge({}, defaults, {
        value: 50,
        max: 75,
        label: '+50% to +75%',
      });
    }

    if (inRange(bmi, 37, 39)) {
      return merge({}, defaults, {
        value: 75,
        max: 100,
        label: '+75% to +100%',
      });
    }

    if (inRange(bmi, 39, 43)) {
      return merge({}, defaults, {
        value: 100,
        max: 150,
        label: '+100% to +150%',
      });
    }

    if (inRange(bmi, 43, 45)
      || gte(bmi, 45)) {
      return merge({}, defaults, {
        value: 100,
        max: 100,
        label: 'Individual Consideration',
      });
    }

    return merge({}, defaults, { show: false });
  }

  get disabilityBenefits() {
    const { bmi, defaults } = this;

    if (inRange(bmi, 35, 37)) {
      return merge({}, defaults, {
        value: 50,
        max: 100,
        label: '+50% to +100%',
      });
    }

    if (inRange(bmi, 37, 39)) {
      return merge({}, defaults, {
        value: 75,
        max: 100,
        label: '+75% to +100%',
      });
    }

    if (inRange(bmi, 39, 43)) {
      return merge({}, defaults, {
        value: 100,
        max: 100,
        label: '+100% with a 13 week wait to individual consideration',
      });
    }

    if (inRange(bmi, 43, 45)) {
      return merge({}, defaults, {
        value: 100,
        max: 100,
        label: 'Individual consideration with a 13 week wait minimum',
      });
    }

    if (gte(bmi, 45)) {
      return merge({}, defaults, {
        value: 100,
        max: 100,
        label: 'Individual consideration',
      });
    }

    return merge({}, defaults, { show: false });
  }

  get livingAssurance() {
    const { bmi, defaults } = this;

    if (inRange(bmi, 35, 37)) {
      return merge({}, defaults, {
        value: 50,
        max: 75,
        label: '+50% to +75%',
      });
    }

    if (inRange(bmi, 37, 39)) {
      return merge({}, defaults, {
        value: 75,
        max: 100,
        label: '+75% to +100%',
      });
    }

    if (inRange(bmi, 39, 43)) {
      return merge({}, defaults, {
        value: 100,
        max: 150,
        label: '+100% to +150%',
      });
    }

    if (inRange(bmi, 43, 45)
      || gte(bmi, 45)) {
      return merge({}, defaults, {
        value: 100,
        max: 100,
        label: 'Individual Consideration',
      });
    }

    return merge({}, defaults, { show: false });
  }

  get life() {
    const { bmi, defaults } = this;

    if (inRange(bmi, 35, 37)) {
      return merge({}, defaults, {
        value: 50,
        max: 75,
        label: '+50% to +75%',
      });
    }

    if (inRange(bmi, 37, 39)) {
      return merge({}, defaults, {
        value: 75,
        max: 100,
        label: '+75% to +100%',
      });
    }

    if (inRange(bmi, 39, 43)
      || inRange(bmi, 43, 45)) {
      return merge({}, defaults, {
        value: 100,
        max: 150,
        label: '+100% to +150%',
      });
    }

    if (gte(bmi, 45)) {
      return merge({}, defaults, {
        value: 150,
        max: 200,
        label: '150% or above',
      });
    }

    return merge({}, defaults, { show: false });
  }
}
