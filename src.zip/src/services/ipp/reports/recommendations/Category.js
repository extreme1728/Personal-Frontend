import { camelCase } from 'lodash';

export default class RecommendationCategoryService {
  static render(category) {
    category = camelCase(category);
    if (typeof this[category] === 'function') return this[category]();
    return 'No category yet.';
  }

  static preAndPostUnderwriting() {
    return 'After you received the initial decision from the underwriter, you have advised that you would like to proceed with an alteration to the initial cover recommendations.';
  }

  static applesForApples() {
    return 'In the discovery meeting, you expressed that you would like limited advice limited to a comparison to what you have currently in place, ie apples for apples.';
  }

  static applesForApplesImproved() {
    return 'In the discovery meeting, you expressed that you would like limited advice around the existing cover you have and to look at how to improve the existing cover in term benefits, features and price.';
  }

  static fullAdvice() {
    return 'In the discovery meeting, you expressed that you would like advice based on your current situation and what you would want to happen should your health fail you.';
  }

  static noExistingInsurance() {
    return 'In the discovery meeting, you expressed that you have no existing insurance in place. You mentioned you would like advice based on your current situation and what you would want to happen should your health fail you restricted to areas specified in the Scope of Engagement.';
  }
}
