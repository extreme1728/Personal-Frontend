import { cloneDeep, find, isEmpty, castArray } from 'lodash';

export const recommendationSchema = {
  id: 0,
  name: null,
  category: null,
  reasons: null,
  comments: null,
  planner_id: null,
  description: null,
  insurance_plan_type: null,
  existing: [],
  proposed: [],
  underwriting: [],
  selections: ['item-recommendations'],
};

export const recommendationPolicySchema = {
  provider: null,
  cover_type: null,
  sum_assured: '0',
  premium: '0',
  notes: null,
  comments: null,
};

export const recommendationItemSchema = {
  name: null,
  offer_type: null,
  policy: cloneDeep(recommendationPolicySchema),
};

export default class RecommendationService {
  constructor(models = [], attributes = {}) {
    this.models = models; // Array from data component.
    this.item = attributes;
    this.isCreatedRecently = false;
  }

  build() {
    const { name, offer_type, policy } = this.item; // eslint-disable-line
    this.isCreatedRecently = isEmpty(find(this.models, { name, offer_type }));
    return this;
  }

  create() {
    const { name, offer_type, policy } = this.item; // eslint-disable-line

    // Initial Model.
    const model = {
      name,
      offer_type,
      policies: [], // Array of policy extracted from item object.
    };

    // Find instance from model.
    let instance = find(this.models, { name, offer_type });

    // Create or Update method.
    if (isEmpty(instance)) {
      model.policies = castArray(policy);
      instance = cloneDeep(model); // Copy from model.
    }
    else {
      const items = cloneDeep(this.models);
      instance = cloneDeep(instance);
      instance.policies = castArray(policy);
      instance = [...items.concat([instance])
        .reduce((r, o) => {
          r.has(o.name) || r.set(o.name, {}); // eslint-disable-line
          const item = r.get(o.name);
          Object.entries(o).forEach(([k, v]) => // eslint-disable-line
            item[k] = Array.isArray(item[k]) ? // eslint-disable-line operator-linebreak
              [...new Set([...item[k], ...v])] : v // eslint-disable-line
          ); // eslint-disable-line
          return r;
        }, new Map()).values()];
    }

    return instance;
  }

  get shouldPush() {
    return this.isCreatedRecently;
  }

  get values() {
    return this.item;
  }
}
