import { date } from 'quasar';
import { isEmpty, compact } from 'lodash';

export default class PmarTemplate {
  constructor(type, model, signatureData = null) {
    this.entity = type;
    this.store = model;
    this.signatureData = signatureData;
  }

  render() {
    const {
      now,
      name,
      address,
      signature,
      generalPractitioner,
    } = this;

    const template = [
      name,
      address,
      now,
      '\n\n',
      generalPractitioner,
      this.generalPractitionerMedicalCenter,
      this.generalPractitionerAddress,
      '\n\n',
      `Dear Dr.${generalPractitioner},`,
      '\n\n',
      `I am writing this letter as formal request for the copy of my full Private Medical Attendant's Report. The report is required for the insurance policies that I applied for. Please treat this request with urgency. You can send the copy of the report to our address: ${address}.`,
      '\n\n',
      'Thank you.',
      '\n\n',
      'Kind regards',
      '\n\n',
      signature,
      '<hr>',
      name,
    ];

    return compact(template).join('<br />').replace(/\n/g, '<br>');
  }

  get generalPractitionerMedicalCenter() {
    const { type, planner } = this;
    const prop = ['client'].includes(type)
      ? 'client_medical_name_general_practitioner_medical_center'
      : 'partner_medical_name_general_practitioner_medical_center';
    return planner[prop] || '[Your General Practitioner Medical Center]';
  }

  get generalPractitionerAddress() {
    const { type, planner } = this;
    const prop = ['client'].includes(type)
      ? 'client_medical_general_practitioner_address'
      : 'partner_medical_general_practitioner_address';
    return planner[prop] || '[Your General Practitioner Address]';
  }

  get generalPractitioner() {
    const { type, planner } = this;
    const prop = ['client'].includes(type)
      ? 'client_medical_usual_general_practitioner'
      : 'partner_medical_usual_general_practitioner';
    return planner[prop] || '[Your General Practitioner]';
  }

  get address() {
    const { type, planner } = this;
    const prop = ['client'].includes(type)
      ? 'client_address'
      : 'partner_address';
    return planner[prop] || '[Your Address]';
  }

  get name() {
    const { type, planner } = this;
    const prop = ['client'].includes(type)
      ? 'client_full_name'
      : 'partner_name';
    return planner[prop] || '[Your Name]';
  }

  get signature() {
    const { signatureData: data } = this;
    return isEmpty(data)
      ? null
      : `<img src="${data}" width="200" height="150"/>`;
  }

  get now() { // eslint-disable-line class-methods-use-this
    return date.formatDate(new Date(), 'Do of MMMM YYYY');
  }

  get planner() {
    return this.store;
  }

  get type() {
    return this.entity;
  }
}
