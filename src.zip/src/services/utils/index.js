import LogoData from './logo';

export { LogoData as default };
