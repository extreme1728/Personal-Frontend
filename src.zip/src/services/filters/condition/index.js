import eq from './eq';

export { eq }; // eslint-disable-line
