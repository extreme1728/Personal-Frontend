function toNumberFixed(value) {
  if (!value && value !== 0) return '';
  return window.parseFloat(value).toFixed(2);
}

export default toNumberFixed;
