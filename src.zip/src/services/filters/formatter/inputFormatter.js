import { isString, replace, startCase, trimEnd } from 'lodash';

function inputFormatter(value) {
  if (!isString(value)) return value;
  value = startCase(trimEnd(value));
  return replace(replace(value, /-/g, ' '), /_/g, ' ');
}

export default inputFormatter;
