import { toString } from 'lodash';
import { numberWithCommas } from 'src/config/utils';

function numberComma(value) {
  if (!value && value !== 0) return '';
  return toString(numberWithCommas(toString(value)));
}

export default numberComma;
