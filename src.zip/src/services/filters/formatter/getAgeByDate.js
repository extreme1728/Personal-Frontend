import moment from 'moment';
import { date } from 'quasar';

function getAgeByDate(value, by = 'years') {
  if (!date.isValid(value)) return null;
  value = moment().diff(moment(value), by);
  if (!value) return null;
  return value;
}

export default getAgeByDate;
