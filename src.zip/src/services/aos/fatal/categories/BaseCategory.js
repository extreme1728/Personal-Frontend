/* eslint-disable */
import { floatFixer } from 'src/config/utils';
import { get, minBy, maxBy, filter } from 'lodash';

export default class BaseCategory {
  constructor(income, annualPreAgreedCoverAmount) {
    this.setCurrentIncomeFromBusiness(income)
      .setAnnualPreAgreedCoverAmount(annualPreAgreedCoverAmount);
  }

  setChildrens(childrens = []) {
    this.arrayOfChildrens = childrens;

    return this;
  }

  /**
   * Get below children ages.
   *
   * @return array
   */
  getMinimumChildrenAge() {
    return get(minBy(this.getChildrens(), 'age'), 'age', 0);
  }

  /**
   * Get above children ages.
   *
   * @return array
   */
  getMaximumChildrenAge(childrens = []) {
    return get(maxBy(this.getChildrens(), 'age'), 'age', 0);
  }

  getChildrens() {
    return this.arrayOfChildrens;
  }

  getChildrensWhoIsStudying(studying = true) {
    return filter(this.getChildrens(), ['studying', studying]);
  }

  setCurrentIncomeFromBusiness(amount) {
    this.currentIncomeFromBusiness = amount;

    return this;
  }

  getCurrentIncomeFromBusiness() {
    return floatFixer(this.currentIncomeFromBusiness);
  }

  setAnnualPreAgreedCoverAmount(amount) {
    this.annualPreAgreedCoverAmount = amount;

    return this;
  }

  setFatalRates(fatalRate) {
    this.fatalRate = fatalRate;

    return this;
  }

  setRateValues(rateValues) {
    this.rateValues = rateValues;

    return this;
  }

  setComponent(component) {
    this.component = component;

    return this;
  }

  getComponent() {
    return this.component;
  }

  getLiableEarnings() {
    return floatFixer(this.getCurrentIncomeFromBusiness() * this.rateValues.liable_earning_rate);
  }

  getAnnualPreAgreedCoverAmount() {
    return floatFixer(this.annualPreAgreedCoverAmount);
  }

  getCoverPlusTotalBenifitAmount() {
    throw new Error('Method must be implemented');
  }

  getCoverPlusExtraTotalBenifitAmount() {
    throw new Error('Method must be implemented');
  }

  getChangesInCoverAmount() {
    throw new Error('Method must be implemented');
  }

  _getCoverPlusSpouseBenifitAmount() {
    return 0;
  }

  _getCoverPlusExtraSpouseBenifitAmount() {
    return 0;
  }

  getAll() {
    return {
      component: this.getComponent(),
      changesInCoverAmount: this.getChangesInCoverAmount(),
      coverPlusTotalBenifitAmount: this.getCoverPlusTotalBenifitAmount(),
      coverPlusTotalSpouseBenifitAmount: this._getCoverPlusSpouseBenifitAmount(),
      coverPlusExtraTotalBenifitAmount: this.getCoverPlusExtraTotalBenifitAmount(),
      coverPlusExtraTotalSpouseBenifitAmount: this._getCoverPlusExtraSpouseBenifitAmount(),
    };
  }
}
