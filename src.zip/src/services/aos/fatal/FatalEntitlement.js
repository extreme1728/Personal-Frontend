/* eslint-disable */
import { upperFirst, camelCase } from 'lodash';
import NoChild from 'src/services/aos/fatal/categories/NoChild';
import StudyingChildren from 'src/services/aos/fatal/categories/StudyingChildren';
import LessThanTwoChildren from 'src/services/aos/fatal/categories/LessThanTwoChildren';
import GreaterThanTwoChildren from 'src/services/aos/fatal/categories/GreaterThanTwoChildren';

const classes = {
  NoChild,
  LessThanTwoChildren,
  GreaterThanTwoChildren,
  StudyingChildren,
};

class FatalEntitlement {
  constructor(income, annualPreAgreedCoverAmount, category, childrens = [], fatalRate, rateValues) {
    this.childrens = childrens;
    this.currentIncomeFromBusiness = income;
    this.annualPreAgreedCoverAmount = annualPreAgreedCoverAmount;
    this.currentCategory = category;
    this.fatalRate = fatalRate;
    this.rateValues = rateValues;
  }

  handle() {
    const type = upperFirst(camelCase(this.currentCategory));

    if (!type) return;

    const ClassInstance = (new classes[type](this.currentIncomeFromBusiness, this.annualPreAgreedCoverAmount));

    return ClassInstance
      .setChildrens(this.childrens)
      .setFatalRates(this.fatalRate)
      .setRateValues(this.rateValues)
      .setComponent(type)
      .getAll();
  }
}

export default FatalEntitlement;
