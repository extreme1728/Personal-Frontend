import Fidelity from './Fidelity';

export default class Aia extends Fidelity {
  constructor(income, mortgageAmount = 0) {
    super(income, mortgageAmount, 0);
  }
}
