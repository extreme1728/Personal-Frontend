import { floatFixer, floatTotals, floatDiff } from 'src/config/utils';
import AccOffset from 'src/services/aos/offset/AccOffset';
import { map, isNull, merge } from 'lodash';

export default class PassiveIncome extends AccOffset {
  setArrayOfPassiveIncomes(incomes) {
    this.totalPassiveIncome = floatTotals(map(incomes, (n) => {
      if (!isNull(n)) return floatFixer(n);
      return floatFixer(0);
    }));

    return this;
  }

  getTotalPassiveIncome() {
    return floatFixer(this.totalPassiveIncome);
  }

  setTaxRateIncome(income) {
    this.taxRateIncome = income;

    return this;
  }

  getTaxRateIncome() {
    return this.taxRateIncome;
  }

  getIncomeProtectionIndemnityAmount() {
    // eslint-disable-next-line
    return floatDiff(floatFixer(this.getCurrentIncomeFromBusiness() * this.getTaxRateIncome().income_protection_indemnity), this.getTotalPassiveIncome());
  }

  getIncomeProtectionAgreedAmount() {
    // eslint-disable-next-line
    return floatDiff(floatFixer(this.getCurrentIncomeFromBusiness() * this.getTaxRateIncome().income_protection_agreed), this.getTotalPassiveIncome());
  }

  getAll() {
    return merge(super.getAll(), {
      incomeProtectionIndemnityAmount: this.getIncomeProtectionIndemnityAmount(),
      incomeProtectionAgreedAmount: this.getIncomeProtectionAgreedAmount(),
      totalPassiveIncome: this.getTotalPassiveIncome(),
    });
  }
}
