import store from 'src/store';
import { every, isEmpty } from 'lodash';

export default ({ router }) => {
  router.beforeEach((to, from, next) => {
    if (to.matched.some(record => record.meta.requiresAuth)) {
      const userTokenData = store.getters['user/currentTokenDataUser'];
      const userModel = store.getters['user/currentUserModel'];
      if (every(userTokenData, isEmpty) && every(userModel, isEmpty)) {
        next({
          path: '/auth',
          query: {
            redirect: to.fullPath,
          },
        });
      }
      else {
        next();
      }
    }
    else {
      next();
    }
  });
};
