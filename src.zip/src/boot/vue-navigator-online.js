import VueOnlinePlugin from 'vue-navigator-online';

export default ({ Vue }) => {
  Vue.use(VueOnlinePlugin);
};
